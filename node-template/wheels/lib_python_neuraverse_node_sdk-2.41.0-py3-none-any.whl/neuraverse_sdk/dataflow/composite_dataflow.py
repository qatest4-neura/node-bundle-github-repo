from typing import Any, Optional

from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    DataFlowCommunicationType,
    DataFlowNodeEntry,
    InputConnection,
    OutputConnection,
)
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.dataflow.mqtt_dataflow_adapter import MQTTDataFlowAdapter
from neuraverse_sdk.dataflow.ros_dataflow_adapter import ROSDataFlowAdapter
from neuraverse_sdk.dataflow.zenoh_dataflow_adapter import ZenohDataFlowAdapter
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.utils.exceptions import DataFlowException

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.dataflow.composite_dataflow"
)

_MQTT = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_MQTT
_ROS = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ROS
_ZENOH = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ZENOH
_UNSPECIFIED = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_UNSPECIFIED

# Every transport this composite can route to. Previously ROS and MQTT were
# hardcoded as two named attributes, which silently dropped Zenoh ports: a port
# the engine had resolved to Zenoh fell through `_adapter_for` to the ROS
# adapter, and `_split_entry` filed it under ROS as well. Zenoh graphs could
# therefore never work through the composite, only through a single-adapter
# node. Keeping this as a set means the next transport is a one-line change.
_SUPPORTED = (_ROS, _MQTT, _ZENOH)

# Fallback for ports the engine left UNSPECIFIED. The engine normally resolves
# every port explicitly (FlowConfigurator), so this only covers hand-written or
# legacy graph entries — it stays MQTT so those keep behaving as they did.
_DEFAULT_COMM_TYPE = _MQTT

_NAMES = {_ROS: "ROS", _MQTT: "MQTT", _ZENOH: "Zenoh"}


def _name(comm_type: DataFlowCommunicationType) -> str:
    """Readable transport name for log lines."""
    return _NAMES.get(comm_type, str(comm_type))


class CompositeDataFlow(IDataFlow):
    """Routes each port to the correct adapter(s) — ROS, MQTT and/or Zenoh — based on
    the communicationTypes the engine resolved for it."""

    def __init__(self, service_config: NodeServiceConfig):
        super().__init__()
        self._service_config = service_config
        # comm type -> adapter, created lazily per configure() for the transports
        # this node's graph entry actually uses.
        self._adapters: dict[DataFlowCommunicationType, IDataFlow] = {}
        # Output ports may fan out to multiple adapters
        self._output_routing: dict[str, list[IDataFlow]] = {}
        # Input ports are always served by a single adapter
        self._input_routing: dict[str, IDataFlow] = {}

    def init(self, config):
        pass

    @property
    def ros_node(self):
        """Underlying rclpy node, so ``NodeBase.get_ros_node()`` works for the composite dataflow.

        ``get_ros_node()`` checks ``hasattr(self.data_flow, "ros_node")``; without this property
        it always returned ``None`` for composite-backed nodes, so any node attaching its own ROS
        subscriptions (e.g. a recorder capturing extra topics) silently got no node. Returns the
        ROS adapter's node when ROS ports exist, else ``None``.

        Note this stays tied to the ROS adapter specifically: it exposes an
        rclpy node, which no other transport has. A node on a Zenoh-only graph
        gets ``None`` here, exactly as an MQTT-only node always did.
        """
        ros_adapter = self._adapters.get(_ROS)
        return ros_adapter.ros_node if ros_adapter else None

    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        entries = self._split_entry(node_data_flow_entry)

        # Destroy any prior adapters before replacing them. Without this
        # a second configure() leaks the previous adapter's MQTT
        # connect-ref (and any active subscriptions) — the new adapter
        # opens a fresh ref so the singleton refcount drifts past what
        # this composite legitimately holds, and future destroy() calls
        # don't actually release the broker connection. See
        # [[160-reconfigure-lifecycle.md]]. The same applies to Zenoh, whose
        # session handler is likewise refcounted.
        for comm_type, adapter in self._adapters.items():
            self._destroy_adapter(comm_type, adapter, "on reconfigure")
        self._adapters.clear()
        self._output_routing.clear()
        self._input_routing.clear()

        for comm_type in _SUPPORTED:
            entry = entries[comm_type]
            if not entry.outputPorts and not entry.inputPorts:
                continue
            adapter = self._create_adapter(comm_type, entry)
            if adapter is not None:
                self._adapters[comm_type] = adapter

        # Build output routing — an output may need to publish on multiple adapters
        for port_name, output_conn in node_data_flow_entry.outputPorts.items():
            adapters: list[IDataFlow] = []
            for comm_type in self._output_comm_types(output_conn):
                adapter = self._adapter_for(comm_type)
                if adapter and adapter not in adapters:
                    adapters.append(adapter)
            self._output_routing[port_name] = adapters

        # Build input routing — each input is served by exactly one adapter
        for port_name, input_conn in node_data_flow_entry.inputPorts.items():
            adapter = self._adapter_for(self._input_comm_type(input_conn))
            if adapter is not None:
                self._input_routing[port_name] = adapter

    def destroy(self) -> None:
        for comm_type, adapter in self._adapters.items():
            self._destroy_adapter(comm_type, adapter, "")

    def publish(self, target: Any, message: Any, meta_data: Any = None) -> None:
        adapters = self._output_routing.get(target)
        if not adapters:
            raise DataFlowException(f"Unknown output target: {target}")
        for adapter in adapters:
            adapter.publish(target, message, meta_data)

    def get_data(self, placeholder: str, timeout: Optional[float] = 1) -> Any:
        adapter = self._input_routing.get(placeholder)
        if adapter is None:
            LOGGER.debug(f"No adapter routed for input '{placeholder}'")
            return None
        return adapter.get_data(placeholder, timeout)

    def wait_for_message(
        self, subscription: Any, timeout: float = -1.0
    ) -> tuple[bool, Any]:
        adapter = self._input_routing.get(subscription)
        if adapter is None:
            raise DataFlowException(f"Unknown input subscription: {subscription}")
        return adapter.wait_for_message(subscription, timeout)

    def get_connected_ports(self) -> dict[str, bool]:
        return self._merge("get_connected_ports")

    def get_input_topics(self) -> dict[str, dict]:
        return self._merge("get_input_topics")

    def get_output_topics(self) -> dict[str, dict]:
        return self._merge("get_output_topics")

    def handle_message(self, input_name: str, msg: Any, topic_info: dict[str, Any]):
        pass

    def register_handler(self, callback, input_name: str = ""):
        if input_name:
            adapter = self._input_routing.get(input_name)
            if adapter:
                adapter.message_handlers[input_name] = callback
        else:
            for adapter in self._adapters.values():
                adapter.handle_message = callback

    # --- Private helpers ---

    def _merge(self, method_name: str) -> dict:
        """Union of ``method_name()`` across every live adapter."""
        result: dict = {}
        for adapter in self._adapters.values():
            result.update(getattr(adapter, method_name)())
        return result

    def _adapter_for(self, comm_type: DataFlowCommunicationType) -> IDataFlow | None:
        """The adapter serving this transport, or None when the graph entry
        declared no port on it.

        This used to fall through to the ROS adapter for anything that was not
        MQTT, which is how Zenoh ports silently became ROS ports.
        """
        return self._adapters.get(comm_type)

    def _create_adapter(
        self, comm_type: DataFlowCommunicationType, entry: DataFlowNodeEntry
    ) -> IDataFlow | None:
        """Build, init and configure one adapter for this transport.

        ``configure()`` is inside the guard, not just construction: every
        adapter's ``init()`` merely stores the config and it is ``configure()``
        that opens the ROS node, the broker connection or the Zenoh session. A
        router that is down therefore raises from there, and catching only the
        constructor would leave the node dying on an unreachable transport.

        Constructed from the classes imported above rather than through
        ``dataflow_factory.create_data_flow_adapter``: that would be a circular
        import (the factory imports this module), and the whole spec suite
        patches these names on this module to swap in fakes.
        """
        adapter: IDataFlow | None = None
        try:
            if comm_type == _ROS:
                adapter = ROSDataFlowAdapter()
                adapter.init({})
            elif comm_type == _MQTT:
                adapter = MQTTDataFlowAdapter()
                adapter.init(self._service_config.mqtt)
            elif comm_type == _ZENOH:
                adapter = ZenohDataFlowAdapter()
                adapter.init(self._service_config.zenoh)
            else:
                raise DataFlowException(
                    f"No adapter for communication type {comm_type}"
                )
            adapter.configure(entry)
            return adapter
        except Exception as exc:
            # One unreachable transport must not take the whole node down: the
            # ports on the other transports are still serviceable, and the
            # unroutable ports simply report as not connected.
            LOGGER.error(
                "Could not bring up the %s dataflow adapter: %s; ports on that "
                "transport will be unavailable",
                _name(comm_type),
                exc,
            )
            # configure() may have got far enough to take an MQTT connect
            # reference before it raised; dropping the adapter without a
            # destroy() is the refcount leak [[160-reconfigure-lifecycle.md]]
            # describes.
            self._destroy_adapter(comm_type, adapter, "after a failed configure")
            return None

    @staticmethod
    def _destroy_adapter(
        comm_type: DataFlowCommunicationType,
        adapter: IDataFlow | None,
        when: str,
    ) -> None:
        """Destroy one adapter without ever raising at the caller."""
        if adapter is None:
            return
        try:
            adapter.destroy()
        except Exception as exc:
            LOGGER.warning(
                "%s adapter destroy %sfailed: %s",
                _name(comm_type),
                f"{when} " if when else "",
                exc,
            )

    @staticmethod
    def _output_comm_types(
        output_conn: OutputConnection,
    ) -> list[DataFlowCommunicationType]:
        comm_types = [c for c in output_conn.communicationTypes if c in _SUPPORTED]
        return comm_types or [_DEFAULT_COMM_TYPE]

    @staticmethod
    def _input_comm_type(
        input_conn: InputConnection,
    ) -> DataFlowCommunicationType:
        comm_type = input_conn.communicationType
        if comm_type == _UNSPECIFIED or comm_type not in _SUPPORTED:
            return _DEFAULT_COMM_TYPE
        return comm_type

    @staticmethod
    def _split_entry(
        entry: DataFlowNodeEntry,
    ) -> dict[DataFlowCommunicationType, DataFlowNodeEntry]:
        """Split a DataFlowNodeEntry into one sub-entry per transport.

        An output port listing several communicationTypes appears in each of
        those sub-entries — that is the fan-out case, e.g. a port feeding both a
        same-host peer and a node on another host.
        """
        outputs: dict[DataFlowCommunicationType, dict[str, OutputConnection]] = {
            c: {} for c in _SUPPORTED
        }
        inputs: dict[DataFlowCommunicationType, dict[str, InputConnection]] = {
            c: {} for c in _SUPPORTED
        }

        for name, output_conn in entry.outputPorts.items():
            for comm_type in CompositeDataFlow._output_comm_types(output_conn):
                outputs[comm_type][name] = output_conn

        for name, input_conn in entry.inputPorts.items():
            inputs[CompositeDataFlow._input_comm_type(input_conn)][name] = input_conn

        return {
            comm_type: DataFlowNodeEntry(
                id=entry.id,
                name=entry.name,
                outputPorts=outputs[comm_type],
                inputPorts=inputs[comm_type],
            )
            for comm_type in _SUPPORTED
        }

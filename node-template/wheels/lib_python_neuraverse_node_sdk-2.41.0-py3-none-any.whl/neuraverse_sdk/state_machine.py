import queue
import threading
from abc import ABC, abstractmethod

from neuraverse.models.v1.gen.business.node_graph_pb2 import ExecutionState
from neuraverse_common.observability.logging import LoggerFactory

from neuraverse_sdk.utils.exceptions import NodeStateError

logger = LoggerFactory.get_logger("neuraverse-node-sdk.state_machine")


class StateMachine:
    _state = None

    def __init__(self, state):
        self._state = state
        self._state.state_machine = self
        self.state_queue = None
        self.node_id = ""
        self._lock = threading.RLock()

    def get_state(self) -> ExecutionState:
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            return self._state.get_state()

    def send_status_message(
        self,
        state_from: ExecutionState,
        state_to: ExecutionState,
        node_id: str,
        message: str = None,
    ):
        """Create a status message for streaming. Caller must hold self._lock."""
        result_msg = f"State of node with ID {self.node_id} changed from {ExecutionState.Name(state_from)} to {ExecutionState.Name(state_to)}"
        if message:
            result_msg += f" | Message: {message}"
        result_dict = {
            "nodeId": node_id,
            "state": state_to,
            "resultCode": 0 if state_to != ExecutionState.EXECUTION_STATE_ERROR else 1,
            "resultMessage": result_msg,
        }
        if self.state_queue:
            try:
                self.state_queue.put_nowait(
                    result_dict
                )  # Non-blocking to avoid delaying transitions
            except queue.Full:
                logger.warning(
                    "Status queue full; dropping update for node %s", node_id
                )
        else:
            logger.debug(
                "Status queue not initialized; skipping send for node %s", node_id
            )

    def end_status_stream(self):
        with self._lock:
            if self.state_queue:
                self.state_queue.put_nowait(None)
                self.state_queue = None

    def transition_to(self, state, message: str = None):
        """
        The StateMachine allows changing the State object at runtime.
        """
        with self._lock:
            previous_state = self._state.get_state() if self._state else None
            log_msg = f"State Machine: Transition of node {self.node_id} from {ExecutionState.Name(previous_state)} to {ExecutionState.Name(state.get_state())}"
            if message:
                log_msg += f" | Message: {message}"
            logger.info(f"{log_msg}")
            self._state = state
            self._state.state_machine = self
            self.send_status_message(
                previous_state, self._state.get_state(), self.node_id, message
            )

    def initialize(self, state_queue, node_id):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")

            self.state_queue = state_queue
            self.node_id = node_id

            self._state.initialize()

    def configure(self):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            self._state.configure()

    def execute(self):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            self._state.execute()

    def pause(self) -> bool:
        """Pause the node. True when this call is what paused it."""
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            return self._state.pause()

    def resume(self) -> bool:
        """Resume the node. True when this call is what un-paused it."""
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            return self._state.resume()

    def stop(self):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            self._state.stop()

    def error(self, error_message: str = None):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            self._state.error(error_message=error_message)

    def reset(self):
        with self._lock:
            if self._state is None:
                raise NodeStateError("State Machine is not initialized")
            self._state.reset()


class State(ABC):
    """
    The base State class declares methods that all Concrete State should
    implement and also provides a backreference to the StateMachine object,
    associated with the State. This backreference can be used by States to
    transition the StateMachine to another State.
    """

    @property
    def state_machine(self) -> StateMachine:
        return self.__state_machine

    @state_machine.setter
    def state_machine(self, state_machine: StateMachine) -> None:
        self.__state_machine = state_machine

    @abstractmethod
    def initialize(self) -> None:
        pass

    @abstractmethod
    def configure(self) -> None:
        pass

    @abstractmethod
    def execute(self) -> None:
        pass

    @abstractmethod
    def pause(self) -> bool:
        """Return True only when this call moved the node into PAUSED."""

    @abstractmethod
    def resume(self) -> bool:
        """Return True only when this call moved the node out of PAUSED."""

    @abstractmethod
    def stop(self) -> None:
        pass

    @abstractmethod
    def error(self, error_message: str = None) -> None:
        pass

    @abstractmethod
    def reset(self) -> None:
        pass

    @abstractmethod
    def get_state(self) -> ExecutionState:
        pass


class IdleState(State):
    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_IDLE

    def initialize(self) -> None:
        logger.info("State Machine: IdleState: Already in IdleState")

    def configure(self) -> None:
        self.state_machine.transition_to(ConfiguredState())

    def execute(self) -> None:
        raise NodeStateError("Cannot execute node. Current state is IdleState")

    def pause(self) -> bool:
        logger.info("State Machine: IdleState: Nothing to pause")
        return False

    def resume(self) -> bool:
        logger.info("State Machine: IdleState: Nothing to resume")
        return False

    def stop(self) -> None:
        logger.info("State Machine: IdleState: Already in IdleState")

    def error(self, error_message) -> None:
        self.state_machine.transition_to(ErrorState(), error_message)

    def reset(self) -> None:
        raise NodeStateError("Cannot reset error. Current state is IdleState")


class ConfiguredState(State):
    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_CONFIGURED

    def initialize(self) -> None:
        pass

    def configure(self) -> None:
        pass

    def execute(self) -> None:
        self.state_machine.transition_to(RunningState())

    def pause(self) -> bool:
        # A node waiting between triggers is still part of a live program, so
        # pause is legal here and returns to CONFIGURED on resume.
        self.state_machine.transition_to(PausedState(ConfiguredState()))
        return True

    def resume(self) -> bool:
        logger.info("State Machine: ConfiguredState: Not paused, nothing to resume")
        return False

    def stop(self) -> None:
        self.state_machine.transition_to(StoppedState())
        self.state_machine.end_status_stream()

    def error(self, error_message) -> None:
        self.state_machine.transition_to(ErrorState(), error_message)

    def reset(self) -> None:
        raise NodeStateError(
            "Cannot reset error in node. Current state is ConfiguredState"
        )


class RunningState(State):
    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_RUNNING

    def initialize(self) -> None:
        raise NodeStateError("Cannot initialize node. Current state is RunningState")

    def configure(self) -> None:
        self.state_machine.transition_to(ConfiguredState())

    def execute(self) -> None:
        pass

    def pause(self) -> bool:
        self.state_machine.transition_to(PausedState(RunningState()))
        return True

    def resume(self) -> bool:
        return False  # Already running

    def stop(self) -> None:
        self.state_machine.transition_to(StoppedState())
        self.state_machine.end_status_stream()

    def error(self, error_message) -> None:
        self.state_machine.transition_to(ErrorState(), error_message)

    def reset(self) -> None:
        raise NodeStateError(
            "Cannot reset error in node. Current state is RunningState"
        )


class PausedState(State):
    """Paused holds a remembered state so nothing can silently un-pause.

    Pause is cooperative: the SDK suspends no work of its own, so an execute
    or a configure arriving while paused must update where resume() lands
    without leaving PausedState.
    """

    def __init__(self, resume_state: "State" = None):
        self._resume_state = resume_state if resume_state is not None else ConfiguredState()

    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_PAUSED

    def initialize(self) -> None:
        raise NodeStateError("Cannot initialize node. Current state is PausedState")

    def configure(self) -> None:
        # A blocking on_execute returning while paused ends up here; stay
        # paused and land on CONFIGURED once resumed.
        self._resume_state = ConfiguredState()

    def execute(self) -> None:
        # Triggers are not gated, so on_execute still runs. Staying paused is
        # what keeps is_paused() true for the node's own guard.
        self._resume_state = RunningState()

    def pause(self) -> bool:
        return False

    def resume(self) -> bool:
        self.state_machine.transition_to(self._resume_state)
        return True

    def stop(self) -> None:
        self.state_machine.transition_to(StoppedState())
        self.state_machine.end_status_stream()

    def error(self, error_message) -> None:
        self.state_machine.transition_to(ErrorState(), error_message)

    def reset(self) -> None:
        raise NodeStateError("Cannot reset error in node. Current state is PausedState")


class StoppedState(State):
    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_STOPPED

    def initialize(self) -> None:
        self.state_machine.transition_to(IdleState())

    def configure(self) -> None:
        self.state_machine.transition_to(ConfiguredState())

    def execute(self) -> None:
        self.state_machine.transition_to(RunningState())

    def pause(self) -> bool:
        logger.info("State Machine: StoppedState: Nothing to pause")
        return False

    def resume(self) -> bool:
        logger.info("State Machine: StoppedState: Nothing to resume")
        return False

    def stop(self) -> None:
        pass

    def error(self, error_message) -> None:
        self.state_machine.transition_to(ErrorState(), error_message)

    def reset(self) -> None:
        raise NodeStateError(
            "Cannot reset error in node. Current state is StoppedState"
        )


class ErrorState(State):
    def get_state(self) -> ExecutionState:
        return ExecutionState.EXECUTION_STATE_ERROR

    def initialize(self) -> None:
        # raise NodeStateError(
        #     "Cannot initialize node. Current state is ErrorState, Reset Error First Before Initializing"
        # )
        self.state_machine.transition_to(IdleState())

    def configure(self) -> None:
        # raise NodeStateError(
        #     "Cannot configure node. Current state is ErrorState, Reset Error First Before Configuring"
        # )
        logger.info("Node configured successfully. In ErrorState")
        self.state_machine.transition_to(ConfiguredState())

    def execute(self) -> None:
        raise NodeStateError(
            "Cannot execute node. Current state is ErrorState, Reset Error First Before Executing"
        )

    def pause(self) -> bool:
        logger.info("State Machine: ErrorState: Nothing to pause")
        return False

    def resume(self) -> bool:
        logger.info("State Machine: ErrorState: Nothing to resume")
        return False

    def stop(self) -> None:
        self.state_machine.transition_to(StoppedState())
        self.state_machine.end_status_stream()

    def error(self, error_message) -> None:
        if error_message:
            logger.error(
                f"Node already in ErrorState. Additional error: {error_message}"
            )
        pass

    def reset(self) -> None:
        self.state_machine.transition_to(IdleState())  # TODO: reset to previous state

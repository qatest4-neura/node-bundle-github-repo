import re
import threading
from typing import Dict

from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.api.consul.clients.service_registry_api import ServiceRegistryClient
from neuraverse_sdk.utils.exceptions import InvalidEndpointError, NodeRegisteryError

LOGGER: Logger = LoggerFactory.get_logger("service.controllers.service_registry_repository")

# Registration is a per-service resource, but repositories are created per
# node instance — and instances churn on every graph stop→re-init cycle.
# Sharing one client (one Consul HTTP session + one ConsulHealthCheck
# monitor thread) per (endpoint, token) keeps the connection count flat;
# per-instance clients accumulated until Consul's per-IP
# http_max_conns_per_client limit turned every call into a 429 (NRV-10272).
_shared_clients: dict[tuple[str, str | None], ServiceRegistryClient] = {}
_shared_clients_lock = threading.Lock()


def _get_shared_client(
    endpoint: str,
    token=None,
    registration_timeout_s: float | None = None,
    registration_retry_delay_s: float | None = None,
) -> ServiceRegistryClient:
    """Return the process-wide ServiceRegistryClient for (endpoint, token).

    The retry settings apply to the client the first caller creates; later
    callers for the same (endpoint, token) reuse it and its settings, since
    the retry budget only matters for the first (bootstrap) registration.
    """
    key = (endpoint, token)
    with _shared_clients_lock:
        client = _shared_clients.get(key)
        if client is None:
            client = ServiceRegistryClient(
                endpoint,
                token,
                registration_timeout_s=registration_timeout_s,
                registration_retry_delay_s=registration_retry_delay_s,
            )
            _shared_clients[key] = client
        return client


def _reset_shared_clients() -> None:
    """Test hook: stop all monitor threads and clear the client cache."""
    with _shared_clients_lock:
        for client in _shared_clients.values():
            stop = getattr(client, "stop_monitoring", None)
            if callable(stop):
                stop()
        _shared_clients.clear()


class ServiceRegistryRepository:
    def __init__(
        self,
        service_registry_endpoint: str,
        token=None,
        registration_timeout_s: float | None = None,
        registration_retry_delay_s: float | None = None,
    ):
        """Initialize the Python nodes instantiator."""
        super().__init__()
        self.service_registry_client: ServiceRegistryClient = _get_shared_client(
            service_registry_endpoint,
            token,
            registration_timeout_s=registration_timeout_s,
            registration_retry_delay_s=registration_retry_delay_s,
        )

    def register_node(
        self,
        node_endpoint: str,
        capability_name: str,
        node_configurations,
        namespace: str = "",
        schema_envelope=None,
    ):
        """
        Register the nodes in service registry.
        #TODO: Error handling
        """
        try:
            if self._is_valid_target_request(node_endpoint):
                self.service_registry_client.register_node(
                    node_endpoint=node_endpoint,
                    capability_name=capability_name,
                    node_configurations=node_configurations,
                    namespace=namespace,
                    schema_envelope=schema_envelope,
                )
            else:
                raise NodeRegisteryError(f"Invalid endpoint: {node_endpoint}")
        except Exception as e:
            LOGGER.error(f"Failed to register node: {node_endpoint}", exc_info=e)
            raise NodeRegisteryError(str(e))

    def stop_monitoring(self):
        """Stop the Consul health check monitoring.

        The client is shared per (endpoint, token): this stops monitoring for
        every registration made through that client, not just this
        repository's. Tests-only — production keeps the monitor alive for the
        process lifetime.
        """
        if hasattr(self.service_registry_client, "stop_monitoring"):
            self.service_registry_client.stop_monitoring()

    def _is_valid_target_request(self, s: str) -> bool:
        """Check if the target is a valid url."""
        pattern = re.compile(
            # r'^(https?://)'          # Must start with http:// or https://
            r"([a-zA-Z0-9.-]+)"  # Domain
            r"(:\d+)?"  # Optional port
            r"(/.*)?$"  # Optional path
        )
        return bool(pattern.match(s))

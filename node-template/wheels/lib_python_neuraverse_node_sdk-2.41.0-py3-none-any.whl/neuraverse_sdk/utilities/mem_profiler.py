"""Generic per-node memory-leak profiler."""

import argparse
import csv
import gc
import glob
import importlib
import json
import os
import sys
import time
from typing import Any


DEFAULT_WARMUP_CYCLES: int = 5
DEFAULT_MAX_RSS_GROWTH_KB: int = 20_000  # ~20 MiB across the window => fail
DEFAULT_MAX_THREAD_GROWTH: int = 3
DEFAULT_SETTLE_SECONDS: float = 0.3


def _bootstrap_and_reexec() -> None:
    """Re-exec under a sourced ROS shell if the ROS env is not already active.

    Replaces the manual:
        source /opt/ros/humble/setup.bash
        export PYTHONPATH=/neuraverse-node/src:$PYTHONPATH
        export ROS_DOMAIN_ID=99

    Paths are overridable via env vars so this stays generic across node images:
        NEURAVERSE_PROFILER_ROS_SETUP   (default /opt/ros/humble/setup.bash)
        NEURAVERSE_PROFILER_SRC         (default /neuraverse-node/src)
        NEURAVERSE_PROFILER_VENV_GLOB   (default the poetry venv python glob)

    Called from main() (NOT at import time) so importing this module is side-effect-free.
    """
    if "AMENT_PREFIX_PATH" in os.environ:
        return  # already inside a sourced ROS env — no-op
    ros_setup = os.environ.get(
        "NEURAVERSE_PROFILER_ROS_SETUP", "/opt/ros/humble/setup.bash"
    )
    if not os.path.exists(ros_setup):
        return  # not a ROS container — let rclpy import fail naturally later
    src_path = os.environ.get("NEURAVERSE_PROFILER_SRC", "/neuraverse-node/src")
    venv_glob = os.environ.get(
        "NEURAVERSE_PROFILER_VENV_GLOB",
        "/root/.cache/pypoetry/virtualenvs/*/bin/python",
    )
    venvs = sorted(glob.glob(venv_glob))
    python = venvs[0] if venvs else sys.executable
    argv_shell = " ".join(repr(a) for a in sys.argv)
    cmd = (
        f"source {ros_setup} && "
        f"export PYTHONPATH={src_path}:${{PYTHONPATH:-}} && "
        "export ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-99} && "
        f"exec {python} {argv_shell}"
    )
    os.execvp("bash", ["bash", "-c", cmd])


def _sample_proc() -> tuple[int, int]:
    """Return (VmRSS in kB, thread count) for THIS process from /proc/self/status."""
    rss_kb = 0
    threads = 0
    with open("/proc/self/status") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                rss_kb = int(line.split()[1])
            elif line.startswith("Threads:"):
                threads = int(line.split()[1])
    return rss_kb, threads


def run_cycles(
    module_name: str,
    class_name: str,
    config: dict[str, Any],
    cycles: int,
    settle: float,
) -> list[tuple[int, int, int]]:
    """Run `cycles` configure->stop cycles against module_name.class_name"""

    module = importlib.import_module(module_name)
    node_cls = getattr(module, class_name)

    samples: list[tuple[int, int, int]] = []
    for i in range(cycles):
        node = node_cls()
        node.on_configure(config)
        time.sleep(settle)
        node.on_stop()
        gc.collect()
        rss_kb, threads = _sample_proc()
        samples.append((i, rss_kb, threads))
        print(f"cycle {i:3d}  rss={rss_kb / 1024:8.1f} MiB  threads={threads}")
    return samples


def evaluate(
    samples: list[tuple[int, int, int]],
    warmup: int,
    max_rss_growth_kb: int,
    max_thread_growth: int,
) -> int:
    """Compare warmup baseline vs final sample; return process exit code (0 = ok)."""
    if len(samples) <= warmup:
        print(f"ERROR: need more than {warmup} cycles to evaluate", file=sys.stderr)
        return 2

    _, base_rss, base_threads = samples[warmup]
    _, last_rss, last_threads = samples[-1]
    rss_growth = last_rss - base_rss
    thread_growth = last_threads - base_threads

    print(
        f"\nbaseline(cycle {warmup}): rss={base_rss / 1024:.1f} MiB threads={base_threads}\n"
        f"final   (cycle {samples[-1][0]}): rss={last_rss / 1024:.1f} MiB threads={last_threads}\n"
        f"growth: rss=+{rss_growth / 1024:.1f} MiB (limit {max_rss_growth_kb / 1024:.1f}) "
        f"threads=+{thread_growth} (limit {max_thread_growth})"
    )

    failed = rss_growth > max_rss_growth_kb or thread_growth > max_thread_growth
    print("RESULT:", "FAIL - possible leak regression" if failed else "PASS - flat")
    return 1 if failed else 0


def _load_config(path: str | None) -> dict[str, Any]:
    """Load the on_configure dict from a JSON file (or {} if none given)."""
    if not path:
        return {}
    with open(path) as f:
        data: dict[str, Any] = json.load(f)
    return data


def main() -> int:
    _bootstrap_and_reexec()  # re-exec into a sourced ROS env if needed (no-op if already set)

    parser = argparse.ArgumentParser(description="NRV-7920 generic per-node memory profiler")
    parser.add_argument("--module", default=None,
                        help="node module import path, e.g. camera_node.camera_node")
    parser.add_argument("--node-class", default=None, help="node class, e.g. CameraNode")
    parser.add_argument("--config-json", default=None,
                        help="path to JSON file with the on_configure config dict")
    parser.add_argument("--cycles", type=int, default=30)
    parser.add_argument("--warmup", type=int, default=DEFAULT_WARMUP_CYCLES)
    parser.add_argument("--settle", type=float, default=DEFAULT_SETTLE_SECONDS)
    parser.add_argument("--max-rss-growth-kb", type=int, default=DEFAULT_MAX_RSS_GROWTH_KB)
    parser.add_argument("--max-thread-growth", type=int, default=DEFAULT_MAX_THREAD_GROWTH)
    parser.add_argument("--csv", default="profile_cycles.csv")
    args = parser.parse_args()

    config = _load_config(args.config_json)
    module_name = args.module or config.pop("_module", None)
    class_name = args.node_class or config.pop("_class", None)
    if not module_name or not class_name:
        parser.error(
            "--module and --node-class are required "
            "(pass on CLI or add _module/_class to --config-json)"
        )
    samples = run_cycles(module_name, class_name, config, args.cycles, args.settle)

    with open(args.csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["cycle", "rss_kb", "threads"])
        writer.writerows(samples)
    print(f"\ntrend written to {args.csv}")

    return evaluate(samples, args.warmup, args.max_rss_growth_kb, args.max_thread_growth)


if __name__ == "__main__":
    raise SystemExit(main())

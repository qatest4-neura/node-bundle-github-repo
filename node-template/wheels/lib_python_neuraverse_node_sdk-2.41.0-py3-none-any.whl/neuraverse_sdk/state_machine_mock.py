"""
Mock state machine that emits random status updates for triangulation testing.
Enable via NEURAVERSE_SDK_MOCK_STATUS=1 (or TRUE/YES).
"""

import os
import queue
import random
import threading

from neuraverse.models.v1.gen.business.node_graph_pb2 import ExecutionState
from neuraverse_common.observability.logging import LoggerFactory

from neuraverse_sdk.state_machine import State, StateMachine
from neuraverse_sdk.utils.exceptions import NodeStateError

logger = LoggerFactory.get_logger("neuraverse-node-sdk.state_machine_mock")

# States used for random transitions (optionally include ERROR with low probability)
_MOCK_RANDOM_STATES = [
    ExecutionState.EXECUTION_STATE_IDLE,
    ExecutionState.EXECUTION_STATE_CONFIGURED,
    ExecutionState.EXECUTION_STATE_RUNNING,
    ExecutionState.EXECUTION_STATE_PAUSED,
    ExecutionState.EXECUTION_STATE_STOPPED,
]


class _MockState(State):
    """State that returns the mock state machine's current state."""

    def get_state(self) -> ExecutionState:
        sm = self.state_machine
        if isinstance(sm, MockRandomStateMachine):
            return sm._current_state
        return ExecutionState.EXECUTION_STATE_IDLE

    def initialize(self) -> None:
        pass

    def configure(self) -> None:
        pass

    def execute(self) -> None:
        pass

    def pause(self) -> bool:
        return False

    def resume(self) -> bool:
        return False

    def stop(self) -> None:
        pass

    def error(self, error_message: str = None) -> None:
        pass

    def reset(self) -> None:
        pass


class MockRandomStateMachine(StateMachine):
    """
    State machine that ignores real lifecycle and emits random status updates on a timer.
    Used for triangulation: drive status flow without real node transitions.
    """

    def __init__(self, interval_sec: float = None):
        if interval_sec is None:
            interval_sec = float(os.environ.get("NEURAVERSE_SDK_MOCK_STATUS_INTERVAL_SEC", "3"))
        self._interval_sec = max(0.5, interval_sec)
        self._current_state = ExecutionState.EXECUTION_STATE_IDLE
        self._stop_flag = threading.Event()
        self._driver_thread: threading.Thread | None = None
        super().__init__(_MockState())

    def get_state(self) -> ExecutionState:
        with self._lock:
            return self._current_state

    def initialize(self, state_queue, node_id, node_name=None):
        super().initialize(state_queue, node_id)
        with self._lock:
            self._stop_flag.clear()
            self._driver_thread = threading.Thread(
                target=self._random_driver_loop,
                daemon=True,
            )
            self._driver_thread.start()

    def _random_driver_loop(self) -> None:
        while not self._stop_flag.wait(timeout=self._interval_sec):
            with self._lock:
                if not self.state_queue:
                    break
                previous = self._current_state
                # 5% chance of ERROR for variety
                if random.random() < 0.05:
                    new_state = ExecutionState.EXECUTION_STATE_ERROR
                else:
                    new_state = random.choice(_MOCK_RANDOM_STATES)
                self._current_state = new_state
                self.send_status_message(previous, new_state, self.node_id)

    def end_status_stream(self):
        self._stop_flag.set()
        with self._lock:
            if self.state_queue:
                try:
                    self.state_queue.put_nowait(None)
                except queue.Full:
                    pass
                self.state_queue = None

"""
Core NodeBase class for Neuraverse SDK

This is the base class that developers inherit from to create their own nodes.
It provides gRPC and HTTP API implementations for node management.
"""

import datetime
import inspect
import json
import os
import queue
import threading
import time
import uuid
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from google.protobuf.internal.containers import MessageMap, ScalarMap
from google.protobuf.json_format import MessageToDict, ParseDict
from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    ExecutionState,
    Node,
    NodeConfigEntry,
    NodeConfigValue,
    ToggleValue,
    VisualizationsTopic,
    VisualizationsTopics,
)
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.api.grpc.clients.data_repository_client import DataRepositoryClient, JsonValue
from neuraverse_sdk.api.grpc.clients.scene_builder_client import SceneBuilderClient
from neuraverse_sdk.controllers.service_registry_repository import (
    ServiceRegistryRepository,
)
from neuraverse_sdk.dataflow.dataflow_factory import create_composite_data_flow
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.models.node_models import (
    NodeVisualizationsTopics,
)
from neuraverse_sdk.state_machine import IdleState, StateMachine
from neuraverse_sdk.state_machine_mock import MockRandomStateMachine
from neuraverse_sdk.trigger.i_trigger import (
    BUILTIN_TRIGGER_NAMES,
    TRIGGER_HANDLER_ATTR,
    ErrorInformation,
    ITrigger,
    TriggerContext,
    TriggerType,
)
from neuraverse_sdk.trigger.trigger_factory import (
    TriggerCommunicationType,
    create_trigger_adapter,
)
from neuraverse_sdk.utils.exceptions import (
    NodeConfigurationError,
    NodeExecutionError,
    NodeHealthCheckError,
    NodePauseError,
    NodeResumeError,
    NodeSimulationModeError,
    NodeStateError,
    NodeStopError,
    TriggerFlowException,
)


def _create_state_machine() -> StateMachine:
    """Create state machine; use mock when NEURAVERSE_SDK_MOCK_STATUS is set for triangulation."""
    env_val = (os.environ.get("NEURAVERSE_SDK_MOCK_STATUS") or "").strip().upper()
    if env_val in ("1", "TRUE", "YES"):
        return MockRandomStateMachine()
    return StateMachine(IdleState())


LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.neuraverse-node-sdk.node_base")

# FrameSource enum numeric values (proto: scene-builder.proto)
_FRAME_SOURCE_PATH = 1
_FRAME_SOURCE_ROBOT = 2
_FRAME_SOURCE_SENSOR = 3
_FRAME_SOURCE_MODEL = 4

_NON_ROBOT_FRAME_SOURCES = (
    _FRAME_SOURCE_PATH,
    _FRAME_SOURCE_SENSOR,
    _FRAME_SOURCE_MODEL,
)


def _health_monitor_worker(
    node: "NodeBase",
    stop_event: threading.Event,
    interval_s: float,
) -> None:
    """Periodically run get_health_check() and push changes to the health stream."""
    if interval_s <= 0:
        return
    while not stop_event.wait(timeout=interval_s):
        try:
            is_healthy, message = node.get_health_check()
            node.send_health_update(is_healthy, message)
        except Exception as e:
            node.log_warning(f"Health monitor check failed: {e}")
            node.send_health_update(False, f"Health check failed: {e}")


def _unhealthy_escalation_worker(
    node: "NodeBase",
    stop_event: threading.Event,
    delay_s: float,
    message: str,
) -> None:
    """Escalate one continuously unhealthy period after its debounce delay."""
    if stop_event.wait(timeout=max(0.0, delay_s)):
        return

    try:
        is_healthy, current_message = node.get_health_check()
        if not is_healthy:
            node._escalate_unhealthy(current_message or message, stop_event)
    except Exception as e:
        node.log_warning(f"Unhealthy escalation check failed: {e}")
    finally:
        node._clear_unhealthy_escalation_worker(stop_event)


class NodeBase(ABC):
    """
    Base class for all Neuraverse nodes.

    Developers should inherit from this class and implement the required abstract methods.
    """

    # Optional per-class version for the registered node schema; falls back to the
    # service descriptor version when unset.
    node_version: Optional[str] = None

    def __init__(self):
        # Node information + Config
        self.node_info: Node = None
        self.node_inputs: dict[str, Any] = {}
        self.node_outputs: dict[str, Any] = {}
        self.node_trigger_inputs: dict[str, Any] = {}
        self.node_trigger_outputs: dict[str, Any] = {}
        self.project_id = ""
        self.node_service_config: Optional[NodeServiceConfig] = None

        # Data + tigger flow
        self.data_flow: Optional[IDataFlow] = None
        self.trigger: Optional[ITrigger] = None
        self._auto_trigger: bool = True
        # Custom trigger handlers (trigger type name -> normalized callback),
        # collected from @trigger_handler-decorated methods on the class.
        self._trigger_handlers: dict[str, Callable[..., bool]] = {}
        self._collect_trigger_handlers()

        # State machine
        self.state_machine: StateMachine = _create_state_machine()
        self.status_queue: Optional[queue.Queue] = None
        self._on_stop_called = False  # No stop triggered
        self._stop_completed = False  # Not stop completed

        # Scene builder + Registry client
        self._scene_builder_client = SceneBuilderClient()
        self._data_repository_client = DataRepositoryClient()
        self.service_registry_client: ServiceRegistryRepository

        # Visualization cache
        self._last_output_cache: dict[str, tuple[Any, float]] = {}
        self._last_output_cache_lock = threading.Lock()
        self._viz_publish_hook: Optional[Any] = None

        self._execute_executor: Optional[ThreadPoolExecutor] = None

        # Message to be displayed in the UI for health check
        self._health_check_message: Optional[str] = None
        self.health_queue: Optional[queue.Queue] = None
        self.node_id: Optional[str] = None
        self._last_health_snapshot: Optional[tuple[bool, str]] = None
        self._last_logged_health: Optional[tuple[bool, str]] = None
        self._health_monitor_stop_event: Optional[threading.Event] = None
        self._health_monitor_thread: Optional[threading.Thread] = None
        self._health_check_lock = threading.RLock()
        self._health_escalation_lock = threading.RLock()
        self._unhealthy_escalation_stop_event: Optional[threading.Event] = None
        self._unhealthy_escalation_thread: Optional[threading.Thread] = None
        self._unhealthy_fault_latched = False

    # ---------------------------------------------------------------------------
    # (I): Overridable

    @abstractmethod
    def on_execute(self, trigger_context: Optional[TriggerContext] = None) -> None:
        """Execute the main node logic. This is called when execution is requested"""
        pass

    @abstractmethod
    def on_stop(self, trigger_context: Optional[TriggerContext] = None) -> None:
        """Called when the node is stopped."""
        pass

    @abstractmethod
    def on_configure(
        self,
        config: ScalarMap[str, str],
        dynamic_config: MessageMap[str, NodeConfigEntry] | None = None,
    ) -> None:
        """Called when the node configuration is updated"""
        pass

    @abstractmethod
    def on_get_configuration(self) -> MessageMap[str, NodeConfigEntry]:
        """Get node configuration to be displayed in the UI"""
        pass

    def on_pause(self) -> None:
        """Called when the node is paused. Suspending real work is up to the node; the SDK keeps delivering
        triggers and dataflow while paused.
        """
        self.log_info("Node paused")

    def on_resume(self) -> None:
        """Called when the node is resumed. Restart whatever on_pause() stopped."""
        self.log_info("Node resumed")

    def on_toggle_simulation_mode(self, is_simulation: bool) -> None:
        """Called when simulation mode is toggled. Override to react to simulation/read mode change."""
        pass

    def on_health_check(self) -> bool:
        """Called when NES polls health. Override to report custom health status. returns True by defualt."""
        return True

    def on_cleanup(self) -> None:
        """Cleanup resources. Called when the node is stopping."""
        self.log_info("Node cleanup")

    def on_get_data_visualization_topics(self) -> NodeVisualizationsTopics:
        """Get remaining visualizations other than outputs, to be displayed on UI"""
        return NodeVisualizationsTopics(topics={})

    def on_start_data_visualization(self, topic_names: list[str]) -> None:
        """Called when live data visualization streaming starts for this node.
        Override to adjust publish rates or perform custom actions."""
        pass

    def on_stop_data_visualization(self) -> None:
        """Called when live data visualization streaming stops for this node."""
        pass

    # ---------------------------------------------------------------------------
    # II: Node signal managment

    def register_node(self, node_service_config: NodeServiceConfig):
        self.node_service_config = node_service_config
        self.__register_service(self.node_service_config)
        self.log_info(f"Node {self.__class__.__name__} registered")

    def initialize(
        self, status_queue: queue.Queue, node_id: str, health_queue: Optional[queue.Queue] = None
    ):
        """Initialize resets attributes and sets execute/stop callbacks"""
        try:
            self._on_stop_called = False  # Set no stop triggered
            self._stop_completed = False  # Set no stop completed
            self.status_queue = status_queue
            self.health_queue = health_queue
            self.node_id = node_id
            self._last_health_snapshot = None

            if self._execute_executor is not None:
                self._execute_executor.shutdown(wait=False, cancel_futures=True)

            thread_prefix = f"{self.__class__.__name__}-execute"
            self._execute_executor = ThreadPoolExecutor(
                max_workers=1, thread_name_prefix=thread_prefix
            )
            self.status_queue = status_queue
            self.state_machine.initialize(self.status_queue, node_id)

            trigger_type = TriggerCommunicationType.TRIGGER_COMMUNICATION_TYPE_MQTT
            self.trigger = create_trigger_adapter(trigger_type)
            self.trigger.init(configuration=self.node_service_config.mqtt)
            self.trigger.set_execute_callback(self._submit_execute)
            self.trigger.set_stop_callback(self.stop)
            self.trigger.set_named_trigger_callbacks(self._trigger_handlers)

            self.data_flow = create_composite_data_flow(self.node_service_config)
            self._scene_builder_client.init(self.node_service_config.scene_builder_endpoint)

            # Only wire the data repository client when an endpoint is configured;
            # nodes that don't use the key/value store skip it (no channel to "").
            if self.node_service_config.node_engine_endpoint:
                self._data_repository_client.init(
                    endpoint=self.node_service_config.node_engine_endpoint,
                    use_tls=self.node_service_config.node_engine_use_tls,
                )

            return True

        except Exception as e:
            err_msg = f"Failed to initialize node: {self.__class__.__name__} - {str(e)}"
            self.state_machine.error(err_msg)
            self.log_error(err_msg)
            raise e

    def configure(self, node_info: Node) -> bool:
        """Resets attributes and registers MQTT trigger callbacks"""

        try:
            self._stop_unhealthy_escalation()
            with self._health_escalation_lock:
                self._unhealthy_fault_latched = False
            with self._health_check_lock:
                self._last_logged_health = None
            self._auto_trigger = True
            self._on_stop_called = False  # Set no stop triggered
            self._stop_completed = False  # Set no stop completed

            if self._execute_executor is None or getattr(
                self._execute_executor, "_shutdown", False
            ):
                thread_prefix = f"{self.__class__.__name__}-execute"
                self._execute_executor = ThreadPoolExecutor(
                    max_workers=1, thread_name_prefix=thread_prefix
                )

            if self.data_flow:
                self.data_flow.configure(node_info.dataFlowEntry)
            if self.trigger:
                # Refresh handlers before configure so late imperative
                # register_trigger_handler() calls are seen by validation.
                self.trigger.set_named_trigger_callbacks(self._trigger_handlers)
                self.trigger.configure(node_info.triggerFlowEntry)

            self.node_inputs = dict(node_info.inputs)
            self.node_outputs = dict(node_info.outputs)
            self.node_trigger_inputs = dict(node_info.triggerFlowEntry.inputTriggers)
            self.node_trigger_outputs = dict(node_info.triggerFlowEntry.outputTriggers)

            self.node_info = node_info
            self.on_configure(node_info.configuration, node_info.dynamicConfiguration or None)
            self.state_machine.configure()
            self._push_current_health()
            self._start_health_monitor()
            return True

        except Exception as e:
            err_msg = f"Failed to update configuration: {node_info.name} - {str(e)}"
            self.state_machine.error(err_msg)
            self.log_error(err_msg, exception=e)
            raise e

    def execute_background(self) -> bool:
        """Start node execution in the background. Returns immediately."""
        thread = threading.Thread(target=self.execute, daemon=True)
        thread.start()
        return True

    def execute(self, trigger_context: Optional[TriggerContext] = None) -> bool:
        """Execute the node once. This is the main execution method. execute() is the entry point the trigger adapter invokes on every incoming Start MQTTmessage."""

        if getattr(self, "_stop_completed", False):
            log_msg = (
                f"Ignoring execute() — node has already been stopped "
                f"(stale Start trigger arrived after stop() completed)"
            )
            self.log_info(log_msg)
            return True

        out_trigger_context = TriggerContext(source_node=str(self.__class__.__name__))
        start_time = time.time()
        try:
            if self.node_info is None:
                self.log_error("Node info is None")
                raise NodeExecutionError("Node info is None")

            self.log_info(f"Executing node {self.node_info.name}")
            self.state_machine.execute()
            if self.supports_argument(func=self.on_execute):
                self.on_execute(trigger_context=trigger_context)
            else:
                self.on_execute()  # For backwards compatibility

            execution_time = time.time() - start_time
            self.log_info(f"Node execution completed in {execution_time:.3f}s")

            with self._health_escalation_lock:
                if (
                    self.state_machine.get_state()
                    == ExecutionState.EXECUTION_STATE_ERROR
                ):
                    self.log_warning(
                        "Ignoring late execution success after health escalation"
                    )
                    return False

                self.state_machine.configure()
                if self.trigger and self._auto_trigger:
                    if self.trigger.has_outgoing_trigger(TriggerType.Start):
                        self.trigger.trigger_next_node(
                            TriggerType.Start, trigger_context=out_trigger_context
                        )
                    if self.trigger.has_outgoing_trigger(TriggerType.Stop):
                        self.trigger.trigger_next_node(
                            TriggerType.Stop, trigger_context=out_trigger_context
                        )
            return True

        except Exception as e:
            out_trigger_context.err_info = ErrorInformation(err_type=str(type(e)), err_msg=str(e))
            if self.trigger.has_outgoing_trigger(TriggerType.Error):
                self.trigger.trigger_next_node(TriggerType.Error, out_trigger_context)

            self.state_machine.error(f"Execution error: {str(e)}")
            self.log_error(f"Execution error: {str(e)}", exception=e)
            raise NodeExecutionError(f"Node Execution failed: {str(e)}")

    def _submit_execute(self, trigger_context: Optional[TriggerContext] = None) -> bool:
        """Trigger callback entry point. Submits execute() in single-threaded executor rather than running execute() directly so that MQTT callback run non blocking"""

        executor = self._execute_executor
        if getattr(self, "_stop_completed", False):
            self.log_info("Ignoring trigger — node has already been stopped")
            return True
        if executor is None:
            self.log_info("Ignoring trigger — node executor is not initialized")
            return True
        try:
            executor.submit(self.execute, trigger_context)
        except RuntimeError:
            self.log_info("Ignoring trigger — node executor is shut down")
        return True

    def stop(self, trigger_context: Optional[TriggerContext] = None) -> bool:
        """
        Stop the node.

        Returns:
            Dict with result code and message
        """
        # If a previous stop() already ran the destroy chain to completion,
        # repeating it is at best a no-op and at worst a hang on already-
        # disposed state. ``_stop_completed`` is cleared by initialize() and
        # configure() so the destroy chain runs cleanly on the next real stop
        # after a fresh setup.
        if getattr(self, "_stop_completed", False):
            return True

        # Disable auto-triggering immediately so any in-flight on_execute()
        # does not fire trigger_next_node() after it returns.
        self._auto_trigger = False

        # Each teardown step is independent: a failure in one must not skip the
        # rest (which would leak the remaining resources). Run them all, collect
        # failures, and surface them after on_stop() has run.
        failed_steps: list[str] = []

        def _step(label: str, fn: Callable[[], Any]) -> None:
            try:
                fn()
            except Exception as e:  # pylint: disable=broad-except
                failed_steps.append(label)
                self.log_error(f"stop(): {label} failed - {str(e)}", exception=e)

        try:
            _step("data_repository_client.close", self._data_repository_client.close)
            _step("state_machine.stop", self.state_machine.stop)
            _step("state_machine.end_status_stream", self.state_machine.end_status_stream)
            _step("end_health_stream", self._end_health_stream)
            _step("on_cleanup", self.on_cleanup)
            if self.data_flow:
                _step("data_flow.destroy", self.data_flow.destroy)
            if self.trigger:
                _step("trigger.destroy", self.trigger.destroy)

            # Shut the trigger executor down so no queued or late-arriving
            # Start triggers fire after the destroy chain. Don't wait on the
            # currently-running execute() (if any) — stop() must be quick.
            if self._execute_executor is not None:
                executor = self._execute_executor
                _step(
                    "executor.shutdown",
                    lambda: executor.shutdown(wait=False, cancel_futures=True),
                )

            # Deliberately do NOT stop Consul registration monitoring here: the
            # capability registration belongs to the running node SERVICE, not
            # to this instance's lifecycle. stop() also runs when a graph
            # re-initializes the node — stopping the (shared) monitor there
            # leaves the registration unmonitored, so a Consul restart or a
            # failed health check loses it permanently. The monitor is a
            # per-process singleton (one client + one thread per registry
            # endpoint, shared across all node instances — NRV-10272) and
            # lives for the process lifetime.
            _step("scene_builder_client.close", self._scene_builder_client.close)

            self._stop_completed = True
        finally:
            # Guarantee on_stop() runs exactly once per lifecycle — even if a
            # step above raised unexpectedly. Resource-release hooks (e.g.
            # dropping a shared robot connection) must never be skipped.
            self._invoke_on_stop_once(trigger_context)

        if failed_steps:
            msg = "Failed to stop node - steps failed: " + ", ".join(failed_steps)
            self.state_machine.error(msg)
            self.log_error(msg)
            raise NodeStopError(msg)
        return True

    def _invoke_on_stop_once(self, trigger_context: Optional[TriggerContext] = None) -> None:
        """Call ``on_stop()`` at most once per node lifecycle.

        Invoked from ``stop()``'s ``finally`` so node cleanup hooks (such as
        releasing a shared robot hold) run exactly once even if the destroy
        chain raised. The once-guard ``_on_stop_called`` is reset in
        ``initialize()`` / ``configure()`` so the next lifecycle re-arms it. A
        failure inside ``on_stop()`` is logged, never propagated.
        """
        if getattr(self, "_on_stop_called", False):
            return
        self._on_stop_called = True
        try:
            if self.supports_argument(func=self.on_stop):
                self.on_stop(trigger_context=trigger_context)
            else:
                self.on_stop()  # For backwards compatibility
        except Exception as e:  # pylint: disable=broad-except
            self.log_error(f"on_stop() failed during stop - {str(e)}", exception=e)

    @staticmethod
    def supports_argument(func: Callable) -> bool:
        sig = inspect.signature(func)
        params = [p for p in sig.parameters.values() if p.name != "self"]
        return len(params) > 0

    def is_paused(self) -> bool:
        return (
            self.state_machine.get_state()
            == ExecutionState.EXECUTION_STATE_PAUSED
        )

    def pause(self) -> bool:
        """
        Pause the node and notify the implementation via on_pause().
        on_pause() fires only when this call is what paused the node, so the
        engine pausing an already-paused node does not re-fire it.

        Returns:
            True if the pause was applied or the node had nothing to pause
        """
        try:
            if self.state_machine.pause():
                self.on_pause()
            return True

        except Exception as e:
            self.log_error(f"Failed to pause node: {str(e)}", exception=e)
            raise NodePauseError(f"Failed to pause node: {str(e)}")

    def resume(self) -> bool:
        """
        Resume the node and notify the implementation via on_resume().

        Returns:
            True if the node was resumed or was not paused to begin with
        """
        try:
            if self.state_machine.resume():
                self.on_resume()
            return True

        except Exception as e:
            self.log_error(f"Failed to resume node: {str(e)}", exception=e)
            raise NodeResumeError(f"Failed to resume node: {str(e)}")

    def toggle_simulation_mode(self, is_simulation: bool) -> bool:
        try:
            self.log_info(f"Simulation mode set to: {is_simulation}")
            self.on_toggle_simulation_mode(is_simulation)
            return True
        except Exception as e:
            self.log_error(f"Failed to toggle simulation mode: {str(e)}", exception=e)
            raise NodeSimulationModeError(f"Failed to toggle simulation mode {str(e)}")

    def get_health_check(self) -> tuple[bool, str]:
        try:
            with self._health_check_lock:
                self._health_check_message = None
                is_healthy = self.on_health_check()
                message = self._health_check_message or (
                    "Healthy" if is_healthy else "Unhealthy"
                )
                self._log_health_sample(is_healthy, message)
                self._handle_health_sample(is_healthy, message)
                return is_healthy, message
        except Exception as e:
            message = f"Health check failed: {str(e)}"
            self._log_health_sample(False, message, exception=e)
            self._handle_health_sample(False, message)
            return False, message

    def _log_health_sample(
        self, is_healthy: bool, message: str, exception: Optional[Exception] = None
    ) -> None:
        """Log a health sample only when the snapshot changed, to keep the poll quiet."""
        with self._health_check_lock:
            snapshot = (is_healthy, message)
            if snapshot == self._last_logged_health:
                return
            self._last_logged_health = snapshot

        if exception is not None:
            self.log_error(f"Healthy check result: {is_healthy}, message: {message}",
                           exception=exception)
        else:
            self.log_info(f"Healthy check result: {is_healthy}, message: {message}")

    def _handle_health_sample(self, is_healthy: bool, message: str) -> None:
        """Cancel or arm escalation based on the latest health sample."""
        # A healthy sample clears the latch and cancels a pending waiter.
        if is_healthy:
            with self._health_escalation_lock:
                self._unhealthy_fault_latched = False
            self._stop_unhealthy_escalation()
            return

        # Unhealthy, but the service has not opted in.
        config = self.node_service_config
        if config is None or not getattr(
            config, "escalate_unhealthy_to_error", False
        ):
            return

        with self._health_escalation_lock:
            # Only a RUNNING node escalates, and only once per fault period.
            if (
                self._unhealthy_fault_latched
                or self.state_machine.get_state() != ExecutionState.EXECUTION_STATE_RUNNING
            ):
                return
            thread = self._unhealthy_escalation_thread
            # A waiter for this fault period is already running.
            if thread is not None and thread.is_alive():
                return

            stop_event = threading.Event()
            delay_s = getattr(config, "unhealthy_escalate_after_s", 7.0)
            thread = threading.Thread(
                target=_unhealthy_escalation_worker,
                args=(self, stop_event, delay_s, message),
                daemon=True,
                name=f"unhealthy-escalation-{self.node_id or 'unknown'}",
            )
            self._unhealthy_escalation_stop_event = stop_event
            self._unhealthy_escalation_thread = thread
            thread.start()

    def _escalate_unhealthy(
        self, message: str, worker_stop_event: threading.Event
    ) -> None:
        """Move a running node to ERROR once for the current unhealthy period."""
        with self._health_escalation_lock:
            if (
                worker_stop_event.is_set()
                or worker_stop_event is not self._unhealthy_escalation_stop_event
                or self._unhealthy_fault_latched
                or self.state_machine.get_state() != ExecutionState.EXECUTION_STATE_RUNNING
            ):
                return

            self._unhealthy_fault_latched = True
            error_message = f"Health escalation: {message}"
            self.state_machine.error(error_message)

            if self.trigger and self.trigger.has_outgoing_trigger(TriggerType.Error):
                trigger_context = TriggerContext(
                    source_node=str(self.__class__.__name__),
                    err_info=ErrorInformation(
                        err_type="HealthFaultEscalation",
                        err_msg=message,
                    ),
                )
                self.trigger.trigger_next_node(
                    TriggerType.Error, trigger_context=trigger_context
                )

    def _clear_unhealthy_escalation_worker(
        self, worker_stop_event: threading.Event
    ) -> None:
        with self._health_escalation_lock:
            if worker_stop_event is self._unhealthy_escalation_stop_event:
                self._unhealthy_escalation_stop_event = None
                self._unhealthy_escalation_thread = None

    def _stop_unhealthy_escalation(self) -> None:
        with self._health_escalation_lock:
            stop_event = self._unhealthy_escalation_stop_event
            if stop_event is not None:
                stop_event.set()
            self._unhealthy_escalation_stop_event = None
            self._unhealthy_escalation_thread = None

    def send_health_update(self, is_healthy: bool, message: str) -> None:
        """Push a health snapshot to the health stream when it changes."""
        if not self.health_queue or not self.node_id:
            return
        snapshot = (is_healthy, message)
        if snapshot == self._last_health_snapshot:
            return
        self._last_health_snapshot = snapshot
        item = {
            "nodeId": self.node_id,
            "isHealthy": is_healthy,
            "resultMessage": message,
        }
        try:
            self.health_queue.put_nowait(item)
        except queue.Full:
            self.log_warning("Health queue full; dropping health update")

    def _push_current_health(self) -> None:
        """Force-push the current health snapshot (e.g. on configure or subscribe)."""
        self._last_health_snapshot = None
        try:
            is_healthy, message = self.get_health_check()
            self.send_health_update(is_healthy, message)
        except Exception as e:
            self.log_warning(f"Failed to push initial health snapshot: {e}")

    def _start_health_monitor(self) -> None:
        self._stop_health_monitor()
        if self.node_service_config is None:
            return
        interval_s = getattr(self.node_service_config, "health_stream_check_interval_s", 10.0)
        if interval_s <= 0 or self.health_queue is None:
            return
        stop_event = threading.Event()
        self._health_monitor_stop_event = stop_event
        thread = threading.Thread(
            target=_health_monitor_worker,
            args=(self, stop_event, interval_s),
            daemon=True,
            name=f"health-monitor-{self.node_id or 'unknown'}",
        )
        thread.start()
        self._health_monitor_thread = thread

    def _stop_health_monitor(self) -> None:
        self._stop_unhealthy_escalation()
        stop_event = self._health_monitor_stop_event
        if stop_event is not None:
            stop_event.set()
        self._health_monitor_stop_event = None
        self._health_monitor_thread = None

    def _end_health_stream(self) -> None:
        self._stop_health_monitor()
        self._last_health_snapshot = None
        if self.health_queue is not None:
            try:
                self.health_queue.put_nowait(None)
            except queue.Full:
                self.log_warning("Health queue full; could not send stream end sentinel")
            self.health_queue = None

    def get_configuration(self) -> MessageMap[str, NodeConfigEntry]:
        """
        Get node configuration.

        Returns:
            MessageMap containing configuration
        """

        try:
            self.log_info(f"Getting node configuration for {self.get_node_class_name()}")
            configuration: MessageMap[str, NodeConfigEntry] = self.on_get_configuration()
            return configuration
        except Exception as e:
            self.log_error(f"Failed to get configuration: {str(e)}", exception=e)
            raise NodeConfigurationError(f"Failed to get configuration: {str(e)}")

    # ---------------------------------------------------------------------------
    # III: Get methods

    def get_inputs(self) -> dict[str, Any]:
        return self.node_inputs

    def get_outputs(self) -> dict[str, Any]:
        return self.node_outputs

    def get_trigger_inputs(self) -> dict[str, Any]:
        return self.node_trigger_inputs

    def get_trigger_outputs(self) -> dict[str, Any]:
        return self.node_trigger_outputs

    def get_node_version(self) -> str:
        """Return the node version: the ``node_version`` class attribute when set,
        otherwise the service descriptor version."""
        if self.node_version:
            return self.node_version
        node_service_config = getattr(self, "node_service_config", None)
        descriptor = getattr(node_service_config, "service_descriptor", None)
        version = getattr(descriptor, "version", "") if descriptor else ""
        return version or "1.0.0"

    def get_schema(self) -> Node:
        """
        Build the self-registration schema for this node class from the static
        sibling ``<module>_schema.json`` (name, inputs, outputs, ...).

        Dynamic configuration is intentionally NOT included: the class is not
        initialized at registration time; it stays runtime-only via
        ``InitializeNode`` / ``on_get_configuration()``.
        Never raises: schema registration must not break node startup.
        """
        schema = self._load_static_schema()
        # The class name's only place in the schema is executionContext.className
        # (the engine resolves capability-<className> from it at configure time);
        # everywhere else the node is identified by its schema name.
        class_name = self.get_node_class_name()
        if not schema.name:
            schema.name = class_name
        if not schema.description:
            schema.description = (self.__class__.__doc__ or "").strip()
        schema.executionContext.className = class_name
        return schema

    def _load_static_schema(self) -> Node:
        """
        Load the static ``<module>_schema.json`` sitting next to the node's module.

        Returns an empty ``Node`` when the file is missing or unparsable.
        """
        class_name = self.get_node_class_name()
        try:
            module_path = Path(inspect.getfile(self.__class__))
            schema_path = module_path.with_name(f"{module_path.stem}_schema.json")
        except (TypeError, OSError) as e:
            self.log_warning(f"Cannot locate module file for {class_name}: {e}")
            return Node()
        if not schema_path.is_file():
            self.log_warning(f"No static schema file found for {class_name} at {schema_path}")
            return Node()
        try:
            with open(schema_path, encoding="utf-8") as schema_file:
                schema_dict = json.load(schema_file)
            return ParseDict(schema_dict, Node(), ignore_unknown_fields=True)
        except Exception as e:
            self.log_warning(f"Failed to parse static schema {schema_path}: {e}")
            return Node()

    def _build_schema_envelope(self, service_config: NodeServiceConfig, namespace: str) -> dict:
        """Serialize the node schema plus registration facts for the registry KV store.

        The node is identified by its schema ``name``; the class name only lives
        inside ``schema.executionContext.className``.
        """
        node_name = self.get_node_class_name()
        try:
            schema = self.get_schema()
            node_name = schema.name or node_name
            schema_dict = MessageToDict(schema)
        except Exception as e:
            self.log_warning(f"Failed to serialize schema for {node_name}: {e}")
            schema_dict = {}
        return {
            "namespace": namespace,
            # container the node service runs in; disambiguates equally-named
            # nodes shipped by different node containers within one namespace
            "container": getattr(service_config, "container_name", "") or "",
            "name": node_name,
            "version": self.get_node_version(),
            "node_cluster_target": service_config.registry_config.node_cluster_target,
            "node_external_target": service_config.registry_config.node_external_target,
            "schema": schema_dict,
        }

    def set_project_id(self, project_id: str):
        """Set the project id for the node."""
        self.project_id = project_id

    def get_frames(self, metadata_filter: Optional[Dict] = None) -> List[Dict]:
        """
        Retrieve a list of non-robot frames from the Scene Builder Backend for a given project.

        This method calls the Scene Builder Backend's ListFrames API with
        ``sources`` set to path, sensor, and model origins (excluding robot frames).

        Args:
            metadata_filter: Optional dictionary to filter frames by metadata.
                Only frames matching all key-value pairs are returned (client-side).
                Example: {"type": "tcp", "robot": "robot1"}

        Returns:
            List of frame dictionaries. Each frame typically contains:
            - id (str): Unique, stable identifier for the frame
            - display_name (str): Human-readable name for UI display
            - initial_pose (dict): Static pose in world space (position and orientation)
            - metadata (dict): Arbitrary metadata key-value pairs
            - source (str): Frame origin (e.g. path, robot, sensor, model)
        """
        try:
            return self._scene_builder_client.list_frames(
                self.project_id,
                metadata_filter=metadata_filter,
                sources=_NON_ROBOT_FRAME_SOURCES,
            )
        except Exception as e:
            raise NodeStateError(f"Failed to get frames: {str(e)}") from e

    def get_robots(self) -> List[Dict]:
        """
        Retrieve a list of robots from the Scene Builder Backend for a given project.

        Robot entries are frames whose ``Frame.source`` is the robot enum value (2).
        """
        try:
            return self._scene_builder_client.list_frames(
                self.project_id,
                metadata_filter=None,
                sources=(_FRAME_SOURCE_ROBOT,),
            )
        except Exception as e:
            raise NodeStateError(f"Failed to get frames: {str(e)}") from e

    def get_paths(
        self,
        target_robot_ids: Optional[List[str]] = None,
    ) -> List[Dict]:
        """
        Retrieve the list of authored paths from the Scene Builder Backend for
        a given project.

        Calls the ``ListPaths`` API; the response carries each path with its
        ordered frames + per-gap motion segments. Useful for executor nodes
        (e.g. ``PathExecutorNode``) that need to enumerate or pick an
        authored path to run.

        Args:
            target_robot_ids: Optional list of robot scene-object ids. When
                non-empty, only paths whose ``target_robot_id`` matches one of
                them are returned. ``None`` or empty returns all paths.

        Returns:
            List of path dictionaries. Each path contains:
            - id (str): Unique, stable identifier for the path
            - display_name (str): Human-readable name shown in the editor
            - frames (list[dict]): Ordered Frame dicts (same shape as ``get_frames``)
            - segments (list[dict]): Per-gap PathSegment dicts (id, motion_type,
                speed, acceleration, jerk, blend, via_frame_id, tool_frame_id)
            - target_robot_id (str): Scene-object id of the executing robot
            - tcp_tip_link (str): Optional kinematic-chain tip-link TCP
            - tcp_flange_name (str): Optional tool-flange TCP (overrides tip-link)
        """
        try:
            return self._scene_builder_client.list_paths(
                self.project_id,
                target_robot_ids=target_robot_ids,
            )
        except Exception as e:
            raise NodeStateError(f"Failed to get paths: {str(e)}") from e

    def get_node_id(self) -> str:
        """Get the node id"""
        if self.node_info is None:
            raise NodeStateError("Node info is not initialized")
        return self.node_info.id

    def get_node_name(self) -> str:
        """Get the node name"""
        if self.node_info is None:
            raise NodeStateError("Node info is not initialized")
        return self.node_info.name

    def get_node_class_name(self) -> str:
        """Get the node class name"""
        return self.__class__.__name__

    def get_ros_node(self) -> Any:
        """Return the rclpy node used by this node for ROS2 communication.

        Override this method in subclasses that manage their own rclpy node
        (e.g. nodes that do not use the standard dataflow adapter).
        The default implementation returns the node held by the dataflow adapter.
        """
        if self.data_flow and hasattr(self.data_flow, "ros_node"):
            return self.data_flow.ros_node
        return None

    def get_connected_ports(self) -> dict[str, bool]:
        if self.data_flow:
            return self.data_flow.get_connected_ports()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    def get_input_topics(self) -> dict[str, Any]:
        if self.data_flow:
            return self.data_flow.get_input_topics()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    def get_output_topics(self) -> dict[str, Any]:
        if self.data_flow:
            return self.data_flow.get_output_topics()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    # ROS types that produce meaningless or oversized visualization output.
    # PointCloud2 / CameraInfo etc. are filtered from the picker.
    _NON_VISUALIZABLE_TYPES: frozenset = frozenset(
        {
            "sensor_msgs/msg/PointCloud2",
            "sensor_msgs/msg/CameraInfo",
            "sensor_msgs/msg/LaserScan",
            "sensor_msgs/msg/Imu",
            "sensor_msgs/msg/NavSatFix",
            "sensor_msgs/msg/MagneticField",
            "tf2_msgs/msg/TFMessage",
        }
    )

    def get_data_visualizations_topics(self) -> VisualizationsTopics:
        try:
            from neuraverse_sdk.streaming.data_visualization_streamer import (
                livekit_safe_viz_name,
                visualization_stream_type,
            )

            data_visualizations_topics = VisualizationsTopics()

            user_defined_data_visualization_topics = self.on_get_data_visualization_topics()

            # ``topicName`` is the identity the UI uses to subscribe to the
            # LiveKit track/data channel verbatim, so it MUST equal the public
            # name the streamer publishes under (LiveKit-safe, node-id keyed).
            # The streamer still subscribes to the real ROS topic internally.
            for (
                data_visualization_name,
                data_visualization_topic,
            ) in user_defined_data_visualization_topics.topics.items():
                topic = VisualizationsTopic()
                topic.topicName = livekit_safe_viz_name(data_visualization_topic.topic_name)
                topic.visualizationType = visualization_stream_type(
                    data_visualization_topic.visualization_type
                )
                data_visualizations_topics.topics[data_visualization_name].CopyFrom(topic)

            output_topics = self.get_output_topics()
            for output_name, output_info in output_topics.items():
                if "ros_type" not in output_info:
                    continue
                ros_type = output_info["ros_type"].lstrip("/")
                if ros_type in self._NON_VISUALIZABLE_TYPES:
                    continue
                topic = VisualizationsTopic()
                topic.topicName = livekit_safe_viz_name(output_info["topic_name"])
                topic.visualizationType = visualization_stream_type(ros_type)
                data_visualizations_topics.topics[output_name].CopyFrom(topic)

            return data_visualizations_topics
        except Exception as e:
            LOGGER.error(f"Failed to get data visualizations topics: {str(e)}")
            raise NodeStateError("Failed to get data visualizations topics")

    # ---------------------------------------------------------------------------
    # IV: Logging methods

    def log_info(self, message: str):
        """Log info message"""
        LOGGER.info(message)

    def log_error(self, message: str, exception: Exception | None = None):
        """Log error message"""
        LOGGER.error(message + (" " + str(exception) if exception else ""))

    def log_warning(self, message: str):
        """Log warning message"""
        LOGGER.warning(message)

    def log_debug(self, message: str):
        """Log debug message"""
        LOGGER.debug(message)

    # ---------------------------------------------------------------------------
    # V: Data repository (node-engine backed key/value store)

    def _data_repo_context(self) -> ExecutionContext:
        """Build an ExecutionContext for data-repository calls.

        No auth token is attached: the node reaches its engine over the trusted
        edge network, where the engine's CRUD RPCs are unauthenticated. This
        context only carries the standard request metadata (trace ids, etc.).
        """
        return ExecutionContext(
            caller_name_and_version=self.__class__.__name__,
        )

    def create_data(self, key: str, value: JsonValue, namespace: str) -> None:
        """Create a record in the node-engine data repository."""
        return self._data_repository_client.create_data(
            self._data_repo_context(), namespace, key, value
        )

    def read_data(self, key: str, namespace: str) -> JsonValue:
        """Read a record from the node-engine data repository."""
        return self._data_repository_client.get_data(self._data_repo_context(), namespace, key)

    def update_data(self, key: str, value: JsonValue, namespace: str) -> None:
        """Update a record in the node-engine data repository."""
        return self._data_repository_client.update_data(
            self._data_repo_context(), namespace, key, value
        )

    def delete_data(self, key: str, namespace: str) -> None:
        """Delete a record from the node-engine data repository."""
        return self._data_repository_client.delete_data(self._data_repo_context(), namespace, key)

    # ---------------------------------------------------------------------------
    # V: Dataflow

    def get_data(self, placeholder: str):
        """Get the data from the node."""
        if self.data_flow:
            data = self.data_flow.get_data(placeholder)
            if data is not None:
                self._try_push_viz_background(placeholder, data)
            return data

    def _try_push_viz_background(self, placeholder: str, msg: Any) -> None:
        """Auto-push image messages as visualization background when viz is active.

        Activated for any node once the visualization controller sets ``_viz_bg_push``
        and ``_viz_bg_mqtt_to_seg``.  Nodes do not need to call this explicitly.
        """
        push_fn = getattr(self, "_viz_bg_push", None)
        if push_fn is None:
            return
        bg_map = getattr(self, "_viz_bg_mqtt_to_seg", {})
        if not bg_map:
            return
        # Build/reuse the placeholder→MQTT-topic cache (retried until non-empty)
        cache = getattr(self, "_viz_bg_input_cache", None)
        if not cache:
            try:
                result = {
                    pn: info.get("topic_name", "") for pn, info in self.get_input_topics().items()
                }
                if result:
                    self._viz_bg_input_cache = result
                    cache = result
            except Exception:
                pass
        mqtt_topic = (cache or {}).get(placeholder, "")
        if not mqtt_topic:
            return
        seg_topic = bg_map.get(mqtt_topic, "")
        if not seg_topic:
            return
        try:
            import cv2
            import numpy as np

            ros_type = ""
            port_info = (self.node_inputs or {}).get(placeholder)
            if port_info:
                rt = getattr(port_info, "rosType", "") or ""
                ros_type = rt.rsplit("/", 1)[-1] if "/" in rt else rt

            if ros_type == "CompressedImage" or (not ros_type and hasattr(msg, "format")):
                raw = bytes(msg.data)
                arr = np.frombuffer(raw, np.uint8)
                bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                if bgr is not None:
                    push_fn(seg_topic, cv2.cvtColor(bgr, cv2.COLOR_BGR2RGBA))
            elif ros_type == "Image" or (
                not ros_type and hasattr(msg, "encoding") and hasattr(msg, "step")
            ):
                encoding = (getattr(msg, "encoding", "") or "").lower()
                h, w = int(msg.height), int(msg.width)
                if h > 0 and w > 0:
                    raw = np.frombuffer(bytes(msg.data), dtype=np.uint8)
                    if encoding in ("rgb8",):
                        push_fn(seg_topic, cv2.cvtColor(raw.reshape(h, w, 3), cv2.COLOR_RGB2RGBA))
                    elif encoding in ("bgr8", "8uc3"):
                        push_fn(seg_topic, cv2.cvtColor(raw.reshape(h, w, 3), cv2.COLOR_BGR2RGBA))
        except Exception:
            pass

    def wait_for_message(self, placeholder: str, timeout: float = -1.0):
        """Wait for a message from the node."""
        if self.data_flow:
            _ = self.data_flow.wait_for_message(placeholder, timeout)

    def publish(self, topic_name: str, message: Any) -> None:
        """Publish the data from the node."""
        if self.data_flow:
            self.data_flow.publish(target=topic_name, message=message, meta_data=None)
        # Cache the last value so a viz session that starts later (or is
        # restarted) can re-emit it via LiveKit immediately.  Cheap: one entry
        # per output port, last value only.  See `get_cached_output`.
        with self._last_output_cache_lock:
            self._last_output_cache[topic_name] = (message, time.monotonic())

        # Protocol-agnostic visualization bridge — when a viz session is
        # active for this node, the controller wires a hook here that
        # dispatches every publish() into the streamer's handlers.  This
        # means the live LiveKit feed works even when the node's data flow
        # is ROS-only (no fragile rclpy subscription on the streamer side
        # required) or when the same value would otherwise reach the viz
        # only via the MQTT-only direct push hooks each node has to wire
        # up by hand.  Failures here are swallowed — viz must never break
        # the publish path.
        hook = self._viz_publish_hook
        if hook is not None:
            try:
                hook(topic_name, message)
            except Exception:
                pass

    def get_cached_output(self, topic_name: str) -> Optional[Any]:
        """Return the last value published for ``topic_name`` (or None).

        Used by the visualization streamer on start to seed the live channel
        with the most recent value, so a UI opening viz late doesn't have to
        wait for the next publish to see anything.
        """
        with self._last_output_cache_lock:
            entry = self._last_output_cache.get(topic_name)
            if entry is None:
                return None
            return entry[0]

    def get_cached_output_topics(self) -> list[str]:
        """Return the list of output port names that have a cached value."""
        with self._last_output_cache_lock:
            return list(self._last_output_cache.keys())

    def register_handler(self, callback, input_name: str = ""):
        """Register a handler for a specific topic."""
        if self.data_flow:
            self.data_flow.register_handler(callback, input_name)

    # ---------------------------------------------------------------------------
    # Custom triggers

    @property
    def trigger_handlers(self) -> dict[str, Callable[..., bool]]:
        """Custom trigger handlers (trigger type name -> callback)."""
        return dict(self._trigger_handlers)

    def register_trigger_handler(self, trigger_type: str, callback: Callable[..., bool]) -> None:
        """Register a handler for a custom input trigger type.

        Must be called before the node is configured. Handlers run on the
        transport callback thread — keep them fast and non-blocking.
        """
        if trigger_type in BUILTIN_TRIGGER_NAMES:
            raise NodeConfigurationError(
                f"Cannot register a custom handler for built-in trigger type "
                f"'{trigger_type}' — built-in triggers keep their implicit SDK behavior."
            )
        self._trigger_handlers[trigger_type] = self._normalize_trigger_handler(callback)
        if self.trigger:
            self.trigger.set_named_trigger_callbacks(self._trigger_handlers)

    def fire_trigger(
        self, port_name: str, trigger_context: Optional[TriggerContext] = None
    ) -> None:
        """Fire a custom output trigger port declared in the node schema."""
        if self.trigger is None:
            raise TriggerFlowException(
                f"Cannot fire trigger '{port_name}': trigger adapter not initialized"
            )
        if trigger_context is None:
            trigger_context = TriggerContext(source_node=str(self.__class__.__name__))
        self.trigger.fire_trigger(port_name, trigger_context)

    def _collect_trigger_handlers(self) -> None:
        """Collect @trigger_handler-decorated methods across the class MRO.

        Base-class handlers are inherited; a subclass re-decorating the same
        trigger type (same method name or not) overrides it. Two methods in
        the same class claiming one trigger type is ambiguous and raises.
        """
        for klass in reversed(type(self).__mro__):
            claimed_in_class: dict[str, str] = {}
            for name, member in vars(klass).items():
                trigger_type = getattr(member, TRIGGER_HANDLER_ATTR, None)
                if trigger_type is None:
                    continue
                if trigger_type in BUILTIN_TRIGGER_NAMES:
                    raise NodeConfigurationError(
                        f"Cannot register a custom handler for built-in trigger type "
                        f"'{trigger_type}' — built-in triggers keep their implicit "
                        "SDK behavior."
                    )
                if trigger_type in claimed_in_class:
                    raise NodeConfigurationError(
                        f"Duplicate @trigger_handler('{trigger_type}') on "
                        f"{klass.__name__}.{claimed_in_class[trigger_type]} and "
                        f"{klass.__name__}.{name}"
                    )
                claimed_in_class[trigger_type] = name
                # getattr binds through the full MRO, so a subclass override
                # of the decorated method is what actually gets called.
                self._trigger_handlers[trigger_type] = self._normalize_trigger_handler(
                    getattr(self, name)
                )

    def _normalize_trigger_handler(self, func: Callable[..., Any]) -> Callable[..., bool]:
        """Wrap a handler so it always accepts an optional TriggerContext."""
        if self.supports_argument(func):

            def handler(trigger_context: Optional[TriggerContext] = None) -> bool:
                return bool(func(trigger_context))

        else:

            def handler(trigger_context: Optional[TriggerContext] = None) -> bool:
                return bool(func())

        return handler

    # ---------------------------------------------------------------------------
    # VI: Service registration

    def __register_service(self, service_config: NodeServiceConfig):
        # register with service registry

        registry_endpoint = service_config.registry_config.registry_endpoint
        if not registry_endpoint:
            self.log_warning("Registry endpoint not configured, skipping registration.")
            return

        if service_config.registry_config.node_cluster_target == "":
            node_endpoint = f"{service_config.grpc.address}:{service_config.grpc.port}"
        else:
            node_endpoint = service_config.registry_config.node_cluster_target

        node_configurations = self.__get_static_configuraions()

        namespace = service_config.registry_config.node_namespace
        schema_envelope = self._build_schema_envelope(service_config, namespace)

        self.service_registry_client = ServiceRegistryRepository(
            registry_endpoint,
            registration_timeout_s=service_config.registry_config.registration_timeout_s,
            registration_retry_delay_s=(
                service_config.registry_config.registration_retry_delay_s
            ),
        )

        self.service_registry_client.register_node(
            node_endpoint=node_endpoint,
            capability_name=self.get_node_class_name(),
            node_configurations=node_configurations,
            namespace=namespace,
            schema_envelope=schema_envelope,
        )

    def __get_static_configuraions(self) -> MessageMap[str, NodeConfigEntry]:
        node_configurations: MessageMap[str, NodeConfigEntry] = {}
        node_configurations["node_external_target"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                stringValue=self.node_service_config.registry_config.node_external_target,
            ),
            required=True,
            displayLabel="Node External Target",
            description="External URL (host:port) when the node is reachable from outside the cluster; stored in registry for is_remote resolution.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )

        node_configurations["is_remote"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                toggleValue=ToggleValue(
                    enabled=False,
                ),
            ),
            required=True,
            displayLabel="Is Remote",
            description="Whether the node is reachable from outside the cluster.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )

        node_configurations["node_deployment_host"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                stringValue=self.node_service_config.registry_config.registry_endpoint,
            ),
            required=True,
            displayLabel="Node Deployment Host",
            description="The host and port of where the node is registerd.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )
        return node_configurations

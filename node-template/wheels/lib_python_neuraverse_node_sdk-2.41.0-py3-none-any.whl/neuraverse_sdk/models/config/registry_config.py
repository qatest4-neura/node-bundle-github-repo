"""
This module defines the `RegistryConfig` class for registring nodes in the consul
It leverages Pydantic for validation and ensures that these
fields are properly set and documented.
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class RegistryConfig(BaseSettings):
    """
    Configuration class for MQTT client settings.
    This class defines the address and port for the MQTT client, providing a
    structured way to manage these settings.
    """

    registry_endpoint: str = Field(default="", description="Nodes Registry Endpoint")
    node_cluster_target: str = Field(default="", description="Nodes endpoint in the cluster")
    node_external_target: str = Field(
        default="",
        description="External URL (host:port) when the node is reachable from outside the cluster; stored in registry for is_remote resolution.",
    )
    node_namespace: str = Field(
        default="gateway",
        description=(
            "Logical deployment namespace this node registers under (e.g. 'gateway', "
            "'robot1'); disambiguates the same node class deployed on multiple hosts "
            "in the central registry and is used to compute is_remote."
        ),
    )

    registration_timeout_s: float = Field(
        default=120.0,
        description=(
            "How long the node's FIRST Consul registration keeps retrying while the "
            "agent cannot be reached. Registration runs before the gRPC server is up, "
            "so a Consul agent that is not listening yet (routine on a cluster "
            "restart) must not abort the bootstrap. When the budget runs out the node "
            "process exits and the container is restarted. Set to 0 to fail on the "
            "first attempt."
        ),
    )
    registration_retry_delay_s: float = Field(
        default=2.0,
        description=(
            "Initial delay between bootstrap registration attempts; doubles on each "
            "failure, capped at 60s."
        ),
    )

    class Config:
        extra = "allow"

"""
Node manager for handling node lifecycle and server management
"""

import asyncio
import grpc
import inject
import logging
import os
import sys
from concurrent import futures
from grpc_interceptor import ExceptionToStatusInterceptor
from grpc_reflection.v1alpha import reflection

from neuraverse.api.node_service.v1.gen import node_service_pb2
from neuraverse.api.node_service.v1.gen.node_service_pb2_grpc import (
    add_NodeServiceApiServicer_to_server,
)
from neuraverse_common.grpc.auth.interceptors.auth_interceptor import JWTAuthInterceptor
from neuraverse_common.grpc.auth.interceptors.grpc_unhandled_exception_interceptor import (
    GrpcUnhandledExceptionInterceptor,
)
from neuraverse_common.grpc.model.config_source.grpc_config import GrpcConfig
from neuraverse_common.grpc.servicer.base_api_servicer_v2 import BaseApiServicerV2
from neuraverse_common.http.model.config_source.HttpConfig import HttpConfig
from neuraverse_common.jwt.jwt_validator import JwtValidator
from neuraverse_common.models.config.config_source.JwtConfig import JwtConfig
from neuraverse_common.models.config.config_source.LogConfig import LogConfig
from neuraverse_common.models.config.config_source.MetricsConfig import MetricsConfig
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.observability.metrics import MetricsFactory
from neuraverse_common.service.base_neuraverse_service import BaseNeuraverseService

from neuraverse_sdk.api.grpc.router.node_router import NodeServiceApi
from neuraverse_sdk.api.http.http_api import serve_http
from neuraverse_sdk.controllers.node_controller import NodeController
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.node_base import NodeBase
from neuraverse_sdk.node_service_base import NodeServiceBase

# Externally provided node instance (to be set by startup script)
_externally_provided_node_classes: list[NodeBase] | None = None
# Externally provided service-level common class (subclass of NodeServiceBase).
# Optional: defaults to NodeServiceBase (no-op hooks) when the startup script
# doesn't set one.
_externally_provided_node_service_class: type[NodeServiceBase] | None = None

LOGGER = LoggerFactory.get_logger("neuraverse-node-sdk.node_manager_service")


def set_node_classes(node_classes: list[NodeBase]) -> None:
    """
    Set the NodeBase instance to be managed by this service.
    Must be called by the startup script before run().
    """
    global _externally_provided_node_classes
    _externally_provided_node_classes = node_classes
    LOGGER.info("Node classes set to %s", node_classes)


def set_node_service_class(node_service_class: type[NodeServiceBase]) -> None:
    """Set the service-level common class (a subclass of ``NodeServiceBase``)
    holding this node service's service-level hooks — e.g.
    ``on_prepare_node_dependencies``. Optional; call before run(). Defaults to
    ``NodeServiceBase`` (no-op) when unset."""
    global _externally_provided_node_service_class
    _externally_provided_node_service_class = node_service_class
    LOGGER.info("Node service class set to %s", node_service_class)


class NodeManagerService(BaseNeuraverseService):
    """
    Manages the lifecycle of a Neuraverse node, including server startup/shutdown
    """

    async def start(self) -> None:
        await super().start()
        self.server = self._serve_grpc()

        # Serve HTTP in parallel
        LOGGER.info("Serving HTTP")
        await serve_http()

    @inject.params(
        node_controller=NodeController,
        grpc_config=GrpcConfig,
        jwt_config=JwtConfig,
        node_service_config=NodeServiceConfig,
    )
    def _serve_grpc(
        self,
        node_controller: NodeController,
        grpc_config: GrpcConfig,
        jwt_config: JwtConfig,
        node_service_config: NodeServiceConfig,
    ) -> grpc.Server:
        return self.start_grpc_service(
            node_controller,
            grpc_config,
            jwt_config,
            max_workers=node_service_config.grpc_server_max_workers,
        )

    def start_grpc_service(
        self,
        node_controller: NodeController,
        grpc_config: GrpcConfig,
        jwt_config: JwtConfig,
        max_workers: int = 50,
    ) -> grpc.Server:
        unauth_methods = BaseApiServicerV2.get_unauthenticated_method_names(
            NodeServiceApi, node_service_pb2.DESCRIPTOR.package, NodeServiceApi.__name__
        )

        interceptors = [
            GrpcUnhandledExceptionInterceptor(self.LOG),
            ExceptionToStatusInterceptor(),
            JWTAuthInterceptor(unauth_methods),
        ]

        server = grpc.server(
            futures.ThreadPoolExecutor(max_workers=max_workers), interceptors=interceptors
        )
        LOGGER.info("gRPC server thread pool size: %s", max_workers)

        add_NodeServiceApiServicer_to_server(
            NodeServiceApi(node_controller, jwt_config),
            server,
        )

        # Enable reflection
        service_names = (
            node_service_pb2.DESCRIPTOR.services_by_name[
                NodeServiceApi.__name__
            ].full_name,
            reflection.SERVICE_NAME,
        )
        reflection.enable_server_reflection(service_names, server)

        server_address = f"{grpc_config.address}:{grpc_config.port}"
        server.add_insecure_port(server_address)

        server.start()
        return server

    @inject.params(service_config=NodeServiceConfig)
    def _on_configure_injection(
        self, binder: inject.Binder, service_config: NodeServiceConfig
    ) -> None:
        LOGGER.info("Configuring injection for %s", service_config)
        # Bind configurations
        binder.bind(NodeServiceConfig, service_config)
        binder.bind(GrpcConfig, service_config.grpc)
        binder.bind(HttpConfig, service_config.http)
        binder.bind(JwtConfig, service_config.jwt)
        binder.bind(LogConfig, service_config.logging)
        binder.bind(MetricsConfig, service_config.metrics)
        binder.bind(ServiceInfo, service_config.service_info)
        binder.bind(JwtValidator, JwtValidator(service_config.jwt))

        # Admin allowlist — YAML mounted from a ConfigMap at the path in
        # NEURAVERSE_ADMIN_ALLOWLIST_PATH (defaults to /etc/neuraverse/...).
        # Loaded once here; SIGHUP reloads in-place without a restart.
        # Inherited by every node template via the SDK's HTTP admin router.
        from neuraverse_sdk.api.http.admin import AdminAllowlist

        binder.bind(AdminAllowlist, AdminAllowlist())

        # Bind the externally provided node implementation
        if (
            _externally_provided_node_classes is None
            or len(_externally_provided_node_classes) == 0
        ):
            raise RuntimeError(
                "No NodeBase classes provided. Call set_node_classes(node_classes) before run()."
            )
        binder.bind(NodeBase, _externally_provided_node_classes)

        # Service-level common class: developer-provided subclass of
        # NodeServiceBase, or the no-op base when none was set.
        node_service_class = _externally_provided_node_service_class or NodeServiceBase

        # Setup controller (let inject provide the NodeBase dependency)
        #
        node_controller = NodeController(
            _externally_provided_node_classes, service_config, node_service_class
        )
        binder.bind(NodeController, node_controller)

    def _on_configure_logging(
        self, service_info: ServiceInfo, log_config: LogConfig
    ) -> None:
        LoggerFactory.configure_logging(
            logCfgFilePath=log_config.ENVVAR_LOG_CFG_PATH,
            globalLabels=self._build_service_global_labels(service_info),
        )

        # now obtain a logger and start logging from now
        self.LOG: Logger = LoggerFactory.get_logger(self.main_logger)

        self.LOG.info("logging for %s configured!", service_info.get_service_name())

    def _on_configure_metrics(
        self, service_info: ServiceInfo, metrics_config: MetricsConfig
    ) -> None:
        MetricsFactory.configure_metrics(
            config=metrics_config,
            global_labels=self._build_service_global_labels(service_info),
        )
        MetricsFactory.start_prometheus_scraping_endpoint()


def register_service_type() -> None:
    BaseNeuraverseService.type = NodeManagerService


async def bootstrap_service() -> None:
    """
    Main entry point to start both gRPC and HTTP servers concurrently.

    This function configures dependency injection, starts the gRPC server,
    and serves the HTTP API in parallel. It blocks until the gRPC server
    is terminated.
    """
    register_service_type()

    # Create an instance of the service dynamically
    service = BaseNeuraverseService.create_instance()

    service.configure(NodeServiceConfig())
    await service.start()
    LOGGER.info("Waiting for termination")
    # Wait for gRPC server termination (blocks until shutdown)
    service.wait_for_termination()


def run() -> None:
    """
    Runs the asyncio event loop.

    This function serves as the main entry point for the application, ensuring
    that the event loop is properly initialized and the main coroutine is executed.

    Exit is forced with ``os._exit`` rather than left to the interpreter: the
    node process starts non-daemon threads (logging, transport adapters,
    node-owned workers), so a dead main thread does not end the process. A
    bootstrap that failed before ``service.start()`` would otherwise linger
    forever with no gRPC server — alive as far as Kubernetes is concerned, so
    never restarted, and needing a manual pod delete.
    """
    exit_code = 0
    try:
        asyncio.run(bootstrap_service())
        LOGGER.info("Node service terminated")
    except KeyboardInterrupt:
        LOGGER.info("KeyboardInterrupt")
    except BaseException as e:
        LOGGER.error("Node service bootstrap failed — exiting: %s", e, exc_info=e)
        exit_code = 1
    _force_exit(exit_code)


def _force_exit(exit_code: int) -> None:
    """Flush logging and leave immediately, without waiting on other threads."""
    try:
        logging.shutdown()
    finally:
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(exit_code)

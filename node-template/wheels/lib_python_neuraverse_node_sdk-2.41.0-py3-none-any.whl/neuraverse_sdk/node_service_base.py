"""Service-level operations shared by all nodes in a node service.

A node service can bundle several node classes, but some operations are about
the service as a whole rather than a single node instance. The most important
is a **post-deployment dependency-preparation** step: before any node can be
initialized, the service may need to download files, fetch remote
configuration, warm caches, etc.

The node developer implements these by subclassing ``NodeServiceBase`` in a
common class placed alongside their node classes, and registering it with
``set_node_service_class(...)``. Because dependency preparation runs before any
node instance exists, the controller invokes these as **class methods** — there
is no instance to bind to.
"""

from __future__ import annotations

from typing import Any, Mapping
from neuraverse_common.observability.logging import Logger, LoggerFactory


class NodeServiceBase:
    """Base for a node service's common, service-level operations.

    Subclass it next to your node classes and override the hooks you need; the
    defaults are safe no-ops so a service without dependencies needs no override.
    """

    LOG: Logger = LoggerFactory.get_logger("service.NodeServiceBase")

    @classmethod
    def on_prepare_node_dependencies(cls, configuration: Mapping[str, Any] | None = None) -> None:
        """Prepare everything the node(s) need before they can be initialized —
        e.g. download model files, fetch remote configuration, warm caches.

        Runs once at the **service level** (not per node), before any node is
        configured or initialized, triggered by the ``PrepareNodeDependencies``
        RPC as a post-deployment step. Invoked as a **class method**: no node
        instance exists yet.

        Default: a no-op. Override in your service's subclass when the node has
        dependencies to prepare. Raise on failure to signal the caller that
        preparation did not succeed.
        """
        cls.LOG.info(
            "on_prepare_node_dependencies: nothing to prepare (default no-op for %s)",
            cls.__name__,
        )

"""
gRPC server implementation for Neuraverse Node Service
"""

from typing import Dict, Iterator

import grpc
import inject
from google.protobuf import json_format
from neuraverse.api.node_service.v1.gen import node_service_pb2
from neuraverse.api.node_service.v1.gen.node_service_pb2_grpc import (
    NodeServiceApiServicer,
)
from neuraverse.models.v1.gen.api.metadata_pb2 import ResponseMetadata
from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    ExecutionState,
    VisualizationsTopics,
)
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.grpc.auth.jwt_decorators import authenticated
from neuraverse_common.grpc.context.grpc_ecntx_handler import GrpcEcntxHandler
from neuraverse_common.grpc.servicer.base_api_servicer_v2 import BaseApiServicerV2
from neuraverse_common.models.config.config_source.JwtConfig import JwtConfig
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability.logging import LoggerFactory
from neuraverse_common.utilities.retry_logic import custom_wait
from tenacity import retry, retry_if_exception, stop_after_attempt

from neuraverse_sdk.controllers.node_controller import NodeController
from neuraverse_sdk.utils.exceptions import NodeSDKError, NodeStopError


def _is_retryable_exception(exc: BaseException) -> bool:
    """Check if the exception is retryable (has is_retryable=True)."""
    return getattr(exc, "is_retryable", False)


def _handle_rpc(
    context: ExecutionContext,
    handler_fn,
    response_builder,
    error_message_prefix: str = "Failed",
):
    """Run handler_fn(), build response via response_builder(context, result), map NodeSDKError/Exception to gRPC status."""
    try:
        result = handler_fn()
        return response_builder(context, result)
    except NodeSDKError as e:
        raise errors_v2.NeuraPublicRuntimeError(
            message=f"{error_message_prefix}. Error: {str(e)}",
        )
    except Exception as e:
        raise errors_v2.NeuraPublicRuntimeError(
            message=f"{error_message_prefix}. Error: {str(e)}",
        )


class NodeServiceApi(NodeServiceApiServicer, BaseApiServicerV2):
    @inject.params(
        node_controller=NodeController,
        jwt_config=JwtConfig,
    )
    def __init__(
        self,
        node_controller: NodeController,
        jwt_config: JwtConfig,
    ):
        super().__init__(
            logger_to_use=LoggerFactory.get_logger(f"service.api.grpc.{self.__class__.__name__}")
        )
        self.node_controller: NodeController = node_controller
        self.jwt_config: JwtConfig = jwt_config

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(max_attempt_number=2),
        reraise=True,
    )
    def _stop_node_with_retry(
        self, request: node_service_pb2.StopNodeRequest, context: ExecutionContext
    ) -> None:
        self.node_controller.stop_node(node_id=request.nodeId, cntx=context)

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def StopNode(
        self,
        request: node_service_pb2.StopNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.StopNodeResponse:
        def handler():
            self._stop_node_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.StopNodeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node stopped successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to Stop Node")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _run_node_with_retry(
        self, request: node_service_pb2.RunNodeRequest, context: ExecutionContext
    ) -> None:
        self.node_controller.execute_node_background(request.nodeId, context)

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def RunNode(
        self,
        request: node_service_pb2.RunNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.RunNodeResponse:
        def handler():
            self._run_node_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.RunNodeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node run successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to Run Node")

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def PrepareNodeDependencies(
        self,
        request: node_service_pb2.PrepareNodeDependenciesRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.PrepareNodeDependenciesResponse:
        # Service-level (not per-node) post-deployment step: prepare anything
        # the node(s) need before initialization (download files, fetch remote
        # info). Delegates to the common class's class method.
        def handler():
            configuration = {
                key: json_format.MessageToDict(value)
                for key, value in request.configuration.items()
            }
            self.node_controller.prepare_node_dependencies(context, configuration)

        def build_response(ctx, _result):
            return node_service_pb2.PrepareNodeDependenciesResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node dependencies prepared successfully",
            )

        return _handle_rpc(
            context, handler, build_response, "Failed to prepare node dependencies"
        )

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _pause_node_with_retry(
        self, request: node_service_pb2.PauseNodeRequest, context: ExecutionContext
    ) -> None:
        self.node_controller.pause_node(request.nodeId, context)

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def PauseNode(
        self,
        request: node_service_pb2.PauseNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.PauseNodeResponse:
        def handler():
            self._pause_node_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.PauseNodeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node paused successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to Pause Node")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _resume_node_with_retry(
        self, request: node_service_pb2.ResumeNodeRequest, context: ExecutionContext
    ) -> None:
        self.node_controller.resume_node(request.nodeId, context)

    def _toggle_simulation_mode_with_retry(self, request, context: ExecutionContext) -> None:
        @retry(
            retry=retry_if_exception(_is_retryable_exception),
            stop=stop_after_attempt(3),
            wait=custom_wait
        )
        def attempt():
            self.node_controller.toggle_simulation_mode(
                request.nodeId, request.isSimulation, context
            )
        attempt()

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def SetToggleSimulationMode(
        self,
        request,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ):
        # Match the StopNode / RunNode / PauseNode pattern: the
        # ``@grpc_api_method`` decorator builds the ExecutionContext from
        # the raw gRPC servicer_context and passes it as ``context``.
        # The pre-fix handler called a non-existent
        # ``GrpcEcntxHandler.get_execution_context`` and was missing the
        # decorator entirely — every cloud-edge runNodeGraph crashed at
        # the simulation-toggle step with "no attribute get_execution_context".
        def handler():
            self._toggle_simulation_mode_with_retry(request, context)

        def build_response(ctx, _result):
            # Proto field is ``meta``, not ``responseMeta`` — the pre-fix
            # code would have raised a ValueError on kwarg validation here
            # if it ever got past the get_execution_context error above.
            return node_service_pb2.ToggleSimulationModeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Simulation mode toggled successfully",
            )

        return _handle_rpc(
            context, handler, build_response, "Failed to toggle simulation mode"
        )

    def _get_health_check_with_retry(self, request, context: ExecutionContext) -> bool:
        @retry(
            retry=retry_if_exception(_is_retryable_exception),
            stop=stop_after_attempt(3),
            wait=custom_wait
        )
        def attempt() -> bool:
            return self.node_controller.get_health_check(request.nodeId, context)
        return attempt()

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def GetHealthCheck(
        self,
        request,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ):
        def handler():
            return self._get_health_check_with_retry(request, context)

        def build_response(ctx, result: tuple[bool, str]):
            is_healthy, message = result
            return node_service_pb2.GetHealthCheckResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                isHealthy=is_healthy,
                resultCode="SUCCESS",
                resultMessage=message,
            )

        return _handle_rpc(
            context, handler, build_response, "Failed to perform health check"
        )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def ResumeNode(
        self,
        request: node_service_pb2.ResumeNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.ResumeNodeResponse:
        def handler():
            self._resume_node_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.ResumeNodeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node resumed successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to Resume Node")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _configure_node_with_retry(
        self, request: node_service_pb2.ConfigureNodeRequest, context: ExecutionContext
    ) -> None:
        self.node_controller.configure_node(request.node, context)

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def ConfigureNode(
        self,
        request: node_service_pb2.ConfigureNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.ConfigureNodeResponse:
        def handler():
            self._configure_node_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.ConfigureNodeResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node configured successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to Configure Node")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _initialize_node_with_retry(
        self, request: node_service_pb2.InitializeNodeRequest, context: ExecutionContext
    ) -> None:
        if not request.projectId:
            raise errors_v2.NeuraPublicValidationError(
                message="InitializeNode request is missing projectId.",
            )
        if not request.nodeId:
            raise errors_v2.NeuraPublicValidationError(
                message="InitializeNode request is missing nodeId.",
            )

        if not request.className:
            raise errors_v2.NeuraPublicValidationError(
                message="InitializeNode request is missing className.",
            )
        node_config = self.node_controller.initialize_node(
            project_id=request.projectId,
            node_id=request.nodeId,
            class_name=request.className,
            cntx=context,
        )

        return node_service_pb2.InitializeNodeResponse(
            meta=GrpcEcntxHandler.get_response_meta(context) or ResponseMetadata(),
            configuration=node_config,
            resultCode="SUCCESS",
            resultMessage="Node initialized successfully",
        )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def InitializeNode(
        self,
        request: node_service_pb2.InitializeNodeRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.InitializeNodeResponse:
        def handler():
            return self._initialize_node_with_retry(request, context)

        def build_response(ctx, result):
            return result

        return _handle_rpc(context, handler, build_response, "Failed to Initialize Node")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _get_node_configuration_with_retry(
        self,
        request: node_service_pb2.GetNodeConfigurationRequest,
        context: ExecutionContext,
    ) -> dict[str, str]:
        return self.node_controller.get_node_configuration(request.nodeId, context)

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def GetNodeConfiguration(
        self,
        request: node_service_pb2.GetNodeConfigurationRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.GetNodeConfigurationResponse:
        def handler():
            return self._get_node_configuration_with_retry(request, context)

        def build_response(ctx, config_result):
            return node_service_pb2.GetNodeConfigurationResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Node configuration retrieved successfully",
                configuration=config_result,
                nodeJson="",
            )

        return _handle_rpc(context, handler, build_response, "Failed to get node configuration")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _get_node_metrics_with_retry(
        self, request: node_service_pb2.GetNodeMetricsRequest, context: ExecutionContext
    ):
        pass

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def GetNodeMetrics(
        self,
        request: node_service_pb2.GetNodeMetricsRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.GetNodeMetricsResponse:
        raise NotImplementedError("GetNodeMetrics is not implemented")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _get_node_logs_with_retry(
        self, request: node_service_pb2.GetNodeLogsRequest, context: ExecutionContext
    ):
        pass

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def GetNodeLogs(
        self,
        request: node_service_pb2.GetNodeLogsRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.GetNodeLogsResponse:
        raise NotImplementedError("GetNodeLogs is not implemented")

    def _get_status_generator(
        self,
        node_id: str,
        context: ExecutionContext,
        servicer_context: grpc.ServicerContext | None = None,
    ) -> Iterator[dict]:
        try:
            return self.node_controller.subscribe_node_status_stream(
                node_id, context, servicer_context=servicer_context
            )
        except Exception as e:
            self._LOG.error(f"Failed to get status generator. Error: {str(e)}")
            raise errors_v2.NeuraPublicRuntimeError(
                message=f"Failed to subscribe to node status stream. Error: {str(e)}",
            )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def SubscribeNodeStatusStream(
        self,
        request: node_service_pb2.SubscribeNodeStatusStreamRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> Iterator[node_service_pb2.SubscribeNodeStatusStreamResponse]:
        self._LOG.debug(
            "SubscribeNodeStatusStream starting node_id=%s",
            request.nodeId,
        )
        status_generator = self._get_status_generator(
            request.nodeId, context, servicer_context=servicer_context
        )

        try:
            _yield_index = 0
            for result in status_generator:
                if not servicer_context.is_active():
                    self._LOG.debug(
                        "SubscribeNodeStatusStream inactive context (client gone) node_id=%s",
                        request.nodeId,
                    )
                    return  # Gracefully exit

                if not isinstance(result, dict) or "nodeId" not in result:
                    self._LOG.warning(f"Invalid status update: {result}")
                    continue

                _yield_index += 1
                if _yield_index == 1:
                    self._LOG.debug(
                        "SubscribeNodeStatusStream first yield node_id=%s",
                        result.get("nodeId", ""),
                    )

                response = node_service_pb2.SubscribeNodeStatusStreamResponse(
                    meta=GrpcEcntxHandler.get_response_meta(context) or ResponseMetadata(),
                    nodeId=result["nodeId"],
                    state=result.get("state", ""),
                    resultCode=str(result.get("resultCode", 0)),
                    resultMessage=result.get("resultMessage", ""),
                )
                yield response

        except Exception as e:
            self._LOG.error(f"Node status stream failed: {str(e)}")
            servicer_context.set_code(grpc.StatusCode.INTERNAL)
            servicer_context.set_details(f"Stream failed: {str(e)}")

    def _get_health_generator(
        self,
        node_id: str,
        context: ExecutionContext,
        servicer_context: grpc.ServicerContext | None = None,
    ) -> Iterator[dict]:
        try:
            return self.node_controller.subscribe_node_health_stream(
                node_id, context, servicer_context=servicer_context
            )
        except Exception as e:
            self._LOG.error(f"Failed to get health generator. Error: {str(e)}")
            raise errors_v2.NeuraPublicRuntimeError(
                message=f"Failed to subscribe to node health stream. Error: {str(e)}",
            )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def SubscribeNodeHealthStream(
        self,
        request: node_service_pb2.SubscribeNodeHealthStreamRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> Iterator[node_service_pb2.SubscribeNodeHealthStreamResponse]:
        self._LOG.debug(
            "SubscribeNodeHealthStream starting node_id=%s",
            request.nodeId,
        )
        health_generator = self._get_health_generator(
            request.nodeId, context, servicer_context=servicer_context
        )

        try:
            for result in health_generator:
                if not servicer_context.is_active():
                    return

                if not isinstance(result, dict) or "nodeId" not in result:
                    self._LOG.warning(f"Invalid health update: {result}")
                    continue

                response = node_service_pb2.SubscribeNodeHealthStreamResponse(
                    meta=GrpcEcntxHandler.get_response_meta(context) or ResponseMetadata(),
                    nodeId=result["nodeId"],
                    isHealthy=result.get("isHealthy", False),
                    resultMessage=result.get("resultMessage", ""),
                )
                yield response

        except Exception as e:
            self._LOG.error(f"Node health stream failed: {str(e)}")
            servicer_context.set_code(grpc.StatusCode.INTERNAL)
            servicer_context.set_details(f"Stream failed: {str(e)}")

    def _get_visualization_topics(self) -> Dict[str, VisualizationsTopics]:
        return self.node_controller.get_data_visualization_topics()

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def GetDataVisualizationTopics(
        self,
        request: node_service_pb2.GetNodeDataVisualizationTopicsRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.GetNodeDataVisualizationTopicsResponse:
        try:
            response = node_service_pb2.GetNodeDataVisualizationTopicsResponse(
                meta=GrpcEcntxHandler.get_response_meta(context) or ResponseMetadata(),
                visualizationTopics=self._get_visualization_topics(),
            )
            return response

        except Exception as e:
            self._LOG.error(f"Fetching data visualization topics failed: {str(e)}")
            servicer_context.set_code(grpc.StatusCode.INTERNAL)
            servicer_context.set_details(f"Request Failed: {str(e)}")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _start_data_visualization_with_retry(
        self,
        request: node_service_pb2.StartNodeDataVisualizationRequest,
        context: ExecutionContext,
    ) -> None:
        self.node_controller.start_data_visualization(
            node_id=request.nodeId,
            room_name=request.roomName,
            publisher_token=request.publisherToken,
            livekit_url=request.livekitUrl,
            topic_names=list(request.topicNames),
            ice_servers=[
                {
                    "urls": list(s.urls),
                    "username": s.username,
                    "credential": s.credential,
                }
                for s in request.iceServers
            ],
        )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def StartNodeDataVisualization(
        self,
        request: node_service_pb2.StartNodeDataVisualizationRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.StartNodeDataVisualizationResponse:
        def handler():
            self._start_data_visualization_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.StartNodeDataVisualizationResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Data visualization started successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to start data visualization")

    @retry(
        retry=retry_if_exception(_is_retryable_exception),
        wait=custom_wait,
        stop=stop_after_attempt(2),
        reraise=True,
    )
    def _stop_data_visualization_with_retry(
        self,
        request: node_service_pb2.StopNodeDataVisualizationRequest,
        context: ExecutionContext,
    ) -> None:
        self.node_controller.stop_data_visualization(
            node_id=request.nodeId,
            room_name=request.roomName,
        )

    @authenticated()
    @BaseApiServicerV2.grpc_api_method(lambda: inject.instance(ServiceInfo))
    def StopNodeDataVisualization(
        self,
        request: node_service_pb2.StopNodeDataVisualizationRequest,
        servicer_context: grpc.ServicerContext,
        context: ExecutionContext,
    ) -> node_service_pb2.StopNodeDataVisualizationResponse:
        def handler():
            self._stop_data_visualization_with_retry(request, context)

        def build_response(ctx, _result):
            return node_service_pb2.StopNodeDataVisualizationResponse(
                meta=GrpcEcntxHandler.get_response_meta(ctx) or ResponseMetadata(),
                resultCode="SUCCESS",
                resultMessage="Data visualization stopped successfully",
            )

        return _handle_rpc(context, handler, build_response, "Failed to stop data visualization")

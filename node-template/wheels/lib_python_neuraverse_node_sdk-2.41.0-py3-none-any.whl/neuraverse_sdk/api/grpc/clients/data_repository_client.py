import grpc
from typing import Dict, Callable, List, Tuple, Optional, Union

from google.protobuf.struct_pb2 import Value
from google.protobuf import json_format

from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.grpc.context.grpc_ecntx_handler import GrpcEcntxHandler

from neuraverse.api.node_engine_service.v1.gen.nodegraph_api_pb2 import (
    CreateDataRequest,
    GetDataRequest,
    GetDataResponse,
    UpdateDataRequest,
    DeleteDataRequest,
)
from neuraverse.api.node_engine_service.v1.gen.nodegraph_api_pb2_grpc import NodeEngineApiStub

_RPC_TIMEOUT_SEC: int = 10

JsonValue = Union[None, int, float, str, bool, List["JsonValue"], Dict[str, "JsonValue"]]

def _value_to_json(value: Value) -> JsonValue:
    """
    Convert a Value to a JsonValue.
    """
    return json_format.MessageToDict(value)

def _json_to_value(value: JsonValue) -> Value:
    """
    Convert a JsonValue to a Value.
    """
    return json_format.ParseDict(value, Value())

class DataRepositoryClient:

    def __init__(self) -> None:

        self.endpoint: str = ""

        self._LOG: Logger = LoggerFactory.get_logger(f'service.api.grpc.clients.{self.__class__.__name__}')
        self._auth_metadata_provider: Optional[Callable[[ExecutionContext], List[Tuple[str, str]]]] = None

    def init(
        self, 
        endpoint: str,
        use_tls: bool = True,
        auth_meta_provider: Optional[Callable[[ExecutionContext], List[Tuple[str, str]]]] = None):

        self.endpoint = endpoint

        if use_tls:
            self.channel = grpc.secure_channel(self.endpoint, grpc.ssl_channel_credentials())
        else:
            self.channel = grpc.insecure_channel(self.endpoint)
            
        self.stub = NodeEngineApiStub(self.channel)
        self.grpc_context_handler = GrpcEcntxHandler()
        self._auth_metadata_provider = auth_meta_provider
    

        self._LOG.info("DataRepositoryClient initialized")
    
    def _auth(self, context: ExecutionContext) -> List[Tuple[str, str]]:

        if self._auth_metadata_provider is not None:
            return self._auth_metadata_provider(context)
        
        return self.grpc_context_handler.get_grpc_auth_metadata(context=context)
    
    def create_data(self, context: ExecutionContext, namespace: str, key: str, value: JsonValue) -> None:
        """
        Create a data in the data repository.
        """

        meta = self.grpc_context_handler.get_request_meta(context=context) 

        request: CreateDataRequest = CreateDataRequest(
            meta=meta,
            namespace=namespace,
            key=key,
            value=_json_to_value(value)
        )

        try:
            self.stub.CreateData(request, metadata=self._auth(context), timeout=_RPC_TIMEOUT_SEC)
        except grpc.RpcError as e:
            self._LOG.error(f"Error creating data for {namespace}/{key}: {e.code()} {e.details()}")
            raise
        
        self._LOG.debug(f"Data created: {namespace}/{key}")
    
    def get_data(self, context: ExecutionContext, namespace: str, key: str) -> JsonValue:
        """
        Get a data from the data repository.
        """

        meta = self.grpc_context_handler.get_request_meta(context=context)

        request: GetDataRequest = GetDataRequest(
            meta=meta,
            namespace=namespace,
            key=key
        )

        try:
            response: GetDataResponse = self.stub.GetData(request, metadata=self._auth(context), timeout=_RPC_TIMEOUT_SEC)
        except grpc.RpcError as e:
            self._LOG.error(f"Error getting data for {namespace}/{key}: {e.code()} {e.details()}")
            raise
        
        self._LOG.debug(f"Data retrieved: {namespace}/{key}")

        return _value_to_json(response.value)
    
    def update_data(self, context: ExecutionContext, namespace: str, key: str, value: JsonValue) -> None:
        """
        Update a data in the data repository.
        """

        meta = self.grpc_context_handler.get_request_meta(context=context)

        request: UpdateDataRequest = UpdateDataRequest(
            meta=meta,
            namespace=namespace,
            key=key,
            value=_json_to_value(value)
        )

        try:
            self.stub.UpdateData(request, metadata=self._auth(context), timeout=_RPC_TIMEOUT_SEC)
        except grpc.RpcError as e:
            self._LOG.error(f"Error updating data for {namespace}/{key}: {e.code()} {e.details()}")
            raise
        
        self._LOG.debug(f"Data updated: {namespace}/{key}")

    def delete_data(self, context: ExecutionContext, namespace: str, key: str) -> None:
        """
        Delete a data from the data repository.
        """

        meta = self.grpc_context_handler.get_request_meta(context=context)

        request: DeleteDataRequest = DeleteDataRequest(
            meta=meta,
            namespace=namespace,
            key=key
        )

        try:
            self.stub.DeleteData(request, metadata=self._auth(context), timeout=_RPC_TIMEOUT_SEC)
        except grpc.RpcError as e:
            self._LOG.error(f"Error deleting data for {namespace}/{key}: {e.code()} {e.details()}")
            raise
        
        self._LOG.debug(f"Data deleted: {namespace}/{key}")

    def close(self) -> None:
        """
        Close the DataRepositoryClient.
        """
        
        self._LOG.info("Closing DataRepositoryClient")
        try:
            if hasattr(self, "channel") and self.channel:
                self.channel.close()
        except Exception as e:
            self._LOG.error(f"Error closing DataRepositoryClient: {e}")
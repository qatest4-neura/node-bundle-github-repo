import json
import os
import threading
import time
from contextlib import contextmanager
from typing import Any

import consul
import requests
from google.protobuf.json_format import MessageToDict
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.observability.logging import Logger, LoggerFactory

# A Consul agent that cannot be reached is an expected condition, not a
# failure: on a cluster restart the node pod frequently wins the race
# against the Consul agent's listener. These are the errors worth waiting
# out; anything else (a bad endpoint, a rejected payload) is a real defect
# and must surface immediately.
RETRYABLE_REGISTRATION_ERRORS = (
    requests.exceptions.RequestException,
    consul.ConsulException,
    OSError,
)

# How long the FIRST registration of a client keeps retrying, and the
# initial delay between attempts (doubling, capped at the delay ceiling).
DEFAULT_REGISTRATION_TIMEOUT_S = float(
    os.getenv("NEURAVERSE_CONSUL_REGISTRATION_TIMEOUT_S", "120")
)
DEFAULT_REGISTRATION_RETRY_DELAY_S = float(
    os.getenv("NEURAVERSE_CONSUL_REGISTRATION_RETRY_DELAY_S", "2")
)


class ServiceRegistryClient:
    """
    gRPC client for interacting with the Node Service API.
    This client provides methods to handle node lifetime functions.

    One client owns one Consul HTTP session and one ``ConsulHealthCheck``
    monitor thread, and can track any number of service registrations
    (one per capability/service ID). Node services share a single client
    per (endpoint, token) — see
    ``neuraverse_sdk.controllers.service_registry_repository`` — so node
    instance churn never multiplies connections or monitor threads
    (NRV-10272: unbounded per-instance clients tripped Consul's per-IP
    ``http_max_conns_per_client`` limit and everything got 429s).
    """

    def __init__(
        self,
        consul_url: str,
        token=None,
        registration_timeout_s: float | None = None,
        registration_retry_delay_s: float | None = None,
    ):
        self._LOG: Logger = LoggerFactory.get_logger(
            f"service.api.grpc.clients.{self.__class__.__name__}"
        )
        consul_address, consul_port = consul_url.split(":")
        self.consul = consul.Consul(host=consul_address, port=int(consul_port), token=token)
        self.consul_url = consul_url
        self.token = token
        # All registrations this client is responsible for, keyed by Consul
        # service ID (== service name for non-namespaced registrations, which
        # matches how agent.services() keys its response). Used for
        # re-registration when a registration drops out of Consul.
        self._registrations: dict[str, dict] = {}
        self._registrations_lock = threading.Lock()
        self._health_check_thread: threading.Thread | None = None
        self._monitor_lock = threading.Lock()
        self._should_monitor = False
        self._stop_event = threading.Event()
        self._health_check_interval = 30
        self._reconnect_delay = 5
        self._max_reconnect_delay = 60
        # Bootstrap registration retry budget — see ``register_node``.
        # Supplied by ``RegistryConfig`` (registration_timeout_s /
        # registration_retry_delay_s); the env-var defaults apply to callers
        # that construct the client directly.
        self._registration_timeout = (
            DEFAULT_REGISTRATION_TIMEOUT_S
            if registration_timeout_s is None
            else float(registration_timeout_s)
        )
        # Floored: a zero delay would spin through the whole budget.
        self._registration_retry_delay = max(
            0.1,
            (
                DEFAULT_REGISTRATION_RETRY_DELAY_S
                if registration_retry_delay_s is None
                else float(registration_retry_delay_s)
            ),
        )

    def _store_configurations_in_kv(
        self,
        service_name: str,
        node_configurations,
        namespace: str = "",
        container: str = "",
    ) -> None:
        """Store node configurations in Consul KV as a JSON blob, preserving full NodeConfigEntry structure.

        Keyed by the same identity as the schema blob: two devices running the
        same node class write different keys instead of racing for one.
        """
        kv_key = self._kv_config_key(service_name, namespace, container)
        config_dict = {}
        for key, entry in node_configurations.items():
            if isinstance(entry, str):
                config_dict[key] = entry
            else:
                config_dict[key] = MessageToDict(entry, preserving_proto_field_name=True)
        payload = json.dumps(config_dict)
        self.consul.kv.put(kv_key, payload)
        self._LOG.info(f"Stored node configurations in KV at '{kv_key}'")

    @staticmethod
    def _kv_config_key(service_name: str, namespace: str, container: str) -> str:
        """Namespaced configuration key. Without a namespace there is nothing to
        separate by, so the pre-discovery flat key stays in use."""
        if not namespace:
            return f"capability/{service_name}/configurations"
        if not container:
            return f"capability/{service_name}/{namespace}/configurations"
        return f"capability/{service_name}/{namespace}/{container}/configurations"

    def _store_schema_in_kv(
        self,
        namespace: str,
        container: str,
        node_name: str,
        schema_envelope: dict[str, Any] | None,
    ) -> None:
        """Store the full node schema envelope in Consul KV for discovery (GetAvailableNodes)."""
        if not namespace or not schema_envelope:
            return
        kv_key = f"available-nodes/{namespace}/{container}/{node_name}/schema"
        if not container:
            kv_key = f"available-nodes/{namespace}/{node_name}/schema"
        self.consul.kv.put(kv_key, json.dumps(schema_envelope))
        self._LOG.info(f"Stored node schema in KV at '{kv_key}'")

    def _build_meta(
        self,
        node_configurations,
        namespace: str = "",
        node_name: str = "",
        schema_envelope: dict[str, Any] | None = None,
    ) -> dict[str, str]:
        entry = node_configurations["node_external_target"]
        meta = {"node_external_target": entry.configValue.stringValue if entry else ""}
        if namespace:
            meta["namespace"] = namespace
            meta["container"] = self._container_from_envelope(schema_envelope)
            meta["name"] = node_name
            meta["version"] = (schema_envelope or {}).get("version", "")
        return meta

    @staticmethod
    def _node_name_from_envelope(schema_envelope: dict[str, Any] | None, fallback: str) -> str:
        """The node's registry identity is its schema name; the class name is only
        used as a fallback (and lives in schema.executionContext.className)."""
        return (schema_envelope or {}).get("name") or fallback

    @staticmethod
    def _container_from_envelope(schema_envelope: dict[str, Any] | None) -> str:
        """Container the node service runs in; part of the registry identity so two
        containers shipping equally-named nodes don't collide within a namespace."""
        return (schema_envelope or {}).get("container", "") or ""

    @staticmethod
    def _resolve_check_endpoint(
        node_configurations, node_address: str, node_port: int
    ) -> tuple[str, int]:
        """Health-check target: node_external_target is how Consul reaches the node
        when it is remote; node_cluster_target (the registered address) is how Consul
        reaches it when it is not remote. Prefer the external target when configured."""
        try:
            entry = node_configurations.get("node_external_target")
        except AttributeError:
            entry = None
        external = entry.configValue.stringValue if entry else ""
        if external and ":" in external:
            host, port = external.rsplit(":", 1)
            try:
                return host, int(port)
            except ValueError:
                pass
        return node_address, node_port

    @contextmanager
    def _log_method_invocation(
        self,
        method_name: str,
        cntx: ExecutionContext | None = None,
        params: dict[str, str] | None = None,
    ):
        """
        Context manager for logging method entry and exit with provided parameters passed to the method optionally.
        """
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        if params:
            log_labels.update(params)
        yield log_labels

    def register_node(
        self,
        node_endpoint: str,
        capability_name: str,
        node_configurations,
        namespace: str = "",
        schema_envelope: dict[str, Any] | None = None,
    ):
        """
        Register the node.

        When a namespace is provided, the service is registered with a namespaced
        service ID (unique per Consul agent, so the same class deployed on several
        hosts does not overwrite itself on a central registry) and the schema
        envelope is stored in KV for discovery via GetAvailableNodes.

        Registering the same capability again (node instance churn) overwrites
        the stored registration info and performs an idempotent Consul update —
        it does not create additional monitor state.

        The FIRST registration on a client is the process bootstrap: it runs
        while dependency injection is wired, before any gRPC server exists.
        A Consul agent that is not up yet (routine on a cluster restart) must
        not abort that bootstrap, so the attempt is retried for up to
        ``_registration_timeout`` seconds. If it still fails, the registration
        is NOT recorded and the monitor is NOT started: a node that never
        registered must not be advertised to the rest of the system by a
        background thread while nothing serves its port (NRV consul reconnect
        loop).

        Later registrations happen with the servers already up, so a transient
        failure there is recorded and left to the monitor to heal.
        """
        try:
            service_name = f"capability-{capability_name}"
            container = self._container_from_envelope(schema_envelope)
            service_id = service_name
            if namespace:
                # namespace disambiguates hosts; container disambiguates node
                # containers shipping equally-named node classes on one host
                service_id = f"{service_name}-{namespace}"
                if container:
                    service_id = f"{service_id}-{container}"
            node_address, node_port = node_endpoint.split(":")
            node_port_int = int(node_port)
            check_address, check_port = self._resolve_check_endpoint(
                node_configurations, node_address, node_port_int
            )
            info = {
                "node_endpoint": node_endpoint,
                "capability_name": capability_name,
                "node_configurations": node_configurations,
                "service_name": service_name,
                "service_id": service_id,
                "namespace": namespace,
                "schema_envelope": schema_envelope,
                "node_address": node_address,
                "node_port": node_port_int,
                "check_address": check_address,
                "check_port": check_port,
            }
            is_bootstrap = not self._is_monitoring()
            if not is_bootstrap:
                # Servers are already up: record before attempting so the
                # running monitor can heal a transient failure.
                with self._registrations_lock:
                    self._registrations[service_id] = info
            success = self._register_with_retries(info, retry=is_bootstrap)
            if not success:
                raise Exception("Failed to register instance service_name")
            with self._registrations_lock:
                self._registrations[service_id] = info
            self._LOG.info(f"Registered instance {service_name} for capability '{service_name}'")
            self._start_health_check_monitoring()
            return success
        except Exception as e:
            self._LOG.error(f"Failed to initialize node {e}")
            raise e

    def _is_monitoring(self) -> bool:
        """Whether the background health-check monitor is running."""
        with self._monitor_lock:
            return bool(self._health_check_thread and self._health_check_thread.is_alive())

    def _register_with_retries(self, info: dict, retry: bool) -> bool:
        """Register with Consul, waiting out a not-yet-reachable agent.

        With ``retry`` the call keeps trying until ``_registration_timeout``
        elapses, but only for errors that mean "Consul could not be reached"
        (see ``RETRYABLE_REGISTRATION_ERRORS``). A rejected payload or a bad
        endpoint is a defect and propagates on the first attempt.
        """
        delay = self._registration_retry_delay
        deadline = time.monotonic() + (self._registration_timeout if retry else 0.0)
        attempt = 0
        while True:
            attempt += 1
            try:
                return self._register_raw(info)
            except RETRYABLE_REGISTRATION_ERRORS as e:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise
                self._LOG.warning(
                    "Consul not reachable for registration of "
                    f"'{info['service_name']}' (attempt {attempt}): {e}. "
                    f"Retrying in {delay:.0f}s ({remaining:.0f}s of budget left)"
                )
                self._stop_event.wait(min(delay, remaining))
                delay = min(delay * 2, self._max_reconnect_delay)

    def _register_raw(self, info: dict) -> bool:
        """One registration attempt: Consul service register plus the KV writes.

        Raises whatever Consul/requests raise — the caller decides whether the
        failure is worth retrying.
        """
        if self.consul is None:
            consul_address, consul_port = self.consul_url.split(":")
            self.consul = consul.Consul(
                host=consul_address, port=int(consul_port), token=self.token
            )
        service_name = info["service_name"]
        namespace = info["namespace"]
        schema_envelope = info["schema_envelope"]
        container = self._container_from_envelope(schema_envelope)
        node_name = self._node_name_from_envelope(schema_envelope, info["capability_name"])
        meta = self._build_meta(
            info["node_configurations"], namespace, node_name, schema_envelope
        )
        self._LOG.info(f"Registering node '{service_name}' with Consul")
        id_kwargs = {"service_id": info["service_id"]} if namespace else {}
        success = self.consul.agent.service.register(
            name=service_name,
            address=info["node_address"],
            port=info["node_port"],
            check=consul.Check.tcp(
                info["check_address"],
                info["check_port"],
                interval="10s",
                timeout="5s",
                deregister="1m",
            ),
            meta=meta,
            **id_kwargs,
        )
        self._store_configurations_in_kv(
            service_name, info["node_configurations"], namespace, container
        )
        self._store_schema_in_kv(namespace, container, node_name, schema_envelope)
        return success

    def _do_register(
        self,
        service_name: str,
        node_address: str,
        node_port: int,
        node_configurations,
        service_id: str = "",
        namespace: str = "",
        capability_name: str = "",
        schema_envelope: dict[str, Any] | None = None,
        check_address: str = "",
        check_port: int = 0,
    ) -> bool:
        """Perform the actual registration with Consul (used for re-registration)."""
        try:
            if self.consul is None:
                consul_address, consul_port = self.consul_url.split(":")
                self.consul = consul.Consul(
                    host=consul_address, port=int(consul_port), token=self.token
                )
            node_name = self._node_name_from_envelope(schema_envelope, capability_name)
            id_kwargs = {"service_id": service_id} if namespace and service_id else {}
            success = self.consul.agent.service.register(
                name=service_name,
                address=node_address,
                port=node_port,
                check=consul.Check.tcp(
                    check_address or node_address,
                    check_port or node_port,
                    interval="10s",
                    timeout="5s",
                    deregister="1m",
                ),
                meta=self._build_meta(node_configurations, namespace, node_name, schema_envelope),
                **id_kwargs,
            )
            if success:
                container = self._container_from_envelope(schema_envelope)
                self._store_configurations_in_kv(
                    service_name, node_configurations, namespace, container
                )
                self._store_schema_in_kv(
                    namespace,
                    container,
                    node_name,
                    schema_envelope,
                )
            return success
        except Exception as e:
            self._LOG.warning(f"Registration attempt failed: {e}")
            return False

    def _start_health_check_monitoring(self):
        """Start the background monitor thread (at most one per client).

        Guarded by a lock: registrations arrive from concurrent gRPC worker
        threads (node bind/init), and the check-then-start below must not
        race into two ``ConsulHealthCheck`` threads.
        """
        with self._monitor_lock:
            if self._health_check_thread and self._health_check_thread.is_alive():
                return
            self._stop_event.clear()
            self._should_monitor = True
            self._health_check_thread = threading.Thread(
                target=self._health_check_worker, daemon=True, name="ConsulHealthCheck"
            )
            self._health_check_thread.start()
        self._LOG.info("Started Consul health check monitoring")

    def _health_check_worker(self):
        """Background worker validating all registrations against Consul.

        One ``agent.services()`` call per cycle covers every registration.
        A transport/HTTP error (Consul down, 429 rate limit, ...) means
        "could not ask", NOT "not registered" — re-registering on it would
        add load to an already-struggling agent (the NRV-10272 feedback
        loop), so the worker only backs off and retries the check.
        """
        while self._should_monitor and not self._stop_event.is_set():
            try:
                if self._stop_event.wait(self._health_check_interval):
                    break
                with self._registrations_lock:
                    service_ids = list(self._registrations)
                if not service_ids:
                    continue
                services = self._fetch_registered_services()
                if services is None:
                    self._LOG.warning(
                        "Consul health check inconclusive (transport/HTTP error); "
                        f"backing off {self._reconnect_delay}s without re-registering"
                    )
                    self._apply_backoff()
                    continue
                # agent.services() is keyed by service ID (== name only for
                # non-namespaced registrations).
                missing = [sid for sid in service_ids if sid not in services]
                for service_id in missing:
                    self._LOG.warning(
                        f"Service {service_id} not found in Consul. Attempting to re-register..."
                    )
                    self._attempt_re_register(service_id)
                if not missing:
                    self._reconnect_delay = 5
            except Exception as e:
                self._LOG.error(f"Error in health check worker: {e}")
                self._apply_backoff()

    def _fetch_registered_services(self) -> dict | None:
        """Fetch all services registered with the Consul agent.

        Returns ``None`` when the agent could not be asked (transport or
        HTTP error) — callers must treat that as "unknown", never as
        "not registered".
        """
        try:
            if self.consul is None:
                consul_address, consul_port = self.consul_url.split(":")
                self.consul = consul.Consul(
                    host=consul_address, port=int(consul_port), token=self.token
                )
            return self.consul.agent.services()
        except Exception as e:
            self._LOG.warning("Error checking service registration: %s", e)
            return None

    def _check_service_registered(self, service_id: str) -> bool | None:
        """Tristate registration check for a single service ID.

        ``True``/``False`` when Consul answered; ``None`` when it could not
        be asked (transport/HTTP error such as a 429 rate limit).
        """
        services = self._fetch_registered_services()
        if services is None:
            return None
        return service_id in services

    def _apply_backoff(self):
        """Wait out the current reconnect delay, then double it (capped).

        Waits on the stop event rather than sleeping so ``stop_monitoring()``
        stays responsive.
        """
        self._stop_event.wait(self._reconnect_delay)
        self._reconnect_delay = min(self._reconnect_delay * 2, self._max_reconnect_delay)

    def _attempt_re_register(self, service_id: str):
        """Attempt to re-register one service with exponential backoff."""
        with self._registrations_lock:
            info = self._registrations.get(service_id)
        if not info:
            return
        try:
            success = self._do_register(
                info["service_name"],
                info["node_address"],
                info["node_port"],
                info["node_configurations"],
                service_id=info.get("service_id", ""),
                namespace=info.get("namespace", ""),
                capability_name=info.get("capability_name", ""),
                schema_envelope=info.get("schema_envelope"),
                check_address=info.get("check_address", ""),
                check_port=info.get("check_port", 0),
            )
            if success:
                self._LOG.info(
                    f"Successfully re-registered service {info['service_name']} with Consul"
                )
                self._reconnect_delay = 5
            else:
                self._LOG.warning(
                    f"Re-registration failed. Will retry in {self._reconnect_delay} seconds"
                )
                self._apply_backoff()
        except Exception as e:
            self._LOG.error(f"Error during re-registration attempt: {e}")
            self._apply_backoff()

    def stop_monitoring(self):
        """Stop the health check monitoring thread.

        On a shared client this stops monitoring for ALL registrations made
        through this (endpoint, token) client. Production code never calls
        it — the monitor deliberately lives for the process lifetime; it
        exists for tests and controlled teardown.
        """
        self._should_monitor = False
        self._stop_event.set()
        if self._health_check_thread and self._health_check_thread.is_alive():
            self._health_check_thread.join(timeout=5)
        self._LOG.info("Stopped Consul health check monitoring")

    def unregister_node(self, context: ExecutionContext):
        """
        Unregister the node.
        """
        self.stop_monitoring()
        with self._registrations_lock:
            service_ids = list(self._registrations)
        for service_id in service_ids:
            try:
                self.consul.agent.service.deregister(service_id)
                self._LOG.info(f"Deregistered service {service_id} from Consul")
            except Exception as e:
                self._LOG.error(f"Error deregistering service: {e}")
        raise NotImplementedError("Unregister node is not implemented")

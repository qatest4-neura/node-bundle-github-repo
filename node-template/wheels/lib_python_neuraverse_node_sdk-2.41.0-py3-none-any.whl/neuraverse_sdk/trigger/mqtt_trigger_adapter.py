from typing import Any, Callable, Dict

from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from pydantic import ValidationError

from neuraverse_sdk.trigger.i_trigger import (
    BUILTIN_TRIGGER_NAMES,
    ITrigger,
    TriggerContext,
    TriggerType,
)
from neuraverse_sdk.utils.exceptions import TriggerFlowException
from neuraverse_sdk.utils.mqtt_singleton import MQTTHandler, Subscription

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.adapter.MQTTTriggerAdapter")


class MQTTTriggerAdapter(ITrigger):
    """MQTT trigger adapter."""

    def __init__(self):
        super().__init__()
        # Subscription handles for our own trigger inputs, indexed by topic
        # so destroy() can release exactly what this adapter registered
        # without touching other adapters sharing the singleton.
        self._subscriptions: Dict[str, Subscription] = {}
        # Tracks whether this adapter owns one outstanding connect() ref on
        # the singleton, so repeated configure() calls don't keep bumping
        # the refcount and leaking it past destroy().
        self._holds_connect_ref = False

    def init(self, configuration: Any) -> None:
        """Initialize the MQTT trigger adapter."""
        # client_id is managed by the MQTTHandler singleton so a single
        # stable identity is used across all adapters in this process.
        self.mqtt_client: MQTTHandler = MQTTHandler()
        self.mqtt_client.configure(configuration)
        if self.mqtt_client.connect(blocking=True, timeout=10.0):
            self._holds_connect_ref = True
            LOGGER.info("Successfully connected to MQTT broker")
        else:
            LOGGER.error("Failed to connect to MQTT broker")
            raise ConnectionError("Failed to connect to MQTT broker")

    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """Configure the MQTT trigger adapter with the given configuration.

        Idempotent across repeated calls: any handles from a prior
        configure() are released first. Without this, each reconfigure
        would leak a callback into the MQTTHandler singleton's per-topic
        fan-out list, and every incoming trigger would fire execute()
        once per leaked handle.
        """
        if not self._holds_connect_ref:
            LOGGER.info("MQTT client not connected; reconnecting before configure")
            if not self.mqtt_client.connect(blocking=True, timeout=10.0):
                raise TriggerFlowException("Failed to reconnect to MQTT broker before configure")
            self._holds_connect_ref = True
        for handle in self._subscriptions.values():
            self.mqtt_client.unsubscribe(handle)
        self._subscriptions.clear()
        self._outgoing_triggers.clear()
        self._outgoing_port_types.clear()
        self._incoming_triggers.clear()
        self._construct_output_triggers(trigger_node_entry)
        self._construct_input_triggers(trigger_node_entry)

    def destroy(self):
        try:
            # Release only our own subscription handles. The MQTTHandler is
            # a process-wide singleton with topic fan-out; another adapter
            # may share a trigger topic and must keep receiving.
            for handle in self._subscriptions.values():
                self.mqtt_client.unsubscribe(handle)
            self._subscriptions.clear()
            self._incoming_triggers.clear()
            if self._holds_connect_ref:
                self.mqtt_client.disconnect()
                self._holds_connect_ref = False
        except Exception as e:
            raise TriggerFlowException(str(e))

    def _publish_trigger(self, topic: str, payload: str) -> bool:
        """Publish a serialized trigger payload with QoS 1.

        The return value surfaces publish failures (e.g. the singleton was
        disconnected and the publish was dropped) so ITrigger can WARN —
        silent reconfigure breakage must be distinguishable from a working
        trigger in production logs.
        """
        return self.mqtt_client.publish(topic, payload=payload, qos=1)

    def _construct_output_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for output_name, trigger_type in trigger_flow_entry.outputTriggers.items():
            # Use id, not name: name is not unique across graphs sharing
            # one engine process, and MQTTHandler is a process-wide
            # singleton with topic fan-out — same-named twins would
            # cross-trigger via the shared topic.
            topic_name = f"{trigger_flow_entry.id}/{output_name}"
            LOGGER.info(
                f"MQTTTriggerAdapter: Creating publisher for topic: {topic_name} of Type: {trigger_type}"
            )
            self._outgoing_triggers[output_name] = topic_name
            self._outgoing_port_types[output_name] = trigger_type

    def _construct_input_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for input_name, input_cfg in trigger_flow_entry.inputTriggers.items():
            trigger_type = input_cfg.rosType
            has_connection = any(topic for topic in input_cfg.sourceConnection)
            if not has_connection:
                if trigger_type and trigger_type not in BUILTIN_TRIGGER_NAMES:
                    # A schema-declared custom trigger must have a handler
                    # even while unconnected — fail configure early instead
                    # of surprising the user when the port is first wired.
                    self._get_callback_for_type_name(trigger_type, input_name)
                LOGGER.info(
                    f"MQTTTriggerAdapter: Input {input_name} is not connected, skipping creating a subscriber"
                )
                continue
            # Resolve the callback per declared port (not per connection).
            callback = self._get_callback_for_type_name(trigger_type, input_name)
            for topic_name in input_cfg.sourceConnection:
                if not topic_name or topic_name == "":
                    LOGGER.info(
                        f"MQTTTriggerAdapter: Input {input_name} is not connected, skipping creating a subscriber"
                    )
                    continue
                LOGGER.info(
                    f"MQTTTriggerAdapter: Creating subscriber for topic: {topic_name} of Type: {trigger_type}"
                )
                handle = self.mqtt_client.subscribe(topic_name, callback)
                if handle is None:
                    raise TriggerFlowException(f"Failed to subscribe to topic: {topic_name}")
                self._incoming_triggers[topic_name] = callback
                self._subscriptions[topic_name] = handle

    def _wrap_callback(self, callback: Callable[..., bool]) -> Callable[[Any], bool]:
        """Wrap a callback to deserialize the trigger payload when one is carried.

        A malformed payload must not escape into the paho callback thread —
        dispatch without context instead.
        """

        def wrapper(payload: Any = None) -> bool:
            if isinstance(payload, (bytes, bytearray)):
                payload = payload.decode("utf-8", errors="replace")
            if payload and payload != "triggered":
                try:
                    trigger_ctx = TriggerContext.model_validate_json(payload)
                except ValidationError:
                    LOGGER.warning("Malformed trigger payload on MQTT, dispatching without context")
                    return callback()
                return callback(trigger_ctx)
            return callback()

        return wrapper

    def _get_callback_for_type_name(self, trigger_type: str, port_name: str) -> Callable[..., bool]:
        # Incoming Error executes the node like Start does (matching the C++
        # SDK): an error-handler node is driven by the upstream Error trigger
        # and can inspect trigger_context.is_triggered_by_error().
        if trigger_type in (
            TriggerType.Start.value,
            TriggerType.InLoop.value,
            TriggerType.BreakLoop.value,
            TriggerType.IfTrue.value,
            TriggerType.IfFalse.value,
            TriggerType.Error.value,
        ):
            if self._execute_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._execute_callback)

        if trigger_type == TriggerType.Stop.value:
            if self._stop_callback is None:
                raise TriggerFlowException(
                    f"Stop callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._stop_callback)

        if trigger_type in self._named_trigger_callbacks:
            return self._wrap_callback(self._named_trigger_callbacks[trigger_type])

        raise TriggerFlowException(
            f"Input trigger port '{port_name}' declares custom trigger type "
            f"'{trigger_type}' but no handler is registered on the node. "
            f'Register one with @trigger_handler("{trigger_type}") before '
            "ConfigureNode."
        )

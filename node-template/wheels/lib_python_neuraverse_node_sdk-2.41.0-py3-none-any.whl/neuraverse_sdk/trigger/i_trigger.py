import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional

from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from pydantic import BaseModel, Field

from neuraverse_sdk.utils.exceptions import TriggerFlowException

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.interfaces.ITrigger")

# -------------------------------------------------------------


class TriggerType(Enum):
    Start = "Start"
    Stop = "Stop"
    Error = "Error"
    IfTrue = "IfTrue"
    IfFalse = "IfFalse"
    InLoop = "InLoop"
    BreakLoop = "BreakLoop"


# Trigger type strings with implicit SDK behavior. Custom handlers may not be
# registered under these names; they keep their built-in execute/stop routing.
BUILTIN_TRIGGER_NAMES: frozenset[str] = frozenset(t.value for t in TriggerType)

# Attribute set by the @trigger_handler decorator, scanned by NodeBase.
TRIGGER_HANDLER_ATTR = "__nv_trigger_handler__"


def trigger_handler(trigger_type: str) -> Callable:
    """Mark a NodeBase method as the handler for a custom input trigger type.

    The handler is dispatched on the transport callback thread, not the
    execute executor — it must be fast and non-blocking.
    """

    def decorator(func: Callable) -> Callable:
        setattr(func, TRIGGER_HANDLER_ATTR, trigger_type)
        return func

    return decorator


class ErrorInformation(BaseModel):
    err_type: str
    err_msg: str
    transaction_id: str = Field(default_factory=lambda: str(uuid.uuid4()))


class TriggerContext(BaseModel):
    source_node: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now())
    err_info: Optional[ErrorInformation] = None

    def is_triggered_by_error(self) -> bool:
        return not self.err_info is None


class ITrigger(ABC):
    """Abstract base class for node trigger adapters."""

    def __init__(self):
        self._incoming_triggers: dict[str, Callable[[], bool]] = {}
        # Outgoing trigger ports, keyed by PORT NAME (schema map key), so a
        # node may expose several ports of the same trigger type and custom
        # ports are addressable individually via fire_trigger().
        self._outgoing_triggers: dict[str, str] = {}  # port name -> topic
        self._outgoing_port_types: dict[str, str] = {}  # port name -> type string
        self._named_trigger_callbacks: dict[str, Callable[..., bool]] = {}
        self._execute_callback: Optional[Callable[..., bool]] = None
        self._stop_callback: Optional[Callable[..., bool]] = None

    @abstractmethod
    def init(self, configuration: Any) -> None:
        """trigger the node."""
        pass

    @abstractmethod
    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """trigger the error."""
        pass

    @abstractmethod
    def destroy(self):
        pass

    @abstractmethod
    def _publish_trigger(self, topic: str, payload: str) -> bool:
        """Transport-specific publish of a serialized trigger payload."""
        pass

    def trigger_next_node(
        self, type: TriggerType, trigger_context: Optional[TriggerContext] = None
    ) -> None:
        """Fire every outgoing port of the given built-in trigger type."""
        ports = [
            port for port, type_name in self._outgoing_port_types.items() if type_name == type.value
        ]
        if not ports:
            raise TriggerFlowException(f"Trigger type {type} not found")
        for port in ports:
            self.fire_trigger(port, trigger_context)

    def fire_trigger(
        self, port_name: str, trigger_context: Optional[TriggerContext] = None
    ) -> None:
        """Fire a single outgoing trigger port by its schema port name."""
        if port_name not in self._outgoing_triggers:
            raise TriggerFlowException(
                f"Unknown output trigger port '{port_name}'. "
                f"Declared trigger output ports: {sorted(self._outgoing_triggers)}"
            )
        topic = self._outgoing_triggers[port_name]
        if trigger_context is not None:
            payload = trigger_context.model_dump_json()
        else:
            payload = "triggered"
        ok = self._publish_trigger(topic, payload)
        if ok:
            LOGGER.info(f"Triggering next node type: {topic}...")
        else:
            LOGGER.warning(
                "Trigger publish dropped — downstream nodes will not "
                "wake. outgoing_trigger=%s (transport not connected or "
                "publish failed).",
                topic,
            )

    def set_execute_callback(self, callback: Callable[[], bool]):
        self._execute_callback = callback

    def set_stop_callback(self, callback: Callable[[], bool]):
        self._stop_callback = callback

    def set_named_trigger_callbacks(self, callbacks: dict[str, Callable[..., bool]]) -> None:
        """Replace the custom trigger handler map (trigger type name -> callback)."""
        self._named_trigger_callbacks = dict(callbacks)

    def has_outgoing_trigger(self, trigger_type: TriggerType) -> bool:
        return trigger_type.value in self._outgoing_port_types.values()

    def has_outgoing_trigger_port(self, port_name: str) -> bool:
        return port_name in self._outgoing_triggers

    def get_outgoing_trigger(self, trigger_type: TriggerType) -> str:
        for port, type_name in self._outgoing_port_types.items():
            if type_name == trigger_type.value:
                return self._outgoing_triggers[port]
        raise TriggerFlowException(f"Trigger type {trigger_type} not found")

    def get_incoming_trigger(self, topic_name: str) -> Callable[[], bool]:
        if topic_name not in self._incoming_triggers:
            raise TriggerFlowException(f"Topic name {topic_name} not found")
        return self._incoming_triggers[topic_name]

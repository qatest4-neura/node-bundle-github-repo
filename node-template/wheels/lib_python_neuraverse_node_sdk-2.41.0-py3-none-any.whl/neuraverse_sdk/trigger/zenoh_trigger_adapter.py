from __future__ import annotations

from collections.abc import Callable
from typing import Any

from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from pydantic import ValidationError

from neuraverse_sdk.trigger.i_trigger import (
    BUILTIN_TRIGGER_NAMES,
    ITrigger,
    TriggerContext,
    TriggerType,
)
from neuraverse_sdk.utils.exceptions import TriggerFlowException
from neuraverse_sdk.utils.zenoh_singleton import ZenohHandler

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.adapter.ZenohTriggerAdapter")


class ZenohTriggerAdapter(ITrigger):
    """Zenoh trigger adapter."""

    def __init__(self):
        super().__init__()

    def init(self, configuration: Any) -> None:
        """Initialize the Zenoh trigger adapter."""
        self.zenoh_session: ZenohHandler = ZenohHandler()
        self.zenoh_session.configure(configuration)
        if self.zenoh_session.connect(blocking=True, timeout=10.0):
            LOGGER.info("Successfully connected to Zenoh router")
        else:
            LOGGER.error("Failed to connect to Zenoh router")
            raise ConnectionError("Failed to connect to Zenoh router")

    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """Configure the Zenoh trigger adapter with the given configuration."""
        if not self.zenoh_session.is_connected():
            LOGGER.info("Zenoh session not connected; reconnecting before configure")
            if not self.zenoh_session.connect(blocking=True, timeout=10.0):
                raise TriggerFlowException("Failed to reconnect to Zenoh router before configure")
        self._outgoing_triggers.clear()
        self._outgoing_port_types.clear()
        self._incoming_triggers.clear()
        self._construct_output_triggers(trigger_node_entry)
        self._construct_input_triggers(trigger_node_entry)

    def destroy(self):
        try:
            self.zenoh_session.disconnect()
        except Exception as e:
            raise TriggerFlowException(str(e))

    def _publish_trigger(self, topic: str, payload: str) -> bool:
        return self.zenoh_session.publish(topic, payload)

    def _construct_output_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for output_name, trigger_type in trigger_flow_entry.outputTriggers.items():
            # KNOWN INCONSISTENCY vs MQTT adapter: topic base is entry.name
            # here, entry.id there. Kept as-is; MQTT is the active path.
            topic_name = f"{trigger_flow_entry.name}/{output_name}"
            LOGGER.info(
                f"ZenohTriggerAdapter: Creating publisher for topic:"
                f" {topic_name} of Type: {trigger_type}"
            )
            self._outgoing_triggers[output_name] = topic_name
            self._outgoing_port_types[output_name] = trigger_type

    def _construct_input_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for input_name, input_cfg in trigger_flow_entry.inputTriggers.items():
            trigger_type = input_cfg.rosType
            has_connection = any(topic for topic in input_cfg.sourceConnection)
            if not has_connection:
                if trigger_type and trigger_type not in BUILTIN_TRIGGER_NAMES:
                    # A schema-declared custom trigger must have a handler
                    # even while unconnected — fail configure early instead
                    # of surprising the user when the port is first wired.
                    self._get_callback_for_type_name(trigger_type, input_name)
                LOGGER.info(
                    f"ZenohTriggerAdapter: Input {input_name} is not connected,"
                    " skipping creating a subscriber"
                )
                continue
            # Resolve the callback per declared port (not per connection).
            callback = self._get_callback_for_type_name(trigger_type, input_name)
            for topic_name in input_cfg.sourceConnection:
                if not topic_name or topic_name == "":
                    LOGGER.info(
                        f"ZenohTriggerAdapter: Input {input_name} is not connected,"
                        " skipping creating a subscriber"
                    )
                    continue
                LOGGER.info(
                    f"ZenohTriggerAdapter: Creating subscriber for topic:"
                    f" {topic_name} of Type: {trigger_type}"
                )
                if self.zenoh_session.subscribe(topic_name, callback):
                    self._incoming_triggers[topic_name] = callback
                else:
                    raise TriggerFlowException(f"Failed to subscribe to topic: {topic_name}")

    def _wrap_callback(self, callback: Callable[..., bool]) -> Callable[[Any], bool]:
        """Wrap a callback to deserialize the trigger payload when one is carried.

        ZenohHandler delivers raw bytes (unlike MQTTHandler, which decodes to
        str), so normalize before comparing against the legacy "triggered"
        marker. A malformed payload must not escape into the Zenoh subscriber
        thread — dispatch without context instead.
        """

        def wrapper(payload: Any = None) -> bool:
            if isinstance(payload, (bytes, bytearray)):
                payload = payload.decode("utf-8", errors="replace")
            if payload and payload != "triggered":
                try:
                    trigger_ctx = TriggerContext.model_validate_json(payload)
                except ValidationError:
                    LOGGER.warning(
                        "Malformed trigger payload on Zenoh, dispatching without context"
                    )
                    return callback()
                return callback(trigger_ctx)
            return callback()

        return wrapper

    def _get_callback_for_type_name(
        self, trigger_type: str, port_name: str
    ) -> Callable[[Any], bool]:
        # Incoming Error executes the node like Start does (matching the C++
        # SDK): an error-handler node is driven by the upstream Error trigger
        # and can inspect trigger_context.is_triggered_by_error().
        if trigger_type in (
            TriggerType.Start.value,
            TriggerType.InLoop.value,
            TriggerType.BreakLoop.value,
            TriggerType.IfTrue.value,
            TriggerType.IfFalse.value,
            TriggerType.Error.value,
        ):
            if self._execute_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._execute_callback)

        if trigger_type == TriggerType.Stop.value:
            if self._stop_callback is None:
                raise TriggerFlowException(
                    f"Stop callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._stop_callback)

        if trigger_type in self._named_trigger_callbacks:
            return self._wrap_callback(self._named_trigger_callbacks[trigger_type])

        raise TriggerFlowException(
            f"Input trigger port '{port_name}' declares custom trigger type "
            f"'{trigger_type}' but no handler is registered on the node. "
            f'Register one with @trigger_handler("{trigger_type}") before '
            "ConfigureNode."
        )

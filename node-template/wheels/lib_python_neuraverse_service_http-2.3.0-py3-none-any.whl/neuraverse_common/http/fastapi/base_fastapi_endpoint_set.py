import ipaddress
from functools import wraps

import inject
from fastapi import APIRouter, Request
from fastapi.responses import Response, StreamingResponse
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability import metrics
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.utilities import preconditions

from neuraverse_common.http.context.ecntx_handler import HttpEcntxHandler
from neuraverse_common.http.model.config_source.HttpConfig import HttpConfig
from neuraverse_common.http.model.error.neura_http_error import NeuraHttpError


class BaseFastApiEndpointSet:
    """
    Base class for HTTP API service classes - which you can think of as a set of FastAPI handlers to bind to URIs.
    You should organize your handlers under subclasses of this base class.

    If you do you get lots of features from this like correct error handling, metrics, logging - many many things.
    """

    _endpoint_metrics: dict[str, metrics.ServerEndpointMetricSet]

    @inject.params(http_config=HttpConfig)
    def __init__(self, http_config: HttpConfig, logger_to_use: Logger | None = None):
        """
        Initialize the BaseFastApiHandlerSet with a logger instance.

        Args:
            logger_to_use (Logger): Optional. Logger instance for logging API calls and errors. If you pass None or omit this entirely then class creates a default logger with name "service.api.http.<className>"
        """
        preconditions.check_argument(
            logger_to_use is None or isinstance(logger_to_use, Logger),
            "'logger_to_use' must be a Logger type if you pass in something",
        )
        if logger_to_use is None:
            logger_name = f"service.api.http.{self.__class__.__name__}"
            logger_to_use = LoggerFactory.get_logger(logger_name)
            # let's make a warning - maybe someone notice? :-P
            logger_to_use.warning(
                "You did NOT pass a specific Logger in constructor so default Logger with name '%s' was created",
                logger_name,
            )
        self._LOG = logger_to_use

        self._log_request_details_on_failure = http_config.log_request_details_on_failure
        self._log_request_details_on_log_level = http_config.log_request_details_on_log_level
        self._log_response_details_on_log_level = http_config.log_response_details_on_log_level

        self._http_config: HttpConfig = http_config
        self.router = APIRouter()

    @classmethod
    def _get_endpoint_metrics(
        cls, endpoint_qualified_name: str, ecntx: ExecutionContext = None
    ) -> metrics.ServerEndpointMetricSet:
        if getattr(cls, "_endpoint_metrics", None) is None:
            cls._endpoint_metrics = dict()
        metric_set = cls._endpoint_metrics.get(endpoint_qualified_name)
        if metric_set is None:
            metric_set = metrics.MetricsFactory.create_server_endpoint_metricset(
                endpoint_name=endpoint_qualified_name, endpoint_type="http", ecntx=ecntx
            )
            cls._endpoint_metrics[endpoint_qualified_name] = metric_set
        return metric_set

    @classmethod
    async def _get_request(cls, args, kwargs) -> Request | None:
        # Find the FastAPI Request object in args or kwargs
        request: Request = kwargs.get("request")
        if request is None:
            for arg in args:
                if isinstance(arg, Request):
                    request = arg

        return request

    @classmethod
    async def _create_and_store_executioncontext(
        cls, request: Request, jwt_payload: dict, service_info_provider=None
    ) -> ExecutionContext:
        """
        This internal helper method takes a request object, creates an ExecutionContext out of it and also stores this within the `request.state` area.
        So later it is easy to get it back from the Request itself.
        """
        if request is None:
            # baaad.... really should not happen
            raise errors_v2.NeuraIllegalStateError(
                message="FastAPI Request object not found in endpoint arguments."
            ).with_is_retryable(False)

        context = await HttpEcntxHandler.get_or_create_execution_context_from_request(
            request=request,
            jwt_payload=jwt_payload,
            service_info=service_info_provider(),
        )
        return context

    @classmethod
    def with_execution_context_rest(cls, service_info_provider=None):
        """
        CAUTION! Read through the full description before you proceed with this one!

        Decorator factory for FastAPI endpoints that injects an `neuraverse_common.context.execution_context.ExecutionContext` into the endpoint - created from the inbound request.
        But does NOT do any request logging!

        Normally this is discouraged! As this way logging and future investigations are fully in your hands!
        It is recommended - unless very good reasons - that you use `@with_execution_context_rest_with_logs` instead of this one.

        Args:
            service_info_provider (Optional[Callable[[], ServiceInfo]]): Lazy loader for ServiceInfo.
        Usage:
            @with_execution_context_rest(ServiceInfo("svc", "1.0.0", 1))
            async def endpoint(request: Request, ..., context=None):
                ...
        """

        def decorator(func):
            @wraps(func)
            async def wrapper(self, *args, **kwargs):
                # first of all we will create an ExecutionContext from the Request and store it
                request = await cls._get_request(args, kwargs)
                context = await cls._create_and_store_executioncontext(
                    request=request,
                    jwt_payload=kwargs.get("jwt_payload"),
                    service_info_provider=service_info_provider,
                )
                # we will also pass this into the method
                kwargs["context"] = context
                # as well as log labels
                log_labels = context.get_labels_for_log() if context else {}
                kwargs["log_labels"] = log_labels
                # time to invoke the function
                return await self._invoke_with_error_handling(func, *args, **kwargs)

            return wrapper

        return decorator

    @classmethod
    def with_execution_context_rest_with_logs(cls, service_info_provider=None):
        """
        Decorator factory for FastAPI endpoints that injects a `neuraverse_common.context.execution_context.ExecutionContext` - created from the inbound request - and logs request info.

        This decorator works like `@with_execution_context_rest`, but also supports efficient logging! This is the recommended decorator to be used.

        Args:
            service_info_provider (Optional[Callable[[], ServiceInfo]]): Lazy loader for ServiceInfo.
            log: Logger instance to use for logging request information.

        Usage:
            @with_execution_context_rest_with_logs(ServiceInfo("svc", "1.0.0", 1), log=my_logger)
            async def endpoint(request: Request, ..., context=None, log_labels=None):
                ...
        """

        def decorator(func):
            @wraps(func)
            async def wrapper(self, *args, **kwargs):
                # first of all we will create an ExecutionContext from the Request and store it
                request = await cls._get_request(args, kwargs)
                context = await cls._create_and_store_executioncontext(
                    request=request,
                    jwt_payload=kwargs.get("jwt_payload"),
                    service_info_provider=service_info_provider,
                )
                # we will also pass this into the method
                kwargs["context"] = context
                # as well as log labels
                log_labels = context.get_labels_for_log() if context else {}
                kwargs["log_labels"] = log_labels

                # let's log the method name anyways
                self._LOG.info(
                    "Received HTTP API request - method .%s() invoked", func.__name__, **log_labels
                )

                # let's log the details of inbound request - due to config
                await self._log_inbound_request_details(
                    http_request=request,
                    log_labels=log_labels,
                    log_level=self._log_request_details_on_log_level,
                )

                # time to invoke the function
                response = await self._invoke_with_error_handling(func, *args, **kwargs)

                # log response - if set
                await self._log_response_details(
                    response=response,
                    log_labels=log_labels,
                    log_level=self._log_response_details_on_log_level,
                )

                return response

            return wrapper

        return decorator

    async def _log_response_details(self, response, log_labels: dict, log_level: str) -> None:
        if not response:
            # not much to do
            return
        if log_level != "info" and log_level != "debug":
            return

        if isinstance(response, Response):
            resp_status = response.status_code
            content_type = response.headers.get("content-type", "").lower()
            body_str = "*not printable*"
            # we only print body of textual response (StreamingResponse has no .body attribute)
            if not isinstance(response, StreamingResponse) and (
                "json" in content_type or "text" in content_type or "yaml" in content_type
            ):
                body_bytes = response.body
                body_str = body_bytes.decode("utf-8")
            if log_level == "info":
                self._LOG.info(
                    "returned response was - status: %s, content-type: %s, body: %s",
                    resp_status,
                    content_type,
                    body_str,
                    **log_labels,
                )
            else:
                self._LOG.debug(
                    "returned response was - status: %s, content-type: %s, body: %s",
                    resp_status,
                    content_type,
                    body_str,
                    **log_labels,
                )
        else:
            if log_level == "info":
                self._LOG.info("returned response was: %s", response, **log_labels)
            else:
                self._LOG.info("returned response was: %s", response, **log_labels)

    async def _log_inbound_request_details(
        self, http_request: Request, log_labels: dict, log_level: str
    ) -> None:
        if http_request is None:
            # not much to do...
            return
        if not log_level or not isinstance(log_level, str):
            # khm... this really means we have a config error...
            self._LOG.warning(
                "Config error! The 'HttpConfig.log_request_details_on_log_level' seems to have invalid value... please check and fix it!"
            )
            return
        # we can get this from HttpConfig - so better to convert it into lowercase
        log_level = log_level.lower()
        if (
            log_level == "none"
            or (log_level == "debug" and not self._LOG.isDebugEnabled())
            or (log_level == "info" and not self._LOG.isInfoEnabled())
        ):
            # no point to waste any moment on this...
            return

        query_args = http_request.url.query
        if query_args != "":
            query_args = "?" + query_args
        ipAddr = self._get_anonymized_client_IP(http_request=http_request)
        method = http_request.method
        is_body_expected = method == "POST" or method == "PUT" or method == "PATCH"
        body_str: str = ""
        content_length: int = 0
        if is_body_expected:
            content_type = http_request.headers.get("content-type", "unknown").lower()
            # we only dump out textual content of body - nothing else!
            if "json" in content_type or "text" in content_type or "yaml" in content_type:
                content_length = int(http_request.headers.get("content-length", "0"))
                body_bytes = await http_request.body()
                try:
                    body_str = body_bytes.decode("utf-8")
                except Exception:
                    body_str = "Decode failed... :-("

        # OK let's log it - on appropriate level!
        if log_level == "debug":
            if is_body_expected:
                self._LOG.debug(
                    "incoming %s request '%s%s' (from %s) - with body ('%s', size %s): %s",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    content_type,
                    content_length,
                    body_str,
                    **log_labels,
                )
            else:
                self._LOG.debug(
                    "incoming %s request '%s%s' (from %s)",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    **log_labels,
                )
        elif log_level == "info":
            if is_body_expected:
                self._LOG.info(
                    "incoming %s request '%s%s' (from %s) - with body ('%s', size %s): %s",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    content_type,
                    content_length,
                    body_str,
                    **log_labels,
                )
            else:
                self._LOG.info(
                    "incoming %s request '%s%s' (from %s)",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    **log_labels,
                )
        elif log_level == "warning":
            if is_body_expected:
                self._LOG.warning(
                    "request was: %s '%s%s' (from %s) - with body ('%s', size %s): %s",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    content_type,
                    content_length,
                    body_str,
                    **log_labels,
                )
            else:
                self._LOG.warning(
                    "request was: %s '%s%s' (from %s)",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    **log_labels,
                )
        else:
            if is_body_expected:
                self._LOG.error(
                    "failed request was: %s '%s%s' (from %s) - with body ('%s', size %s): %s",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    content_type,
                    content_length,
                    body_str,
                    **log_labels,
                )
            else:
                self._LOG.error(
                    "failed request was: %s '%s%s' (from %s)",
                    method,
                    http_request.url.path,
                    query_args,
                    ipAddr,
                    **log_labels,
                )

    def _get_anonymized_client_IP(self, http_request: Request) -> str:
        # to support Proxies - see "behind" them and get the real orogonal IP
        forwardedFor = http_request.headers.get("x-forwarded-for")
        if forwardedFor is None:
            forwardedFor = http_request.headers.get("x-forwardedfor")
        if forwardedFor is not None:
            return forwardedFor
        ip = str(http_request.client)
        try:
            ip_obj = ipaddress.ip_address(ip)
        except ValueError:
            return ip  # invalid IP, return as-is

        if isinstance(ip_obj, ipaddress.IPv4Address):
            network = ipaddress.IPv4Network(f"{ip_obj}/24", strict=False)
        else:  # IPv6
            network = ipaddress.IPv6Network(f"{ip_obj}/48", strict=False)
        return str(network.network_address)

    async def _invoke_with_error_handling(self, func, *args, **kwargs):
        ecntx: ExecutionContext = kwargs.get("context", None)
        endpoint_metrics: metrics.ServerEndpointMetricSet = (
            BaseFastApiEndpointSet._get_endpoint_metrics(
                endpoint_qualified_name=func.__qualname__, ecntx=ecntx
            )
        )
        log_labels = kwargs.get("log_labels")
        if not log_labels:
            log_labels = ecntx.get_labels_for_log() if ecntx else dict()

        request: Request = await self.__class__._get_request(args, kwargs)
        request_method = request.method if request else "?"

        try:
            response: Response = await func(self, *args, **kwargs)
            # we are good! adjust metrics
            status_code = response.status_code if isinstance(response, Response) else 200
            endpoint_metrics.increment(status_code=status_code, method=request_method)
            endpoint_metrics.observe_exec_time(
                status_code=status_code,
                method=request_method,
                ellapsed_millis=ecntx.get_took_millis(),
            )
            return response

        except NeuraHttpError as exc:
            requestToLog = "*feature off*"
            _log_fn = self._LOG.warning if exc.status == 304 else self._LOG.error
            if self._log_request_details_on_failure:
                # was it logged already? then dont log again
                if (
                    self._log_request_details_on_log_level == "debug" and self._LOG.isDebugEnabled()
                ) or (
                    self._log_request_details_on_log_level == "info" and self._LOG.isInfoEnabled()
                ):
                    requestToLog = "*already logged*"
                    _log_fn(
                        "%s(): returning prepared NeuraHttpError: %s, inbound request was: %s",
                        func.__name__,
                        exc,
                        requestToLog,
                        **log_labels,
                    )
                else:
                    cls = self.__class__
                    request = await cls._get_request(args, kwargs)
                    _log_fn(
                        "%s(): returning prepared NeuraHttpError: %s, inbound request we log next",
                        func.__name__,
                        exc,
                        **log_labels,
                    )
                    await self._log_inbound_request_details(
                        http_request=request,
                        log_labels=log_labels,
                        log_level="warning" if exc.status == 304 else "error",
                    )
            else:
                _log_fn(
                    "%s(): returning prepared NeuraHttpError: %s, inbound request was: %s",
                    func.__name__,
                    exc,
                    requestToLog,
                    **log_labels,
                )

            # adjust metrics
            status_code = exc.status
            endpoint_metrics.increment(status_code=status_code, method=request_method)
            endpoint_metrics.observe_exec_time(
                status_code=status_code,
                method=request_method,
                ellapsed_millis=ecntx.get_took_millis(),
            )
            # and return the response constructed from the exception
            return exc.to_JSON_response(ecntx=ecntx)

        except Exception as exc:
            self._LOG.warning(
                "%s(): non NeuraHttpError exception captured - converting to NeuraHttpError error... original error was: %s",
                func.__name__,
                exc,
                **log_labels,
            )
            # let's convert it into grpc error response
            httpException = NeuraHttpError.from_error_or_exception(exc, self._LOG, ecntx)

            requestToLog = "*feature off*"
            _log_fn = self._LOG.warning if httpException.status == 304 else self._LOG.error
            if self._log_request_details_on_failure:
                # was it logged already? then dont log again
                if (
                    self._log_request_details_on_log_level == "debug" and self._LOG.isDebugEnabled()
                ) or (
                    self._log_request_details_on_log_level == "info" and self._LOG.isInfoEnabled()
                ):
                    requestToLog = "*already logged*"
                    _log_fn(
                        "%s(): returning converted NeuraHttpError: %s, inbound request was: %s",
                        func.__name__,
                        httpException,
                        requestToLog,
                        **log_labels,
                    )
                else:
                    cls = self.__class__
                    request = await cls._get_request(args, kwargs)
                    _log_fn(
                        "%s(): returning converted NeuraHttpError: %s, inbound request we log next",
                        func.__name__,
                        httpException,
                        **log_labels,
                    )
                    await self._log_inbound_request_details(
                        http_request=request,
                        log_labels=log_labels,
                        log_level="warning" if httpException.status == 304 else "error",
                    )
            else:
                _log_fn(
                    "%s(): returning converted NeuraHttpError: %s, inbound request was: %s",
                    func.__name__,
                    httpException,
                    requestToLog,
                    **log_labels,
                )

            # adjust metrics
            status_code = httpException.status
            endpoint_metrics.increment(status_code=status_code, method=request_method)
            endpoint_metrics.observe_exec_time(
                status_code=status_code,
                method=request_method,
                ellapsed_millis=ecntx.get_took_millis(),
            )

            # and return the response constructed from the exception
            return httpException.to_JSON_response(ecntx=ecntx)

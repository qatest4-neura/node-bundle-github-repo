from logging import Logger

import inject
from fastapi import Request
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.observability.logging import LoggerFactory

from neuraverse_common.http.context.ecntx_handler import HttpEcntxHandler
from neuraverse_common.http.model.error.neura_http_error import NeuraHttpError


def get_neura_exception_handler():
    """
    Creates a FastAPI exception handler for converting any Exception into a response.

    This is using `NeuraHttpError.from_error_or_exception()` method to convert any exception into that. Which then we can turn into response.

    Returns:
        callable: An asynchronous exception handler function.
    """

    async def handler(request: Request, exc: Exception):

        # let's get this back from injection
        service_info = inject.instance(ServiceInfo)
        # in theory, the ExecutionContext is already in the request! if not, well then a new one will be created - best effort
        ecntx: ExecutionContext = (
            await HttpEcntxHandler.get_or_create_execution_context_from_request(
                request=request, jwt_payload=None, service_info=service_info
            )
        )

        _LOG: Logger = LoggerFactory.get_logger("lib.http.fastapi.NeuraExceptionHandler")
        neura_err = NeuraHttpError.from_error_or_exception(exc=exc, logger_to_use=_LOG, ecntx=ecntx)
        return neura_err.to_JSON_response(ecntx=ecntx)

    return handler

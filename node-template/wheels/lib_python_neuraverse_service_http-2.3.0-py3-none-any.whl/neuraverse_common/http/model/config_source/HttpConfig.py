"""
This module defines the `HttpConfig` class for managing HTTP server configuration
in the NEURA robotics tenant service.

The `HttpConfig` class provides structured fields for defining the HTTP server's
address and port. It leverages Pydantic for validation and ensures that these
fields are properly set and documented.
"""

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class HttpConfig(BaseSettings):
    """
    Configuration class for HTTP server settings.

    This class defines the address and port for the HTTP server, providing a
    structured way to manage these settings.
    """

    model_config = SettingsConfigDict(extra="allow")

    address: str = Field(default="0.0.0.0", description="HTTP address")
    port: int = Field(default=8080, description="HTTP port")
    root_path: str = Field(default="/", description="Root path for the HTTP server")
    reload: bool = Field(
        default=False,
        description="Enable uvicorn auto-reload on code changes. Should only be enabled for local development.",
    )

    # behavior related
    log_request_details_on_failure: bool = Field(
        default=True,
        description="In case request failed with exception our `BaseFastApiEndpointSet@with_execution_context_rest_with_logs` wrapper will make sure the request is logged if TRUE.",
    )
    log_request_details_on_log_level: str = Field(
        default="debug",
        description="If you set it to 'info' or 'debug' then inbound request will be logged on that level - setting to None will turn this feture off. Defult is 'debug'",
    )
    log_response_details_on_log_level: str = Field(
        default="debug",
        description="If you set it to 'info' or 'debug' then outbound response will be logged on that level - otherwise not at all. Default is 'debug'",
    )

import json
from typing import Optional

import inject
from fastapi import Request
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.auth.AuthInfo import AuthInfo
from neuraverse_common.models.config.config_source.JwtConfig import AuthApplicationName, JwtConfig
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.models.error import errors_v2
from neuraverse_common.utilities import proto_utils

from neuraverse_common.http.context.http_headers import HttpHeaders


class HttpEcntxHandler:
    """
    A utility class for HTTP-related operations to handle `neuraverse_common.context.execution_context.ExecutionContext`.

    This class provides methods to process HTTP requests and contexts, enabling
    seamless integration with the internal execution context standard.
    """

    @staticmethod
    async def get_or_create_execution_context_from_request(
        request: Request,
        jwt_payload: dict,
        service_info: ServiceInfo,
        jwt_config: Optional[JwtConfig] = None,
    ) -> ExecutionContext:
        """
        Takes a HTTP request and creates an internal `neuraverse_common.context.execution_context.ExecutionContext` out of it.
        Once done, it is registered into the Request itself, into `request.state.execution_context` key. So next time this method invoked
        on the same Request, it is simply just retrieved from the Request.

        Args:
            request: The incoming HTTP request.
            user_payload (dict): The user payload containing authentication information.
            service_info (ServiceInfo): The service information for logging and context creation.
            jwt_config (JwtConfig, optional): Used to resolve which configured JWT application the
                token's issuer belongs to (e.g. Neura Gym's Cognito pool), so that application's own
                claims can be mapped instead of falling through to the legacy `sub`-based resolution
                below. Resolved via `inject.instance(JwtConfig)` when not explicitly passed; callers
                for whom that isn't configured simply skip that mapping and keep today's behavior.
        Returns:
            ExecutionContext: The internal execution context containing metadata.
        """
        if request is None:
            # baaad.... really should not happen
            raise errors_v2.NeuraIllegalStateError(
                message="'request' is mandatory, it can not be None"
            ).with_is_retryable(False)

        # do we have already?
        ecntx = getattr(request.state, "execution_context", None)
        if ecntx is not None:
            # we already have it, just retrieve
            return ecntx

        # OK let's create and register a new one
        headers = request.headers

        transaction_id = headers.get(HttpHeaders.X_TRANSACTION_ID)
        trace_id = headers.get(HttpHeaders.X_TRACE_ID)
        request_timestamp = headers.get(HttpHeaders.X_REQUEST_TIMESTAMP)
        caller_name_and_version = headers.get(HttpHeaders.X_CALLER_NAME_AND_VERSION)
        auth_header = headers.get(HttpHeaders.AUTHORIZATION)
        user_id = None
        org_id = None
        service_id = None
        if jwt_payload:
            if jwt_config is None:
                try:
                    jwt_config = inject.instance(JwtConfig)
                except inject.InjectorException:
                    jwt_config = None
            resolved_application = (
                jwt_config.application_for_issuer(jwt_payload.get("iss")) if jwt_config else None
            )
            if resolved_application == AuthApplicationName.NEURA_GYM:
                # Neura Gym tokens are Cognito-issued: they carry no "https://neuraverse.com/*"
                # claims and their "sub" is the Cognito pool-local subject, not the Neuraverse
                # user id - the legacy fallback below must never run for this issuer (NRV-10541).
                user_id = jwt_payload.get("custom:neuraverseUserId")
                if user_id is None:
                    raise errors_v2.NeuraPublicAuthenticationError(
                        message="Invalid Neura Gym token: missing 'custom:neuraverseUserId' claim"
                    )
                org_id = jwt_payload.get("custom:neuraverseOrgId")
            else:
                # TODO NRV-4152 / NRV-4541 - add support for M2M tokens properly here - service_id!
                # IMPORTANT! if you change anything here, you also need to change in grpc lib the same! find it!
                user_id = jwt_payload.get("https://neuraverse.com/user_id")
                service_id = jwt_payload.get("https://neuraverse.com/service_id")
                # Configure fallback logic in case neither user_id nor service_id found
                if user_id is None and service_id is None:
                    subject = jwt_payload.get("sub")
                    # A SPIFFE JWT-SVID (e.g. issued by a SPIRE server) carries the SPIFFE ID in
                    # its subject and identifies a workload/device, i.e. a service identity. Auth0
                    # M2M tokens are identified by the "client-credentials" grant type.
                    fallback_is_service_token = jwt_payload.get("gty") == "client-credentials" or (
                        isinstance(subject, str) and subject.startswith("spiffe://")
                    )
                    if fallback_is_service_token:
                        service_id = subject
                    else:
                        user_id = subject

                if user_id is not None:
                    # This is a user token - we can also have org_id in that case
                    org_id = jwt_payload.get("https://neuraverse.com/org_id")

        auth_info = AuthInfo(
            user_id=user_id,
            service_id=service_id,
            auth_header_content=auth_header,
            org_id=org_id,
        )

        service_name_and_version = None
        api_version = None
        if service_info:
            service_name_and_version = (
                f"{service_info.get_service_name()} {service_info.get_service_version()}"
            )
            api_version = service_info.get_api_version()

        ecntx = ExecutionContext(
            request_timestamp=int(request_timestamp) if request_timestamp else None,
            transaction_id=transaction_id,
            trace_id=trace_id,
            caller_name_and_version=caller_name_and_version,
            service_name_and_version=service_name_and_version,
            api_version=api_version,
            auth_info=auth_info,
        )
        # let's register it into the Request
        request.state.execution_context = ecntx

        return ecntx

    @staticmethod
    def get_response_headers(context: ExecutionContext) -> dict[str, str]:
        """
        Returns a dictionary which you should set on your HTTP Response headers - info coming from this context.

        Response Headers:
            x-trace-id, trace-id: The traceId used internally to serve this request.
            x-transaction-id: The transactionId used internally to serve this request.
            x-took-millis: The number of milliseconds it took to process the request.
            x-request-received-at-timestamp: The timestamp when we have received this request from the caller.
            x-service-name-and-version: The name and version of the service that served the request.
            x-api-version: The API version of the service.
            x-origin-request-timestamp: The original request timestamp from the caller, if available.
        """
        if context is None or not isinstance(context, ExecutionContext):
            # we can not do too much...
            return {}

        headers = {
            HttpHeaders.X_TRANSACTION_ID: context.transaction_id,
            HttpHeaders.X_TRACE_ID: context.trace_id,
            HttpHeaders.X_TOOK_MILLIS: str(context.get_took_millis()),
            HttpHeaders.X_REQUEST_RECEIVED_AT_TIMESTAMP: str(context.request_timestamp),
        }

        # Add optional headers only if available
        optional_fields = [
            (HttpHeaders.X_SERVICE_NAME_AND_VERSION, context.service_name_and_version),
            (HttpHeaders.X_API_VERSION, context.api_version),
            (HttpHeaders.X_ORIG_REQUEST_TIMESTAMP, context.request_origin_timestamp),
        ]

        headers.update(
            {header: str(value) if value is not None else "" for header, value in optional_fields}
        )
        # Add warnings if present
        warnings = context.get_warnings()
        if warnings:
            headers[HttpHeaders.X_WARNINGS] = json.dumps(
                [proto_utils.proto_to_dict(proto_obj=w, keep_all_fields=False) for w in warnings]
            )

        return headers

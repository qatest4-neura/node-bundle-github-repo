"""
This module defines JWT-related dependencies for FastAPI endpoints in the
NEURA robotics tenant service.

The `JWTAuthValidator` class provides a dependency for validating JWT tokens, while
the `rbac` function implements role-based access control (RBAC) for securing
endpoints. These utilities ensure secure and authenticated access to the API.
"""

import inject
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from neuraverse_common.jwt.jwt_validator import JwtValidator
from neuraverse_common.models.config.config_source.JwtConfig import JwtConfig
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability.logging import LoggerFactory
from requests.exceptions import ConnectTimeout

bearer_scheme = HTTPBearer(auto_error=False)


def get_jwt_config() -> JwtConfig:
    """
    Inject the JwtConfig for JwtValidator.

    Returns:
        JwtConfig: The injected JWT configuration.
    """
    return inject.instance(JwtConfig)


def get_jwt_validator() -> JwtValidator:
    """
    Inject the JwtValidator for validating JWT tokens.

    Returns:
        JwtValidator: The injected JWT validator.
    """
    return inject.instance(JwtValidator)


class OptionalJWTAuthValidator:
    """
    Dependency that returns the validated JWT payload if provided,
    or None if no token is passed.

    This can be used for endpoints that allow both authenticated
    and unauthenticated access, e.g. to retrieve public attachments.
    """

    def __init__(self):
        self._logger_name = "lib.http.auth.OptionalJWTAuthValidator"
        self._LOG = LoggerFactory.get_logger(self._logger_name)

    def __call__(self, credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
        if not credentials:
            # No token provided, proceed unauthenticated
            return None

        try:
            token = credentials.credentials
            jwt_validator = inject.instance(JwtValidator)
            payload = jwt_validator.validate_token(token)
            return payload
        except Exception as e:
            if type(e) is ConnectTimeout:
                # we want to log this out and not lose details
                # TODO ExecutionContext??? we will not have transaction id etc this way...
                self._LOG.error(
                    "failed to validate auth data due to timeout - error was: %s", str(e)
                )
                raise errors_v2.NeuraPublicIllegalStateError(
                    message="Failed to validate authentication data - timeout happened... Please retry!"
                ).with_is_retryable(True).with_errorcode(
                    errors_v2.NeuraPublicIllegalStateError.ERRCODE_TIMED_OUT
                ) from e
            raise errors_v2.NeuraPublicAuthenticationError(
                message="Authentication failed due to invalid token"
            )


class JWTAuthValidator:
    """
    Dependency class for validating JWT tokens in FastAPI endpoints.
    """

    def __init__(self, auto_error: bool = True):
        """
        Initializes the JWTAuthValidator dependency.

        Args:
            auto_error (bool): Whether to raise an error if the token is missing or invalid.
        """
        self.auto_error = auto_error
        self._logger_name = "lib.http.auth.JWTAuthValidator"
        self._LOG = LoggerFactory.get_logger(self._logger_name)

    def __call__(self, credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
        """
        Validates the provided JWT token.

        Args:
            credentials (HTTPAuthorizationCredentials): The authorization credentials.

        Returns:
            dict: The decoded JWT payload if valid.

        Raises:
            NeuraPublicAuthenticationError: If the token is missing or invalid.
        """
        if not credentials:
            if self.auto_error:
                raise errors_v2.NeuraPublicAuthenticationError(
                    message="Authentication required"
                ).with_errorcode(errors_v2.NeuraPublicAuthenticationError.ERROR_MISSING)
            else:
                return None

        try:
            token = credentials.credentials
            jwt_validator = get_jwt_validator()
            payload = jwt_validator.validate_token(token)
            return payload
        except Exception as e:
            if type(e) is ConnectTimeout:
                # we want to log this out and not lose details
                # TODO ExecutionContext??? we will not have transaction id etc this way...
                self._LOG.error(
                    "failed to validate auth data due to timeout - error was: %s", str(e)
                )
                raise errors_v2.NeuraPublicIllegalStateError(
                    message="Failed to validate authentication data - timeout happened... Please retry!"
                ).with_is_retryable(True).with_errorcode(
                    errors_v2.NeuraPublicIllegalStateError.ERRCODE_TIMED_OUT
                ) from e
            raise errors_v2.NeuraPublicAuthenticationError(
                message="Authentication data is invalid"
            ).with_errorcode(errors_v2.NeuraPublicAuthenticationError.ERROR_FAILED)


def rbac(get_roles_from_config):
    """
    Role-based access control (RBAC) dependency for FastAPI endpoints.

    Args:
        get_roles_from_config (Callable): A function to retrieve required roles from the JWT configuration.

    Returns:
        Callable: A dependency function for RBAC enforcement.
    """

    def dependency(user: dict = Depends(JWTAuthValidator())):
        """
        Checks if the user has the required roles.

        Args:
            user (dict): The decoded JWT payload.

        Returns:
            dict: The user payload if access is granted.

        Raises:
            HTTPException: If the user lacks the required roles.
        """
        jwt_config = get_jwt_config()
        required_roles = get_roles_from_config(jwt_config)

        user_roles = user.get("role", [])
        if not any(role in user_roles for role in required_roles):
            raise errors_v2.NeuraPublicAuthorizationError(
                message="Sorry you have no permission to this resource / operation."
            )
        return user

    return dependency

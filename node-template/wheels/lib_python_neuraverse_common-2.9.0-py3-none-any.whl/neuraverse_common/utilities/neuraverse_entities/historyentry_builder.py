from datetime import datetime

from neuraverse.models.v1.gen.business.common_pb2 import HistoryEntry, HistoryOperation

from neuraverse_common.context.execution_context import ExecutionContext


class HistoryEntryBuilder:

    def __init__(self, operation: HistoryOperation, ecntx: ExecutionContext):
        self._operation = operation
        self._actor_id = ecntx.auth_info.get_displayed_id() if ecntx and ecntx.auth_info else None
        # remove this once this deprecated field is removed
        self._user_id = ecntx.auth_info.get_user_id() if ecntx and ecntx.auth_info else None
        self._system_comments: dict[str, str] = dict()
        self._user_comment = None

    def with_user_comment(self, user_comment: str):
        self._user_comment = user_comment
        return self

    def with_system_comment(self, key: str, system_comment: str):
        self._system_comments[key] = system_comment
        return self

    def with_system_comments(self, system_comments: dict[str, str]):
        self._system_comments = system_comments
        return self

    def build(self) -> HistoryEntry:
        timestamp = int(datetime.now().timestamp() * 1000)
        he = HistoryEntry(
            timestamp=timestamp,
            operation=self._operation,
            byActorId=self._actor_id,
            byUserId=self._user_id,
            byUserNickname=None,
            systemComments=self._system_comments,
            userComment=self._user_comment,
        )
        return he

from collections.abc import Iterable, Mapping
from typing import Any

from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message
from pydantic import BaseModel


class VarPrinter:
    """
    This class is wrapping a variable - any type - and if to-string conversion happens to it then it correctly prints that into a string.
    This is really happening lazy fashion - only when string conversion occurs.

    Therefore this is is really useful for logging for example - as wrapping something into this is cheap, expensive string conversion will really only occur if needed.

    This also support recognizing and printing Protobuf objects as well as Pydantic models.

    Sample usage together with logging:
    ```
    # we have a list of complex objects
    entities: List[AssetDefinition] = list()
    ...
    # and finally we want to log the list of these complex objects
    # BUT only if debug level log is enabled (otherwise do NOT assemble the strings)
    # To achieve this I can simply wrap it into a VarPrinter
    self._LOG.debug("%s() returned: %s", method_name, VarPrinter(entities), **log_labels)
    ```
    """

    def __init__(self, var: Any):
        self._var = var

    def __str__(self):
        if isinstance(self._var, str):
            return f"'{self._var}'"
        if (
            isinstance(self._var, bool)
            or isinstance(self._var, int)
            or isinstance(self._var, float)
        ):
            return f"{self._var}"

        # is is a Protobuf generated object?
        if isinstance(self._var, Message):
            to_dic = MessageToDict(
                self._var,
                preserving_proto_field_name=True,
                always_print_fields_with_no_presence=True,
            )
            v_str = str(to_dic)
            return v_str

        # is this a Pydantic model?
        if isinstance(self._var, BaseModel):
            # it has a nice built in 1 liner json printing
            return f"{self._var}"

        # does this variable have custom to-string?
        if self._var.__class__.__str__ is not object.__str__:
            return f"{self._var}"

        if isinstance(self._var, Mapping):
            # Now we have something which is a map/dict whatever, key-value pairs - we go into recursion
            items: list[str] = list()
            for k, v in self._var.items():
                key_vprinter = VarPrinter(k)
                value_vprinter = VarPrinter(v)
                items.append(f"{key_vprinter}:{value_vprinter}")
            return "{" + ", ".join(items) + "}"

        if isinstance(self._var, Iterable):
            # Now we have something which is a list/set whatever - we go into recursion
            items: list[str] = list()
            for item in self._var:
                vprinter = VarPrinter(item)
                items.append(str(vprinter))
            return "[" + ", ".join(items) + "]"

        # OK no better idea - just fall back to str
        return f"{self._var}"

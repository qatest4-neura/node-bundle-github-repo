"""
Exception helper methods.
"""


def get_exception_message(exc: Exception) -> str:
    """
    Retrieve the 'message' attribute from an Exception, if it exists.
    Falls back to str(exc) if 'message' is not present.

    Args:
        exc (Exception): The exception instance.

    Returns:
        str: The exception's message.
    """
    if hasattr(exc, "message"):
        return getattr(exc, "message", None)
    return str(exc)

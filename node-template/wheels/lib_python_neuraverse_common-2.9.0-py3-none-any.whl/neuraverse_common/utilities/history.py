from typing import List, Optional, TypeVar

from neuraverse.models.v1.gen.business.asset_pb2 import AssetDefinition, AssetInstance
from neuraverse.models.v1.gen.business.common_pb2 import HistoryEntry
from neuraverse.models.v1.gen.business.project_pb2 import Project


def append_and_trim_history(
    history_entries: List[HistoryEntry],
    new_entry: Optional[HistoryEntry],
    max_entity_num_of_history: int,
) -> List[HistoryEntry]:
    """
    Append a new history entry to the list and trim it to maintain a maximum size.

    If new_entry is None, the function will only trim the list without appending.
    The function keeps the first (oldest) entry plus the most recent
    (max_entity_num_of_history - 1) entries, ensuring we always retain the earliest
    history entry for audit purposes while limiting the total size.

    Entries with timestamp=0 (not set) are excluded from sorting and preserve
    their original relative positions in the list.

    Args:
        history_entries: List of existing HistoryEntry objects. Can be empty.
        new_entry: The new HistoryEntry to append. If None, only trims the list.
        max_entity_num_of_history: Maximum number of history entries to retain.
                                   Must be at least 1.

    Returns:
        The trimmed list of HistoryEntry objects with the new entry appended (if provided).

    Raises:
        ValueError: If max_entity_num_of_history is less than 1.
    """
    if max_entity_num_of_history < 1:
        raise ValueError("max_entity_num_of_history must be at least 1")

    # Append the new entry before sorting, so its position is handled correctly
    entries = list(history_entries)
    if new_entry is not None:
        entries.append(new_entry)

    # Separate entries into zero-timestamp (position preserved) and non-zero (to be sorted)
    zero_ts_positions = {}  # index -> entry, for entries with timestamp=0
    non_zero_entries = []  # entries with a real timestamp

    for i, entry in enumerate(entries):
        if entry.timestamp == 0:
            zero_ts_positions[i] = entry
        else:
            non_zero_entries.append(entry)

    # Sort only the non-zero timestamp entries
    sorted_non_zero = sorted(non_zero_entries, key=lambda e: e.timestamp)

    # Merge back: fill positions in order, reinserting zero-ts entries at original slots
    merged: List[HistoryEntry] = []
    non_zero_iter = iter(sorted_non_zero)

    for i in range(len(entries)):
        if i in zero_ts_positions:
            merged.append(zero_ts_positions[i])
        else:
            merged.append(next(non_zero_iter))

    # Trim: keep first entry + most recent (max_entity_num_of_history - 1) entries
    if len(merged) > max_entity_num_of_history:
        first_entry = [merged[0]]
        num_recent = max_entity_num_of_history - 1
        recent_entries = merged[-num_recent:] if num_recent > 0 else []
        merged = first_entry + recent_entries

    return merged


T = TypeVar("T", AssetInstance, AssetDefinition, Project)


def trim_history(
    entity: T,
    new_history_entry: HistoryEntry,
    max_entity_num_of_history: int,
    max_attachment_num_of_history: int,
):
    """
    Trims the history of an entity and its attachments in place.

    Appends the new history entry to the entity's history and trims it to the
    specified maximum size. The same trimming is applied to each attachment's
    history, without appending a new entry.

    Args:
        entity (T): The entity whose history will be trimmed. Can be any type
            that has a `history` list and an `attachments` dictionary
            (e.g. AssetInstance, AssetDefinition, Project).
        new_history_entry (HistoryEntry): The new history entry to append to
            the entity's history before trimming.
        max_entity_num_of_history (int): Maximum number of history entries to
            retain for the entity. If 0 or less, entity history is not trimmed.
        max_attachment_num_of_history (int): Maximum number of history entries
            to retain per attachment. If 0 or less, attachment history is not trimmed.

    Returns:
        None: The entity and its attachments are modified in place.

    Example:
        >>> trim_history(project, new_history_entry, max_entity_num_of_history=10, max_attachment_num_of_history=5)
    """

    if max_entity_num_of_history > 0:
        trimmed_history = append_and_trim_history(
            entity.history, new_history_entry, max_entity_num_of_history
        )
        entity.history.clear()
        entity.history.extend(trimmed_history)

    # trim attachment history
    if max_attachment_num_of_history > 0:
        for attachment in entity.attachments.values():
            trimmed_attachment_history = append_and_trim_history(
                attachment.history, None, max_attachment_num_of_history
            )
            attachment.history.clear()
            attachment.history.extend(trimmed_attachment_history)

"""
This module provides utility methods for working with protobuf objects within
the NEURA robotics tenant service.

The `ProtoUtils` class includes methods for converting dictionaries to protobuf
messages, wrapping strings into protobuf `Any` types, and extracting service
versions from service names. These utilities simplify common protobuf-related
operations and promote code reuse across the application.
"""

import re
from typing import Set, Type

from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.message import Message


def dict_to_proto(
    data: dict,
    proto_class: Type[Message],
    ignored_fields: Set[str] = None,
    ignore_unknown_fields=True,
) -> Message:
    """
    Converts a dictionary into a protobuf object, removing unwanted internal fields like `_id`, `_t`.

    Args:
        data (dict): The dictionary to convert into a protobuf message.
        proto_class (Type[Message]): The protobuf message class to instantiate and populate.
        ignored_fields (Set[str], optional): A set of field names to exclude from the dictionary before conversion.
            Defaults to {"_id", "_t"} if not provided.
        ignore_unknown_fields (bool, optional): Whether to ignore unknown fields in the input dictionary that
            do not correspond to fields in the protobuf message. Defaults to True.

    Returns:
        Message: An instance of the specified protobuf message class populated with the data from the dictionary,
            excluding any ignored fields.
    """
    ignored_fields = ignored_fields or {"_id", "_t"}
    clean_data = {k: v for k, v in data.items() if k not in ignored_fields}
    return ParseDict(clean_data, proto_class(), ignore_unknown_fields=ignore_unknown_fields)


def proto_to_string(proto_message):
    """
    Converts a protobuf message to a string by first converting it to a dictionary using
    `google.protobuf.json_format.MessageToDict`, then casting the dictionary to a string.
    If the input is not a protobuf message, returns its string representation.

    Options used in MessageToDict:
        - preserving_proto_field_name=True:
            Field names in the resulting dictionary will match the names defined in the .proto file (snake_case),
            rather than being converted to camelCase. This helps maintain consistency with the proto schema.
        - always_print_fields_with_no_presence=True:
            Fields that do not have presence (such as scalar fields in proto3) will always be included in the output,
            even if they are set to their default values. This ensures all fields are visible in the output, not just those explicitly set.

    Args:
        obj: The object to convert.

    Returns:
        str: A string representation of the protobuf message as a dictionary, or the string representation of the input if it is not a protobuf message.
    """
    if isinstance(proto_message, Message):
        to_dic = MessageToDict(
            proto_message,
            preserving_proto_field_name=True,
            always_print_fields_with_no_presence=True,
        )
        return str(to_dic)
    return str(proto_message)


def proto_to_dict(proto_obj: Message, keep_all_fields: bool = False) -> dict:
    """
    Converts a protobuf object to a dictionary suitable for MongoDB storage.

    Args:
        proto_obj (Message): The protobuf object to convert.
        keep_all_fields (bool): If False then we leave out all feilds from the dict which are not set - otherwise all fields will be there but with proto default values. Default is: False

    Returns:
        dict: The resulting dictionary.
    """

    # Use MessageToDict to convert proto to dict, preserving field names and including default values
    return MessageToDict(
        proto_obj,
        preserving_proto_field_name=True,
        always_print_fields_with_no_presence=keep_all_fields,
    )


def extract_service_version(service_name: str) -> str:
    """
    Extracts the version of the service from the service name as defined in the proto file.

    Args:
        service_name (str): The name of the service.

    Returns:
        str: The extracted version, or an empty string if no version is found.
    """
    match = re.search(r"\.v(\d+)\.", service_name)
    return match.group(1) if match else ""

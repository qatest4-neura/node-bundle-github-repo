"""
This module implements the `JwtValidator` class for validating JWT tokens
using JSON Web Key Set (JWKS) endpoints.

The `JwtValidator` class fetches the JWKS from the configured authorization server,
retrieves the appropriate public key for a given token, and validates the token's
signature, audience, and issuer.
"""

import threading
import time
from functools import lru_cache
from typing import Optional

import requests
from cachetools import LRUCache
from jose import JWTError, jwt

from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.config.config_source.JwtConfig import (
    AuthAppConfig,
    AuthApplicationName,
    JwtConfig,
)
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability.logging import Logger, LoggerFactory


# Cache one entry per distinct JWKS URL. Multiple identity providers (e.g. Auth0 and SPIRE)
# are now supported simultaneously, so maxsize must be > 1 to avoid the two providers'
# JWKS evicting each other on every alternating request.
@lru_cache(maxsize=32)
def _load_jwks_cached(jwks_url: str, ttl_hash=None) -> list:
    """
    Internal cached function to fetch JWKS without dynamic context.
    """
    del ttl_hash
    response = requests.get(jwks_url)
    response.raise_for_status()
    return response.json()["keys"]


def load_jwks(jwks_url: str, ttl_hash=None, context: ExecutionContext = None) -> list:
    """
    Fetches JWKS from the given URL with caching.

    Args:
        jwks_url (str): JWKS endpoint.
        ttl_hash (int, optional): Dummy TTL-based hash to expire cache.
        context (ExecutionContext, optional): Unused execution context.

    Returns:
        list: List of JWK keys.
    """
    return _load_jwks_cached(jwks_url, ttl_hash)


load_jwks.cache_clear = _load_jwks_cached.cache_clear


class JwtValidator:
    """
    Validates JWT tokens using a JSON Web Key Set (JWKS),
    with lazy cache eviction for expired tokens.
    """

    _global_last_eviction_time = 0
    _global_eviction_lock = threading.Lock()
    logger_name: str = "lib.common.jwt.JWTValidator"

    USER_ID_CLAIM = "https://neuraverse.com/user_id"
    USER_FALLBACK_CLAIM = "sub"
    SERVICE_ID_CLAIM = "https://neuraverse.com/service_id"
    SERVICE_FALLBACK_CLAIM = "gty"
    # SPIFFE JWT-SVIDs carry the SPIFFE ID (e.g. "spiffe://trust-domain/workload") in their subject.
    SPIFFE_SUBJECT_PREFIX = "spiffe://"
    ISSUER_CLAIM = "iss"
    AUDIENCE_CLAIM = "aud"
    # Cognito mints access and ID tokens from the same pool and distinguishes them with this claim.
    TOKEN_USE_CLAIM = "token_use"

    def __init__(self, jwt_config: JwtConfig):
        """
        Initializes the validator with the given JWT configuration.

        Args:
            jwt_config (JwtConfig): The JWT configuration for validation.
        """
        self.LOG: Logger = LoggerFactory.get_logger(self.logger_name)
        self.jwt_config = jwt_config
        self.token_cache = LRUCache(maxsize=jwt_config.token_cache_size)
        self._lazy_eviction_interval = jwt_config.token_cache_ttl_seconds

    # --- JWKS retrieval and caching ---
    def _get_ttl_hash(self, context: ExecutionContext = None) -> int:
        """
        Returns a value that changes every configured JWKS TTL interval (in days).
        Used to simulate TTL-based cache invalidation for lru_cache.
        """
        ttl_seconds = self.jwt_config.jwks_ttl_days * 24 * 60 * 60
        return round(time.time() / ttl_seconds)

    def _get_jwks(self, jwks_url: str, context: ExecutionContext = None) -> list:
        """
        Retrieves JWKS using TTL-based cached function.

        Args:
            jwks_url (str): The JWKS URL.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            list: List of JWKs.
        """
        ttl_hash = self._get_ttl_hash(context=context)
        return load_jwks(jwks_url=jwks_url, ttl_hash=ttl_hash, context=context)

    def force_refresh(self, context: ExecutionContext = None) -> None:
        """
        Forces JWKS cache to be cleared and refetched on next call.
        Clears the token cache as well.
        """
        # TODO context passing here?
        load_jwks.cache_clear()
        self.clear_token_cache(context=context)
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.info(
            "JWKS and token caches have been cleared. JWKS will be refetched on next call.",
            **log_labels,
        )

    def _get_public_key(self, token: str, jwks_url: str, context: ExecutionContext = None) -> dict:
        """
        Retrieves the public key matching the token's key ID (kid).

        Args:
            token (str): The JWT token.
            jwks_url (str): The JWKS URL to fetch keys from.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            dict: The public key.
        """
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
        jwks = self._get_jwks(jwks_url, context=context)
        key = next((k for k in jwks if k["kid"] == kid), None)
        if not key:
            raise errors_v2.NeuraIllegalStateError(
                message="Matching public key not found in JWKs"
            ).with_is_retryable(False).with_errorcode(
                errors_v2.NeuraIllegalStateError.ERRCODE_EXCPECTATION_FAILED
            )

        return key

    # --- Token validation and caching ---
    def _resolve_application_by_claim_shape(
        self, unverified_claims: dict, context: ExecutionContext = None
    ) -> Optional[str]:
        """Resolves the application from the shape of the token's claims.

        Fallback for tokens whose issuer is not indexed - in practice the Auth0 applications,
        which all share the same derived issuer. Unchanged behaviour, extracted from
        `_decode_token` so issuer based routing can run ahead of it.

        Args:
            unverified_claims (dict): The token's claims, not yet verified.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            Optional[str]: The resolved application name.
        """
        subject = unverified_claims.get(self.USER_FALLBACK_CLAIM, "")

        # SPIFFE JWT-SVIDs (issued by a SPIRE server) are identified by a "spiffe://" subject.
        # They are validated against the dedicated SPIRE application JWKS, not Auth0.
        if subject.startswith(self.SPIFFE_SUBJECT_PREFIX):
            return AuthApplicationName.SPIRE
        if self.USER_ID_CLAIM in unverified_claims or subject.startswith("auth0|"):
            return AuthApplicationName.SPA

        # TODO: [NRV-4541] Create config map for each M2M application by service_id
        if self.SERVICE_ID_CLAIM in unverified_claims:
            return self.jwt_config.applications.get([unverified_claims[self.SERVICE_ID_CLAIM]])
        # Note: For now, we only have one M2M application, so we map all other cases to it
        if (
            self.SERVICE_FALLBACK_CLAIM in unverified_claims
            and unverified_claims[self.SERVICE_FALLBACK_CLAIM] == "client-credentials"
        ):
            return AuthApplicationName.M2M_DEFAULT

        # Neither the issuer nor the claim shape identifies a configured application.
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.warning(
            "Rejected token: issuer '%s' matches no configured application, and its claims match "
            "no known application shape.",
            unverified_claims.get(self.ISSUER_CLAIM),
            **log_labels,
        )
        raise errors_v2.NeuraAuthenticationError(
            message="Invalid token: no configured authentication application matches its issuer "
            "or claims"
        )

    def _reject_unexpected_audience(
        self, decoded_token: dict, app_name: str, context: ExecutionContext = None
    ) -> None:
        """Rejects a token that carries an "aud" we were never told how to validate.

        Only reached for applications with no configured audience. Such an application cannot
        check an audience, so accepting a token that asserts one would silently widen what the
        application accepts - previously jose rejected these, because the unset audience was
        passed through as the literal "Not set" and compared. Cognito access tokens carry no
        "aud" at all and are unaffected.

        Args:
            decoded_token (dict): The verified token payload.
            app_name (str): The resolved application name, for logging.
            context (ExecutionContext, optional): The execution context for logging.
        """
        if self.AUDIENCE_CLAIM not in decoded_token:
            return

        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.warning(
            "Rejected token for application '%s': it carries an 'aud' claim but the application "
            "configures no audience to validate it against.",
            app_name,
            **log_labels,
        )
        raise errors_v2.NeuraAuthenticationError(
            message="Invalid token: unexpected audience for an application with no configured "
            "audience"
        )

    def _verify_token_use(
        self,
        decoded_token: dict,
        app_config: AuthAppConfig,
        app_name: str,
        context: ExecutionContext = None,
    ) -> None:
        """Enforces the application's required "token_use" claim, when it declares one.

        Cognito mints access and ID tokens from the same user pool and tells them apart with this
        claim, so an application backed by a Cognito pool must reject anything that is not an
        access token. Applications that do not set `required_token_use` (every Auth0 one) are
        unaffected.

        Args:
            decoded_token (dict): The verified token payload.
            app_config (AuthAppConfig): The resolved application configuration.
            app_name (str): The resolved application name, for logging.
            context (ExecutionContext, optional): The execution context for logging.
        """
        required_token_use = app_config.required_token_use
        if required_token_use is None:
            return

        token_use = decoded_token.get("token_use")
        if token_use != required_token_use:
            log_labels = context.get_labels_for_log() if context else {}
            self.LOG.warning(
                "Rejected token for application '%s': token_use '%s', expected '%s'.",
                app_name,
                token_use,
                required_token_use,
                **log_labels,
            )
            raise errors_v2.NeuraAuthenticationError(
                message=f"Invalid token: expected token_use '{required_token_use}'"
            )

    def _decode_token(self, token: str, context: ExecutionContext = None) -> dict:
        """
        Decodes and validates the JWT token using the public key.
        Args:
            token (str): The JWT token to decode.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            dict: The decoded token payload.
        """
        try:
            # Get unverified claims to determine which application config to use
            unverified_claims = jwt.get_unverified_claims(token)

            # Issuer based routing first: it is explicit and works for any provider, including
            # ones whose tokens carry none of the Auth0/SPIRE claim shapes below (e.g. Neura Gym's
            # Cognito pool). The issuer is only ever used to look up a configured application - a
            # JWKS URL is never constructed from it.
            app_name = self.jwt_config.application_for_issuer(
                unverified_claims.get(self.ISSUER_CLAIM)
            )

            if app_name is None:
                app_name = self._resolve_application_by_claim_shape(
                    unverified_claims, context=context
                )

            app_config = self.jwt_config.applications.get(app_name)
            if app_config is None:
                raise errors_v2.NeuraAuthenticationError(
                    message=f"No authentication application configured for token (resolved: '{app_name}')"
                )

            # Validate using the appropriate application config. Algorithms may be overridden per
            # application (e.g. SPIRE JWT-SVIDs may use a different algorithm than Auth0).
            issuer = app_config.issuer
            jwks_url = app_config.jwks_url
            algorithms = app_config.algorithms or [self.jwt_config.algorithm]
            public_key = self._get_public_key(token, jwks_url)

            if app_config.has_audience():
                decoded_token = jwt.decode(
                    token,
                    public_key,
                    algorithms=algorithms,
                    audience=app_config.audience,
                    issuer=issuer,
                )
            else:
                # No audience configured. Cognito access tokens carry no "aud" claim at all, and
                # python-jose skips audience validation entirely when the claim is absent, so
                # passing an audience here would look like a check while validating nothing.
                # Disable the check explicitly instead of relying on that silent behaviour.
                decoded_token = jwt.decode(
                    token,
                    public_key,
                    algorithms=algorithms,
                    issuer=issuer,
                    options={"verify_aud": False},
                )
                self._reject_unexpected_audience(decoded_token, app_name, context=context)

            self._verify_token_use(decoded_token, app_config, app_name, context=context)
            return decoded_token
        except JWTError as e:
            log_labels = context.get_labels_for_log() if context else {}
            self.LOG.error("JWT decoding failed: %s", str(e), **log_labels)
            if "Signature verification failed" in str(e):
                self.force_refresh(context=context)
                # we throw unsafe error at this point
                raise errors_v2.NeuraAuthenticationError(message="Invalid token signature") from e
            else:
                raise errors_v2.NeuraAuthenticationError(message=f"Invalid token: {str(e)}") from e

    def _get_cached_token(self, token: str, context: ExecutionContext = None) -> Optional[dict]:
        """
        Check cache and return decoded token if still valid.

        Args:
            token (str): The JWT token.

        Returns:
            Optional[dict]: The decoded token if found and not expired, else None.
        """
        cached = self.token_cache.get(token)
        if cached:
            expiry_ts, decoded_token = cached
            if time.time() < expiry_ts:
                return decoded_token
            else:
                del self.token_cache[token]
        return None

    def _store_in_cache(
        self, token: str, decoded_token: dict, context: ExecutionContext = None
    ) -> None:
        """
        Stores a token with its *exact* exp claim as cache expiry.
        If no exp is present, falls back to configured default TTL.
        Also, clears expired tokens from cache before storing.

        Args:
            token (str): The JWT token.
            decoded_token (dict): The decoded token payload.
        """
        now = time.time()
        exp = decoded_token.get("exp")

        expiry_ts = exp if exp is not None else now + self.jwt_config.token_cache_ttl_seconds

        self.token_cache[token] = (expiry_ts, decoded_token)

    def clear_token_cache(self, context: ExecutionContext = None) -> None:
        """Clear all cached validated tokens."""
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.debug("clearing cache", **log_labels)

        self.token_cache.clear()

    def _evict_expired_tokens(self, context: ExecutionContext = None) -> None:
        """
        Removes expired tokens from cache opportunistically.
        """
        now = time.time()
        expired_keys = [
            token for token, (expiry_ts, _) in self.token_cache.items() if expiry_ts < now
        ]
        for token in expired_keys:
            del self.token_cache[token]
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.info(f"Evicted {len(expired_keys)} expired tokens from cache.", **log_labels)

    def _evict_cache_if_needed(self, context: ExecutionContext = None):
        """
        Performs lazy eviction of expired tokens from the cache.
        Eviction is triggered only if the configured interval has elapsed since the last eviction.
        Uses a lock to ensure thread safety and prevent redundant evictions under concurrent access.
        """
        now = time.time()

        if now - JwtValidator._global_last_eviction_time < self._lazy_eviction_interval:
            return

        if JwtValidator._global_eviction_lock.acquire(blocking=False):
            try:
                self._evict_expired_tokens(context=context)
                JwtValidator._global_last_eviction_time = now
            finally:
                JwtValidator._global_eviction_lock.release()

    def validate_token(self, token: str, context: ExecutionContext = None) -> dict:
        """
        Validates JWT token, using cache if available & not expired.

        Args:
            token (str): The JWT token to validate.

        Returns:
            dict: The decoded token if valid.
        """
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.debug("validating token...", **log_labels)

        self._evict_cache_if_needed(context=context)

        cached = self._get_cached_token(token, context=context)
        if cached:
            self.LOG.debug("found in cache - returning as validated", **log_labels)
            return cached

        self.LOG.debug("decoding token...", **log_labels)
        decoded_token = self._decode_token(token, context=context)
        self._store_in_cache(token, decoded_token, context=context)

        self.LOG.debug("all done - token cached", **log_labels)
        return decoded_token

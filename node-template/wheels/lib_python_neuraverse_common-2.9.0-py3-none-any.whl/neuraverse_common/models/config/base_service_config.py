import os
from typing import ClassVar, Tuple, Type

from dotenv import load_dotenv
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

from .config_source.RuntimeConfig import RuntimeConfig
from .service_info import ServiceInfo

# Load .env file explicitly into os.environ
load_dotenv()


class BaseServiceConfig(BaseSettings):
    """
    Base class for service configuration.
    Provides common model config and YAML/env resolution behavior.
    """

    runtime: RuntimeConfig = RuntimeConfig()

    # Constants for derived classes to override if needed
    CONFIG_FILE_ENVVAR: ClassVar[str] = "ENVVAR_CFG_PATH"
    DEFAULT_CONFIG_FILE: ClassVar[str] = "config/service_config.yaml"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._service_info = ServiceInfo()

    @property
    def service_info(self) -> ServiceInfo:
        """Get service information including name, version, and API version."""
        return self._service_info

    model_config = SettingsConfigDict(
        extra="allow",
        case_sensitive=True,
        validate_assignment=True,
        env_prefix="",
        env_nested_delimiter="__",
    )

    @classmethod
    def get_config_file_path(cls) -> str:
        """
        Determine the YAML configuration file path based on env var fallback.
        """
        return os.environ.get(cls.CONFIG_FILE_ENVVAR, cls.DEFAULT_CONFIG_FILE)

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        """
        Customizes configuration loading order: ENV -> YAML -> init.
        """
        config_path = cls.get_config_file_path()

        return (
            env_settings,
            YamlConfigSettingsSource(settings_cls, config_path),
            init_settings,
        )

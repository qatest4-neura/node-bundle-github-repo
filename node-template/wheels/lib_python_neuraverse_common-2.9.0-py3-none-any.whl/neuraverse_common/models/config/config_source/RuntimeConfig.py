from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class RuntimeConfig(BaseSettings):
    """
    Configuration for the asyncio event-loop runtime.
    """

    model_config = SettingsConfigDict(extra="allow")

    executor_max_workers: Optional[int] = Field(
        default=None,
        gt=0,
        description="Max threads in the asyncio default executor; defaults to Python built-in (min(32, cpu_count+4)) when unset",
    )

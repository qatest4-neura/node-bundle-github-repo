"""
This module defines the `JwtConfig` class for managing JWT configuration in the
NEURA robotics tenant service.

The `JwtConfig` class provides structured fields for defining JWT-related
settings, such as the JWKS URL, issuer, client ID, and roles. It
leverages Pydantic for validation and ensures that these fields are properly
set and documented.
"""

from enum import Enum
from typing import Dict, List, Optional, Union

from pydantic import ConfigDict, Field, model_validator
from pydantic_settings import BaseSettings


class AuthApplicationName(str, Enum):
    """
    This enum defines the standard names for authentication applications used in the Neuraverse ecosystem.

    New unknown application names can also be used as plain strings in the configuration.
    """

    # Single page application for end users
    SPA = "spa"
    # Auth0 Management API application
    AUTH0_MGMT = "auth0_mgmt"
    # Machine to Machine applications (for now only one, but will be extended in the future, 1 per service)
    M2M_DEFAULT = "m2m_default"
    # SPIFFE/SPIRE issued JWT-SVIDs (e.g. for devices/workloads authenticating via a SPIRE server).
    # Unlike the Auth0 based applications above, SPIRE is not backed by Auth0: it has no client
    # credentials and its issuer/JWKS endpoint do not follow the Auth0 "https://{domain}/..."
    # convention, so they must be configured explicitly.
    SPIRE = "spire"
    # Neura Gym's AWS Cognito user pool. Neura Gym users authenticate against Auth0 via SAML
    # federation, but the Cognito pool mints the access token, so the token is Cognito issued
    # and not Auth0 issued. Like SPIRE, its issuer/JWKS endpoint must be configured explicitly.
    NEURA_GYM = "neura_gym"


# Applications whose tokens are not issued by Auth0. They have no client credentials, and their
# issuer/JWKS endpoint do not follow the Auth0 "https://{domain}/..." convention, so both must be
# set explicitly rather than derived from the top level domain.
NON_AUTH0_APPLICATIONS = (AuthApplicationName.SPIRE, AuthApplicationName.NEURA_GYM)

# Sentinel used as the default for the string fields below: these are plain `str` rather than
# Optional[str] for backward compatibility, so "unset" has to be spelled out.
NOT_SET = "Not set"


class AuthAppConfig(BaseSettings):
    audience: str = Field(default="Not set", description="Audience for the application")
    client_id: str = Field(default="Not set", description="Client ID for the application")

    client_secret: str = Field(default="Not set", description="Client Secret for the application")
    domain: str = Field(default="Not set", description="Auth0 domain for the application")
    issuer: str = Field(
        default="Not set",
        description="Token issuer (defaults to https://{domain}/)",
    )
    jwks_url: str = Field(
        default="Not set",
        description="JWKS URL for the authentication provider (defaults to https://{domain}/.well-known/jwks.json)",
    )
    algorithms: Optional[List[str]] = Field(
        default=None,
        description=(
            "JWT signing algorithms accepted for this application. When not set, the global "
            "JwtConfig.algorithm is used. This allows non-Auth0 providers such as SPIRE, whose "
            "JWT-SVIDs may be signed with a different algorithm (e.g. ES256), to coexist with "
            "Auth0 (RS256)."
        ),
    )
    required_token_use: Optional[str] = Field(
        default=None,
        description=(
            "Required value of the 'token_use' claim. Cognito issues both access and ID tokens "
            "from the same pool and distinguishes them with this claim, so it is defaulted to "
            "'access' for the Neura Gym application to stop an ID token being presented in place "
            "of an access token. When None the claim is not checked, which is the behaviour for "
            "every Auth0 based application."
        ),
    )

    issuer_explicitly_configured: bool = Field(
        default=False,
        description=(
            "Set by JwtConfig once configuration is loaded: whether 'issuer' came from the "
            "configuration rather than being derived from the Auth0 domain. Only an explicitly "
            "configured issuer is used to route a token to this application - see "
            "JwtConfig.application_for_issuer. Not intended to be set by hand."
        ),
    )

    def has_audience(self) -> bool:
        """Whether a real audience is configured for this application.

        `audience` defaults to the sentinel string "Not set" rather than None, and Cognito access
        tokens carry no `aud` claim at all. Callers use this to decide whether to ask the JWT
        library to validate the audience - see JwtValidator._decode_token.
        """
        return bool(self.audience) and self.audience != NOT_SET


class JwtConfig(BaseSettings):
    """
    Configuration class for JWT settings.

    This class defines the necessary fields for configuring JWT authentication
    and role-based access control, now supporting multiple applications.

    Example configuration in YAML format:
    jwt:
        auth_type: "Bearer"
        algorithm: "RS256"
        domain: "xxx"  # default domain for applications
        jwks_ttl_days: 1
        token_cache_size: 1000
        token_cache_ttl_seconds: 32400
        applications:
            spa:
                audience: "xxx"
                # you can add/ omit domain, issuer, and jwks_url to use the defaults, or set them explicitly
                # domain: "xxx"
                # issuer: "xxx"
                # jwks_url: "xxx"
            auth0_mgmt:
                audience: "xxx"
            m2m_default:
                audience: "xxx"
            spire:
                # SPIRE is not Auth0 based: issuer and jwks_url MUST be set explicitly.
                audience: "xxx"
                issuer: "https://spire.example.com"
                jwks_url: "https://spire.example.com/keys"
                # SPIRE JWT-SVIDs may use a different algorithm than Auth0 (RS256).
                algorithms: ["RS256", "ES256"]
            neura_gym:
                # Neura Gym's AWS Cognito user pool. Not Auth0 based: issuer and jwks_url MUST be
                # set explicitly. Deliberately no 'audience': Cognito access tokens carry no 'aud'
                # claim, and the app client id is NOT an audience - it appears as 'client_id'.
                # Configuring it as an audience would silently validate nothing (python-jose skips
                # the check when 'aud' is absent), so leave it unset.
                issuer: "https://cognito-idp.eu-central-1.amazonaws.com/eu-central-1_xxx"
                jwks_url: "https://cognito-idp.eu-central-1.amazonaws.com/eu-central-1_xxx/.well-known/jwks.json"
                algorithms: ["RS256"]
                # required_token_use defaults to "access" for this application.

    other fields like AUTH_CLIENT_ID, AUTH_IDP_API_CLIENT_ID, and AUTH_IDP_API_CLIENT_SECRET
    are expected to be set via environment variables or secret management.
    """

    model_config = ConfigDict(extra="allow")

    # Sensitive variables from environment variables or secret management
    AUTH_CLIENT_ID: str = Field(default="Not set", description="Default client ID")
    AUTH_IDP_API_CLIENT_ID: str = Field(
        default="Not set", description="Auth0 Client ID for Machine to Machine Application"
    )
    AUTH_IDP_API_CLIENT_SECRET: str = Field(
        default="Not set", description="Auth0 Client Secret for Machine to Machine Application"
    )
    # Only for local development
    FOR_LOCAL_DEVELOPMENT_IDP_API_TOKEN_OVERRIDE: str = Field(
        default="",
        description="Auth0 management API token - so we do not fetch a new one every time in local development",
    )
    # --- Deprecated fields for backward compatibility ---
    # TODO: Remove deprecated fields from secret manager. These variables can be derived from 'domain' in each app config.
    AUTH_JWKS_URL: str = Field(default="Not set", description="JWKS endpoint URL")
    AUTH_ISSUER: str = Field(default="Not set", description="JWT issuer")

    # Variables defined in the config file
    auth_type: str = Field(default="Bearer", description="Authentication type")
    algorithm: str = Field(default="RS256", description="JWT signing algorithm")
    domain: str = Field(default="Not set", description="Auth0 domain for default application")
    jwks_ttl_days: int = Field(
        default=1, description="Time-to-live for cached JWKS in days, defaults to 1 day"
    )
    token_cache_size: int = Field(default=1000, description="Maximum size of the token cache")
    token_cache_ttl_seconds: int = Field(
        default=32400, description="Time-to-live for cached tokens in seconds, defaults to 9 hours"
    )

    applications: Dict[Union[AuthApplicationName, str], AuthAppConfig] = Field(
        default_factory=dict,
        description="Configuration for different Auth0 applications",
    )

    @model_validator(mode="after")
    def map_client_credentials(self) -> "JwtConfig":
        for app_name, app_config in self.applications.items():
            # Record this before any derivation below overwrites it: an issuer that was derived
            # from the Auth0 domain is shared by every Auth0 application and so cannot identify
            # one, whereas an explicitly configured issuer can.
            app_config.issuer_explicitly_configured = app_config.issuer != NOT_SET

            # Non-Auth0 applications (SPIRE, Neura Gym) have no client credentials and their
            # issuer/JWKS endpoint do not follow the Auth0 "https://{domain}/..." convention,
            # so they must be configured explicitly and skip the Auth0 derivation below.
            if app_name in NON_AUTH0_APPLICATIONS:
                if app_config.jwks_url == NOT_SET or app_config.issuer == NOT_SET:
                    raise ValueError(
                        f"'{AuthApplicationName(app_name).value}' application config requires "
                        "explicit 'issuer' and 'jwks_url'."
                    )
                # Cognito issues access and ID tokens from the same pool, so the Neura Gym
                # application always checks token_use unless it is overridden explicitly.
                if (
                    app_name == AuthApplicationName.NEURA_GYM
                    and app_config.required_token_use is None
                ):
                    app_config.required_token_use = "access"
                continue

            # Populate domain if not set
            if app_config.domain == NOT_SET:
                app_config.domain = self.domain

            # Map client credentials to known applications
            if app_name == AuthApplicationName.SPA:
                app_config.client_id = self.AUTH_CLIENT_ID
            # TODO: [NRV-4541] Add support for multiple M2M applications with different configurations
            # Note: For now, we have only one M2M application used by multiple services, so we map the same credentials.
            # Note: auth0 mgmt api and m2m default share the same client id/secret but have different audiences/ domains
            elif app_name in (
                AuthApplicationName.AUTH0_MGMT,
                AuthApplicationName.M2M_DEFAULT,
            ):
                app_config.client_id = self.AUTH_IDP_API_CLIENT_ID
                app_config.client_secret = self.AUTH_IDP_API_CLIENT_SECRET

            # Derive OIDC fields if not explicitly set
            if app_config.issuer == NOT_SET:
                app_config.issuer = f"https://{app_config.domain}/"

            if app_config.jwks_url == NOT_SET:
                app_config.jwks_url = f"https://{app_config.domain}/.well-known/jwks.json"
        return self

    def application_for_issuer(
        self, issuer: Optional[str]
    ) -> Optional[Union[AuthApplicationName, str]]:
        """Returns the application configured for the given token issuer, if exactly one is.

        Only applications with an *explicitly configured* issuer are considered. The Auth0
        applications derive the same "https://{domain}/" issuer, so it identifies none of them;
        their tokens are routed by claim shape instead. An explicit issuer shared by more than one
        application is treated as ambiguous and also ignored, so routing never has to guess.

        Args:
            issuer (Optional[str]): The "iss" claim of the token being validated.

        Returns:
            Optional[Union[AuthApplicationName, str]]: The application name, or None when no
            single application owns this issuer.
        """
        if not issuer:
            return None
        matches = [
            app_name
            for app_name, app_config in self.applications.items()
            if app_config.issuer_explicitly_configured and app_config.issuer == issuer
        ]
        return matches[0] if len(matches) == 1 else None

"""
This module defines the `ExternalServicesConfig` class for managing external gRPC service
configuration in the NEURA robotics services.
"""

from deprecated import deprecated
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


@deprecated(
    "This does not belong here as a generic thing so if you use it, move away from here somehow as we will remove this class soon"
)
class ExternalServicesConfig(BaseSettings):
    """
    Configuration class for External services settings.

    This class defines the necessary fields for configuring external gRPC services,
    including service name, address, and port. It uses Pydantic's BaseSettings to
    provide validation and settings management.
    """

    model_config = SettingsConfigDict(extra="allow")

    name: str = Field(..., description="Name of the external gRPC service")
    address: str = Field(..., description="Hostname or IP address of the gRPC service")
    port: int = Field(..., description="Port number the gRPC service is running on")

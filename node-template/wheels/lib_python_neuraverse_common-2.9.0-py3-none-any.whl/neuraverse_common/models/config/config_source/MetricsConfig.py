"""
This module defines the `MetricsConfig` class for managing Prometheus exposition format / server configuration
in the NEURA robotics service.
"""

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MetricsConfig(BaseSettings):
    """
    Configuration class for Metrics settings.
    """

    model_config = SettingsConfigDict(extra="allow")

    is_enabled: bool = Field(
        default=True, description="If set to False then basically metrics is disabled completely."
    )
    http_port: int = Field(default=9008, description="HTTP port of Prometheus scraping endpoint")
    GC_COLLECTOR_enabled: bool = Field(
        default=False, description="If True then GC related metrics will be exposed - otherwise not"
    )
    PLATFORM_COLLECTOR_enabled: bool = Field(
        default=False,
        description="If True then PlatformCollector related metrics will be exposed - otherwise not",
    )
    PROCESS_COLLECTOR_enabled: bool = Field(
        default=False,
        description="If True then ProcessCollector related metrics will be exposed - otherwise not",
    )

    # For this long time window Summaries provide statistical information like min/max/mean etc.
    # Choose it based on your metrics scraping interval! Best is if this window is the same but should not be smaller at least.
    default_sliding_timewindow_seconds: int = Field(
        default=60,
        description="For statistical calculations this is the reveant time window size measured in seconds",
    )

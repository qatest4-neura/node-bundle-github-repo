import sys
import threading
import time
from typing import Iterable, Optional, Sequence

import prometheus_client
from prometheus_client import values
from prometheus_client.registry import REGISTRY, CollectorRegistry
from prometheus_client.samples import Sample

from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.config.config_source import MetricsConfig
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.utilities import preconditions


class _MaintainedMetricInstance:
    """
    Internal helper class
    """

    def __init__(self, instance: any, trigger_seconds: int = 0):
        self.instance = instance
        self.trigger_seconds = trigger_seconds
        self.next_maintenance_ts: float = time.time() + trigger_seconds


class _MaintainedMetrics:
    """
    Internal class.
    We need to implement some scheduled actions over certain metrics. This class holds them so we can do the scheduling at central place.
    """

    MAINTENANCE_FREQUENCY_SECS: int = 5

    _instances: set[_MaintainedMetricInstance] = set()
    _LOG: Logger = LoggerFactory.get_logger("lib.observability._MaintainedMetrics")
    _timer = None
    _default_sliding_timewindow_seconds: int

    @classmethod
    def start(cls, metrics_config: MetricsConfig) -> None:
        cls._default_sliding_timewindow_seconds = metrics_config.default_sliding_timewindow_seconds
        cls._schedule_next_maintenance()

    @classmethod
    def _schedule_next_maintenance(cls) -> None:
        cls._timer = threading.Timer(
            interval=cls.MAINTENANCE_FREQUENCY_SECS, function=cls._maintain
        )
        cls._timer.start()

    @classmethod
    def register_instance(cls, instance, trigger_seconds: int = -1) -> None:
        if trigger_seconds == -1:
            trigger_seconds = cls._default_sliding_timewindow_seconds
        cls._instances.add(
            _MaintainedMetricInstance(instance=instance, trigger_seconds=trigger_seconds)
        )
        cls._LOG.debug("added metric to maintained metrics: %s", instance)

    @classmethod
    def _maintain(cls) -> None:
        cls._LOG.debug("maintenance triggered...")
        curr_time = time.time()
        for instance in cls._instances:
            try:
                if curr_time >= instance.next_maintenance_ts:
                    instance.instance.maintain_values()
                    # calculate next timeout
                    instance.next_maintenance_ts = curr_time + instance.trigger_seconds
            except Exception:
                # just skip silently
                pass
        cls._schedule_next_maintenance()


class _StatInfoBucket:
    """
    Internal class
    Holds statistical information for a time slice. Used by our Summary implementation
    """

    def __init__(self):
        self.create_ts = time.time()
        self.min: float = sys.maxsize
        self.max: float = 0
        self.count: int = 0
        self.sum: float = 0

    def observe(self, amount: float) -> None:
        self.count = self.count + 1
        self.sum = self.sum + amount
        if amount < self.min:
            self.min = amount
        if amount > self.max:
            self.max = amount

    def get_min(self) -> float:
        return self.min if self.min != sys.maxsize else 0

    def get_max(self) -> float:
        return self.max

    def get_mean(self) -> float:
        return self.sum / self.count

    def get_count(self) -> int:
        return self.count

    def get_sum(self) -> float:
        return self.sum

    def get_age_in_seconds(self) -> float:
        return time.time() - self.create_ts


class Summary(prometheus_client.Summary):
    """
    Our implementation of Summary to replace / wrap Prom Client's Summary class.
    Motivation: as we speak original Summary does not provide percentile / min/max/mean statistics - but we want to implement something on our level!

    For now `min`, `max` and `mean` statistical values are maintained for `MetricsConfig.default_sliding_timewindow_seconds` sliding time window.
    After window "slided" out all values return to be 0.0.
    Adding percentiles can come next but for now it is a good start.
    """

    _LOG: Logger = LoggerFactory.get_logger("lib.observability.Summary")

    def __init__(
        self,
        name: str,
        documentation: str,
        labelnames: Iterable[str] = (),
        namespace: str = "",
        subsystem: str = "",
        unit: str = "",
        registry: Optional[CollectorRegistry] = REGISTRY,
        _labelvalues: Optional[Sequence[str]] = None,
    ):
        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        super().__init__(
            name=name,
            documentation=documentation,
            labelnames=labelnames,
            namespace=namespace,
            subsystem=subsystem,
            unit=unit,
            registry=registry,
            _labelvalues=_labelvalues,
        )

        # TODO make these params / config later? for now let's just bake them
        sliding_timewindow_seconds = -1
        max_num_of_stat_buckets = 12

        self._lock = threading.Lock()

        if sliding_timewindow_seconds == -1:
            sliding_timewindow_seconds = MetricsFactory._config.default_sliding_timewindow_seconds
        self._sliding_timewindow_seconds = sliding_timewindow_seconds

        # one stat bucket will contain this many seconds of data in time
        self._statbucket_timespan = self._sliding_timewindow_seconds / max_num_of_stat_buckets
        # having too short timespan is just waste of resources! so keep it sane!
        if self._statbucket_timespan < 3:
            self._statbucket_timespan = 3

        self._LOG.debug(
            "created - num_of_stat_buckets: %s, statbucket_timespan: %s sec",
            max_num_of_stat_buckets,
            self._statbucket_timespan,
        )

        self._stat_buckets_queue: list[_StatInfoBucket] = list()

        # We will receive periodic triggers from here for maintenance
        _MaintainedMetrics.register_instance(instance=self)

    def maintain_values(self) -> None:
        """
        Removes all outdated `_StatInfoBucket` instances
        """

        # let's timeout and remove too old buckets
        with self._lock:
            if len(self._stat_buckets_queue) > 0:
                stat_buckets: list[_StatInfoBucket] = list()
                for stat_bucket in self._stat_buckets_queue:
                    if stat_bucket.get_age_in_seconds() < self._sliding_timewindow_seconds:
                        # we keep this - not timed out yet
                        stat_buckets.append(stat_bucket)
                self._stat_buckets_queue = stat_buckets
                self._current_stat_bucket = stat_buckets[-1] if len(stat_buckets) > 0 else None
            # self._LOG.debug("maintain finished - num of statbuckets now: %d", len(self._stat_buckets_queue))

    # we need to override this - to do not fail when metrics is disabled
    def labels(self, *labelvalues, **labelkwargs):
        if MetricsFactory._config.is_enabled:
            # normal operation
            return super().labels(*labelvalues, **labelkwargs)
        return self

    def _metric_init(self) -> None:
        super()._metric_init()

        self._min = values.ValueClass(
            self._type,
            self._name,
            self._name + "_min",
            self._labelnames,
            self._labelvalues,
            self._documentation,
        )
        self._min.set(0)
        self._max = values.ValueClass(
            self._type,
            self._name,
            self._name + "_max",
            self._labelnames,
            self._labelvalues,
            self._documentation,
        )
        self._max.set(0)
        self._mean = values.ValueClass(
            self._type,
            self._name,
            self._name + "_mean",
            self._labelnames,
            self._labelvalues,
            self._documentation,
        )
        self._mean.set(0)

    def _child_samples(self) -> Iterable[Sample]:
        samples: list[Sample] = list()
        samples.extend(super()._child_samples())

        min: float = sys.maxsize
        max: float = 0
        mean: float = 0
        # _c = 1
        with self._lock:
            if len(self._stat_buckets_queue) > 0:
                for statbucket in self._stat_buckets_queue:
                    if statbucket.get_min() < min:
                        min = statbucket.get_min()
                    if statbucket.get_max() > max:
                        max = statbucket.get_max()
                    mean = mean + statbucket.get_mean()
                    # print(f"_child_samples: calc#{_c} - min: {min}, max: {max}, mean: {mean}")
                    # _c += 1
                mean = mean / len(self._stat_buckets_queue)

        if min == sys.maxsize:
            min = 0

        # print(f"_child_samples: min: {min}, max: {max}, mean: {mean}")

        samples.append(Sample("", {"quantile": "0"}, min, None, None))
        samples.append(Sample("", {"quantile": "1"}, max, None, None))
        samples.append(Sample("", {"quantile": "0.5"}, mean, None, None))

        return tuple(samples)

    def observe(self, amount: float) -> None:
        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        super().observe(amount)

        # let's grab to top most bucket from the queue (we store reference too for this)
        with self._lock:
            curr_stat_bucket: _StatInfoBucket = None
            if len(self._stat_buckets_queue) > 0:
                # we need the last element
                curr_stat_bucket = self._stat_buckets_queue[-1]
                if curr_stat_bucket.get_age_in_seconds() > self._statbucket_timespan:
                    # too old to be current... let's ignore
                    curr_stat_bucket = None
                # else:
                #     self._LOG.debug("most recent StatInfoBucket still valid - num of statbuckets now: %d", len(self._stat_buckets_queue))
            # allocate a stat bucket - if we do not have any
            if curr_stat_bucket is None:
                curr_stat_bucket = _StatInfoBucket()
                # and push it to the end of queue
                self._stat_buckets_queue.append(curr_stat_bucket)
                # self._LOG.debug("new StatInfoBucket appended - num of statbuckets now: %d", len(self._stat_buckets_queue))

        # by now, this or that way but we have our current stat info
        # let's update it!
        curr_stat_bucket.observe(amount)


class MetricSet:
    """
    Base class of all metrics collection - created for a specific purpose
    """


class MessageConsumerMetricSet(MetricSet):
    """
    A set of metrics for message consuming scenarios. Simply just instantiate one metric set for each of your consumers and start using its methods to gain visibility!
    """

    _counter_template: prometheus_client.Counter = None
    _err_counter_template: prometheus_client.Counter = None
    _summary_template: Summary = None

    @classmethod
    def _get_counter_template(cls) -> prometheus_client.Counter:
        # we do it only once
        if cls._counter_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "consumer_id", "topic"])
            cls._counter_template = prometheus_client.Counter(
                name="messageconsumer_exec_count",
                documentation="Count 'of' something - groupped by consumer and topic",
                labelnames=label_names,
            )
        return cls._counter_template

    @classmethod
    def _get_err_counter_template(cls) -> prometheus_client.Counter:
        # we do it only once
        if cls._err_counter_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "consumer_id", "topic"])
            cls._err_counter_template = prometheus_client.Counter(
                name="messageconsumer_err_count",
                documentation="Count 'of' errors - groupped by consumer and topic",
                labelnames=label_names,
            )
        return cls._err_counter_template

    @classmethod
    def _getsummary_template(cls) -> Summary:
        # we do it only once
        if cls._summary_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "consumer_id", "topic"])
            cls._summary_template = Summary(
                # sliding_timewindow_seconds=0,
                name="messageconsumer_exec_time",
                documentation="Execution time 'of' something in millisecs - groupped by consumer and topic",
                labelnames=label_names,
            )
        return cls._summary_template

    def __init__(self, consumer_instance_id: str, topic_name: str):
        """
        Arguments:
            consumer_instance_id (str): The unique identifier of this message consumer instance - you will recognize from dashboard which one it is
            topic_name (str): The name of the topic this consumer is consuming
        """

        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        self._processing_started_counter = self.__class__._get_counter_template().labels(
            of="processing-started",
            consumer_id=consumer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )
        self._processing_failed_counter = self.__class__._get_err_counter_template().labels(
            of="processing-failed",
            consumer_id=consumer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )
        self._processing_time_observer = self.__class__._getsummary_template().labels(
            of="processing-time",
            consumer_id=consumer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )

    def processing_started(self, cntx: ExecutionContext = None):
        """
        Invoke this when your Consumer received a message. This will increase the respective counters to reflect this fact.
        """
        if MetricsFactory._config.is_enabled:
            self._processing_started_counter.inc()

    def processing_failed(self, cntx: ExecutionContext = None):
        """
        Invoke this when your Consumer failed to process the message. This will increase the respective counters to reflect this fact.
        """
        if MetricsFactory._config.is_enabled:
            self._processing_failed_counter.inc()

    def observe_processing_time(self, ellapsed_millis: int, cntx: ExecutionContext = None):
        """
        Invoke this to track how long did it take to actually process the message - passing in the millisecs value.
        """
        if MetricsFactory._config.is_enabled:
            self._processing_time_observer.observe(ellapsed_millis)


class MessageProducerMetricSet(MetricSet):
    """
    A set of metrics for message sending/producing scenarios. Simply just instantiate one metric set for each of your producers and start using its methods to gain visibility!
    """

    _counter_template: prometheus_client.Counter = None
    _err_counter_template: prometheus_client.Counter = None
    _summary_template: Summary = None

    @classmethod
    def _get_counter_template(cls) -> prometheus_client.Counter:
        # we do it only once
        if cls._counter_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "producer_id", "topic"])
            cls._counter_template = prometheus_client.Counter(
                name="messageproducer_exec_count",
                documentation="Count 'of' something - groupped by producer and topic",
                labelnames=label_names,
            )
        return cls._counter_template

    @classmethod
    def _get_err_counter_template(cls) -> prometheus_client.Counter:
        # we do it only once
        if cls._err_counter_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "producer_id", "topic"])
            cls._err_counter_template = prometheus_client.Counter(
                name="messageproducer_err_count",
                documentation="Count 'of' errors - groupped by producer and topic",
                labelnames=label_names,
            )
        return cls._err_counter_template

    @classmethod
    def _getsummary_template(cls) -> Summary:
        # we do it only once
        if cls._summary_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["of", "producer_id", "topic"])
            cls._summary_template = Summary(
                # sliding_timewindow_seconds=0,
                name="messageproducer_exec_time",
                documentation="Execution time 'of' something in millisecs - groupped by producer and topic",
                labelnames=label_names,
            )
        return cls._summary_template

    def __init__(self, producer_instance_id: str, topic_name: str):
        """
        Arguments:
            producer_instance_id (str): The unique identifier of this message producer instance - you will recognize from dashboard which one it is
            topic_name (str): The name of the topic this producer is sending to
        """

        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        self._sending_started_counter = self.__class__._get_counter_template().labels(
            of="sending-started",
            producer_id=producer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )
        self._sending_failed_counter = self.__class__._get_err_counter_template().labels(
            of="sending-failed",
            producer_id=producer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )
        self._sending_time_observer = self.__class__._getsummary_template().labels(
            of="sending-time",
            producer_id=producer_instance_id,
            topic=topic_name,
            **MetricsFactory._global_labels,
        )

    def sending_started(self, cntx: ExecutionContext = None):
        """
        Invoke this when your Producer starts sending a message. This will increase the respective counters to reflect this fact.
        """
        if MetricsFactory._config.is_enabled:
            self._sending_started_counter.inc()

    def sending_failed(self, cntx: ExecutionContext = None):
        """
        Invoke this when your Producer failed to send the message. This will increase the respective counters to reflect this fact.
        """
        if MetricsFactory._config.is_enabled:
            self._sending_failed_counter.inc()

    def observe_sending_time(self, ellapsed_millis: int, cntx: ExecutionContext = None):
        """
        Invoke this to track how long did it take to actually send the message - passing in the millisecs value.
        """
        if MetricsFactory._config.is_enabled:
            self._sending_time_observer.observe(ellapsed_millis)


class ServerEndpointMetricSet(MetricSet):
    """
    Useful for HTTP/gRPC/etc endpoints. This handy class brings a set of metrics optimized for synchronous serving typical scenarios.

    When you have an endpoint you simply go to the MetricsFactory.get_server_endpoint_metrics() method and get an instance of this class.
    Once you have the instance all you need to do is once you finished generating the response you invoke the .increment() method of it - passing over
    the status code you ended up with. This will dynamically create a Counter / Summary instances - if not yet exists - for that particular status_code and start counting.
    """

    _counter_template: prometheus_client.Counter = None
    _summary_template: Summary = None

    @classmethod
    def _get_counter_template(cls) -> prometheus_client.Counter:
        # we do it only once
        if cls._counter_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["endpoint", "type", "statusCode", "method"])
            cls._counter_template = prometheus_client.Counter(
                name="server_exec_count",
                documentation="Count of invocations - groupped by status code and method",
                labelnames=label_names,
            )
        return cls._counter_template

    @classmethod
    def _getsummary_template(cls) -> Summary:
        # we do it only once
        if cls._summary_template is None:
            # These will act as a family
            label_names: set[str] = set(MetricsFactory._global_labels.keys())
            label_names.update(["endpoint", "type", "statusCode", "method"])
            cls._summary_template = Summary(
                # sliding_timewindow_seconds=0,
                name="server_exec_time",
                documentation="How long req processing takes in millisecs - groupped by status code ('ok', 'not_found', ...)",
                labelnames=label_names,
            )
        return cls._summary_template

    def __init__(self, endpoint_name: str, endpoint_type: str):
        """
        Arguments:
            endpoint_name (str): the system wide unique name of this endpoint - keep it short!!!
            endpoint_type (str): Type of your server, like 'http' or 'grpc' or whatever
        """
        preconditions.check_argument(
            endpoint_name is not None and isinstance(endpoint_name, str) and endpoint_name != "",
            "'endpoint_name' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            endpoint_type is not None and isinstance(endpoint_type, str) and endpoint_type != "",
            "'endpoint_type' is mandatory and must be non emtpy string",
        )

        self.endpoint_name = endpoint_name
        self.endpoint_type = endpoint_type
        self._counters: dict[str, any] = dict()
        self._exec_times: dict[str, any] = dict()

    def increment(
        self,
        status_code: str | int = 0,
        method: str = "?",
        cntx: ExecutionContext = None,
    ) -> None:
        """Once you finished the response generation and know your status_code simply invoke this to get an incremented Count for that status code"""

        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        key = f"{status_code}_{method}"
        counter_instance = self._counters.get(key)
        if counter_instance is None:
            counter_tpl = self._get_counter_template()
            counter_instance = counter_tpl.labels(
                endpoint=self.endpoint_name,
                type=self.endpoint_type,
                statusCode=status_code,
                method=method,
                **MetricsFactory._global_labels,
            )
            self._counters.update({key: counter_instance})
        counter_instance.inc()

    def observe_exec_time(
        self,
        ellapsed_millis: int,
        status_code: str | int = 0,
        method: str = "?",
        cntx: ExecutionContext = None,
    ) -> None:
        """Once you finished the response generation and know your status_code simply invoke this and pass on how much millis did it take for that status code"""

        if MetricsFactory._config.is_enabled is False:
            # no point to do anything - lets just skip
            return

        key = f"{status_code}_{method}"
        summary_instance = self._exec_times.get(key)
        if summary_instance is None:
            counter_tpl = self._getsummary_template()
            summary_instance = counter_tpl.labels(
                endpoint=self.endpoint_name,
                type=self.endpoint_type,
                statusCode=status_code,
                method=method,
                **MetricsFactory._global_labels,
            )
            self._exec_times.update({key: summary_instance})
        summary_instance.observe(float(ellapsed_millis))


class MetricsFactory:
    """Static class helping you to deal with metrics. This class is your first contact point! To configure metrics and create metrics you can bind into your code"""

    _std_label_names: set[str] = None

    _std_event_counter_tpl: prometheus_client.Counter = None
    _std_error_counter_tpl: prometheus_client.Counter = None
    _std_warning_counter_tpl: prometheus_client.Counter = None
    _std_processing_time_summary_tpl: Summary = None
    _std_value_observer_summary_tpl: Summary = None

    @classmethod
    def configure_metrics(cls, config: MetricsConfig, global_labels: dict[str, any] = None):
        cls._LOG: Logger = LoggerFactory.getLogger("lib.common.observability.MetricsFactory")

        cls._config: MetricsConfig = config
        cls._global_labels: dict[str, any] = global_labels
        cls._std_label_names = set(cls._global_labels.keys())
        cls._std_label_names.update(["of", "qualifier", "_mtype"])

        cls._metric_sets: dict[str, MetricSet] = dict()

        if not cls._config.GC_COLLECTOR_enabled:
            prometheus_client.REGISTRY.unregister(prometheus_client.GC_COLLECTOR)
        if not cls._config.PLATFORM_COLLECTOR_enabled:
            prometheus_client.REGISTRY.unregister(prometheus_client.PLATFORM_COLLECTOR)
        if not cls._config.PROCESS_COLLECTOR_enabled:
            prometheus_client.REGISTRY.unregister(prometheus_client.PROCESS_COLLECTOR)

        # we dont need creation times - not useful
        prometheus_client.disable_created_metrics()

    @classmethod
    def start_prometheus_scraping_endpoint(cls, cntx: ExecutionContext = None) -> None:
        """Starts the Prometheus metrics endpoint - unless disabled by config..."""
        labels = cntx.get_labels_for_log() if cntx is not None else dict()

        if not cls._config.is_enabled:
            cls._LOG.info(
                "metrics is disabled by config - skipping starting Prometheus endpoint",
                **labels,
            )
            return

        prometheus_client.start_http_server(port=cls._config.http_port)
        cls._LOG.info(
            "Prometheus metrics endpoint is running on http://localhost:%s",
            cls._config.http_port,
            **labels,
        )

        # let's start the maintainer
        _MaintainedMetrics.start(metrics_config=cls._config)

    @classmethod
    def create_server_endpoint_metricset(
        cls, endpoint_name: str, endpoint_type: str, ecntx: ExecutionContext = None
    ) -> ServerEndpointMetricSet:
        """
        Returns a new `ServerEndpointMetricSet` registered for endpoint `endpoint_name` which you can use in your gRPC/HTTP/etc server endpoint.
        IMPORTANT! Make sure your `endpoint_name` is unique service wide!

        Arguments:
            endpoint_name (str): the system wide unique name of this endpoint - keep it short!!!
            endpoint_type (str): Type of your server, like 'http' or 'grpc' or whatever
        """
        labels = ecntx.get_labels_for_log() if ecntx is not None else dict()

        key = endpoint_type + ":" + endpoint_name
        metric_set = cls._metric_sets.get(key)
        if metric_set is None:
            metric_set = ServerEndpointMetricSet(
                endpoint_name=endpoint_name, endpoint_type=endpoint_type
            )
            # let's save it
            cls._metric_sets.update({key: metric_set})
            cls._LOG.debug(
                "created '%s' ServerEndpointMetricSet with endpoint name '%s'",
                endpoint_type,
                endpoint_name,
                **labels,
            )
        return metric_set

    @classmethod
    def create_message_consumer_metricset(
        cls, consumer_instance_id: str, topic_name: str, ecntx: ExecutionContext = None
    ) -> MessageConsumerMetricSet:
        """
        Returns a new `MessageConsumerMetricSet` registered for endpoint `consumer_instance_id` which you can use in your consumer.
        IMPORTANT! Make sure your `consumer_instance_id` is unique service wide!

        Arguments:
            consumer_instance_id (str): the system wide unique identifier of your message consumer - keep it short!!! Make it something you will recognize from your monitoring dashboard who is this?
            topic_name (str): the name of the topic this consumer consumes
        """
        labels = ecntx.get_labels_for_log() if ecntx is not None else dict()

        key = consumer_instance_id + ":" + topic_name
        metric_set = cls._metric_sets.get(key)
        if metric_set is None:
            metric_set = MessageConsumerMetricSet(
                consumer_instance_id=consumer_instance_id, topic_name=topic_name
            )
            # let's save it
            cls._metric_sets.update({key: metric_set})
            cls._LOG.debug(
                "created '%s' MessageConsumerMetricSet for topic '%s'",
                consumer_instance_id,
                topic_name,
                **labels,
            )
        return metric_set

    @classmethod
    def create_message_producer_metricset(
        cls, producer_instance_id: str, topic_name: str, ecntx: ExecutionContext = None
    ) -> MessageProducerMetricSet:
        """
        Returns a new `MessageProducerMetricSet` registered for endpoint `producer_instance_id` which you can use in your producer.
        IMPORTANT! Make sure your `producer_instance_id` is unique service wide!

        Arguments:
            producer_instance_id (str): the system wide unique identifier of your message producer - keep it short!!! Make it something you will recognize from your monitoring dashboard who is this?
            topic_name (str): the name of the topic this producer sending messages to
        """
        labels = ecntx.get_labels_for_log() if ecntx is not None else dict()

        key = producer_instance_id + ":" + topic_name
        metric_set = cls._metric_sets.get(key)
        if metric_set is None:
            metric_set = MessageProducerMetricSet(
                producer_instance_id=producer_instance_id, topic_name=topic_name
            )
            # let's save it
            cls._metric_sets.update({key: metric_set})
            cls._LOG.debug(
                "created '%s' MessageProducerMetricSet for topic '%s'",
                producer_instance_id,
                topic_name,
                **labels,
            )
        return metric_set

    @classmethod
    def create_std_event_counter(cls, of: str, qualifier: str = "-") -> prometheus_client.Counter:
        """
        Creates a "standard" `Counter` instance with standardized labels you can use to count certain events.

        The advantage of using a standardized counter like this - and not a `prometheus_client.Counter` in general - is that then this will by default appear on our generic Service Metrics dashboards nicely.
        You get something for free.

        You should NOT create an event counter to count warnings / errors!
        We have more specific standard counters for those, see: `create_std_warning_counter()` and `create_std_error_counter()` methods!

        Attributes:
            of (str): The name of the event you are counting - try to keep it short please!
            qualifier (str): Optional further specifier of what this counter is counting - in case `of` you want to break up further somehow. Keep this short as well!
        """
        preconditions.check_argument(
            of is not None and isinstance(of, str) and of != "",
            "'of' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            qualifier == "-" or (isinstance(qualifier, str) and qualifier != ""),
            "if 'qualifier' is given then it must be non emtpy string",
        )

        if cls._std_event_counter_tpl is None:
            # This will act as a family
            cls._std_event_counter_tpl = prometheus_client.Counter(
                name="std_eventCount",
                documentation="Reports how many times a specific event occured - (check 'of' / 'qualifier' attributes!)",
                labelnames=cls._std_label_names,
            )
        counter_instance = cls._std_event_counter_tpl.labels(
            of=of,
            qualifier=qualifier,
            _mtype="counter",
            **MetricsFactory._global_labels,
        )
        return counter_instance

    @classmethod
    def create_std_warning_counter(cls, of: str, qualifier: str = "-") -> prometheus_client.Counter:
        """
        Creates a "standard" `Counter` instance with standardized labels you can use to count specific warning events.

        The advantage of using a standardized counter like this - and not a `prometheus_client.Counter` in general - is that then this will by default appear on our generic Service Metrics dashboards nicely.
        You get something for free.

        To count errors or events see: `create_std_event_counter()` and `create_std_error_counter()` methods!

        Attributes:
            of (str): The name of the warning event you are counting - try to keep it short please!
            qualifier (str): Optional further specifier of what this counter is counting - in case `of` you want to break up further somehow. Keep this short as well!
        """
        preconditions.check_argument(
            of is not None and isinstance(of, str) and of != "",
            "'of' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            qualifier == "-" or (isinstance(qualifier, str) and qualifier != ""),
            "if 'qualifier' is given then it must be non emtpy string",
        )

        if cls._std_warning_counter_tpl is None:
            # This will act as a family
            cls._std_warning_counter_tpl = prometheus_client.Counter(
                name="std_warnCount",
                documentation="Reports how many times a specific warning occured - (check 'of' / 'qualifier' attributes!)",
                labelnames=cls._std_label_names,
            )
        counter_instance = cls._std_warning_counter_tpl.labels(
            of=of,
            qualifier=qualifier,
            _mtype="counter",
            **MetricsFactory._global_labels,
        )
        return counter_instance

    @classmethod
    def create_std_error_counter(cls, of: str, qualifier: str = "-") -> prometheus_client.Counter:
        """
        Creates a "standard" `Counter` instance with standardized labels you can use to count specific error events.

        The advantage of using a standardized counter like this - and not a `prometheus_client.Counter` in general - is that then this will by default appear on our generic Service Metrics dashboards nicely.
        You get something for free.

        To count warnings or events see: `create_std_event_counter()` and `create_std_warning_counter()` methods!

        Attributes:
            of (str): The name of the error event you are counting - try to keep it short please!
            qualifier (str): Optional further specifier of what this counter is counting - in case `of` you want to break up further somehow. Keep this short as well!
        """
        preconditions.check_argument(
            of is not None and isinstance(of, str) and of != "",
            "'of' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            qualifier == "-" or (isinstance(qualifier, str) and qualifier != ""),
            "if 'qualifier' is given then it must be non emtpy string",
        )

        if cls._std_error_counter_tpl is None:
            # This will act as a family
            cls._std_error_counter_tpl = prometheus_client.Counter(
                name="std_errorCount",
                documentation="Reports how many times a specific error occured - (check 'of' / 'qualifier' attributes!)",
                labelnames=cls._std_label_names,
            )
        counter_instance = cls._std_error_counter_tpl.labels(
            of=of,
            qualifier=qualifier,
            _mtype="counter",
            **MetricsFactory._global_labels,
        )
        return counter_instance

    @classmethod
    def create_std_processing_time_observer(cls, of: str, qualifier: str = "-") -> Summary:
        """
        Creates a "standard" `Summary` (observer) instance with standardized labels you can use to track processing time of something.

        The advantage of using a standardized metrics like this - and not a `Summary` in general - is that then this will by default appear on our generic Service Metrics dashboards nicely.
        You get something for free.

        As unit you should use is milliseconds for this type metric!
        If you need higher precision - e.g nano seconds - please note: the values are float values! Feel free to use fractions.

        Attributes:
            of (str): The name of the process/flow who's speed you are tracking - try to keep it short please!
            qualifier (str): Optional further specifier of what you are observing - in case `of` you want to break up further somehow. Keep this short as well!
        """
        preconditions.check_argument(
            of is not None and isinstance(of, str) and of != "",
            "'of' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            qualifier == "-" or (isinstance(qualifier, str) and qualifier != ""),
            "if 'qualifier' is given then it must be non emtpy string",
        )

        if cls._std_processing_time_summary_tpl is None:
            # This will act as a family
            cls._std_processing_time_summary_tpl = Summary(
                name="std_processingTime",
                documentation="Reports processing time of something - (check 'of' / 'qualifier' attributes!)",
                labelnames=cls._std_label_names,
            )
        summary_instance = cls._std_processing_time_summary_tpl.labels(
            of=of,
            qualifier=qualifier,
            _mtype="summary",
            **MetricsFactory._global_labels,
        )
        return summary_instance

    @classmethod
    def create_std_value_observer(cls, of: str, qualifier: str = "-") -> Summary:
        """
        Creates a "standard" `Summary` (observer) instance with standardized labels you can use to track any value. This can be whatever you can describe with a numeric value.

        The advantage of using a standardized metrics like this - and not a `Summary` in general - is that then this will by default appear on our generic Service Metrics dashboards nicely.
        You get something for free.

        Do NOT use this metric to track value like "processing time" of something! For that we have more specific metric, see: `create_std_processing_time_observer()` method!

        As unit this metric does not specify anything - too generic. So just consider it as a float number.

        Attributes:
            of (str): The name of the value who's distribution you are tracking - try to keep it short please!
            qualifier (str): Optional further specifier of what you are observing - in case `of` you want to break up further somehow. Keep this short as well!
        """
        preconditions.check_argument(
            of is not None and isinstance(of, str) and of != "",
            "'of' is mandatory and must be non emtpy string",
        )
        preconditions.check_argument(
            qualifier == "-" or (isinstance(qualifier, str) and qualifier != ""),
            "if 'qualifier' is given then it must be non emtpy string",
        )

        if cls._std_value_observer_summary_tpl is None:
            # This will act as a family
            cls._std_value_observer_summary_tpl = Summary(
                name="std_valueObserver",
                documentation="Tracks and reports a value of something - (check 'of' / 'qualifier' attributes!)",
                labelnames=cls._std_label_names,
            )
        summary_instance = cls._std_value_observer_summary_tpl.labels(
            of=of,
            qualifier=qualifier,
            _mtype="summary",
            **MetricsFactory._global_labels,
        )
        return summary_instance

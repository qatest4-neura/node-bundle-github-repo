import asyncio
import socket
from abc import abstractmethod
from concurrent.futures import ThreadPoolExecutor
from typing import Type

import grpc
import inject

from neuraverse_common.models.config.base_service_config import BaseServiceConfig
from neuraverse_common.models.config.config_source.LogConfig import LogConfig
from neuraverse_common.models.config.config_source.MetricsConfig import MetricsConfig
from neuraverse_common.models.config.config_source.RuntimeConfig import RuntimeConfig
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.observability.common import buildGlobalLabels
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.service.i_base_neuraverse_service import INeuraverseService
from neuraverse_common.utilities.ids import generate_uuid


class BaseNeuraverseService(INeuraverseService):
    """
    ToDo: move to common package
    Base class for Neuraverse services.

    The class provides base implementation of the service lifecycle methods
    and defines hooks methods to be implemented by subclasses.
    """

    log_config_file_name: str = "log_config.yaml"
    env_log_config_path: str = "ENVVAR_LOG_CFG_PATH"
    main_logger: str = "main"  # Main logger name as define in log config file

    # Class-level attribute to specify the service type
    type: Type["BaseNeuraverseService"] = None

    @classmethod
    def create_instance(cls) -> "BaseNeuraverseService":
        """
        Create a new instance of the service type specified in the `type` attribute.

        Returns:
            BaseNeuraverseService: A new instance of the specified service type.
        """
        if cls.type is None:
            raise ValueError("The `type` attribute must be set to a valid service class.")
        return cls.type()

    def __init__(self) -> None:
        self.server: grpc.Server = None
        self._LOG: Logger = LoggerFactory.get_logger(f"service.service.{self.__class__.__name__}")

    def configure(self, service_config: BaseServiceConfig) -> None:
        """
        Configure the service with the given configuration.

        Args:
            config (Any): The configuration object for the service.
        """

        self._on_configure_runtime(service_config.runtime)
        self._on_configure_logging(service_config.service_info, service_config.logging)
        self._on_configure_metrics(service_config.service_info, service_config.metrics)
        inject.configure(lambda binder: self._on_configure_injection(binder, service_config))

    def _on_configure_runtime(self, runtime_config: RuntimeConfig) -> None:
        if runtime_config.executor_max_workers:
            asyncio.get_running_loop().set_default_executor(
                ThreadPoolExecutor(max_workers=runtime_config.executor_max_workers)
            )

    async def start(self) -> None:
        """
        Start the service.

        This method should contain the logic to initialize and start the service.
        """
        pass

    def stop(self) -> None:
        """
        Stop the service by gracefully shutting down the gRPC server.
        """
        if self.server:
            self.server.stop(grace=5)  # Gracefully stop the server with a 5-second timeout

    def wait_for_termination(self) -> None:
        """
        Wait for the gRPC server to terminate.

        This method blocks until the server is terminated, allowing for graceful shutdown.
        """
        if self.server:
            # TODO: close connections to mongodb
            self.server.wait_for_termination()

    @abstractmethod
    def _on_configure_injection(self, binder: inject.Binder) -> None:
        """
        Configure dependency injection for the service.

        This method should bind the necessary components to the dependency injection container.
        """
        pass

    @abstractmethod
    def _on_configure_logging(self, service_info: ServiceInfo, log_config: LogConfig) -> None:
        """
        Configure logging for the service.

        This method should set up the logging configuration based on the provided service descriptor.
        """
        pass

    @abstractmethod
    def _on_configure_metrics(
        self, service_info: ServiceInfo, metrics_config: MetricsConfig
    ) -> None:
        """
        Configure metrics for the service.

        This method should set up the MetricsFactory configuration based on the provided service descriptor.
        """
        pass

    def _build_service_global_labels(
        self,
        service_info: ServiceInfo,
    ) -> dict[str, str]:
        """
        Build the service descriptor for the service.

        This descriptor is used for observability and logging, providing metadata
        such as service name, version, host, and instance ID.

        Args:
            service_descriptor_config (ServiceDescriptorConfig): Configuration for the service descriptor.

        Returns:
            dict[str, str]: A dictionary containing global labels for the service.
        """
        global_labels = buildGlobalLabels()

        # TODO: avoid using magic strings
        # if Kubernetes / Docker did not inject anything let's fill these up
        if global_labels["serviceName"] == "?":
            global_labels["serviceName"] = service_info.get_service_name()
        if global_labels["serviceVer"] == "?":
            global_labels["serviceVer"] = service_info.get_service_version()
        if global_labels["host"] == "?":
            global_labels["host"] = socket.gethostname()
        if global_labels["instId"] == "?":
            global_labels["instId"] = generate_uuid()

        return global_labels

import functools

from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.grpc.context.grpc_ecntx_handler import GrpcEcntxHandler
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.grpc.model.error.neura_grpc_error import NeuraGrpcError
from neuraverse_common.grpc.model.config_source.grpc_config import GrpcConfig
from neuraverse_common.utilities import preconditions
from neuraverse_common.observability import metrics
from google.protobuf.json_format import MessageToDict, MessageToJson
from neuraverse_common.utilities.strings import camel_to_kebab
from neuraverse.models.v1.gen.api.metadata_pb2 import ResponseMetadata
from typing import List, Tuple
from unidecode import unidecode
from collections.abc import Iterator

import grpc
import inject


class BaseApiServicerV2:
    """
    Base class for gRPC API service classes - all service classes should extend this one.

    If you do you get lots of features from this like correct error handling, metrics, logging - many many things.
    """

    _endpoint_metrics: dict[str, metrics.ServerEndpointMetricSet]

    @inject.params(
        grpc_config=GrpcConfig
    )
    def __init__(self, grpc_config: GrpcConfig, logger_to_use: Logger|None = None):
        """
        Initialize the BaseApiServicer with a logger instance.

        Args:
            logger_to_use (Logger): Optional. Logger instance for logging API calls and errors. If you pass None or omit this entirely then class creates a default logger with name "service.api.grpc.<className>"
        """
        preconditions.check_argument(logger_to_use == None  or isinstance(logger_to_use, Logger), "'logger_to_use' must be a Logger type if you pass in something")
        if logger_to_use == None:
            logger_name = f"service.api.grpc.{self.__class__.__name__}"
            logger_to_use = LoggerFactory.get_logger(logger_name)
            # let's make a warning - maybe someone notice? :-P
            logger_to_use.warning("You did NOT pass a specific Logger in constructor so default Logger with name '%s' was created", logger_name)
        self._LOG = logger_to_use

        self._log_request_body_on_failure = grpc_config.log_request_body_on_failure
        self._log_request_body_on_log_level = grpc_config.log_request_body_on_log_level
        self._log_response_body_on_log_level = grpc_config.log_response_body_on_log_level


    @classmethod
    def _get_endpoint_metrics(cls, endpoint_qualified_name: str, ecntx: ExecutionContext = None) -> metrics.ServerEndpointMetricSet:
        if getattr(cls, "_endpoint_metrics", None) == None:
            cls._endpoint_metrics = dict()
        metric_set = cls._endpoint_metrics.get(endpoint_qualified_name)
        if metric_set == None:
            metric_set = metrics.MetricsFactory.create_server_endpoint_metricset(endpoint_name=endpoint_qualified_name, endpoint_type='grpc', ecntx=ecntx)
            cls._endpoint_metrics[endpoint_qualified_name] = metric_set
        return metric_set
    

    @classmethod
    def get_unauthenticated_method_names(
        cls, servicer_class: type, grpc_package_name: str, grpc_service_name: str
    ) -> set[str]:
        """
        Get a set of all unauthenticated methods from the servicer class.

        This function iterates over all attributes of the given gRPC servicer class
        and identifies methods marked with the `_unauthenticated` attribute. It then
        constructs the full gRPC method names for these unauthenticated methods and
        returns them as a set.

        Args:
            servicer_class (type): The gRPC servicer class to inspect.
            grpc_package_name (str): The name of the gRPC package.
            grpc_service_name (str): The name of the gRPC service.

        Returns:
            set[str]: A set of fully qualified gRPC method names that are marked as unauthenticated.
        """
        unauthenticated_methods = set()
        for attr_name in dir(servicer_class):
            attr = getattr(servicer_class, attr_name)
            if callable(attr) and getattr(attr, "_unauthenticated", False):
                full_name = f"/{grpc_package_name}.{grpc_service_name}/{attr_name}"
                unauthenticated_methods.add(full_name)
        return unauthenticated_methods


    @classmethod
    def grpc_api_method(cls, service_info_provider=None):
        """
        This is a decorator you can use to decorate your gRPC API service methods.

        This brings standardized error handling (by capturing possible exceptions of any kind) conforming our latest contract (using)
        """
        
        def api_method_decorator(api_method):
            @functools.wraps(api_method)
            def wrapper(self, request, servicer_context):
                unary_request = None
                handler_request = None
                if isinstance(request, Iterator):
                    first_msg = next(request, None)
                    unary_request = first_msg
                    if first_msg is None:
                        self._LOG.warning("Request stream for {%s} was empty", api_method.__name__)

                    def _stream_with_first():
                        if first_msg is not None:
                            yield first_msg
                        yield from request

                    handler_request = _stream_with_first()
                else:
                    unary_request = request
                    handler_request = request
                ecntx: ExecutionContext = GrpcEcntxHandler.create_execution_context(
                    request=unary_request,
                    context=servicer_context,
                    service_info=service_info_provider(),
                )
                self._log_api_call_info(
                    caller_func_name=api_method.__name__, ecntx=ecntx
                )

                resp = self._invoke_with_error_handling(api_method, handler_request, servicer_context, ecntx)
                
                if self._log_response_body_on_log_level == "debug" and self._LOG.isDebugEnabled():
                    log_labels = ecntx.get_labels_for_log()
                    self._LOG.debug("response returned: {%s}", resp, **log_labels)
                if self._log_response_body_on_log_level == "info" and self._LOG.isInfoEnabled():
                    log_labels = ecntx.get_labels_for_log()
                    self._LOG.info("response returned: {%s}", resp, **log_labels)

                return resp

            return wrapper
            
        return api_method_decorator

    def _log_api_call_info(
        self,
        caller_func_name: str,
        ecntx: ExecutionContext = None,
    ):
        """
        Log information about an incoming API call.

        Args:
            caller_func_name (str): Name of the API method being called.
            ecntx (ExecutionContext, optional): The execution context for the request.
        """

        if not self._LOG.isInfoEnabled():
            # no work to do
            return
        
        log_labels = ecntx.get_labels_for_log() if ecntx else {}
        
        if self._log_request_body_on_log_level == "info":
            self._LOG.info(
                "Received API request: {%s.%s}.{%s} - request body: {%s}",
                self.__class__,
                __name__,
                caller_func_name,
                ecntx.get_keyvalue("request"),
                **log_labels,
            )
            # we are done here
            return
        
        # just minimalistic info on 'info' level
        self._LOG.info(
            "Received API request: {%s.%s}.{%s}",
            self.__class__,
            __name__,
            caller_func_name,
            **log_labels,
        )

        if self._log_request_body_on_log_level == "debug" and self._LOG.isDebugEnabled():
            self._LOG.debug("request body: {%s}", ecntx.get_keyvalue("request"), **log_labels)


    def _invoke_with_error_handling(self, api_method, request, servicer_context, ecntx: ExecutionContext):
        """
        Error handler for API methods. Catches and logs exceptions, and handles them appropriately.

        Args:
            self (BaseApiServicer): The API servicer instance.
            api_method (callable): The API method being called.
            request: The gRPC request object.
            servicer_context: The gRPC servicer context.
            ecntx (ExecutionContext): The execution context for the request.

        Returns:
            The result of the API method, or handles the exception.
        """

        endpoint_metrics: metrics.ServerEndpointMetricSet = BaseApiServicerV2._get_endpoint_metrics(endpoint_qualified_name=api_method.__qualname__, ecntx=ecntx)

        try:
            result = api_method(self, request, servicer_context, ecntx)
            # we are good! adjust metrics
            status_code = grpc.StatusCode.OK.name
            endpoint_metrics.increment(status_code=status_code)
            endpoint_metrics.observe_exec_time(status_code=status_code, ellapsed_millis=ecntx.get_took_millis())
            return result
        
        except NeuraGrpcError as exc:
            log_labels = ecntx.get_labels_for_log() if ecntx else {}
            
            requestToLog = "*feature off*"
            if self._log_request_body_on_failure:
                # was it logged already? then dont log again
                if (self._log_request_body_on_log_level == "debug" and self._LOG.isDebugEnabled()) or (self._log_request_body_on_log_level == "info" and self._LOG.isInfoEnabled()):
                    requestToLog = "*already logged*"
                else:
                    # TODO should not we get rid of the 'request' param?? we have in in context
                    requestToLog = ecntx.get_keyvalue("request")
                    
            self._LOG.error("%s(): returning prepared gRPC error: %s, inbound request was: %s", api_method.__name__, exc, requestToLog, **log_labels)

            # adjust metrics
            status_code = exc.status.name
            endpoint_metrics.increment(status_code=status_code)
            endpoint_metrics.observe_exec_time(status_code=status_code, ellapsed_millis=ecntx.get_took_millis())

            self._handle_exception(servicer_context, exc)
        
        except Exception as exc:
            log_labels = ecntx.get_labels_for_log() if ecntx else {}
            self._LOG.warning("%s(): non NeuraGrpcError exception captured - converting to NeuraGrpcError error... original error was: %s", api_method.__name__, exc, **log_labels)
            # let's convert it into grpc error response
            grpcException = NeuraGrpcError.from_error_or_exception(exc, self._LOG, ecntx)

            requestToLog = "*feature off*"
            if self._log_request_body_on_failure:
                # was it logged already? then dont log again
                if (self._log_request_body_on_log_level == "debug" and self._LOG.isDebugEnabled()) or (self._log_request_body_on_log_level == "info" and self._LOG.isInfoEnabled()):
                    requestToLog = "*already logged*"
                else:
                    # TODO should not we get rid of the 'request' param?? we have in in context
                    requestToLog = ecntx.get_keyvalue("request")

            self._LOG.error("%s(): returning converted NeuraGrpcError: %s, inbound request was: %s", api_method.__name__, grpcException, requestToLog, **log_labels)

            # adjust metrics
            status_code = grpcException.status.name
            endpoint_metrics.increment(status_code=status_code)
            endpoint_metrics.observe_exec_time(status_code=status_code, ellapsed_millis=ecntx.get_took_millis())

            self._handle_exception(servicer_context, grpcException)


    def _convert_protobuf_to_trailers(self, response_meta: ResponseMetadata) -> List[Tuple[str, str]]:
        """
        Convert a ResponseMetadata protobuf message to a list of tuples for gRPC trailing metadata.
        Each tuple contains a key (kebab-case) and a one-line string value.
        """
        trailers = []
        dict_response_meta = MessageToDict(
            response_meta, preserving_proto_field_name=True, always_print_fields_with_no_presence=True
        )
        for key, value in dict_response_meta.items():
            trailers.append((camel_to_kebab(key), unidecode(str(value))))

        return trailers

    def _handle_exception(self, context: grpc.ServicerContext, exc: NeuraGrpcError):
        """
        Handles a NeuraGrpcError by mapping its status code and error details to the gRPC ServicerContext.
        This sets the appropriate gRPC status code, trailing metadata, and error details for gRPC error responses.

        Args:
            context (grpc.ServicerContext): The gRPC context to set error details on.
            exc (NeuraGrpcErrorResponseException|LegacyNeuraGrpcErrorResponseException): The exception to handle.
        """

        # OK we have the most modern exception type (just for typing)
        _exc: NeuraGrpcError = exc

        grcp_status_code = _exc.status 
        if grcp_status_code is None:
            grcp_status_code = grpc.StatusCode.UNKNOWN
        context.set_code(grcp_status_code)

        response_meta = (
            _exc.error_details.responseMeta
            if _exc.error_details and _exc.error_details.responseMeta
            else None
        )
        if response_meta:
            trailing_metadata = self._convert_protobuf_to_trailers(response_meta)
            context.set_trailing_metadata(trailing_metadata)

        detailsStr = MessageToJson(message=_exc.error_details, always_print_fields_with_no_presence=True, indent=None)

        context.abort(grcp_status_code, detailsStr)    

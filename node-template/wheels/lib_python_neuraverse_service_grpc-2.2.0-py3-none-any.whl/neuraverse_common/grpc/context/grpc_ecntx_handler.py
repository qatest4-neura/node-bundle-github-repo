from typing import List, Optional, Tuple

import google.protobuf.message
import grpc
from neuraverse.models.v1.gen.api.metadata_pb2 import RequestMetadata, ResponseMetadata
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.auth.AuthInfo import AuthInfo
from neuraverse_common.models.config.service_info import ServiceInfo


class GrpcEcntxHandler:
    """
    A utility class which provides static methods to nicely instantiate and use `neuraverse_common.context.execution_context.ExecutionContext`
    in a gRPC environment, enabling seamless integration with the internal execution context standard.
    """

    # change method comment once https://neurarobotics.atlassian.net/browse/NRV-3672 actioned
    @classmethod
    def create_execution_context(
        cls,
        request: google.protobuf.message.Message,
        context: grpc.ServicerContext,
        service_info: ServiceInfo,
    ) -> ExecutionContext:
        """
        Converts a gRPC request and context into an internal ExecutionContext.

        This method extracts metadata such as transaction and trace IDs from the
        gRPC request and uses them to create an `ExecutionContext` instance. This method searches for and finds
        `RequestMeta` (old) or `RequestMetadata` (new) field in incoming request by type - not field name.

        Args:
            request: The incoming gRPC request.
            context (grpc.ServicerContext): The gRPC context.
            service_info (ServiceInfo): The service information for logging and context creation.

        Returns:
            ExecutionContext: The internal execution context containing metadata.
        """

        # If the request has metadata, extract its values
        meta: RequestMetadata = cls._get_metadata_field_of_grpc_request(request=request)
        transaction_id = meta.transactionId if meta else None
        trace_id = meta.traceId if meta else None
        request_timestamp = meta.requestTimestamp if meta else None
        caller_name_and_version = meta.callerNameAndVersion if meta else None
        caller_context = meta.callerContext if meta else None
        auth_info = GrpcEcntxHandler.get_auth_info_from_context(context)

        service_name_and_version = None
        api_version = None
        if service_info:
            service_name_and_version = (
                f"{service_info.get_service_name()} {service_info.get_service_version()}"
            )
            api_version = service_info.get_api_version()

        cntx: ExecutionContext = ExecutionContext(
            request_timestamp=request_timestamp,
            transaction_id=transaction_id,
            trace_id=trace_id,
            api_version=api_version,
            service_name_and_version=service_name_and_version,
            auth_info=auth_info,
            caller_name_and_version=caller_name_and_version,
            caller_context=caller_context,
        )
        # let's store the request - this way we can log that in case of failure has happened
        cntx.set_keyvalue("request", request)

        return cntx

    @staticmethod
    def get_auth_info_from_context(context: grpc.ServicerContext) -> Optional[AuthInfo]:
        """
        Extracts the authentication information from the gRPC context.

        This method retrieves the authentication information from the gRPC context
        and returns it as an `ExecutionContext` instance.

        Args:
            context (grpc.ServicerContext): The gRPC context.

        Returns:
            AuthInfo: The authentication information extracted from the context.
        """
        if context is None:
            return None

        # Extract relevant information from the metadata in the context
        auth_header_content = None
        for key, value in context.invocation_metadata():
            if key.lower() == "authorization":
                auth_header_content = value
                break

        # Extract relevant information from the token in the context
        token = getattr(context, "decoded_token", None)
        user_id = None
        org_id = None
        service_id = None
        if token:
            # TODO NRV-4152 / NRV-4541 - add support for M2M tokens properly here - service_id!
            # IMPORTANT! if you change anything here, you also need to change in http lib the same! find it!
            user_id = token.get("https://neuraverse.com/user_id")
            service_id = token.get("https://neuraverse.com/service_id")
            # Configure fallback logic in case neither user_id nor service_id found
            if user_id is None and service_id is None:
                fallback_is_service_token = (
                    True if token.get("gty") == "client-credentials" else False
                )
                if fallback_is_service_token:
                    service_id = token.get("sub")
                else:
                    user_id = token.get("sub")

        if not any([user_id, service_id, auth_header_content]):
            return None

        if user_id is not None:
            # This is a user token - we can also have org_id in that case
            org_id = token.get("https://neuraverse.com/org_id")

        return AuthInfo(
            user_id=user_id,
            service_id=service_id,
            auth_header_content=auth_header_content,
            org_id=org_id,
        )

    @staticmethod
    def get_request_meta(context: ExecutionContext) -> RequestMetadata:
        """
        Returns the gRPC request metadata.
        """

        return RequestMetadata(
            transactionId=context.transaction_id,
            traceId=context.trace_id,
            requestTimestamp=context.request_timestamp,
            callerNameAndVersion=context.caller_name_and_version or "",
            callerContext=context.caller_context or "",
        )

    @staticmethod
    def get_response_meta(context: ExecutionContext) -> ResponseMetadata:
        """
        Returns the gRPC response metadata.
        """
        if context is None:
            # we can just return an empty stuff
            return ResponseMetadata()

        return ResponseMetadata(
            transactionId=context.transaction_id,
            traceId=context.trace_id,
            tookMillis=context.get_took_millis(),
            serviceNameAndVersion=context.service_name_and_version,
            apiVersion=context.api_version,
            requestReceivedAtTimestamp=context.request_timestamp,
            origRequestTimestamp=context.request_origin_timestamp,
            warnings=context.get_warnings(),
        )

    @staticmethod
    def get_grpc_auth_metadata(context: ExecutionContext) -> List[Tuple[str, str]]:
        """
        Returns the gRPC metadata for authentication.
        """
        if context.auth_info is None or context.auth_info.auth_header_content is None:
            return []

        return [("authorization", context.auth_info.auth_header_content)]

    @staticmethod
    def _get_metadata_field_of_grpc_request(
        request: google.protobuf.message.Message,
    ) -> RequestMetadata:
        for field, value in request.ListFields():
            if (
                field.type == field.TYPE_MESSAGE
                and field.message_type is RequestMetadata.DESCRIPTOR
            ):
                return value

        return None

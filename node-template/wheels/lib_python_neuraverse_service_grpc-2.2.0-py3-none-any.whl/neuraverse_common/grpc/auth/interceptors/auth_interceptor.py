"""
This module implements the `JWTAuthInterceptor` for gRPC services in the
NEURA robotics tenant service.

The `JWTAuthInterceptor` is responsible for authenticating gRPC requests
using JWT tokens. It validates the token, extracts the decoded payload,
and attaches it to the gRPC context for downstream processing. The interceptor
also supports unauthenticated methods by checking for a `_unauthenticated`
attribute on the gRPC method.
"""

import grpc
import inject
from grpc_interceptor import ServerInterceptor
from requests.exceptions import ConnectTimeout

from neuraverse_common.jwt.jwt_validator import JwtValidator
from neuraverse_common.models.config.config_source.JwtConfig import JwtConfig
from neuraverse_common.observability.logging import Logger, LoggerFactory


def get_jwt_config() -> JwtConfig:
    """
    Inject the JwtConfig for JwtValidator.

    Returns:
        JwtConfig: The injected JWT configuration.
    """
    return inject.instance(JwtConfig)


def get_jwt_validator() -> JwtValidator:
    """
    Inject the JwtValidator for validating JWT tokens.

    Returns:
        JwtValidator: The injected JWT validator.
    """
    return inject.instance(JwtValidator)


class JWTAuthInterceptor(ServerInterceptor):
    """
    gRPC interceptor for authenticating requests using JWT tokens.
    """

    REFLECTION_METHOD = "/grpc.reflection.v1alpha.ServerReflection/ServerReflectionInfo"

    def __init__(self, unauthenticated_methods: set[str]):
        """
        Initializes the interceptor with JWT configuration.

        Args:
            unauthenticated_methods (set[str]): The set of unauthenticated method names.
        """
        self.jwt_config = get_jwt_config()
        self.jwt_validator = get_jwt_validator()
        logger_name_prefix = "lib.grpc.auth"
        self.logger: Logger = LoggerFactory.get_logger(
            f"{logger_name_prefix}.{self.__class__.__name__}"
        )

        self.unauthenticated_methods = unauthenticated_methods
        self.unauthenticated_methods.add(self.REFLECTION_METHOD)

    def intercept(self, method, request, context, method_name):
        """
        Intercepts gRPC requests to validate JWT tokens, except for unauthenticated methods.

        Args:
            method: The gRPC method being called.
            request: The incoming gRPC request.
            context (grpc.ServicerContext): The gRPC context.
            method_name (str): The name of the gRPC method.

        Returns:
            The result of the gRPC method call.

        Raises:
            grpc.RpcError: If the token is missing, invalid, or fails validation.
        """
        if method_name in self.unauthenticated_methods:
            return method(request, context)

        metadata = dict(context.invocation_metadata())
        auth_header = metadata.get("authorization")

        if not auth_header or not auth_header.startswith(self.jwt_config.auth_type):
            context.abort(
                grpc.StatusCode.UNAUTHENTICATED,
                "Missing or invalid authorization header",
            )

        try:

            success = True
            parts = auth_header.split(" ", 1)

            if len(parts) != 2:
                success = False
                context.abort(
                    grpc.StatusCode.UNAUTHENTICATED,
                    f"Invalid authorization header format, actual header lenght: {len(parts)}, expected 2 parts",
                )
            elif len(parts) == 1:
                token = auth_header[len(self.jwt_config.auth_type) :]
            else:
                token = parts[1].strip()

            if success:
                decoded_token = self.jwt_validator.validate_token(token)
                context.decoded_token = decoded_token
        except Exception as e:
            self.logger.error(
                "Exception in intercept of method: %s, error: %s",
                method_name,
                str(e),
            )
            if isinstance(e, ConnectTimeout):
                context.abort(grpc.StatusCode.UNAVAILABLE, "JWT connection timeout")
            else:
                context.abort(grpc.StatusCode.UNAUTHENTICATED, str(e))

        return method(request, context)

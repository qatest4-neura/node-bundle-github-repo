"""
This module provides decorators for handling authentication and role-based
access control (RBAC) in gRPC methods for the NEURA robotics tenant service.

The `authenticated` decorator enforces authentication by ensuring a valid
decoded token is present in the gRPC context. The `unauthenticated` decorator
marks methods as not requiring authentication. The `rbac` decorator enforces
RBAC by checking if the user's roles match the required roles for the method.
"""

from functools import wraps

import grpc


def authenticated():
    """
    Decorator to enforce authentication for gRPC methods.

    This decorator checks if a valid decoded token is present in the gRPC
    context. If not, it aborts the request with an UNAUTHENTICATED status code.

    Returns:
        Callable: The wrapped gRPC method.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(self, request, context):
            token = getattr(context, "decoded_token", None)
            if token is None:
                context.abort(grpc.StatusCode.UNAUTHENTICATED, "Authentication required")
            return func(self, request, context)

        return wrapper

    return decorator


def unauthenticated(func):
    """
    Decorator to mark a gRPC method as not requiring authentication.

    This decorator sets a `_unauthenticated` attribute on the method, which can
    be used by interceptors to bypass authentication checks.

    Args:
        func (Callable): The gRPC method to decorate.

    Returns:
        Callable: The decorated gRPC method.
    """
    func._unauthenticated = True
    return func


def rbac(required_roles_callable):
    """
    Role-based access control (RBAC) decorator.

    This decorator checks if the user's roles, as provided in the decoded token,
    include at least one of the required roles. If not, it aborts the request
    with a PERMISSION_DENIED status code.

    Args:
        required_roles_callable (Callable): A callable that returns the required
        roles dynamically based on the JWT configuration.

    Returns:
        Callable: The wrapped gRPC method.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(self, request, context, *args, **kwargs):
            token = getattr(context, "decoded_token", None)
            if token is None:
                context.abort(grpc.StatusCode.UNAUTHENTICATED, "No decoded token found")

            required_roles = required_roles_callable(self.jwt_config)

            # Get user roles/permissions for compatibility between different auth providers
            # Keycloak uses "role" field while Auth0 uses "permissions" field
            # This is maintained during transition period to ReBAC where this field becomes less important
            user_roles = context.decoded_token.get("role", []) + context.decoded_token.get(
                "permissions", []
            )

            if not any(role in user_roles for role in required_roles):
                context.abort(
                    grpc.StatusCode.PERMISSION_DENIED,
                    "Access denied: permission denied.",
                )
                # TODO: log the denied access attempt with more details

            return func(self, request, context, *args, **kwargs)

        return wrapper

    return decorator

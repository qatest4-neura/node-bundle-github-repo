"""
This module defines the `GrpcConfig` class for managing gRPC server configuration
in the NEURA robotics tenant service.

The `GrpcConfig` class provides structured fields for defining the gRPC server's
address and port.

Additionally it also provides some settings which configures what and how will be logged in terms of incoming requests, outgoing responses and possible failures.

It leverages Pydantic for validation and ensures that these
fields are properly set and documented.
"""

from pydantic import ConfigDict, Field
from pydantic_settings import BaseSettings


class GrpcConfig(BaseSettings):
    """
    Configuration class for gRPC server settings.

    This class defines the address and port for the gRPC server, providing a
    structured way to manage these settings.
    """

    model_config = ConfigDict(extra="allow")

    address: str = Field(default="[::]", description="gRPC address")
    port: int = Field(default=1, description="gRPC port")

    # behavior related
    log_request_body_on_failure: bool = Field(
        default=True,
        description="In case request failed with exception our `BaseApiServicerV2` wrapper will make sure the request is logged if TRUE.",
    )
    log_request_body_on_log_level: str = Field(
        default="debug",
        description="If you set it to 'info' or 'debug' then inbound request will be logged on that level - setting to None will turn this feture off. Defult is 'debug'",
    )
    log_response_body_on_log_level: str = Field(
        default="debug",
        description="If you set it to 'info' or 'debug' then outbound response will be logged on that level - otherwise not at all. Default is 'debug'",
    )

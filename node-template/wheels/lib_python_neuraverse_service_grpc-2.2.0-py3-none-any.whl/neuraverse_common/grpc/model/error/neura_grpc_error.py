import grpc
from neuraverse.api.common_pb2 import GrpcErrorDetails
from neuraverse_common.observability.logging import Logger
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.utilities.neuraverse_entities.error_builder import ErrorBuilder
from neuraverse_common.grpc.context.grpc_ecntx_handler import GrpcEcntxHandler
from neuraverse_common.models.error import errors_v2


class NeuraGrpcError(Exception):
    """
    This exception contains a gRPC statusCode and also carrying a `GrpcErrorDetails` - defined in
    https://gitlab.hrg.systems/neuraverse/neuraverse-entities/-/blob/main/protos/neuraverse/api/common.proto?ref_type=heads
    therefore suitable to return an error response due to our contract.

    **Please note:** this class has static factory method too `from_error_or_exception()` you can use to convert any error/exception
    easily into a NeuraGrpcError safe way (meaning: we do not leak out unsafe internal info into a gRPC response). See method for more details!
    """
    status: grpc.StatusCode
    error_details: GrpcErrorDetails

    def __init__(self, status: grpc.StatusCode, error_details: GrpcErrorDetails):
        self.status = status
        self.error_details = error_details

    def __str__(self) -> str:
        return f"NeuraGrpcError[status: {self.status}, error_details: {self.error_details}]"


    @staticmethod
    def from_error_or_exception(exc: Exception, logger_to_use: Logger, ecntx: ExecutionContext):
        """
        Static factory method to convert a - hopefully at least - `neuraverse_common.models.error.errors_v2.NeuraPublicRuntimeError` (or all subclasses)
        exception into a `NeuraGrpcError`.

        In case the provided exception is not `NeuraPublicRuntimeError` (or subclass) it is treated as unsafe exception to return details to caller. In this case
        it is converted first into a `NeuraPublicRuntimeError` using its static factory method `.from_error_or_exception()` into one.
        See description of that method to know more!

        Arguments:
            exc (Exception): The error/exception you want to turn into NeuraGrpcError.
            logger_to_use (Logger): If a not safe exception/error is converted (means: not `neuraverse_common.models.error.errors_v2.NeuraPublicRuntimeError` or subclasses) then this logger
                                  is used to log the original exception so we have it, because the converted error message will not give ANY specific details back. In case no logger provided
                                  then a default Logger will be used for this.
            ecntx (ExecutionContext): if provided then labels from this context are used in the log and the returned ResponseMetadata (part of `GrpcErrorDetails`)
        """

        # This method call ensures every non-safe exception is properly converted (logged too if happens) into a NeuraPublicRuntimeError
        # Exceptions already NeuraPublicRuntimeError class are not changed
        serviceExc: errors_v2.NeuraPublicRuntimeError = errors_v2.NeuraPublicRuntimeError.from_error_or_exception(exc=exc, logger_to_use=logger_to_use, ecntx=ecntx)

        error_builder = ErrorBuilder(
            message_template = serviceExc.message,
            is_retryable = serviceExc.is_retryable
        )
        error_builder = (
            error_builder.with_retryhint_minwaitmillis(serviceExc.retry_hint_min_wait_ms)
                        .with_codes(serviceExc.error_codes)
                        .with_labels(serviceExc.labels)
                        .with_audience_messagetemplates(serviceExc.messages_by_audience)
        )

        # default status code is internal error
        status = grpc.StatusCode.INTERNAL
        
        # Now lets be error type specific from this point
        # CAREFUL!!! Checking order matters as exception classes extend each other!
        # we need to do checks bottom-up!
        if isinstance(serviceExc, errors_v2.NeuraPublicAuthenticationError):
            status = grpc.StatusCode.UNAUTHENTICATED
        elif isinstance(serviceExc, errors_v2.NeuraPublicAuthorizationError):
            status = grpc.StatusCode.PERMISSION_DENIED
        elif isinstance(serviceExc, errors_v2.NeuraPublicResourceNotFoundError):
            status = grpc.StatusCode.NOT_FOUND
        elif isinstance(serviceExc, errors_v2.NeuraPublicConstraintViolationError):
            status = grpc.StatusCode.FAILED_PRECONDITION
            if serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_ID_ALREADY_TAKEN) or serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_ALREADY_EXIST):
                status = grpc.StatusCode.ALREADY_EXISTS
            elif serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_DOES_NOT_EXIST):
                status = grpc.StatusCode.NOT_FOUND
        elif isinstance(serviceExc, errors_v2.NeuraPublicValidationError):
            status = grpc.StatusCode.INVALID_ARGUMENT
        elif isinstance(serviceExc, errors_v2.NeuraPublicNotImplementedError):
            status = grpc.StatusCode.UNIMPLEMENTED
        elif isinstance(serviceExc, errors_v2.NeuraPublicIllegalStateError):
            status = grpc.StatusCode.INTERNAL
            if serviceExc.has_error_code(errors_v2.NeuraPublicIllegalStateError.ERRCODE_EXCPECTATION_FAILED):
                status = grpc.StatusCode.FAILED_PRECONDITION
            elif serviceExc.has_error_code(errors_v2.NeuraPublicIllegalStateError.ERRCODE_EXHAUSTED):
                status = grpc.StatusCode.RESOURCE_EXHAUSTED

        neura_exc = NeuraGrpcError(
            status = status,
            error_details = GrpcErrorDetails(
                error = error_builder.build(),
                responseMeta = GrpcEcntxHandler.get_response_meta(ecntx)
            )
        )

        return neura_exc

from collections.abc import Sequence
from concurrent import futures

import grpc
from grpc_reflection.v1alpha import reflection

from neuraverse_common.grpc.model.config_source.grpc_config import GrpcConfig


def create_grpc_server(
    grpc_config: GrpcConfig,
    interceptors: Sequence[grpc.ServerInterceptor] = (),
    reflection_service_names: Sequence[str] = (),
) -> grpc.Server:
    """
    Create and configure a gRPC server from GrpcConfig.

    Handles thread pool sizing, port binding, and optional reflection setup.
    The caller is responsible for registering servicers and calling server.start().

    Args:
        grpc_config: Server configuration (address, port, max_workers, reflection_enabled).
        interceptors: Interceptors to attach to the server.
        reflection_service_names: Proto service names to expose via reflection.
            Only used when grpc_config.reflection_enabled is True.
            reflection.SERVICE_NAME is appended automatically.
    """
    server = grpc.server(
        futures.ThreadPoolExecutor(max_workers=grpc_config.max_workers),
        interceptors=interceptors,
    )
    if grpc_config.reflection_enabled and reflection_service_names:
        reflection.enable_server_reflection(
            (*reflection_service_names, reflection.SERVICE_NAME),
            server,
        )
    server.add_insecure_port(f"{grpc_config.address}:{grpc_config.port}")
    return server

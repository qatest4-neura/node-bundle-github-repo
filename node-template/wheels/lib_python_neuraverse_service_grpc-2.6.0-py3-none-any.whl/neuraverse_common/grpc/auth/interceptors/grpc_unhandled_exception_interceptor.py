"""
This module implements a lightweight gRPC interceptor for error handling and logging.

The GrpcUnhandledExceptionInterceptor provides comprehensive error logging for gRPC services:
- Authentication failures (UNAUTHENTICATED status)
- Authorization failures (PERMISSION_DENIED status)
- General gRPC errors with status codes
- Unhandled Python exceptions during request processing

This interceptor focuses on error scenarios only and does not add overhead to successful requests.

Usage:
    from neuraverse_common.observability.logging import Logger
    from neuraverse_asset.interceptors.grpc_unhandled_exception_interceptor import GrpcUnhandledExceptionInterceptor
    logger = Logger("asset-service")
    interceptor = GrpcUnhandledExceptionInterceptor(logger)
    # Add to gRPC server
    server = grpc.server(
        futures.ThreadPoolExecutor(max_workers=10),
        interceptors=[interceptor]
    )
"""

import grpc
from grpc_interceptor import ServerInterceptor
from neuraverse_common.observability.logging import Logger, LoggerFactory


class GrpcUnhandledExceptionInterceptor(ServerInterceptor):
    """
    A lightweight gRPC server interceptor that provides comprehensive error logging.

    This interceptor catches and logs various types of gRPC errors and exceptions:
    - Authentication failures (UNAUTHENTICATED)
    - Authorization failures (PERMISSION_DENIED)
    - Other gRPC status errors
    - Unhandled Python exceptions

    The interceptor adds minimal overhead to successful requests and focuses
    on providing detailed logging for error scenarios to aid in debugging
    and monitoring.
    """

    def __init__(self, logger_to_use: Logger | None = None):
        """
        Initialize the gRPC error logging interceptor.

        Args:
            logger (Logger): Logger instance from neuraverse_common.observability.logging
                           used for recording error events and exceptions.
        """
        # Create logger if not provided
        # Allowing passing of logger from outside for backwords compatibility,
        # but it is prefered to create a new logger
        self.logger = logger_to_use

        if logger_to_use is None:
            logger_name_prefix = "lib.grpc.auth"
            self.logger: Logger = LoggerFactory.get_logger(
                f"{logger_name_prefix}.{self.__class__.__name__}"
            )

    def intercept(
        self,
        method,
        request,
        context: grpc.ServicerContext,
        method_name: str,
    ):
        """
        Intercept gRPC requests to provide comprehensive error logging.

        This method wraps all gRPC service method calls to catch and log various
        error conditions while allowing successful requests to pass through with
        minimal overhead. It specifically handles:

        - Authentication failures (logs as warnings)
        - Authorization failures (logs as warnings)
        - Other gRPC errors (logs as warnings with status details)
        - Unhandled Python exceptions (logs as errors with full context)

        Args:
            method: The gRPC service method being called.
            request: The gRPC request message.
            context (grpc.ServicerContext): The gRPC context containing metadata.
            method_name (str): The name of the gRPC method being invoked.

        Returns:
            The result of the service method call if successful.

        Raises:
            grpc.RpcError: Re-raises gRPC errors after logging.
            Exception: Re-raises any other exceptions after logging.
        """

        try:
            return method(request, context)
        except grpc.RpcError as e:
            # Log gRPC errors with specific handling for authentication and authorization failures
            if e.code() == grpc.StatusCode.UNAUTHENTICATED:
                self.logger.warning(
                    "[%s] type [grpc.RpcError] gRPC authentication failure: %s - %s",
                    method_name,
                    e.code().name,
                    e.details(),
                )
            elif e.code() == grpc.StatusCode.PERMISSION_DENIED:
                self.logger.warning(
                    "[%s] type [grpc.RpcError] gRPC permission denied: %s - %s",
                    method_name,
                    e.code().name,
                    e.details(),
                )
            else:
                self.logger.warning(
                    "[%s] type [grpc.RpcError] gRPC request failed: %s - %s",
                    method_name,
                    e.code().name,
                    e.details(),
                )
            raise

        except Exception as e:
            # Log unexpected exceptions only if they haven't been handled by the service method
            # We check if the context has details set to determine if the exception was handled
            context_has_details = hasattr(context, "details") and context.details() is not None

            if not context_has_details:
                # This is an unhandled exception that should be logged for debugging
                self.logger.error(
                    "[%s] type [%s] Unhandled exception in gRPC method: %s",
                    method_name,
                    type(e).__module__ + "." + type(e).__name__,
                    str(e),
                )

            raise

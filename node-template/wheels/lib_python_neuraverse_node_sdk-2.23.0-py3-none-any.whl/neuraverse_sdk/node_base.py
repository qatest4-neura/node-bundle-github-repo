"""
Core NodeBase class for Neuraverse SDK

This is the base class that developers inherit from to create their own nodes.
It provides gRPC and HTTP API implementations for node management.
"""

import os
import queue
import threading
import time
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional, Callable

from google.protobuf.internal.containers import MessageMap, ScalarMap
from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    Node,
    NodeConfigEntry,
    NodeConfigValue,
    ToggleValue,
    VisualizationsTopic,
    VisualizationsTopics,
)
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.api.grpc.clients.scene_builder_client import SceneBuilderClient
from neuraverse_sdk.controllers.service_registry_repository import (
    ServiceRegistryRepository,
)
from neuraverse_sdk.dataflow.dataflow_factory import create_composite_data_flow
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.models.node_models import (
    NodeVisualizationsTopics,
)
from neuraverse_sdk.state_machine import IdleState, StateMachine
from neuraverse_sdk.state_machine_mock import MockRandomStateMachine


def _create_state_machine() -> StateMachine:
    """Create state machine; use mock when NEURAVERSE_SDK_MOCK_STATUS is set for triangulation."""
    env_val = (os.environ.get("NEURAVERSE_SDK_MOCK_STATUS") or "").strip().upper()
    if env_val in ("1", "TRUE", "YES"):
        return MockRandomStateMachine()
    return StateMachine(IdleState())


from neuraverse_sdk.trigger.i_trigger import ITrigger, TriggerType
from neuraverse_sdk.trigger.trigger_factory import (
    TriggerCommunicationType,
    create_trigger_adapter,
)
from neuraverse_sdk.utils.exceptions import (
    NodeConfigurationError,
    NodeExecutionError,
    NodePauseError,
    NodeResumeError,
    NodeHealthCheckError,
    NodeSimulationModeError,
    NodeStateError,
    NodeStopError,
)

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.neuraverse-node-sdk.node_base")

# FrameSource enum numeric values (proto: scene-builder.proto)
_FRAME_SOURCE_PATH = 1
_FRAME_SOURCE_ROBOT = 2
_FRAME_SOURCE_SENSOR = 3
_FRAME_SOURCE_MODEL = 4

_NON_ROBOT_FRAME_SOURCES = (
    _FRAME_SOURCE_PATH,
    _FRAME_SOURCE_SENSOR,
    _FRAME_SOURCE_MODEL,
)


def _health_monitor_worker(
    node: "NodeBase",
    stop_event: threading.Event,
    interval_s: float,
) -> None:
    """Periodically run get_health_check() and push changes to the health stream."""
    if interval_s <= 0:
        return
    while not stop_event.wait(timeout=interval_s):
        try:
            is_healthy, message = node.get_health_check()
            node.send_health_update(is_healthy, message)
        except Exception as e:
            node.log_warning(f"Health monitor check failed: {e}")
            node.send_health_update(False, f"Health check failed: {e}")




class NodeBase(ABC):
    """
    Base class for all Neuraverse nodes.

    Developers should inherit from this class and implement the required abstract methods.
    """

    def __init__(self):
        """Initialize the node"""

        # Threading and execution control

        # Node information
        self.node_info: Node = None
        self.node_inputs: dict[str, Any] = {}
        self.node_outputs: dict[str, Any] = {}
        self.node_trigger_inputs: dict[str, Any] = {}
        self.node_trigger_outputs: dict[str, Any] = {}
        self.project_id = ""

        # Dataflow
        self.data_flow: IDataFlow = None

        self.trigger: ITrigger = None

        self._auto_trigger: bool = True

        # State machine (or MockRandomStateMachine when NEURAVERSE_SDK_MOCK_STATUS=1)
        self.state_machine: StateMachine = _create_state_machine()

        # Service Registry Client
        self.service_registry_client: ServiceRegistryRepository

        # Service Configurations
        self.node_service_config: NodeServiceConfig

        self.status_queue: queue.Queue = None
        self._scene_builder_client = SceneBuilderClient()

        # Last-output cache.  Always-on, cheap (one entry per output port,
        # last value only).  Lets the visualization streamer — which is started
        # lazily on user request — seed itself with the last published value
        # so a UI opening viz late still sees data immediately.  Lives outside
        # the streamer so it survives viz start/stop and exists even before
        # any viz has ever been requested.
        self._last_output_cache: dict[str, tuple[Any, float]] = {}
        self._last_output_cache_lock = threading.Lock()

        # Protocol-agnostic visualization bridge.  Set by
        # NodeController.start_data_visualization to a callable that pumps
        # every publish() into the streamer regardless of whether the data
        # also flows through ROS, MQTT, or both.  ``None`` when no viz
        # session is active.  See ``publish()`` for invocation and
        # ``NodeController._make_viz_publish_hook`` for the wiring.
        self._viz_publish_hook: Optional[Any] = None

        # Single-threaded executor that runs execute() in response to trigger
        # messages.  Keeps the MQTT network thread responsive (callbacks must
        # return quickly) and serializes concurrent Start triggers so
        # on_execute() runs one at a time per node.  Recreated in
        # initialize() so a stop()/initialize() cycle starts fresh.
        self._execute_executor: Optional[ThreadPoolExecutor] = None
        
        # Message to be displayed in the UI for health check
        self._health_check_message: Optional[str] = None
        self.health_queue: Optional[queue.Queue] = None
        self.node_id: Optional[str] = None
        self._last_health_snapshot: Optional[tuple[bool, str]] = None
        self._health_monitor_stop_event: Optional[threading.Event] = None
        self._health_monitor_thread: Optional[threading.Thread] = None

    # Abstract methods that must be implemented by subclasses
    @abstractmethod
    def on_execute(self) -> None:
        """
        Execute the main node logic. This is called when execution is requested. Must be implemented by subclasses.
        """
        pass

    @abstractmethod
    def on_configure(
        self,
        config: ScalarMap[str, str],
        dynamic_config: MessageMap[str, NodeConfigEntry] | None = None,
    ) -> None:
        """
        Called when the node configuration is updated.

        Args:
            config: Plain string key-value configuration (backward compatible).
            dynamic_config: Typed configuration entries. Populated when the node graph
                uses the new dynamicConfiguration format; None for old-format graphs.
        """
        pass

    @abstractmethod
    def on_stop(self) -> None:
        """
        Called when the node is stopped.
        """
        pass

    @abstractmethod
    def on_get_configuration(self) -> MessageMap[str, NodeConfigEntry]:
        """Get node configuration to be displayed in the UI"""
        pass

    # Optional methods that can be overridden
    def on_pause(self) -> None:
        """
        Called when the node is paused.
        """
        self.log_info("Node paused")

    def on_resume(self) -> None:
        """
        Called when the node is resumed.
        """
        self.log_info("Node resumed")

    def on_toggle_simulation_mode(self, is_simulation: bool) -> None:
        """Called when simulation mode is toggled. Override to react to simulation/read mode change."""
        pass

    def on_health_check(self) -> bool:
        """Called when NES polls health. Override to report custom health status. returns True by defualt."""
        return True

    def on_cleanup(self) -> None:
        """
        Cleanup resources. Called when the node is stopping.
        """
        self.log_info("Node cleanup")

    def on_get_data_visualization_topics(self) -> NodeVisualizationsTopics:
        """
        Get remaining visualizations other than outputs, to be displayed on UI
        """
        return NodeVisualizationsTopics(topics={})

    def on_start_data_visualization(self, topic_names: list[str]) -> None:
        """Called when live data visualization streaming starts for this node.
        Override to adjust publish rates or perform custom actions."""
        pass

    def on_stop_data_visualization(self) -> None:
        """Called when live data visualization streaming stops for this node."""
        pass

    # Node lifecycle management

    def register_node(self, node_service_config: NodeServiceConfig):
        self.node_service_config = node_service_config
        self.__register_service(self.node_service_config)
        self.log_info(f"Node {self.__class__.__name__} registered")

    def initialize(
        self,
        status_queue: queue.Queue,
        node_id: str,
        health_queue: Optional[queue.Queue] = None,
    ):
        """Initialize the node"""
        try:
            self.status_queue = status_queue
            self.health_queue = health_queue
            self.node_id = node_id
            self._last_health_snapshot = None
            # Fresh init means a new lifecycle — re-arm stop() so its
            # destroy chain runs again on the next stop, and re-arm the
            # on_stop() once-guard so it fires again for this lifecycle.
            self._stop_completed = False
            self._on_stop_called = False

            # Fresh executor for this lifecycle. A previous stop() may have
            # shut it down; submitting to a shut-down executor raises
            # RuntimeError, so we always start clean here.
            if self._execute_executor is not None:
                self._execute_executor.shutdown(wait=False, cancel_futures=True)
            self._execute_executor = ThreadPoolExecutor(
                max_workers=1,
                thread_name_prefix=f"{self.__class__.__name__}-execute",
            )

            self.state_machine.initialize(self.status_queue, node_id)
            # Trigger initialization
            self.trigger = create_trigger_adapter(
                TriggerCommunicationType.TRIGGER_COMMUNICATION_TYPE_MQTT
            )

            self.trigger.init(configuration=self.node_service_config.mqtt)
            self.trigger.set_execute_callback(self._submit_execute)
            # self.trigger.set_error_callback(self.error)
            self.trigger.set_stop_callback(self.stop)

            # Dataflow initialization
            self.data_flow = create_composite_data_flow(self.node_service_config)

            # Initialize ScenebuilderClient
            self._scene_builder_client.init(self.node_service_config.scene_builder_endpoint)
            return True

        except Exception as e:
            self.state_machine.error(
                f"Failed to initialize node: {self.__class__.__name__} - {str(e)})"
            )
            self.log_error(
                message=f"Failed to initialize node: {self.__class__.__name__} - {str(e)}"
            )
            raise e

    def configure(self, node_info: Node) -> bool:
        """
        Update node configuration.

        Args:
            node_info: Node information
        Returns:
            Dict with result code and message
        """

        try:
            # Re-enable auto-triggering for this new run (may have been cleared by stop())
            self._auto_trigger = True
            # Reconfigure means a fresh lifecycle from this point — re-arm
            # stop() so its destroy chain runs again on the next stop, and
            # re-arm the on_stop() once-guard so it fires again next stop.
            self._stop_completed = False
            self._on_stop_called = False

            # Recreate the executor when it was shut down by a prior
            # stop().  Without this, every incoming Start trigger that
            # arrives on the rebuilt MQTT subscription is dropped by
            # ``_submit_execute`` with the log line "Ignoring trigger
            # — node executor is shut down", and the downstream node
            # silently does nothing on every Run after the first
            # Stop → Configure → Run cycle.  See
            # [[160-reconfigure-lifecycle.md]] and the
            # ``020-subscriber-side-reconfigure`` spec.
            if self._execute_executor is None or getattr(
                self._execute_executor, "_shutdown", False
            ):
                self._execute_executor = ThreadPoolExecutor(
                    max_workers=1,
                    thread_name_prefix=f"{self.__class__.__name__}-execute",
                )
            if self.data_flow:
                self.data_flow.configure(node_info.dataFlowEntry)
            if self.trigger:
                self.trigger.configure(node_info.triggerFlowEntry)

            self.node_inputs = dict(node_info.inputs)
            self.node_outputs = dict(node_info.outputs)
            self.node_trigger_inputs = dict(node_info.triggerFlowEntry.inputTriggers)
            self.node_trigger_outputs = dict(node_info.triggerFlowEntry.outputTriggers)

            self.node_info = node_info
            self.on_configure(node_info.configuration, node_info.dynamicConfiguration or None)
            self.state_machine.configure()
            self._push_current_health()
            self._start_health_monitor()
            return True

        except Exception as e:
            self.state_machine.error(f"Failed to update configuration: {node_info.name} - {str(e)}")
            self.log_error(
                f"Failed to update configuration: {node_info.name} - {str(e)}",
                exception=e,
            )
            raise e

    def get_inputs(self) -> dict[str, Any]:
        return self.node_inputs

    def get_outputs(self) -> dict[str, Any]:
        return self.node_outputs

    def get_trigger_inputs(self) -> dict[str, Any]:
        return self.node_trigger_inputs

    def get_trigger_outputs(self) -> dict[str, Any]:
        return self.node_trigger_outputs

    def execute(self) -> bool:
        """
        Execute the node once. This is the main execution method.

        Returns:
            Dict containing execution results
        """
        # Use-after-stop guard.  ``execute()`` is the entry point the trigger
        # adapter invokes on every incoming Start MQTT message.  Once ``stop()``
        # has run the destroy chain, the data flow and trigger are torn down
        # — but a Start message already queued on paho's network thread can
        # still arrive a moment later, calling back into ``execute()`` and
        # then into ``on_execute()``.  For nodes whose ``on_execute`` is a
        # publish loop (camera/microphone stream nodes) this is fatal: the
        # loop clears its stop event at the top of ``on_execute`` and then
        # spams ``Cannot publish: not connected`` forever against the
        # disconnected MQTT client.  Refuse to run after stop has completed
        # so the stale trigger drains harmlessly.
        if getattr(self, "_stop_completed", False):
            self.log_info(
                "Ignoring execute() — node has already been stopped "
                "(stale Start trigger arrived after stop() completed)"
            )
            return True
        # Execute the node
        start_time = time.time()
        try:
            if self.node_info == None:
                self.log_error("Node info is None")
                raise NodeExecutionError("Node info is None")

            self.log_info(f"Executing node {self.node_info.name}")

            self.state_machine.execute()
            self.on_execute()

            execution_time = time.time() - start_time
            self.log_info(f"Node execution completed in {execution_time:.3f}s")
            self.state_machine.configure()

            if self.trigger and self._auto_trigger:
                if self.trigger.has_outgoing_trigger(TriggerType.Start):
                    self.trigger.trigger_next_node(TriggerType.Start)
                if self.trigger.has_outgoing_trigger(TriggerType.Stop):
                    self.trigger.trigger_next_node(TriggerType.Stop)

            return True

        except Exception as e:
            self.state_machine.error(f"Execution error: {str(e)}")

            self.log_error(f"Execution error: {str(e)}", exception=e)

            raise NodeExecutionError(f"Node Execution failed: {str(e)}")

    def execute_background(self) -> bool:
        """
        Start node execution in the background. Returns immediately.
        """
        thread = threading.Thread(target=self.execute, daemon=True)
        thread.start()
        return True

    def _submit_execute(self) -> bool:
        """Trigger callback entry point.

        Submits execute() to the per-node single-threaded executor so the MQTT
        network thread (which invokes this callback from paho's on_message)
        returns immediately. Without this, a long-running on_execute() would
        block paho's network loop past keep_alive and the broker would drop
        the client, kicking off a reconnect storm and silent QoS-1 retries.
        """
        # Use-after-stop guard at the callback entry. ``execute()`` has
        # its own guard, but stopping the chain earlier saves us
        # queueing a doomed task and produces clearer logs ("the
        # trigger arrived after stop") for operators tracing flow.
        if getattr(self, "_stop_completed", False):
            self.log_info(
                "Ignoring trigger — node has already been stopped"
            )
            return True
        executor = self._execute_executor
        if executor is None:
            self.log_info("Ignoring trigger — node executor is not initialized")
            return True
        try:
            executor.submit(self.execute)
        except RuntimeError:
            # Executor was shut down (node stopped); drop the trigger.
            self.log_info("Ignoring trigger — node executor is shut down")
        return True

    def stop(self) -> bool:
        """
        Stop the node.

        Returns:
            Dict with result code and message
        """
        # If a previous stop() already ran the destroy chain to completion,
        # repeating it is at best a no-op and at worst a hang on already-
        # disposed state. ``_stop_completed`` is cleared by initialize() and
        # configure() so the destroy chain runs cleanly on the next real stop
        # after a fresh setup.
        if getattr(self, "_stop_completed", False):
            return True

        # Disable auto-triggering immediately so any in-flight on_execute()
        # does not fire trigger_next_node() after it returns.
        self._auto_trigger = False

        # Each teardown step is independent: a failure in one must not skip the
        # rest (which would leak the remaining resources). Run them all, collect
        # failures, and surface them after on_stop() has run.
        failed_steps: list[str] = []

        def _step(label: str, fn: Callable[[], Any]) -> None:
            try:
                fn()
            except Exception as e:  # pylint: disable=broad-except
                failed_steps.append(label)
                self.log_error(f"stop(): {label} failed - {str(e)}", exception=e)

        try:
            _step("state_machine.stop", self.state_machine.stop)
            _step("state_machine.end_status_stream", self.state_machine.end_status_stream)
            _step("end_health_stream", self._end_health_stream)
            _step("on_cleanup", self.on_cleanup)
            if self.data_flow:
                _step("data_flow.destroy", self.data_flow.destroy)
            if self.trigger:
                _step("trigger.destroy", self.trigger.destroy)

            # Shut the trigger executor down so no queued or late-arriving
            # Start triggers fire after the destroy chain. Don't wait on the
            # currently-running execute() (if any) — stop() must be quick.
            if self._execute_executor is not None:
                executor = self._execute_executor
                _step(
                    "executor.shutdown",
                    lambda: executor.shutdown(wait=False, cancel_futures=True),
                )

            # Stop Consul monitoring if service registry client exists
            if hasattr(self, "service_registry_client") and self.service_registry_client:
                if hasattr(self.service_registry_client, "stop_monitoring"):
                    _step(
                        "service_registry.stop_monitoring",
                        self.service_registry_client.stop_monitoring,
                    )
            _step("scene_builder_client.close", self._scene_builder_client.close)

            self._stop_completed = True
        finally:
            # Guarantee on_stop() runs exactly once per lifecycle — even if a
            # step above raised unexpectedly. Resource-release hooks (e.g.
            # dropping a shared robot connection) must never be skipped.
            self._invoke_on_stop_once()

        if failed_steps:
            msg = "Failed to stop node - steps failed: " + ", ".join(failed_steps)
            self.state_machine.error(msg)
            self.log_error(msg)
            raise NodeStopError(msg)
        return True

    def _invoke_on_stop_once(self) -> None:
        """Call ``on_stop()`` at most once per node lifecycle.

        Invoked from ``stop()``'s ``finally`` so node cleanup hooks (such as
        releasing a shared robot hold) run exactly once even if the destroy
        chain raised. The once-guard ``_on_stop_called`` is reset in
        ``initialize()`` / ``configure()`` so the next lifecycle re-arms it. A
        failure inside ``on_stop()`` is logged, never propagated.
        """
        if getattr(self, "_on_stop_called", False):
            return
        self._on_stop_called = True
        try:
            self.on_stop()
        except Exception as e:  # pylint: disable=broad-except
            self.log_error(f"on_stop() failed during stop - {str(e)}", exception=e)

    def pause(self) -> bool:
        """
        Pause the node.
        Returns:
            Dict with result code and message
        """
        try:
            self.state_machine.pause()
            self.on_pause()
            return True

        except Exception as e:
            self.state_machine.error(f"Failed to pause node: {str(e)}")
            self.log_error(f"Failed to pause node: {str(e)}", exception=e)
            raise NodePauseError(f"Failed to pause node: {str(e)}")

    def resume(self) -> bool:
        """
        Resume the node (transition Paused -> Running and send status update).
        Returns:
            True if resumed successfully
        """
        try:
            self.state_machine.resume()
            self.on_resume()
            return True

        except Exception as e:
            self.state_machine.error(f"Failed to resume node: {str(e)}")
            self.log_error(f"Failed to resume node: {str(e)}", exception=e)
            raise NodeResumeError(f"Failed to resume node: {str(e)}")

    def toggle_simulation_mode(self, is_simulation: bool) -> bool:
        try:
            self.log_info(f"Simulation mode set to: {is_simulation}")
            self.on_toggle_simulation_mode(is_simulation)
            return True
        except Exception as e:
            self.log_error(f"Failed to toggle simulation mode: {str(e)}", exception=e)
            raise NodeSimulationModeError(f"Failed to toggle simulation mode {str(e)}")

    def get_health_check(self) -> tuple[bool, str]:
        try:
            self._health_check_message = None
            is_healthy = self.on_health_check()
            message = self._health_check_message or (
                "Healthy" if is_healthy else "Unhealthy"
            )
            self.log_info(f"Healthy check result: {is_healthy}, message: {message}")
            return is_healthy , message
        except Exception as e:
            self.log_error(f"health check failed: {str(e)}", exception=e)
            return False , f"Health check failed: {str(e)}"

    def send_health_update(self, is_healthy: bool, message: str) -> None:
        """Push a health snapshot to the health stream when it changes."""
        if not self.health_queue or not self.node_id:
            return
        snapshot = (is_healthy, message)
        if snapshot == self._last_health_snapshot:
            return
        self._last_health_snapshot = snapshot
        item = {
            "nodeId": self.node_id,
            "isHealthy": is_healthy,
            "resultMessage": message,
        }
        try:
            self.health_queue.put_nowait(item)
        except queue.Full:
            self.log_warning("Health queue full; dropping health update")

    def _push_current_health(self) -> None:
        """Force-push the current health snapshot (e.g. on configure or subscribe)."""
        self._last_health_snapshot = None
        try:
            is_healthy, message = self.get_health_check()
            self.send_health_update(is_healthy, message)
        except Exception as e:
            self.log_warning(f"Failed to push initial health snapshot: {e}")

    def _start_health_monitor(self) -> None:
        self._stop_health_monitor()
        if self.node_service_config is None:
            return
        interval_s = getattr(
            self.node_service_config, "health_stream_check_interval_s", 10.0
        )
        if interval_s <= 0 or self.health_queue is None:
            return
        stop_event = threading.Event()
        self._health_monitor_stop_event = stop_event
        thread = threading.Thread(
            target=_health_monitor_worker,
            args=(self, stop_event, interval_s),
            daemon=True,
            name=f"health-monitor-{self.node_id or 'unknown'}",
        )
        thread.start()
        self._health_monitor_thread = thread

    def _stop_health_monitor(self) -> None:
        stop_event = self._health_monitor_stop_event
        if stop_event is not None:
            stop_event.set()
        self._health_monitor_stop_event = None
        self._health_monitor_thread = None

    def _end_health_stream(self) -> None:
        self._stop_health_monitor()
        self._last_health_snapshot = None
        if self.health_queue is not None:
            try:
                self.health_queue.put_nowait(None)
            except queue.Full:
                self.log_warning("Health queue full; could not send stream end sentinel")
            self.health_queue = None

    def get_configuration(self) -> MessageMap[str, NodeConfigEntry]:
        """
        Get node configuration.

        Returns:
            MessageMap containing configuration
        """

        try:
            self.log_info(f"Getting node configuration for {self.get_node_class_name()}")
            configuration: MessageMap[str, NodeConfigEntry] = self.on_get_configuration()
            return configuration
        except Exception as e:
            self.log_error(f"Failed to get configuration: {str(e)}", exception=e)
            raise NodeConfigurationError(f"Failed to get configuration: {str(e)}")

    # Information getters

    def set_project_id(self, project_id: str):
        """Set the project id for the node."""
        self.project_id = project_id

    def get_frames(self, metadata_filter: Optional[Dict] = None) -> List[Dict]:
        """
        Retrieve a list of non-robot frames from the Scene Builder Backend for a given project.

        This method calls the Scene Builder Backend's ListFrames API with
        ``sources`` set to path, sensor, and model origins (excluding robot frames).

        Args:
            metadata_filter: Optional dictionary to filter frames by metadata.
                Only frames matching all key-value pairs are returned (client-side).
                Example: {"type": "tcp", "robot": "robot1"}

        Returns:
            List of frame dictionaries. Each frame typically contains:
            - id (str): Unique, stable identifier for the frame
            - display_name (str): Human-readable name for UI display
            - initial_pose (dict): Static pose in world space (position and orientation)
            - metadata (dict): Arbitrary metadata key-value pairs
            - source (str): Frame origin (e.g. path, robot, sensor, model)
        """
        try:
            return self._scene_builder_client.list_frames(
                self.project_id,
                metadata_filter=metadata_filter,
                sources=_NON_ROBOT_FRAME_SOURCES,
            )
        except Exception as e:
            raise NodeStateError(f"Failed to get frames: {str(e)}") from e

    def get_robots(self) -> List[Dict]:
        """
        Retrieve a list of robots from the Scene Builder Backend for a given project.

        Robot entries are frames whose ``Frame.source`` is the robot enum value (2).
        """
        try:
            return self._scene_builder_client.list_frames(
                self.project_id,
                metadata_filter=None,
                sources=(_FRAME_SOURCE_ROBOT,),
            )
        except Exception as e:
            raise NodeStateError(f"Failed to get frames: {str(e)}") from e

    def get_node_id(self) -> str:
        """Get the node id"""
        if self.node_info is None:
            raise NodeStateError("Node info is not initialized")
        return self.node_info.id

    def get_node_name(self) -> str:
        """Get the node name"""
        if self.node_info is None:
            raise NodeStateError("Node info is not initialized")
        return self.node_info.name

    def get_node_class_name(self) -> str:
        """Get the node class name"""
        return self.__class__.__name__

    def get_ros_node(self) -> Any:
        """Return the rclpy node used by this node for ROS2 communication.

        Override this method in subclasses that manage their own rclpy node
        (e.g. nodes that do not use the standard dataflow adapter).
        The default implementation returns the node held by the dataflow adapter.
        """
        if self.data_flow and hasattr(self.data_flow, "ros_node"):
            return self.data_flow.ros_node
        return None

    def get_connected_ports(self) -> dict[str, bool]:
        if self.data_flow:
            return self.data_flow.get_connected_ports()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    def get_input_topics(self) -> dict[str, Any]:
        if self.data_flow:
            return self.data_flow.get_input_topics()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    def get_output_topics(self) -> dict[str, Any]:
        if self.data_flow:
            return self.data_flow.get_output_topics()

        raise NodeStateError("Dataflow is not configured, please configure node first")

    # ROS types that produce meaningless or oversized visualization output.
    # PointCloud2 / CameraInfo etc. are filtered from the picker.
    _NON_VISUALIZABLE_TYPES: frozenset = frozenset(
        {
            "sensor_msgs/msg/PointCloud2",
            "sensor_msgs/msg/CameraInfo",
            "sensor_msgs/msg/LaserScan",
            "sensor_msgs/msg/Imu",
            "sensor_msgs/msg/NavSatFix",
            "sensor_msgs/msg/MagneticField",
            "tf2_msgs/msg/TFMessage",
        }
    )

    def get_data_visualizations_topics(self) -> VisualizationsTopics:
        try:
            from neuraverse_sdk.streaming.data_visualization_streamer import (
                livekit_safe_viz_name,
                visualization_stream_type,
            )

            data_visualizations_topics = VisualizationsTopics()

            user_defined_data_visualization_topics = self.on_get_data_visualization_topics()

            # ``topicName`` is the identity the UI uses to subscribe to the
            # LiveKit track/data channel verbatim, so it MUST equal the public
            # name the streamer publishes under (LiveKit-safe, node-id keyed).
            # The streamer still subscribes to the real ROS topic internally.
            for (
                data_visualization_name,
                data_visualization_topic,
            ) in user_defined_data_visualization_topics.topics.items():
                topic = VisualizationsTopic()
                topic.topicName = livekit_safe_viz_name(data_visualization_topic.topic_name)
                topic.visualizationType = visualization_stream_type(
                    data_visualization_topic.visualization_type
                )
                data_visualizations_topics.topics[data_visualization_name].CopyFrom(topic)

            output_topics = self.get_output_topics()
            for output_name, output_info in output_topics.items():
                if "ros_type" not in output_info:
                    continue
                ros_type = output_info["ros_type"].lstrip("/")
                if ros_type in self._NON_VISUALIZABLE_TYPES:
                    continue
                topic = VisualizationsTopic()
                topic.topicName = livekit_safe_viz_name(output_info["topic_name"])
                topic.visualizationType = visualization_stream_type(ros_type)
                data_visualizations_topics.topics[output_name].CopyFrom(topic)

            return data_visualizations_topics
        except Exception as e:
            LOGGER.error(f"Failed to get data visualizations topics: {str(e)}")
            raise NodeStateError("Failed to get data visualizations topics")

    # Logging methods

    def log_info(self, message: str):
        """Log info message"""
        LOGGER.info(message)

    def log_error(self, message: str, exception: Exception | None = None):
        """Log error message"""
        LOGGER.error(message + (" " + str(exception) if exception else ""))

    def log_warning(self, message: str):
        """Log warning message"""
        LOGGER.warning(message)

    def log_debug(self, message: str):
        """Log debug message"""
        LOGGER.debug(message)

    # Dataflow methods

    def get_data(self, placeholder: str):
        """Get the data from the node."""
        if self.data_flow:
            data = self.data_flow.get_data(placeholder)
            if data is not None:
                self._try_push_viz_background(placeholder, data)
            return data

    def _try_push_viz_background(self, placeholder: str, msg: Any) -> None:
        """Auto-push image messages as visualization background when viz is active.

        Activated for any node once the visualization controller sets ``_viz_bg_push``
        and ``_viz_bg_mqtt_to_seg``.  Nodes do not need to call this explicitly.
        """
        push_fn = getattr(self, "_viz_bg_push", None)
        if push_fn is None:
            return
        bg_map = getattr(self, "_viz_bg_mqtt_to_seg", {})
        if not bg_map:
            return
        # Build/reuse the placeholder→MQTT-topic cache (retried until non-empty)
        cache = getattr(self, "_viz_bg_input_cache", None)
        if not cache:
            try:
                result = {
                    pn: info.get("topic_name", "") for pn, info in self.get_input_topics().items()
                }
                if result:
                    self._viz_bg_input_cache = result
                    cache = result
            except Exception:
                pass
        mqtt_topic = (cache or {}).get(placeholder, "")
        if not mqtt_topic:
            return
        seg_topic = bg_map.get(mqtt_topic, "")
        if not seg_topic:
            return
        try:
            import cv2
            import numpy as np

            ros_type = ""
            port_info = (self.node_inputs or {}).get(placeholder)
            if port_info:
                rt = getattr(port_info, "rosType", "") or ""
                ros_type = rt.rsplit("/", 1)[-1] if "/" in rt else rt

            if ros_type == "CompressedImage" or (not ros_type and hasattr(msg, "format")):
                raw = bytes(msg.data)
                arr = np.frombuffer(raw, np.uint8)
                bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                if bgr is not None:
                    push_fn(seg_topic, cv2.cvtColor(bgr, cv2.COLOR_BGR2RGBA))
            elif ros_type == "Image" or (
                not ros_type and hasattr(msg, "encoding") and hasattr(msg, "step")
            ):
                encoding = (getattr(msg, "encoding", "") or "").lower()
                h, w = int(msg.height), int(msg.width)
                if h > 0 and w > 0:
                    raw = np.frombuffer(bytes(msg.data), dtype=np.uint8)
                    if encoding in ("rgb8",):
                        push_fn(seg_topic, cv2.cvtColor(raw.reshape(h, w, 3), cv2.COLOR_RGB2RGBA))
                    elif encoding in ("bgr8", "8uc3"):
                        push_fn(seg_topic, cv2.cvtColor(raw.reshape(h, w, 3), cv2.COLOR_BGR2RGBA))
        except Exception:
            pass

    def wait_for_message(self, placeholder: str, timeout: float = -1.0):
        """Wait for a message from the node."""
        if self.data_flow:
            _ = self.data_flow.wait_for_message(placeholder, timeout)

    def publish(self, topic_name: str, message: Any) -> None:
        """Publish the data from the node."""
        if self.data_flow:
            self.data_flow.publish(target=topic_name, message=message, meta_data=None)
        # Cache the last value so a viz session that starts later (or is
        # restarted) can re-emit it via LiveKit immediately.  Cheap: one entry
        # per output port, last value only.  See `get_cached_output`.
        with self._last_output_cache_lock:
            self._last_output_cache[topic_name] = (message, time.monotonic())

        # Protocol-agnostic visualization bridge — when a viz session is
        # active for this node, the controller wires a hook here that
        # dispatches every publish() into the streamer's handlers.  This
        # means the live LiveKit feed works even when the node's data flow
        # is ROS-only (no fragile rclpy subscription on the streamer side
        # required) or when the same value would otherwise reach the viz
        # only via the MQTT-only direct push hooks each node has to wire
        # up by hand.  Failures here are swallowed — viz must never break
        # the publish path.
        hook = self._viz_publish_hook
        if hook is not None:
            try:
                hook(topic_name, message)
            except Exception:
                pass

    def get_cached_output(self, topic_name: str) -> Optional[Any]:
        """Return the last value published for ``topic_name`` (or None).

        Used by the visualization streamer on start to seed the live channel
        with the most recent value, so a UI opening viz late doesn't have to
        wait for the next publish to see anything.
        """
        with self._last_output_cache_lock:
            entry = self._last_output_cache.get(topic_name)
            if entry is None:
                return None
            return entry[0]

    def get_cached_output_topics(self) -> list[str]:
        """Return the list of output port names that have a cached value."""
        with self._last_output_cache_lock:
            return list(self._last_output_cache.keys())

    def register_handler(self, callback, input_name: str = ""):
        """Register a handler for a specific topic."""
        if self.data_flow:
            self.data_flow.register_handler(callback, input_name)

    # __Private methods___
    #

    def __register_service(self, service_config: NodeServiceConfig):
        # register with service registry

        registry_endpoint = service_config.registry_config.registry_endpoint
        if not registry_endpoint:
            self.log_warning("Registry endpoint not configured, skipping registration.")
            return

        if service_config.registry_config.node_cluster_target == "":
            node_endpoint = f"{service_config.grpc.address}:{service_config.grpc.port}"
        else:
            node_endpoint = service_config.registry_config.node_cluster_target

        node_configurations = self.__get_static_configuraions()

        self.service_registry_client = ServiceRegistryRepository(
            registry_endpoint,
        )

        self.service_registry_client.register_node(
            node_endpoint=node_endpoint,
            capability_name=self.get_node_class_name(),
            node_configurations=node_configurations,
        )

    def __get_static_configuraions(self) -> MessageMap[str, NodeConfigEntry]:
        node_configurations: MessageMap[str, NodeConfigEntry] = {}
        node_configurations["node_external_target"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                stringValue=self.node_service_config.registry_config.node_external_target,
            ),
            required=True,
            displayLabel="Node External Target",
            description="External URL (host:port) when the node is reachable from outside the cluster; stored in registry for is_remote resolution.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )

        node_configurations["is_remote"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                toggleValue=ToggleValue(
                    enabled=False,
                ),
            ),
            required=True,
            displayLabel="Is Remote",
            description="Whether the node is reachable from outside the cluster.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )

        node_configurations["node_deployment_host"] = NodeConfigEntry(
            configValue=NodeConfigValue(
                stringValue=self.node_service_config.registry_config.registry_endpoint,
            ),
            required=True,
            displayLabel="Node Deployment Host",
            description="The host and port of where the node is registerd.",
            unit="",
            readOnly=False,
            isOverridable=False,
        )
        return node_configurations

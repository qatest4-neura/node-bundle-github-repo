from dataclasses import dataclass
from typing import Dict

@dataclass
class NodeVisualizationsTopic:
    topic_name: str
    visualization_type: str


@dataclass
class NodeVisualizationsTopics:
    topics: Dict[str, NodeVisualizationsTopic]

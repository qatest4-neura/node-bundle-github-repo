"""
This module defines the `RegistryConfig` class for registring nodes in the consul
It leverages Pydantic for validation and ensures that these
fields are properly set and documented.
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class RegistryConfig(BaseSettings):
    """
    Configuration class for MQTT client settings.
    This class defines the address and port for the MQTT client, providing a
    structured way to manage these settings.
    """

    registry_endpoint: str = Field(
        default="", description="Nodes Registry Endpoint"
    )
    node_cluster_target: str = Field(
        default="", description="Nodes endpoint in the cluster"
    )
    node_external_target: str = Field(
        default="",
        description="External URL (host:port) when the node is reachable from outside the cluster; stored in registry for is_remote resolution.",
    )

    class Config:
        extra = "allow"

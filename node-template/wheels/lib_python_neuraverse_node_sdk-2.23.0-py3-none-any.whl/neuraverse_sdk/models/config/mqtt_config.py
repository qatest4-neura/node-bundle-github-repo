"""
This module defines the `MqttConfig` class for managing MQTTclient configuration
in the NEURA robotics tenant service.
The `MqttConfig` class provides structured fields for defining the MQTTclient's
address and port. It leverages Pydantic for validation and ensures that these
fields are properly set and documented.
"""
from pydantic import Field
from pydantic_settings import BaseSettings
from typing import Optional

class MQTTConfig(BaseSettings):
    """
    Configuration class for MQTT client settings.
    This class defines the address and port for the MQTT client, providing a
    structured way to manage these settings.
    """
    broker_host: str = Field(default="[::]", description="MQTT broker address")
    broker_port: int = Field(default=1883, description="MQTT broker port")
    client_id: str = Field(default="neuraverse_node", description="MQTT client id for the connection")
    username: Optional[str] = Field(default=None, description="MQTT username")
    password: Optional[str] = Field(default=None, description="MQTT username")
    keep_alive: int = Field(default=120, description="MQTT keep alive interval in seconds")
    clean_session: bool = Field(default=True, description="MQTT clean session flag")
    qos: int = Field(default=1, description="MQTT Quality of Service level")
    retain:bool = Field(default=False, description="MQTT retain flag for messages")
    reconnect_delay_min: float = Field(default=1.0, description="MQTT minimum reconnect delay in seconds")
    reconnect_delay_max: float = Field(default=60.0, description="MQTT maximum reconnect delay in seconds")

    class Config:
        extra = "allow"

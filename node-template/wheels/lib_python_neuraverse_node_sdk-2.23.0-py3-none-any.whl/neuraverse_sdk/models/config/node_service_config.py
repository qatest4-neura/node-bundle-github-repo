from pydantic import Field, BaseModel
from neuraverse_common.models.config.base_service_config import BaseServiceConfig
from neuraverse_common.grpc.model.config_source.grpc_config import GrpcConfig
from neuraverse_common.http.model.config_source.HttpConfig import HttpConfig
from neuraverse_common.models.config.config_source.JwtConfig import JwtConfig
from neuraverse_common.models.config.config_source.LogConfig import LogConfig
from neuraverse_common.models.config.config_source.MetricsConfig import MetricsConfig
from neuraverse_sdk.models.config.mqtt_config import MQTTConfig
from neuraverse_sdk.models.config.registry_config import RegistryConfig
from neuraverse_sdk.models.config.zenoh_config import ZenohConfig


class NodeServiceDescriptor(BaseModel):
    """Service descriptor for node implementations."""

    name: str = Field(default="Node SDK Service", description="Service name")
    version: str = Field(default="1.0.0", description="Service version")
    description: str = Field(default="", description="Service description")


class NodeServiceConfig(BaseServiceConfig):
    """
    Node service configuration class.

    Attributes:
        jwt: JWT configuration settings
        grpc: gRPC API configuration settings
        http: HTTP API configuration settings
        logging: Logging configuration settings
        metrics: Metrics configuration settings
        mqtt: MQTT configuration settings
        registry_config: Service Registry configuration settings
        service_descriptor: Service descriptor (name, version, description)
        container_name: Name of the container
    """

    jwt: JwtConfig = Field(default_factory=JwtConfig, description="Jwt configuration")
    grpc: GrpcConfig = Field(default_factory=GrpcConfig, description="gRPC API config")
    http: HttpConfig = Field(default_factory=HttpConfig, description="HTTP API config")
    logging: LogConfig = Field(default_factory=LogConfig, description="Logging config")
    metrics: MetricsConfig = Field(default_factory=MetricsConfig, description="Metrics config")
    mqtt: MQTTConfig = Field(default_factory=MQTTConfig, description="MQTT config")
    zenoh: ZenohConfig | None = Field(default=None, description="Zenoh config")
    registry_config: RegistryConfig = Field(
        default_factory=RegistryConfig, description="Service Registry config"
    )
    service_descriptor: NodeServiceDescriptor = Field(
        default_factory=NodeServiceDescriptor, description="Service descriptor"
    )
    container_name: str = Field(default="", description="Name of the container")
    scene_builder_endpoint: str = Field(default="", description="Scene builder client endpoint")
    livekit_url: str = Field(
        default="",
        description="LiveKit server WebSocket URL (e.g., wss://livekit.dev.neuraverse.com)",
    )
    status_stream_heartbeat_interval_s: float = Field(
        default=1.0,
        description=(
            "Interval in seconds for periodic re-send of the last known node status on the "
            "status stream. Keeps the stream alive on long-running graphs and gives "
            "reconnecting subscribers fast visibility of the current state. "
            "Set to 0 (or negative) to disable."
        ),
    )
    health_stream_check_interval_s: float = Field(
        default=10.0,
        description=(
            "Interval in seconds for the in-node health monitor to run get_health_check() "
            "and push updates on the health stream when the (isHealthy, message) snapshot "
            "changes. Set to 0 (or negative) to disable periodic checks."
        ),
    )
    viz_sources_ready_timeout_s: float = Field(
        default=10.0,
        description=(
            "Maximum seconds to wait for the LiveKit data-visualization streamer to "
            "register its video sources before wiring the publish hook anyway. A flaky "
            "signaling endpoint cannot hang StartDataVisualization beyond this bound. "
            "On timeout the controller logs a WARNING and proceeds; the first publishes "
            "may drop until LiveKit catches up."
        ),
    )

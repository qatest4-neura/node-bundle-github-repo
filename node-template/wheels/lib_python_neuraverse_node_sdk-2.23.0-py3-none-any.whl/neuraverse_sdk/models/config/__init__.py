"""
Neuraverse SDK Configuration Models
""" 
from pydantic import Field
from pydantic_settings import BaseSettings


class ZenohConfig(BaseSettings):
    """Configuration class for Zenoh session settings."""

    locator: str = Field(
        default="tcp/zenoh-router:7447",
        description="Zenoh router endpoint to connect to (e.g. tcp/zenoh-router:7447)",
    )
    mode: str = Field(
        default="client",
        description="Zenoh session mode: client, peer, or router",
    )
    priority: str = Field(
        default="data",
        description="QoS message priority: real_time, interactive_high, interactive_low, "
        "data_high, data, data_low, background",
    )
    reliability: str = Field(
        default="reliable",
        description="QoS reliability: reliable or best_effort",
    )
    congestion_control: str = Field(
        default="drop",
        description="QoS congestion control when network is saturated: block or drop",
    )
    express: bool = Field(
        default=False,
        description="QoS express flag: bypass internal batching for lower latency",
    )

    class Config:
        extra = "allow"

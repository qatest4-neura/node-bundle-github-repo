from contextlib import contextmanager
import json
import consul
import threading
import time
from google.protobuf.json_format import MessageToDict
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.observability.logging import Logger, LoggerFactory


class ServiceRegistryClient:
    """
    gRPC client for interacting with the Node Service API.
    This client provides methods to handle node lifetime functions.
    """
    def __init__(self, consul_url: str, token=None):
        self._LOG: Logger = LoggerFactory.get_logger(
            f"service.api.grpc.clients.{self.__class__.__name__}"
        )
        consul_address, consul_port = consul_url.split(":")
        self.consul = consul.Consul(host=consul_address, port=int(consul_port), token=token)
        self.consul_url = consul_url
        self.token = token
        # for re-registration
        self._registration_info: dict | None = None
        self._health_check_thread: threading.Thread | None = None
        self._should_monitor = False
        self._stop_event = threading.Event()
        self._health_check_interval = 30
        self._reconnect_delay = 5
        self._max_reconnect_delay = 60

    def _store_configurations_in_kv(self, service_name: str, node_configurations) -> None:
        """Store node configurations in Consul KV as a JSON blob, preserving full NodeConfigEntry structure."""
        kv_key = f"capability/{service_name}/configurations"
        config_dict = {}
        for key, entry in node_configurations.items():
            if isinstance(entry, str):
                config_dict[key] = entry
            else:
                config_dict[key] = MessageToDict(entry, preserving_proto_field_name=True)
        payload = json.dumps(config_dict)
        self.consul.kv.put(kv_key, payload)
        self._LOG.info(f"Stored node configurations in KV at '{kv_key}'")

    def _build_meta(self, node_configurations) -> dict[str, str]:
        entry = node_configurations["node_external_target"]
        return {"node_external_target": entry.configValue.stringValue if entry else ""}

    @contextmanager
    def _log_method_invocation(
        self,
        method_name: str,
        cntx: ExecutionContext | None = None,
        params: dict[str, str] | None = None,
    ):
        """
        Context manager for logging method entry and exit with provided parameters passed to the method optionally.
        """
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        if params:
            log_labels.update(params)
        yield log_labels

    def register_node(self, node_endpoint: str, capability_name: str, node_configurations):
        """
        Register the node.
        """
        try:
            service_name = f"capability-{capability_name}"
            node_address, node_port = node_endpoint.split(":")
            node_port_int = int(node_port)
            self._registration_info = {
                "node_endpoint": node_endpoint,
                "capability_name": capability_name,
                "node_configurations": node_configurations,
                "service_name": service_name,
                "node_address": node_address,
                "node_port": node_port_int
            }
            if self.consul is None:
                consul_address, consul_port = self.consul_url.split(":")
                self.consul = consul.Consul(host=consul_address, port=int(consul_port), token=self.token)
            meta = self._build_meta(node_configurations)
            self._LOG.info(f"Registering node '{service_name}' with Consul")
            success = self.consul.agent.service.register(
                name=service_name,
                address=node_address,
                port=node_port_int,
                check=consul.Check.tcp(
                    node_address,
                    node_port_int,
                    interval="10s",
                    timeout="5s",
                    deregister="1m"
                ),
                meta=meta
            )
            self._store_configurations_in_kv(service_name, node_configurations)
            if success:
                self._LOG.info(f"Registered instance {service_name} for capability '{service_name}'")
                self._start_health_check_monitoring()
                return success
            else:
                raise Exception("Failed to register instance service_name")
        except Exception as e:
            self._LOG.error(f"Failed to initialize node {e}")
            self._start_health_check_monitoring()
            raise e

    def _do_register(self, service_name: str, node_address: str, node_port: int, node_configurations) -> bool:
        """Perform the actual registration with Consul (used for re-registration)."""
        try:
            if self.consul is None:
                consul_address, consul_port = self.consul_url.split(":")
                self.consul = consul.Consul(host=consul_address, port=int(consul_port), token=self.token)
            success = self.consul.agent.service.register(
                name=service_name,
                address=node_address,
                port=node_port,
                check=consul.Check.tcp(
                    node_address,
                    node_port,
                    interval="10s",
                    timeout="5s",
                    deregister="1m"
                ),
                meta=self._build_meta(node_configurations)
            )
            if success:
                self._store_configurations_in_kv(service_name, node_configurations)
            return success
        except Exception as e:
            self._LOG.warning(f"Registration attempt failed: {e}")
            return False

    def _start_health_check_monitoring(self):
        """Start background thread to monitor registration health."""
        if self._health_check_thread and self._health_check_thread.is_alive():
            return
        self._stop_event.clear()
        self._should_monitor = True
        self._health_check_thread = threading.Thread(
            target=self._health_check_worker,
            daemon=True,
            name="ConsulHealthCheck"
        )
        self._health_check_thread.start()
        self._LOG.info("Started Consul health check monitoring")

    def _health_check_worker(self):
        """Background worker that periodically checks if node is registered in Consul."""
        while self._should_monitor and not self._stop_event.is_set():
            try:
                if self._stop_event.wait(self._health_check_interval):
                    break
                if not self._registration_info:
                    continue
                is_registered = self._check_service_registered(
                    self._registration_info["service_name"]
                )
                if not is_registered:
                    self._LOG.warning(
                        f"Service {self._registration_info['service_name']} not found in Consul. "
                        "Attempting to re-register..."
                    )
                    self._attempt_re_register()
                else:
                    self._reconnect_delay = 5
            except Exception as e:
                self._LOG.error(f"Error in health check worker: {e}")
                if self._registration_info:
                    self._attempt_re_register()

    def _check_service_registered(self, service_name: str) -> bool:
        """Check if the service is currently registered in Consul."""
        try:
            if self.consul is None:
                consul_address, consul_port = self.consul_url.split(":")
                self.consul = consul.Consul(host=consul_address, port=int(consul_port), token=self.token)
            services = self.consul.agent.services()
            return service_name in services
        except Exception as e:
            self._LOG.warning("Error checking service registration: %s", e)
            return False

    def _attempt_re_register(self):
        """Attempt to re-register the node with exponential backoff."""
        if not self._registration_info:
            return
        try:
            info = self._registration_info
            success = self._do_register(
                info["service_name"],
                info["node_address"],
                info["node_port"],
                info["node_configurations"]
            )
            if success:
                self._LOG.info(
                    f"Successfully re-registered service {info['service_name']} with Consul"
                )
                self._reconnect_delay = 5
            else:
                self._LOG.warning(
                    f"Re-registration failed. Will retry in {self._reconnect_delay} seconds"
                )
                time.sleep(self._reconnect_delay)
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    self._max_reconnect_delay
                )
        except Exception as e:
            self._LOG.error(f"Error during re-registration attempt: {e}")
            time.sleep(self._reconnect_delay)
            self._reconnect_delay = min(
                self._reconnect_delay * 2,
                self._max_reconnect_delay
            )

    def stop_monitoring(self):
        """Stop the health check monitoring thread."""
        self._should_monitor = False
        self._stop_event.set()
        if self._health_check_thread and self._health_check_thread.is_alive():
            self._health_check_thread.join(timeout=5)
        self._LOG.info("Stopped Consul health check monitoring")

    def unregister_node(self, context: ExecutionContext):
        """
        Unregister the node.
        """
        self.stop_monitoring()
        if self._registration_info:
            try:
                service_name = self._registration_info["service_name"]
                self.consul.agent.service.deregister(service_name)
                self._LOG.info(f"Deregistered service {service_name} from Consul")
            except Exception as e:
                self._LOG.error(f"Error deregistering service: {e}")
        raise NotImplementedError("Unregister node is not implemented")

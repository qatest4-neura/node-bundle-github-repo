"""
HTTP server implementation for Neuraverse Node Service using FastAPI
"""
import inject
from fastapi import APIRouter


from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.controllers.node_controller import NodeController

nodeRouter = APIRouter(tags=["Node SDK API"])
# nodeRouter.prefix = "/"

_LOG: Logger = LoggerFactory.get_logger("service.api.http.node-engine")

def inject_node_controller() -> NodeController:
    return inject.instance(NodeController)

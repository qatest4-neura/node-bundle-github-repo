from datetime import datetime

import inject
import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from neuraverse_common.http.fastapi.base_middleware import BaseNeuraFastAPIMiddleware
from neuraverse_common.http.fastapi.error_handler import get_neura_exception_handler
from neuraverse_common.http.model.config_source.HttpConfig import HttpConfig
from neuraverse_common.models.config.config_source.LogConfig import LogConfig

from neuraverse_sdk.api.http.admin import build_admin_router
from neuraverse_sdk.api.http.router.node_router import nodeRouter

app = FastAPI(
    title="Neuraverse Node SDK Service",
    description="HTTP API for Neuraverse Node SDK Service",
    docs_url=None,
    openapi_url=None,
)


@app.get("/", include_in_schema=False)
def default_index():
    """
    Returns a simple HTML page indicating the service is running.
    """
    now = datetime.now().isoformat(timespec="seconds")
    return HTMLResponse(f"<h1>pong - you reached node sdk web service!</h1>" f"<p>on {now}</p>")


# Include node-sdk-related routes
app.include_router(nodeRouter)  # TODO: Add prefix

# Admin REST API ("nodectl") — auth via existing Auth0 JWT, authorization
# via local YAML allowlist (see neuraverse_sdk.api.http.admin).  Inherited
# by every node template that uses the SDK's HTTP server.
app.include_router(build_admin_router())

# Register the exception handler for any Exception
app.add_exception_handler(Exception, get_neura_exception_handler())

# Middleware to handle non-existent paths as 400 Bad Request
BaseNeuraFastAPIMiddleware(app=app)


async def serve_http():
    """
    Start the FastAPI HTTP server.

    This function retrieves the HTTP configuration using dependency injection
    and starts the FastAPI server with the specified settings.
    """
    http_config = inject.instance(HttpConfig)
    log_config = inject.instance(LogConfig)
    config = uvicorn.Config(
        app,
        host=http_config.address,
        port=http_config.port,
        root_path=http_config.root_path,
        # log_level="info",
        log_config=log_config.ENVVAR_LOG_CFG_PATH,
        reload=True,
    )

    server = uvicorn.Server(config)
    await server.serve()

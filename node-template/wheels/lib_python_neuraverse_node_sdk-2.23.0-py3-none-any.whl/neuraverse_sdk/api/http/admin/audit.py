"""Structured audit log for admin REST API calls.

One ``nodectl.audit`` event per admin call.  Uses stdlib ``logging``
directly (rather than the LoggerFactory wrapper) so the structured fields
land as ``LogRecord`` attributes via ``extra=`` — callable formatters,
test capture (``caplog``), and ops sinks all read from the same place.
The dedicated logger name keeps the audit stream filterable in any
handler config.
"""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from typing import Any

AUDIT_LOGGER_NAME = "nodectl.audit"

_LOG = logging.getLogger(AUDIT_LOGGER_NAME)


def emit(
    *,
    actor: str,
    op: str,
    target: str | None = None,
    outcome: str,
    latency_ms: float | None = None,
    source_ip: str | None = None,
    request_id: str | None = None,
    args: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    """Write a single audit line.

    ``args`` should already be sanitized — never pass tokens, raw bodies, or
    anything sensitive.  The audit stream is stored alongside ordinary logs
    and may be retained longer / shipped to a different index.
    """
    payload: dict[str, Any] = {
        "audit": True,
        "actor": actor,
        "op": op,
        "outcome": outcome,
    }
    if target is not None:
        payload["target"] = target
    if latency_ms is not None:
        payload["latency_ms"] = round(latency_ms, 2)
    if source_ip is not None:
        payload["source_ip"] = source_ip
    if request_id is not None:
        payload["request_id"] = request_id
    if args:
        payload["args"] = args
    if error is not None:
        payload["error"] = error
    _LOG.info("admin %s %s -> %s", op, target or "-", outcome, extra=payload)


@contextmanager
def record(
    *,
    actor: str,
    op: str,
    target: str | None = None,
    source_ip: str | None = None,
    request_id: str | None = None,
    args: dict[str, Any] | None = None,
):
    """Context manager that emits a single audit line on exit, with latency
    and outcome derived from whether the body raised.

    Use::

        with audit.record(actor=user.identity, op="nodes.restart_soft", target=node_id):
            do_work()
    """
    t0 = time.monotonic()
    error: str | None = None
    outcome = "ok"
    try:
        yield
    except Exception as exc:
        outcome = "error"
        error = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        emit(
            actor=actor,
            op=op,
            target=target,
            outcome=outcome,
            latency_ms=(time.monotonic() - t0) * 1000,
            source_ip=source_ip,
            request_id=request_id,
            args=args,
            error=error,
        )

"""Admin REST API for node containers (delivered via the SDK).

Same shape as the proxy and engine admin modules — Auth0 JWT proves
identity, a local YAML allowlist (``/etc/neuraverse/admin_allowlist.yaml``
by default) decides who has which scope.  Every node template inherits
the surface for free.
"""

from neuraverse_sdk.api.http.admin.allowlist import AdminAllowlist, AdminUser
from neuraverse_sdk.api.http.admin.dependencies import RequireAdmin
from neuraverse_sdk.api.http.admin.router import build_admin_router

__all__ = [
    "AdminAllowlist",
    "AdminUser",
    "RequireAdmin",
    "build_admin_router",
]

"""YAML-backed admin allowlist.

The list lives in a ConfigMap mounted into the pod (default path
``/etc/neuraverse/admin_allowlist.yaml``).  We keep auth completely outside
Auth0 because we cannot register new APIs/permissions in the tenant — the
JWT only proves identity, this file decides whether that identity has any
admin power.

Schema:

    admins:
      - sub: "auth0|abc123"          # match by Auth0 sub (preferred, stable)
        email: alice@example.com    # match by email (fallback, mutable)
        scopes: [read, write]       # subset of {read, write, destructive}

Reload semantics: parsed once at startup, re-parsed on SIGHUP.  Edge nodes
that lose connectivity keep using the in-memory copy — there's no remote
fetch in the validation path.
"""

from __future__ import annotations

import os
import signal
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import yaml

from neuraverse_common.observability.logging import Logger, LoggerFactory

DEFAULT_ALLOWLIST_PATH = "/etc/neuraverse/admin_allowlist.yaml"
ALLOWLIST_PATH_ENV = "NEURAVERSE_ADMIN_ALLOWLIST_PATH"

VALID_SCOPES = frozenset({"read", "write", "destructive"})


@dataclass(frozen=True)
class AdminUser:
    """A resolved admin entry — either matched the JWT's sub or its email."""

    sub: str | None
    email: str | None
    scopes: frozenset[str] = field(default_factory=frozenset)

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes

    @property
    def identity(self) -> str:
        """Stable label for audit logs — prefer sub, fall back to email."""
        return self.sub or self.email or "<unknown>"


class AdminAllowlist:
    """Loads + reloads the admin allowlist YAML.

    Thread-safe for the read path: ``check()`` only touches an immutable
    snapshot that ``_reload()`` swaps in atomically.
    """

    _LOG: Logger = LoggerFactory.get_logger("nodectl.admin.allowlist")

    def __init__(self, path: str | None = None, *, install_sighup: bool = True):
        self._path = Path(path or os.environ.get(ALLOWLIST_PATH_ENV, DEFAULT_ALLOWLIST_PATH))
        self._lock = threading.Lock()
        self._by_sub: dict[str, AdminUser] = {}
        self._by_email: dict[str, AdminUser] = {}
        self._reload()
        if install_sighup:
            self._install_sighup_handler()

    @property
    def path(self) -> Path:
        return self._path

    def __len__(self) -> int:
        with self._lock:
            return len(self._by_sub) + sum(
                1 for email in self._by_email if self._by_email[email].sub is None
            )

    def check(self, *, sub: str | None, email: str | None, scope: str) -> AdminUser | None:
        """Return the admin entry if (sub OR email) is listed and has ``scope``,
        otherwise ``None``.  Match-by-sub wins over match-by-email."""
        if scope not in VALID_SCOPES:
            raise ValueError(f"unknown scope: {scope!r}")
        with self._lock:
            user: AdminUser | None = None
            if sub and sub in self._by_sub:
                user = self._by_sub[sub]
            elif email and email.lower() in self._by_email:
                user = self._by_email[email.lower()]
        if user is None:
            return None
        return user if user.has_scope(scope) else None

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def reload(self) -> None:
        """Public entrypoint; same as the SIGHUP handler."""
        self._reload()

    def _reload(self) -> None:
        try:
            entries = self._parse_file(self._path)
        except FileNotFoundError:
            self._LOG.warning(
                "Admin allowlist %s not found — admin API will reject everyone",
                self._path,
            )
            entries = []
        except Exception as exc:
            # On parse error keep the existing snapshot rather than locking
            # everyone out — better to serve a stale-but-valid roster than
            # silently disable admin access.
            self._LOG.error(
                "Admin allowlist %s failed to parse — keeping previous snapshot: %s",
                self._path,
                exc,
            )
            return

        by_sub: dict[str, AdminUser] = {}
        by_email: dict[str, AdminUser] = {}
        for entry in entries:
            if entry.sub:
                by_sub[entry.sub] = entry
            if entry.email:
                by_email[entry.email.lower()] = entry

        with self._lock:
            self._by_sub = by_sub
            self._by_email = by_email
        self._LOG.info(
            "Admin allowlist loaded: %d entries (path=%s)",
            len(entries),
            self._path,
        )

    @staticmethod
    def _parse_file(path: Path) -> list[AdminUser]:
        with path.open("r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        admins = raw.get("admins") or []
        if not isinstance(admins, list):
            raise ValueError("`admins` must be a list")

        result: list[AdminUser] = []
        for idx, item in enumerate(admins):
            if not isinstance(item, dict):
                raise ValueError(f"entry #{idx} is not a mapping")
            sub = item.get("sub")
            email = item.get("email")
            if not sub and not email:
                raise ValueError(f"entry #{idx} needs at least `sub` or `email`")
            scopes = item.get("scopes") or []
            if not isinstance(scopes, Iterable) or isinstance(scopes, (str, bytes)):
                raise ValueError(f"entry #{idx}: `scopes` must be a list")
            scope_set = frozenset(str(s) for s in scopes)
            unknown = scope_set - VALID_SCOPES
            if unknown:
                raise ValueError(
                    f"entry #{idx}: unknown scopes {sorted(unknown)} "
                    f"(valid: {sorted(VALID_SCOPES)})"
                )
            result.append(
                AdminUser(
                    sub=str(sub) if sub else None,
                    email=str(email) if email else None,
                    scopes=scope_set,
                )
            )
        return result

    def _install_sighup_handler(self) -> None:
        try:
            existing = signal.getsignal(signal.SIGHUP)

            def _handler(signum, frame):
                self._LOG.info("SIGHUP received — reloading admin allowlist")
                try:
                    self._reload()
                except Exception as exc:
                    self._LOG.error("allowlist reload failed: %s", exc)
                # Chain to any pre-existing handler so we don't shadow other
                # SIGHUP consumers in the process.
                if callable(existing) and existing not in (signal.SIG_DFL, signal.SIG_IGN):
                    existing(signum, frame)

            signal.signal(signal.SIGHUP, _handler)
        except (ValueError, OSError) as exc:
            # Non-main thread or platform without SIGHUP — silently skip; the
            # process can still call ``reload()`` programmatically.
            self._LOG.debug("SIGHUP handler not installed: %s", exc)

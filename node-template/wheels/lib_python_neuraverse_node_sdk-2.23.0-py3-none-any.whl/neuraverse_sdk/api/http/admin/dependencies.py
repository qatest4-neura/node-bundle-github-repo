"""FastAPI dependencies for per-node admin endpoints.

Mirrors the proxy and engine ``RequireAdmin`` shape: chain
``JWTAuthValidator`` (signature / issuer / audience / expiry) and then
check the local YAML allowlist for the requested scope.  Same UX so an
operator can hit any admin layer without re-learning the auth model.
"""

from __future__ import annotations

import inject
from fastapi import Depends
from neuraverse_common.http.auth.jwt_dependencies import JWTAuthValidator
from neuraverse_common.models.error import errors_v2

from neuraverse_sdk.api.http.admin.allowlist import AdminAllowlist, AdminUser

EMAIL_CLAIM = "https://neuraverse.com/email"
EMAIL_FALLBACK_CLAIM = "email"
SUB_CLAIM = "sub"


def _resolve_email(claims: dict) -> str | None:
    val = claims.get(EMAIL_CLAIM) or claims.get(EMAIL_FALLBACK_CLAIM)
    return str(val) if val else None


def _resolve_sub(claims: dict) -> str | None:
    val = claims.get(SUB_CLAIM)
    return str(val) if val else None


class RequireAdmin:
    """``Depends(RequireAdmin("read"))`` for every admin route."""

    def __init__(self, scope: str):
        self._scope = scope
        self._jwt_dep = JWTAuthValidator()

    def __call__(
        self,
        claims: dict = Depends(JWTAuthValidator()),
    ) -> AdminUser:
        sub = _resolve_sub(claims)
        email = _resolve_email(claims)
        allowlist = inject.instance(AdminAllowlist)
        admin = allowlist.check(sub=sub, email=email, scope=self._scope)
        if admin is None:
            # Echo the requester's own identity back so they can self-
            # diagnose.  Auth0 access tokens in dev/prod tenants don't
            # carry email by default — most allowlist mismatches are
            # "my sub isn't listed yet".
            identity = sub or email or "<no sub or email in token>"
            raise errors_v2.NeuraPublicAuthorizationError(
                message=(
                    f"Admin permission required (scope={self._scope!r}). "
                    f"Token identity: sub={sub!r}, email={email!r}. "
                    f"Add {identity!r} to the admin allowlist with the "
                    f"{self._scope!r} scope."
                )
            )
        return admin

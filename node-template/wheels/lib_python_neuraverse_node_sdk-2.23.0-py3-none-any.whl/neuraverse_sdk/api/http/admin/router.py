"""Admin REST router for the Neuraverse Node SDK.

Inherited by every node container that uses the SDK — no per-node-template
wiring.  Read-only surface for v1; mutators (``restart-soft``,
``log-level``) land with Step 6 of the admin-API plan and reuse the same
auth + allowlist pipeline.

Operationally this is the fallback path for when the engine can't reach a
specific node (the engine→node hop is dynamic per node graph and not
guaranteed).  The CLI flow is identical to engine-mediated access; only
the URL changes.
"""

from __future__ import annotations

import time
from typing import Any, Optional

import inject
from fastapi import APIRouter, Depends, Request
from neuraverse.models.v1.gen.business.node_graph_pb2 import ExecutionState
from neuraverse_common.models.config.service_info import ServiceInfo
from neuraverse_common.models.error import errors_v2

from neuraverse_sdk.api.http.admin import audit
from neuraverse_sdk.api.http.admin.allowlist import AdminUser
from neuraverse_sdk.api.http.admin.dependencies import RequireAdmin
from neuraverse_sdk.controllers.node_controller import NodeController

ADMIN_PREFIX = "/admin"


def _source_ip(request: Request) -> Optional[str]:
    return request.client.host if request.client else None


# ---------------------------------------------------------------------------
# State helpers — pure, exception-safe so a wedged node instance can't
# 500 the entire admin surface.
# ---------------------------------------------------------------------------


def _state_name(state: int) -> str:
    """Map ExecutionState enum int to its short string ('RUNNING', 'IDLE', ...)."""
    try:
        full = ExecutionState.Name(state)
    except Exception:
        return "UNKNOWN"
    prefix = "EXECUTION_STATE_"
    return full[len(prefix):] if full.startswith(prefix) else full


def _list_bound_instances(controller: NodeController) -> list[dict]:
    """Walk the NodesRegistry and return one row per *bound* node instance.

    Instances are added to the registry at SDK init with ``node_id=None``;
    they only get a real id after the engine sends ``InitializeNode``.
    Unbound entries are skipped from the list — they aren't yet a node
    in the operational sense.
    """
    rows: list[dict] = []
    registry = controller.nodes_registry.current_nodes_instances_registry
    for node_class, instances in registry.items():
        for instance, node_id in instances:
            if node_id is None:
                continue
            try:
                state = instance.state_machine.get_state()
                state_str = _state_name(state)
            except Exception:
                state_str = "UNKNOWN"
            rows.append(
                {
                    "node_id": node_id,
                    "class_name": node_class.__name__,
                    "state": state_str,
                }
            )
    rows.sort(key=lambda r: r["node_id"])
    return rows


def _find_instance(controller: NodeController, node_id: str):
    """Return ``(instance, class_name)`` for ``node_id`` or ``None`` if unbound.

    Class name comes from the registry key (the registered node class) rather
    than ``type(instance).__name__`` so it's consistent with what
    ``_list_bound_instances`` reports — single source of truth.
    """
    registry = controller.nodes_registry.current_nodes_instances_registry
    for node_class, instances in registry.items():
        for instance, bound_id in instances:
            if bound_id == node_id:
                return instance, node_class.__name__
    return None


def _last_status_for_node(controller: NodeController, node_id: str) -> Optional[dict]:
    """Most recent status entry recorded by ``_record_last_status_snapshot``."""
    with controller._last_status_lock:
        snapshot = controller._last_status_by_node_id.get(node_id)
    if snapshot is None:
        return None
    # Only echo back the small/safe subset — the snapshot can contain proto
    # messages and other stuff that doesn't json-serialize cleanly.
    return {
        "result_code": snapshot.get("resultCode"),
        "result_message": snapshot.get("resultMessage"),
        "state": snapshot.get("state"),
    }


def _topic_summary(instance) -> dict[str, Any]:
    """Return port → topic_name maps for inputs and outputs.

    Both calls are best-effort; a node in early lifecycle may not have
    them populated, in which case we return empty maps rather than 500.
    """
    inputs: dict[str, str] = {}
    outputs: dict[str, str] = {}
    try:
        for port_name, port_info in (instance.get_input_topics() or {}).items():
            topic = (
                port_info.get("topic_name")
                if isinstance(port_info, dict)
                else getattr(port_info, "topic_name", None)
            )
            if topic:
                inputs[port_name] = topic
    except Exception:
        pass
    try:
        for port_name, port_info in (instance.get_output_topics() or {}).items():
            topic = (
                port_info.get("topic_name")
                if isinstance(port_info, dict)
                else getattr(port_info, "topic_name", None)
            )
            if topic:
                outputs[port_name] = topic
    except Exception:
        pass
    return {"inputs": inputs, "outputs": outputs}


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------


def build_admin_router() -> APIRouter:
    router = APIRouter(prefix=ADMIN_PREFIX, tags=["admin"])

    # ------------------------------------------------------------------
    # /admin/whoami
    # ------------------------------------------------------------------
    @router.get("/whoami")
    def whoami(
        request: Request,
        admin: AdminUser = Depends(RequireAdmin("read")),
    ) -> dict:
        with audit.record(
            actor=admin.identity, op="admin.whoami", source_ip=_source_ip(request)
        ):
            return {
                "sub": admin.sub,
                "email": admin.email,
                "scopes": sorted(admin.scopes),
            }

    # ------------------------------------------------------------------
    # /admin/node/status — process-level summary for this container.
    # ------------------------------------------------------------------
    @router.get("/node/status")
    def node_status(
        request: Request,
        admin: AdminUser = Depends(RequireAdmin("read")),
    ) -> dict:
        controller = inject.instance(NodeController)
        service_info = inject.instance(ServiceInfo)
        uptime = max(0.0, time.monotonic() - controller._start_time_monotonic)
        bound = _list_bound_instances(controller)
        # Registered classes — useful even when nothing is bound yet (helps
        # answer "is this image the right node template?" before init).
        classes = sorted(
            cls.__name__
            for cls in controller.nodes_registry.current_nodes_instances_registry
        )
        with audit.record(
            actor=admin.identity, op="admin.node.status", source_ip=_source_ip(request)
        ):
            return {
                "service_name": service_info.get_service_name(),
                "uptime_seconds": round(uptime, 2),
                "registered_classes": classes,
                "bound_instances": len(bound),
            }

    # ------------------------------------------------------------------
    # /admin/nodes — list bound instances on this container.
    # ------------------------------------------------------------------
    @router.get("/nodes")
    def nodes_list(
        request: Request,
        admin: AdminUser = Depends(RequireAdmin("read")),
    ) -> dict:
        controller = inject.instance(NodeController)
        rows = _list_bound_instances(controller)
        with audit.record(
            actor=admin.identity,
            op="admin.nodes.list",
            source_ip=_source_ip(request),
            args={"count": len(rows)},
        ):
            return {"nodes": rows}

    # ------------------------------------------------------------------
    # /admin/nodes/{node_id}/state
    # ------------------------------------------------------------------
    @router.get("/nodes/{node_id}/state")
    def node_state(
        request: Request,
        node_id: str,
        admin: AdminUser = Depends(RequireAdmin("read")),
    ) -> dict:
        controller = inject.instance(NodeController)
        found = _find_instance(controller, node_id)
        if found is None:
            raise errors_v2.NeuraPublicResourceNotFoundError(
                message=f"No node with id {node_id!r} on this container."
            )
        instance, class_name = found
        try:
            state_str = _state_name(instance.state_machine.get_state())
        except Exception:
            state_str = "UNKNOWN"
        with audit.record(
            actor=admin.identity,
            op="admin.nodes.state",
            source_ip=_source_ip(request),
            target=node_id,
        ):
            return {
                "node_id": node_id,
                "class_name": class_name,
                "state": state_str,
            }

    # ------------------------------------------------------------------
    # /admin/nodes/{node_id}/diag
    # ------------------------------------------------------------------
    @router.get("/nodes/{node_id}/diag")
    def node_diag(
        request: Request,
        node_id: str,
        admin: AdminUser = Depends(RequireAdmin("read")),
    ) -> dict:
        controller = inject.instance(NodeController)
        found = _find_instance(controller, node_id)
        if found is None:
            raise errors_v2.NeuraPublicResourceNotFoundError(
                message=f"No node with id {node_id!r} on this container."
            )
        instance, class_name = found
        try:
            state_str = _state_name(instance.state_machine.get_state())
        except Exception:
            state_str = "UNKNOWN"
        with audit.record(
            actor=admin.identity,
            op="admin.nodes.diag",
            source_ip=_source_ip(request),
            target=node_id,
        ):
            return {
                "node_id": node_id,
                "class_name": class_name,
                "state": state_str,
                "last_status": _last_status_for_node(controller, node_id),
                "topics": _topic_summary(instance),
            }

    return router

import grpc
from typing import Dict, List, Optional, Sequence

from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse.api.scene_builder_backend.v1.gen.scene_builder_api_pb2 import ListFramesRequest, ListFramesResponse
from neuraverse.api.scene_builder_backend.v1.gen.scene_builder_api_pb2_grpc import SceneBuilderServiceStub
from neuraverse_sdk.utils.proto_helper import proto_to_dict

class SceneBuilderClient:
    def __init__(self) -> None:
        """
        Initialize the SceneBuilderClient.
        """
        self.endpoint: str = ""
        self._LOG: Logger = LoggerFactory.get_logger(f"service.api.grpc.clients.{self.__class__.__name__}")

    def init(self, endpoint: str):
        self.endpoint = endpoint
        self.channel: grpc.Channel = grpc.secure_channel(self.endpoint, grpc.ssl_channel_credentials())
        self.stub: SceneBuilderServiceStub = SceneBuilderServiceStub(self.channel)
        self._LOG.info("SceneBuilderClient initialized")

    def list_frames(
        self,
        project_id: str,
        metadata_filter: Optional[Dict] = None,
        sources: Optional[Sequence[int]] = None,
    ) -> List[Dict]:
        """
        List the frames for a given project.

        Args:
            project_id: Scene project to query.
            metadata_filter: If set, only frames whose metadata contains all given
                key-value pairs are returned (after the server responds).
            sources: If non-empty, only frames whose ``Frame.source`` matches at least
                one of these enum *values* (ints) are returned by the server (OR semantics):
                0 UNSPECIFIED, 1 PATH, 2 ROBOT, 3 SENSOR, 4 MODEL (see ``FrameSource`` proto).
                If None or empty, all frame sources are requested (backward compatible).
        """
        try:
            request = ListFramesRequest(project_id=project_id)
            if sources:
                request.sources.extend(sources)

            response: ListFramesResponse = self.stub.ListFrames(request)
            frames = [proto_to_dict(frame) for frame in response.frames]

            if metadata_filter:
                filtered_frames = []
                for frame in frames:
                    frame_metadata = frame.get("metadata", {})
                    if all(
                        frame_metadata.get(key) == value
                        for key, value in metadata_filter.items()
                    ):
                        filtered_frames.append(frame)
                frames = filtered_frames

            self._LOG.debug(f"Retrieved {len(frames)} frames for project {project_id}")
            return frames
        except Exception as e:
            self._LOG.error(f"Error listing frames for project {project_id}: {e}")
            raise e

    def close(self) -> None:
        """
        Close the SceneBuilderClient.
        """
        self._LOG.info("Closing SceneBuilderClient")
        try:
            if hasattr(self, "channel") and self.channel:
                self.channel.close()
        except Exception as e:
            self._LOG.error(f"Error closing SceneBuilderClient: {e}")
            raise e

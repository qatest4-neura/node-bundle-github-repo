from __future__ import annotations

import threading
from collections.abc import Callable
from enum import Enum
from typing import Any

import zenoh
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_sdk.models.config.zenoh_config import ZenohConfig
from neuraverse_sdk.utils.exceptions import TriggerFlowException


class ConnectionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTED = "connected"
    ERROR = "error"


class ZenohHandler:
    """Thread-safe Zenoh session wrapper for the Neuraverse Node SDK."""

    def __init__(self) -> None:
        self._session: zenoh.Session | None = None
        self._config: ZenohConfig | None = None
        self._connection_state = ConnectionState.DISCONNECTED
        self._subscribers: dict[str, Any] = {}
        self._message_callbacks: dict[str, Callable[[bytes], None]] = {}
        self._lock = threading.Lock()
        self._logger: Logger = LoggerFactory.get_logger("service.utils.zenoh_singleton")

    def configure(self, config: ZenohConfig) -> None:
        """Store Zenoh configuration."""
        with self._lock:
            self._config = config
            self._logger.info(
                "ZenohHandler configured: locator=%s mode=%s",
                config.locator,
                config.mode,
            )

    def connect(self, blocking: bool = False, timeout: float = 10.0) -> bool:
        """Open a Zenoh session."""
        if not self._config:
            raise TriggerFlowException("ZenohHandler not configured. Call configure() first.")
        with self._lock:
            if self._connection_state == ConnectionState.CONNECTED:
                self._logger.info("ZenohHandler: already connected")
                return True
            try:
                conf = zenoh.Config()
                conf.insert_json5("mode", f'"{self._config.mode}"')
                conf.insert_json5("connect/endpoints", f'["{self._config.locator}"]')
                self._session = zenoh.open(conf)
                self._connection_state = ConnectionState.CONNECTED
                self._logger.info(
                    "ZenohHandler: connected to %s (mode=%s)",
                    self._config.locator,
                    self._config.mode,
                )
                return True
            except Exception as e:
                self._connection_state = ConnectionState.ERROR
                self._logger.error("ZenohHandler: failed to open session: %s", e)
                return False

    def disconnect(self) -> None:
        """Undeclare all subscribers and close the Zenoh session."""
        with self._lock:
            if self._connection_state != ConnectionState.CONNECTED:
                return
            for key_expr, sub in self._subscribers.items():
                try:
                    sub.undeclare()
                except Exception as e:
                    self._logger.warning(
                        "ZenohHandler: error undeclaring subscriber for %s: %s",
                        key_expr,
                        e,
                    )
            self._subscribers.clear()
            self._message_callbacks.clear()
            try:
                if self._session is not None:
                    self._session.close()
            except Exception as e:
                self._logger.warning("ZenohHandler: error closing session: %s", e)
            self._session = None
            self._connection_state = ConnectionState.DISCONNECTED
            self._logger.info("ZenohHandler: disconnected")

    def publish(self, key_expr: str, payload: Any, qos: int | None = None) -> bool:
        """Put a message on the given key expression."""
        if not self._is_connected():
            self._logger.warning("ZenohHandler: cannot publish to %s: not connected", key_expr)
            return False
        try:
            encoded = payload.encode() if isinstance(payload, str) else payload
            if self._session is None:
                self._logger.warning(
                    "ZenohHandler: cannot publish to %s: no active session", key_expr
                )
                return False
            self._session.put(key_expr, encoded)
            return True
        except Exception as e:
            self._logger.error("ZenohHandler: error publishing to %s: %s", key_expr, e)
            return False

    def add_topic(
        self,
        key_expr: str,
        callback: Callable | None = None,
        qos: int | None = None,
    ) -> bool:
        """Declare a Zenoh subscriber for the given key expression."""
        if not self._is_connected():
            self._logger.warning("ZenohHandler: cannot subscribe to %s: not connected", key_expr)
            return False
        try:

            def _handler(sample: zenoh.Sample) -> None:
                raw = bytes(sample.payload)
                if callback:
                    callback(raw)

            with self._lock:
                if key_expr in self._subscribers:
                    self._subscribers[key_expr].undeclare()
                if self._session is None:
                    self._logger.warning(
                        "ZenohHandler: cannot subscribe to %s: no active session", key_expr
                    )
                    return False
                sub = self._session.declare_subscriber(key_expr, _handler)
                self._subscribers[key_expr] = sub
                if callback:
                    self._message_callbacks[key_expr] = callback

            self._logger.info("ZenohHandler: subscribed to key_expr=%s", key_expr)
            return True
        except Exception as e:
            self._logger.error("ZenohHandler: error subscribing to %s: %s", key_expr, e)
            return False

    def subscribe(
        self,
        key_expr: str,
        callback: Callable | None = None,
        qos: int | None = None,
    ) -> bool:
        """Alias for add_topic — used by ZenohTriggerAdapter."""
        return self.add_topic(key_expr, callback, qos)

    def unsubscribe(self, key_expr: str) -> bool:
        """Undeclare the subscriber for the given key expression."""
        try:
            with self._lock:
                if key_expr not in self._subscribers:
                    self._logger.warning("ZenohHandler: no subscriber found for %s", key_expr)
                    return False
                self._subscribers[key_expr].undeclare()
                del self._subscribers[key_expr]
                self._message_callbacks.pop(key_expr, None)
            self._logger.info("ZenohHandler: unsubscribed from key_expr=%s", key_expr)
            return True
        except Exception as e:
            self._logger.error("ZenohHandler: error unsubscribing from %s: %s", key_expr, e)
            return False

    def get_topics(self) -> dict[str, Any]:
        """Return dict of currently subscribed key expressions."""
        with self._lock:
            return {
                key_expr: {"has_callback": key_expr in self._message_callbacks}
                for key_expr in self._subscribers
            }

    def is_connected(self) -> bool:
        """Public check: is the session open?"""
        return self._connection_state == ConnectionState.CONNECTED

    def _is_connected(self) -> bool:
        """Internal check: session open and not None."""
        return self._session is not None and self._connection_state == ConnectionState.CONNECTED

    def __del__(self) -> None:
        """Cleanup when handler is garbage-collected."""
        try:
            self.disconnect()
        except Exception:
            pass

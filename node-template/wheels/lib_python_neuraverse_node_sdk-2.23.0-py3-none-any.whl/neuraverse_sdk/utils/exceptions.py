"""
Exception classes for Neuraverse SDK
"""


class NodeSDKError(Exception):
    """Base exception for all Neuraverse SDK errors"""

    def __init__(self, message: str, error_code: str = "SDK_ERROR"):
        super().__init__(message)
        self.message: str = message
        self.error_code: str = error_code


class NodeConfigurationError(NodeSDKError):
    """Raised when there's an error in node configuration"""

    def __init__(self, message: str):
        super().__init__(message, "CONFIG_ERROR")


class NodeExecutionError(NodeSDKError):
    """Raised when there's an error during node execution"""

    def __init__(self, message: str):
        super().__init__(message, "EXECUTION_ERROR")


class NodeStopError(NodeSDKError):
    """Raised when there's an error during node stop"""

    def __init__(self, message: str):
        super().__init__(message, "STOP_ERROR")


class NodePauseError(NodeSDKError):
    """Raised when there's an error during node pause"""

    def __init__(self, message: str):
        super().__init__(message, "PAUSE_ERROR")


class NodeResumeError(NodeSDKError):
    """Raised when there's an error during node resume"""

    def __init__(self, message: str):
        super().__init__(message, "RESUME_ERROR")


class NodeNotFoundError(NodeSDKError):
    """Raised when a node is not found"""

    def __init__(self, message: str):
        super().__init__(message, "NODE_NOT_FOUND")


class InvalidEndpointError(NodeSDKError):
    """Raised when an endpoint is not found"""

    def __init__(self, message: str):
        super().__init__(message, "ENDPOINT_NOT_FOUND")


class NodeRegisteryError(NodeSDKError):
    """Raised when a node is not able to register"""

    def __init__(self, message: str):
        super().__init__(message, "NODE_REGISTRATION_ERROR")


class NodeStateError(NodeSDKError):
    """Raised when a node is in an invalid state for the requested operation"""

    def __init__(self, message: str):
        super().__init__(message, "INVALID_STATE")


class DataFlowException(NodeSDKError):
    """Raised when dataflow is not valid"""

    def __init__(self, message: str):
        super().__init__(message, "DATA_FLOW_ERROR")


class TriggerFlowException(NodeSDKError):
    """Raised when trigger flow is not valid"""

    def __init__(self, message: str):
        super().__init__(message, "TRIGGER_FLOW_ERROR")


class RobotException(NodeSDKError):
    """Raised when robot is in error"""

    def __init__(self, message: str):
        super().__init__(message, "ROBOT_ERROR")

class NodeSimulationModeError(NodeSDKError):
    """Raised when there's an error toggling simulation mode"""

    def __init__(self, message: str):
        super().__init__(message, "SIMULATION_MODE_ERROR")


class NodeHealthCheckError(NodeSDKError):
    """Raised when there's an error performing a health check"""

    def __init__(self, message: str):
        super().__init__(message, "HEALTH_CHECK_ERROR")

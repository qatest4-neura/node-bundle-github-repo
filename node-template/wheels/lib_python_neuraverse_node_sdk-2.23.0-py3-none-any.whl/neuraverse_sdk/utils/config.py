from neuraverse.models.v1.gen.business.node_graph_pb2 import NodeConfigEntry


def get_config_value(key: str, config, dynamic_config=None) -> str | None:
    """Read a config value preferring dynamic_config (typed) over config (plain strings).

    Args:
        key: Config key to read.
        config: Plain string ScalarMap (Node.configuration). Used as fallback.
        dynamic_config: Typed MessageMap (Node.dynamicConfiguration). Takes priority when present.

    Returns:
        The resolved string value, or None if not found in either source.
    """
    if dynamic_config is not None and key in dynamic_config:
        cv = dynamic_config[key].configValue
        try:
            which = cv.WhichOneof("value")
            if which == "stringValue":
                return cv.stringValue
            if which == "rangeValue":
                return str(cv.rangeValue.value)
            if which == "toggleValue":
                return str(cv.toggleValue.enabled).lower()
            if which == "singleSelectListValue":
                val = cv.singleSelectListValue.selectedItem
                if val:
                    return val
            elif which == "multiSelectListValue":
                items = cv.multiSelectListValue.selectedItems
                if items:
                    return items[0]
        except (ValueError, AttributeError):
            pass
    return config.get(key)

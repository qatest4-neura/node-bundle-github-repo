from google.protobuf.json_format import MessageToDict
from google.protobuf.message import Message


def proto_to_dict(proto_message: Message) -> dict:
    """
    Converts a protobuf message to a dictionary.
    """
    if isinstance(proto_message, Message):
        to_dic = MessageToDict(
            proto_message,
            preserving_proto_field_name=True,
            always_print_fields_with_no_presence=True,
        )
    return to_dic

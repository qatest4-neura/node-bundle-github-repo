from __future__ import annotations

import threading
from typing import Callable, TypeVar, cast

from neuraverse_common.observability.logging import Logger, LoggerFactory

T = TypeVar("T")


class ConnectionPool:
    """Thread-safe singleton connection pool."""

    _instance: ConnectionPool | None = None
    _instance_lock = threading.Lock()

    def __new__(cls) -> ConnectionPool:
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        self._connections: dict[str, object] = {}
        self._lock = threading.Lock()
        self._logger: Logger = LoggerFactory.get_logger("service.utils.connection_pool")

    def get_or_create(self, key: str, factory: Callable[[], T]) -> tuple[T, bool]:
        """Return existing connection or create a new one via factory."""
        with self._lock:
            existing = self._connections.get(key)
            if existing is not None:
                self._logger.info("Reusing pooled connection for %s", key)
                return cast(T, existing), False
            self._logger.info("Creating new pooled connection for %s", key)
            connection = factory()
            self._connections[key] = connection
            return connection, True

    def remove(self, key: str) -> None:
        with self._lock:
            self._connections.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._connections.clear()

import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

import paho.mqtt.client as mqtt
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.models.config.mqtt_config import MQTTConfig
from neuraverse_sdk.utils.exceptions import TriggerFlowException


class ConnectionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    ERROR = "error"


@dataclass(eq=False)
class Subscription:
    """Handle returned by MQTTHandler.subscribe().

    Callers keep this and pass it back to unsubscribe() to release just
    this subscription. Multiple subscriptions on the same topic fan out —
    every callback runs on every received message — and the broker-level
    SUBSCRIBE stays in place until the last handle for that topic is
    released. Equality is by identity (eq=False) so the same (topic, qos,
    callback) triple registered twice produces two distinct, independently
    cancellable handles.
    """

    topic: str
    qos: int
    callback: Callable[[Any], Any]
    # Set to True once unsubscribe() has accepted this handle; further
    # unsubscribe() calls on the same handle are no-ops.
    _cancelled: bool = field(default=False, repr=False, compare=False)


class MQTTHandler:
    """Process-wide singleton MQTT client for the Neuraverse Node Engine.

    Multiple adapters (dataflow, trigger) share a single TCP connection.
    connect() / disconnect() are refcounted so the underlying socket only
    opens on the first connect() and only closes after the matching
    disconnect() call — adapters can come and go without disrupting each
    other.

    Subscriptions are handle-based: subscribe(topic, callback) returns a
    Subscription token. Multiple subscriptions on the same topic fan out
    independently; unsubscribe(handle) releases just that one. The broker
    only sees one SUBSCRIBE per topic regardless of how many local
    callbacks are registered.
    """

    _instance: Optional["MQTTHandler"] = None
    _instance_lock = threading.Lock()

    def __new__(cls):
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        self._client: Optional[mqtt.Client] = None
        self._config: Optional[MQTTConfig] = None
        self._connection_state = ConnectionState.DISCONNECTED

        # Per-topic subscriber lists. One process-wide map so multiple
        # nodes can subscribe to the same producer topic and each receive
        # every message (topic fan-out).
        self._subscriptions: Dict[str, List[Subscription]] = {}

        self._logger: Logger = LoggerFactory.get_logger("service.utils.mqtt_singleton")
        self._client_lock = threading.Lock()
        self._connect_refs = 0

    def configure(self, config: MQTTConfig) -> None:
        """Configure the MQTT client. First call wins; subsequent calls with
        a compatible broker host/port are silently ignored so multiple
        adapters can call configure() without disrupting an in-use connection.
        """
        with self._client_lock:
            if self._client is not None:
                if (
                    self._config.broker_host != config.broker_host
                    or self._config.broker_port != config.broker_port
                ):
                    raise TriggerFlowException(
                        f"MQTTHandler already configured for "
                        f"{self._config.broker_host}:{self._config.broker_port}; "
                        f"refusing to reconfigure to "
                        f"{config.broker_host}:{config.broker_port}"
                    )
                self._logger.debug(
                    "MQTTHandler.configure called on already-configured singleton; ignoring"
                )
                return

            # Pin a unique client_id for the lifetime of the process so paho's
            # auto-reconnect keeps the same identity on every retry, and so
            # two node pods don't collide on the broker's client_id
            # uniqueness check (which would cause them to kick each other off
            # in a loop).
            if not config.client_id or config.client_id == "neuraverse_node":
                config.client_id = f"neuraverse_{uuid.uuid4().hex}"

            self._config = config

            self._client = mqtt.Client(
                client_id=config.client_id, clean_session=config.clean_session
            )

            # Use paho's default outgoing-queue settings (max_inflight=20,
            # max_queued=unlimited). Concurrent publishers across multiple
            # adapters in this process need parallel in-flight slots — a
            # lower cap would serialize their QoS-1 traffic. The "no
            # silent retry storm" property is upheld instead by
            # publish()'s _is_connected() guard at the application
            # boundary, combined with the NodeBase executor that keeps
            # paho's network thread responsive so keepalive timeouts
            # don't trigger disconnects in the first place.

            # Paho's built-in auto-reconnect with exponential backoff;
            # replaces the custom _reconnect_worker that used to race with it.
            self._client.reconnect_delay_set(
                min_delay=int(max(1, config.reconnect_delay_min)),
                max_delay=int(max(1, config.reconnect_delay_max)),
            )

            if config.username and config.password:
                self._client.username_pw_set(config.username, config.password)

            self._client.on_connect = self._on_connect
            self._client.on_disconnect = self._on_disconnect
            self._client.on_message = self._on_message
            self._client.on_subscribe = self._on_subscribe
            self._client.on_unsubscribe = self._on_unsubscribe

            self._logger.info(
                f"MQTT singleton configured for {config.broker_host}:{config.broker_port} "
                f"as client_id={config.client_id}"
            )

    def connect(self, blocking: bool = False, timeout: float = 10.0) -> bool:
        """Connect to the MQTT broker (refcounted).

        The first call opens the TCP connection and starts paho's network
        loop. Subsequent calls just bump the refcount and return
        immediately; the connection stays up until the matching number of
        disconnect() calls have been made.
        """
        if not self._config:
            raise TriggerFlowException(
                "MQTT client not configured. Call configure() first."
            )

        with self._client_lock:
            self._connect_refs += 1
            if self._connection_state == ConnectionState.CONNECTED:
                self._logger.debug(
                    f"MQTT singleton already connected (refs={self._connect_refs})"
                )
                return True

            try:
                self._connection_state = ConnectionState.CONNECTING

                self._client.connect_async(
                    self._config.broker_host,
                    self._config.broker_port,
                    self._config.keep_alive,
                )
                self._client.loop_start()

                if blocking:
                    start_time = time.time()
                    while (
                        self._connection_state == ConnectionState.CONNECTING
                        and time.time() - start_time < timeout
                    ):
                        time.sleep(0.1)
                    return self._connection_state == ConnectionState.CONNECTED

                return True

            except Exception as e:
                self._logger.error(f"Failed to connect to MQTT broker: {e}")
                self._connection_state = ConnectionState.ERROR
                self._connect_refs -= 1
                return False

    def disconnect(self) -> None:
        """Release one connect() refcount; only actually disconnect when the
        last user releases. Adapters can call disconnect() in their
        destroy() paths without dropping the connection for other
        still-alive adapters.
        """
        with self._client_lock:
            if self._connect_refs <= 0:
                self._logger.debug(
                    "MQTTHandler.disconnect called with no outstanding refs; ignoring"
                )
                return
            self._connect_refs -= 1
            if self._connect_refs > 0:
                self._logger.debug(
                    f"MQTT singleton still in use (refs={self._connect_refs}); not disconnecting"
                )
                return

            if self._client and self._connection_state != ConnectionState.DISCONNECTED:
                self._client.disconnect()
                self._client.loop_stop()
                self._connection_state = ConnectionState.DISCONNECTED
                self._logger.info("Disconnected from MQTT broker")

    def publish(
        self,
        topic: str,
        payload: Any,
        qos: Optional[int] = None,
        retain: Optional[bool] = None,
    ) -> bool:
        """Publish a message to a topic.

        Returns True if the message was handed to paho successfully, False
        if not (including when disconnected — see max_queued_messages_set(0)
        in configure() for why we want fail-fast publishes).
        """
        if not self._is_connected():
            self._logger.warning(f"Cannot publish to {topic}: not connected")
            return False

        try:
            qos = qos if qos is not None else self._config.qos
            retain = retain if retain is not None else self._config.retain

            if not isinstance(payload, (str, bytes, bytearray, int, float)):
                payload = str(payload)

            result = self._client.publish(topic, payload, qos, retain)

            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                return True
            else:
                self._logger.error(f"Failed to publish to {topic}: {result.rc}")
                return False

        except Exception as e:
            self._logger.error(f"Error publishing to {topic}: {e}")
            return False

    def subscribe(
        self,
        topic: str,
        callback: Callable[[Any], Any],
        qos: Optional[int] = None,
    ) -> Optional[Subscription]:
        """Register ``callback`` for messages on ``topic`` and return a
        Subscription handle the caller must keep to release it later.

        Multiple subscriptions on the same topic fan out: each callback is
        invoked on each received message. The broker-level SUBSCRIBE is
        sent only when the topic gains its first local subscriber (or its
        effective qos increases); it is removed only when the last
        subscriber for that topic unsubscribes.

        Returns None if the broker SUBSCRIBE call fails. Subscribing while
        disconnected is allowed — the handle is recorded and the broker
        SUBSCRIBE is issued from _on_connect.
        """
        if callback is None:
            raise ValueError("subscribe() requires a non-None callback")

        if qos is None:
            qos = self._config.qos if self._config else 1

        sub = Subscription(topic=topic, qos=qos, callback=callback)

        with self._client_lock:
            existing = self._subscriptions.get(topic, [])
            current_max_qos = max((s.qos for s in existing), default=-1)
            need_broker_call = (not existing) or qos > current_max_qos

            self._subscriptions.setdefault(topic, []).append(sub)

            if need_broker_call and self._is_connected():
                broker_qos = max(qos, current_max_qos) if existing else qos
                try:
                    result = self._client.subscribe(topic, broker_qos)
                except Exception as e:
                    self._subscriptions[topic].remove(sub)
                    if not self._subscriptions[topic]:
                        del self._subscriptions[topic]
                    self._logger.error(f"Error subscribing to {topic}: {e}")
                    return None
                if result[0] != mqtt.MQTT_ERR_SUCCESS:
                    self._subscriptions[topic].remove(sub)
                    if not self._subscriptions[topic]:
                        del self._subscriptions[topic]
                    self._logger.error(
                        f"Failed to subscribe to {topic}: {result[0]}"
                    )
                    return None
                self._logger.info(
                    f"Subscribed to {topic} at qos={broker_qos} "
                    f"(fan-out: {len(self._subscriptions[topic])})"
                )
            else:
                self._logger.debug(
                    f"Added subscription to {topic} "
                    f"(fan-out: {len(self._subscriptions[topic])}, "
                    f"connected={self._is_connected()})"
                )

        return sub

    def unsubscribe(self, subscription: Optional[Subscription]) -> bool:
        """Release a single Subscription handle.

        Idempotent on a given handle (cancelling twice returns False the
        second time). The broker SUBSCRIBE is removed only when the last
        subscriber for the topic releases.
        """
        if subscription is None:
            return False

        with self._client_lock:
            if subscription._cancelled:
                return False
            subs = self._subscriptions.get(subscription.topic)
            if not subs:
                return False
            try:
                subs.remove(subscription)
            except ValueError:
                return False
            subscription._cancelled = True

            if subs:
                self._logger.debug(
                    f"Released one subscription to {subscription.topic} "
                    f"(fan-out remaining: {len(subs)})"
                )
                return True

            # Last subscriber for this topic — tell the broker to stop.
            del self._subscriptions[subscription.topic]
            if self._is_connected():
                try:
                    self._client.unsubscribe(subscription.topic)
                except Exception as e:
                    self._logger.error(
                        f"Error unsubscribing from {subscription.topic}: {e}"
                    )
                    return False
                self._logger.info(
                    f"Unsubscribed from {subscription.topic} (last subscriber)"
                )
            return True

    def is_connected(self) -> bool:
        """Check if the client is connected to the broker."""
        return self._connection_state == ConnectionState.CONNECTED

    def get_connection_state(self) -> ConnectionState:
        """Get the current connection state."""
        return self._connection_state

    def subscriber_count(self, topic: str) -> int:
        """How many subscriptions currently fan out for ``topic``."""
        with self._client_lock:
            return len(self._subscriptions.get(topic, []))

    def _is_connected(self) -> bool:
        return (
            self._client is not None
            and self._connection_state == ConnectionState.CONNECTED
        )

    def _on_connect(self, client, userdata, flags, rc):
        """Callback for when the client connects to the broker."""
        if rc != 0:
            self._connection_state = ConnectionState.ERROR
            self._logger.error(f"Failed to connect to MQTT broker: {rc}")
            return

        self._connection_state = ConnectionState.CONNECTED
        self._logger.info("Connected to MQTT broker")

        # Resubscribe every topic on (re)connect. With clean_session=True
        # the broker drops all subscriptions on disconnect, so each
        # reconnect needs to replay them from our local state.
        with self._client_lock:
            if not self._subscriptions:
                return
            self._logger.info(
                f"Resubscribing to {len(self._subscriptions)} topic(s)"
            )
            for topic, subs in self._subscriptions.items():
                if not subs:
                    continue
                qos = max(s.qos for s in subs)
                try:
                    result = self._client.subscribe(topic, qos)
                    if result[0] == mqtt.MQTT_ERR_SUCCESS:
                        self._logger.debug(
                            f"Resubscribed to {topic} at qos={qos} "
                            f"(fan-out: {len(subs)})"
                        )
                    else:
                        self._logger.error(
                            f"Failed to resubscribe to {topic}: {result[0]}"
                        )
                except Exception as e:
                    self._logger.error(
                        f"Error resubscribing to {topic}: {e}"
                    )

    def _on_disconnect(self, client, userdata, rc):
        """Callback for when the client disconnects from the broker.

        Paho's network loop handles auto-reconnect itself (configured via
        reconnect_delay_set in configure()); we just update local state.
        """
        if rc == 0:
            self._connection_state = ConnectionState.DISCONNECTED
            self._logger.info("Disconnected from MQTT broker")
        else:
            self._connection_state = ConnectionState.RECONNECTING
            self._logger.warning(
                f"Unexpected disconnection from MQTT broker: {rc} — paho will auto-reconnect"
            )

    def _on_message(self, client, userdata, msg):
        """Fan out an incoming message to every Subscription on its topic.

        Exceptions in one callback never prevent the others from firing.
        We snapshot the subscriber list under the lock so a callback that
        un/subscribes synchronously can't corrupt iteration.
        """
        topic = msg.topic
        payload_bytes = msg.payload
        self._logger.debug(
            "MQTT message received: topic=%s payload_len=%d",
            topic,
            len(payload_bytes),
        )
        try:
            payload = payload_bytes.decode("utf-8")
        except Exception as exc:
            self._logger.error(
                "MQTT message on topic=%s could not be decoded as UTF-8: %s",
                topic,
                exc,
            )
            return

        with self._client_lock:
            subs_snapshot = list(self._subscriptions.get(topic, []))

        if not subs_snapshot:
            self._logger.warning(f"No subscribers for topic: {topic}")
            return

        for sub in subs_snapshot:
            try:
                sub.callback(payload)
            except Exception as e:
                self._logger.error(
                    f"Error in subscriber callback for {topic}: {e}"
                )

    def _on_subscribe(self, client, userdata, mid, granted_qos):
        """Callback for when a subscription is confirmed."""
        self._logger.debug(f"Subscription confirmed with QoS: {granted_qos}")

    def _on_unsubscribe(self, client, userdata, mid):
        """Callback for when an unsubscription is confirmed."""
        self._logger.debug("Unsubscription confirmed")

    def __del__(self):
        """Best-effort cleanup. Bypasses the refcount because by the time
        the singleton is being collected there are no callers left to
        balance.
        """
        try:
            client = getattr(self, "_client", None)
            if client is not None:
                client.disconnect()
                client.loop_stop()
        except Exception:
            pass

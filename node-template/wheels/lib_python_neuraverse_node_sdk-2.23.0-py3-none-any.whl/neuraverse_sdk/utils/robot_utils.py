from google.protobuf import empty_pb2
from geometry_msgs.msg import Pose, Point, Quaternion


from neuraverse_sdk.utils.exceptions import RobotException


def ai_pose_to_ros_pose(ai_pose):
    return Pose(
        position=Point(
            x=ai_pose.translation.x, y=ai_pose.translation.y, z=ai_pose.translation.z
        ),
        orientation=Quaternion(
            x=ai_pose.orientation.x,
            y=ai_pose.orientation.y,
            z=ai_pose.orientation.z,
            w=ai_pose.orientation.w,
        ),
    )


def switch_to_automatic(robot):
    # Switch the robot to  automatic mode
    switch_response = robot.SwitchToAutomaticMode(empty_pb2.Empty())
    if switch_response.error:
        raise RobotException(
            f"Error switching to automatic mode: {switch_response.error}"
        )


def initialize_program(robot):
    init_program_response = robot.InitProgram(empty_pb2.Empty())
    if init_program_response.error:
        raise RobotException(
            f"Error switching to automatic mode: {init_program_response.error}"
        )

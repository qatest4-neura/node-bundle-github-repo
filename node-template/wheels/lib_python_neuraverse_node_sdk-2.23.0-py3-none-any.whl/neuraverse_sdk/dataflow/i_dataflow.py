import threading
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

from neuraverse.models.v1.gen.business.node_graph_pb2 import DataFlowNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.interfaces.IDataFlow"
)


class IDataFlow(ABC):
    """Abstract base class for data flow adapters."""

    def __init__(self) -> None:
        self.topic_map: dict[str, str] = {}
        self.blackboard_lock = threading.Lock()
        self.blackboard: dict[str, Any] = {}
        self._data_events: dict[str, threading.Event] = {}
        self.message_handlers: dict[str, Callable] = {}

    @abstractmethod
    def init(self, config: Any) -> None:
        """Initialize the data flow adapter with configuration."""
        pass

    @abstractmethod
    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        """Configure the data flow by connecting nodes."""
        pass

    @abstractmethod
    def destroy(self) -> None:
        """Destroy the data flow if not needed anymore."""
        pass

    @abstractmethod
    def publish(self, target: str, message: Any, meta_data: Any) -> None:
        """Publish a message using the given publisher."""
        pass

    @abstractmethod
    def wait_for_message(
        self, subscription: str, timeout: float = -1.0
    ) -> tuple[bool, Any]:
        """Wait for a message on a subscription."""
        pass

    @abstractmethod
    def get_connected_ports(self) -> dict[str, bool]:
        pass

    @abstractmethod
    def get_input_topics(self) -> dict[str, Any]:
        pass

    @abstractmethod
    def get_output_topics(self) -> dict[str, Any]:
        pass

    @abstractmethod
    def handle_message(self, input_name: str, msg: Any, topic_info: Any) -> None:
        """Default hook. Override in derived classes for catch-all behavior."""
        pass

    def get_data(self, placeholder: str, timeout: float | None = 1.0) -> Any:
        """Get the data from the node."""
        if not timeout:
            with self.blackboard_lock:
                return self.blackboard.get(placeholder)

        event = self._data_events.get(placeholder)

        if event is None:
            LOGGER.debug(f"No data event for '{placeholder}'")
            return None  # assuming the input_port is not connected

        # # Clear previous signal
        # event.clear()

        # Wait for message
        received = event.wait(timeout)

        if not received:
            return None

        with self.blackboard_lock:
            return self.blackboard.get(placeholder)

    def _save_data(
        self, message: Any, input_name: str, topic_info: Any
    ) -> None:
        """Callback for the data flow."""
        # LOGGER.info(f"ROSDataFlowAdapter: Saving data from topic: {topic_info['topic_name']}")
        with self.blackboard_lock:
            self.blackboard[input_name] = message

        self._data_events[input_name].set()

        # Per-topic handler takes priority
        if input_name in self.message_handlers:
            self.message_handlers[input_name](message)
        else:
            # Fall back to generic handler
            self.handle_message(input_name, message, topic_info)

from neuraverse.models.v1.gen.business.node_graph_pb2 import DataFlowCommunicationType

from neuraverse_sdk.dataflow.composite_dataflow import CompositeDataFlow
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.dataflow.mqtt_dataflow_adapter import MQTTDataFlowAdapter
from neuraverse_sdk.dataflow.ros_dataflow_adapter import ROSDataFlowAdapter
from neuraverse_sdk.dataflow.zenoh_dataflow_adapter import ZenohDataFlowAdapter
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.utils.exceptions import DataFlowException


class DataFlowFactory:
    """Factory for creating data flow adapters"""

    _adapters: dict[DataFlowCommunicationType, type[IDataFlow]] = {  # type: ignore[assignment]
        DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ROS: ROSDataFlowAdapter,
        DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_MQTT: MQTTDataFlowAdapter,
        DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ZENOH: ZenohDataFlowAdapter,
    }

    @classmethod
    def create_adapter(
        cls, adapter_type: DataFlowCommunicationType, **kwargs
    ) -> IDataFlow:
        """Instantiate the adapter registered for adapter_type."""
        if adapter_type not in cls._adapters:
            raise ValueError(
                f"Unsupported adapter type '{adapter_type}'. Available: {cls._adapters.keys()}"
            )

        adapter_class = cls._adapters[adapter_type]
        return adapter_class(**kwargs)

    @classmethod
    def register_adapter(
        cls, adapter_type: DataFlowCommunicationType, adapter_class: type
    ) -> None:
        """Register a custom adapter type."""
        cls._adapters[adapter_type] = adapter_class

    @classmethod
    def get_available_adapters(cls) -> list[DataFlowCommunicationType]:
        """Get list of available adapter types"""
        return list(cls._adapters.keys())


def create_data_flow_adapter(
    dataflow_communication_type: DataFlowCommunicationType,
    service_config: NodeServiceConfig,
    **kwargs,
) -> IDataFlow:
    """Create and init an adapter from node service config."""
    if dataflow_communication_type not in DataFlowFactory.get_available_adapters():
        raise DataFlowException(
            f"Dataflow communication type '{dataflow_communication_type}' is not supported"
        )

    adapter = DataFlowFactory.create_adapter(dataflow_communication_type, **kwargs)
    if (
        dataflow_communication_type
        == DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_MQTT
    ):
        adapter.init(service_config.mqtt)
    elif (
        dataflow_communication_type
        == DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ROS
    ):
        adapter.init({})
    elif (
        dataflow_communication_type
        == DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ZENOH
    ):
        adapter.init(service_config.zenoh)
    return adapter


def create_composite_data_flow(
    service_config: NodeServiceConfig,
) -> CompositeDataFlow:
    """Create a CompositeDataFlow that routes each port to ROS or MQTT at runtime."""
    return CompositeDataFlow(service_config)

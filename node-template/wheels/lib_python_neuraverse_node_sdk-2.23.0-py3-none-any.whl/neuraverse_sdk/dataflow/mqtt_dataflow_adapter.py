import base64
import json
import threading
from dataclasses import dataclass
from functools import partial
from typing import Any, Optional, Tuple, Type, TypeVar

from neuraverse.models.v1.gen.business.node_graph_pb2 import DataFlowNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from rclpy.serialization import deserialize_message, serialize_message
from typing_extensions import override

from neuraverse_sdk.dataflow.dataflow_helper import _import_msg_type
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.utils.exceptions import DataFlowException
from neuraverse_sdk.utils.mqtt_singleton import MQTTHandler, Subscription

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.dataflow.mqtt_dataflow_adapter"
)

T = TypeVar("T")


@dataclass
class MQTTMessage:
    """Wrapper for serialized ROS2 messages with type information."""

    msg_type: str  # e.g., "geometry_msgs.msg.Twist"
    payload: str  # base64-encoded CDR bytes

    def to_json(self) -> str:
        return json.dumps({"msg_type": self.msg_type, "payload": self.payload})

    @classmethod
    def from_json(cls, json_str: str) -> "MQTTMessage":
        data = json.loads(json_str)
        return cls(msg_type=data["msg_type"], payload=data["payload"])


class ROS2MessageSerializer:
    """Handles serialization/deserialization of any ROS2 message using CDR format."""

    def __init__(self):
        self._type_cache: dict[str, Type] = {}

    def serialize(self, msg) -> MQTTMessage:
        """
        Serialize any ROS2 message to an MQTTMessage wrapper.

        Args:
            msg: Any ROS2 message instance

        Returns:
            MQTTMessage with type info and base64-encoded CDR payload
        """
        # Get fully qualified type name
        module = msg.__class__.__module__
        class_name = msg.__class__.__name__
        pkg = module.split(".")[0]
        msg_type = f"/{pkg}/msg/{class_name}"

        # Serialize to CDR bytes and encode as base64 for MQTT transport
        cdr_bytes = serialize_message(msg)
        payload = base64.b64encode(cdr_bytes).decode("utf-8")

        return MQTTMessage(msg_type=msg_type, payload=payload)

    def deserialize(self, mqtt_msg: MQTTMessage) -> object:
        """
        Deserialize an MQTTMessage back to the original ROS2 message.

        Args:
            mqtt_msg: MQTTMessage wrapper containing type info and payload

        Returns:
            Reconstructed ROS2 message instance
        """
        msg_class = _import_msg_type(mqtt_msg.msg_type)
        cdr_bytes = base64.b64decode(mqtt_msg.payload)
        return deserialize_message(cdr_bytes, msg_class)

    def deserialize_typed(self, payload: str, msg_type: Type[T]) -> T:
        """
        Deserialize when you already know the message type.

        Args:
            payload: base64-encoded CDR bytes
            msg_type: The ROS2 message class

        Returns:
            Reconstructed ROS2 message instance
        """
        cdr_bytes = base64.b64decode(payload)
        return deserialize_message(cdr_bytes, msg_type)


class MQTTDataFlowAdapter(IDataFlow):
    """MQTT data flow adapter."""

    def __init__(self):
        """Initialize the MQTT data flow adapter with node and edge information.


        Args:
            node_info: Dictionary containing node information including id, name, inputs and outputs
        """
        super().__init__()
        self.publishers = {}
        self.subscribers = {}
        self.connected_ports: dict[str, bool] = {}
        self.input_topics = {}
        self.output_topics = {}
        self.serializer = ROS2MessageSerializer()
        # Tracks whether this adapter owns one outstanding connect() ref on
        # the singleton, so repeated configure() calls don't keep bumping
        # the refcount and leaking it past destroy().
        self._holds_connect_ref = False

    @override
    def init(self, config):
        # client_id is managed by the MQTTHandler singleton so a single
        # stable identity is used across all adapters in this process.
        self._config = config

    @override
    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        """Configure the data flow by connecting nodes and initializing the data flow.

        Idempotent across repeated calls: prior subscription handles are
        released first (otherwise reconfiguring would leak callbacks into
        the singleton's fan-out list and every incoming message would fire
        the handler once per leaked handle), and the connect refcount is
        held by this adapter exactly once for its lifetime.
        """
        self.mqtt_client = MQTTHandler()
        self.mqtt_client.configure(self._config)
        if not self._holds_connect_ref:
            if not self.mqtt_client.connect(blocking=True, timeout=2.0):
                LOGGER.error(f"Failed to connect to MQTT broker | {self._config}")
                raise ConnectionError(
                    f"Failed to connect to MQTT broker | {self._config}"
                )
            self._holds_connect_ref = True
            LOGGER.info(f"Successfully connected to MQTT broker | {self._config}")

        if not self.mqtt_client.is_connected():
            raise ValueError("MQTT client is not connected.")

        # Release subscriptions from a prior configure() so we don't stack
        # duplicate callbacks in the singleton's per-topic fan-out list.
        for handle in self.subscribers.values():
            self.mqtt_client.unsubscribe(handle)
        self.subscribers.clear()
        self.input_topics.clear()
        self.output_topics.clear()
        self.connected_ports.clear()

        self._construct_publishers_and_subscribers(node_data_flow_entry)

    @override
    def destroy(self):
        """Destroy the data flow."""
        self.publishers = {}
        self.blackboard = {}
        for key, event in self._data_events.items():
            event.clear()
        self._data_events = {}
        # Release only our own subscription handles. The MQTTHandler is a
        # process-wide singleton with topic fan-out; another adapter may
        # share the same topic and must keep receiving.
        for handle in self.subscribers.values():
            self.mqtt_client.unsubscribe(handle)
        self.subscribers = {}
        self.input_topics = {}
        if self._holds_connect_ref:
            self.mqtt_client.disconnect()
            self._holds_connect_ref = False

    @override
    def publish(self, target: str, message: Any, meta_data: Any = None) -> None:
        """Publish a message to the specified target output.

        Args:
            target: Name of the output to publish to
            message: Message to publish
            meta_data: Optional metadata
        """
        if target not in self.output_topics:
            raise DataFlowException(f"Unknown output target: {target}")

        try:
            topic = self.output_topics[target]["topic_name"]
            mqtt_msg = self.serializer.serialize(message)

            self.mqtt_client.publish(topic, mqtt_msg.to_json())
        except Exception as e:
            LOGGER.error(
                f"MQTTDataFlowAdapter: Error publishing message to {target}: {e}"
            )

    @override
    def wait_for_message(
        self, subscription: str, timeout: float = -1.0
    ) -> Tuple[bool, Any]:
        """Wait for a message on the specified input subscription.

        Args:
            subscription: Name of the input to wait for
            timeout: Timeout in seconds (-1 for infinite)

        Returns:
            Tuple of (success, message)
        """
        raise NotImplementedError("This method is not implemented yet.")

    @override
    def get_connected_ports(self) -> dict[str, bool]:
        """Get the connected ports of the data flow.

        Returns:
            Dictionary of connected ports
        """
        return self.connected_ports

    @override
    def get_input_topics(self) -> dict[str, dict]:
        return self.input_topics

    @override
    def get_output_topics(self) -> dict[str, dict]:
        return self.output_topics

    def _construct_publishers_and_subscribers(
        self, node_data_flow_entry: DataFlowNodeEntry
    ) -> None:
        if self.mqtt_client is None:
            raise ValueError("MQTT client is not initialized")
        # Initialize publishers for each output
        for output_name, output_conn in node_data_flow_entry.outputPorts.items():
            # Use id, not name: name is not unique across graphs sharing
            # one engine process, and MQTTHandler is a process-wide
            # singleton with topic fan-out.
            topic_name = f"{node_data_flow_entry.id}/{output_name}"

            self.output_topics[output_name] = {
                "topic_name": topic_name,
                "ros_type": output_conn.rosType,
            }

        # Initialize subscribers for each input
        for input_name, input_cfg in node_data_flow_entry.inputPorts.items():
            self.connected_ports[input_name] = False
            if not input_cfg.sourceConnection:
                LOGGER.info(
                    "MQTTDataFlowAdapter: input=%s has no sourceConnection — no MQTT subscription created",
                    input_name,
                )
            for topic_name in input_cfg.sourceConnection:
                ros_type = input_cfg.rosType
                if not topic_name or topic_name == "":
                    LOGGER.warning(
                        "MQTTDataFlowAdapter: input=%s has empty topic in sourceConnection — skipped",
                        input_name,
                    )
                    continue
                msg_type = _import_msg_type(ros_type)

                LOGGER.info(
                    "MQTTDataFlowAdapter: subscribing input=%s to MQTT topic=%s ros_type=%s",
                    input_name,
                    topic_name,
                    ros_type,
                )
                topic_info = {
                    "topic_name": topic_name,
                    "msg_type": msg_type,
                    "ros_type": ros_type,
                }
                self.input_topics[input_name] = topic_info
                handle: Optional[Subscription] = self.mqtt_client.subscribe(
                    topic_name,
                    partial(
                        self._save_data,
                        input_name=input_name,
                        topic_info=topic_info,
                    ),
                    qos=1,
                )
                if handle is None:
                    raise DataFlowException(
                        f"Failed to subscribe to input topic {topic_name}"
                    )
                self.subscribers[input_name] = handle
                self.topic_map[topic_name] = input_name
                event = threading.Event()
                self._data_events[input_name] = event

                self.connected_ports[input_name] = True

    def get_data(self, placeholder: str, timeout: Optional[float] = 1) -> Any:
        raw_payload = super().get_data(placeholder, timeout)
        if raw_payload is None:
            topic_info = self.input_topics.get(placeholder, {})
            LOGGER.debug(
                "MQTTDataFlowAdapter.get_data: no data within %.1fs for input=%s topic=%s",
                timeout or 0,
                placeholder,
                topic_info.get("topic_name", "?"),
            )
            return None

        # Parse JSON string to MQTTMessage, then deserialize to ROS2
        try:
            mqtt_msg = MQTTMessage.from_json(raw_payload)
        except Exception as exc:
            preview = raw_payload[:120] if isinstance(raw_payload, str) else repr(raw_payload)[:120]
            LOGGER.error(
                "MQTTDataFlowAdapter.get_data: JSON parse failed for input=%s: %s | payload_preview=%r",
                placeholder,
                exc,
                preview,
            )
            return None

        try:
            ros_msg = self.serializer.deserialize(mqtt_msg)
        except Exception as exc:
            LOGGER.error(
                "MQTTDataFlowAdapter.get_data: CDR deserialise failed for input=%s "
                "msg_type=%s payload_len=%d: %s",
                placeholder,
                mqtt_msg.msg_type,
                len(mqtt_msg.payload),
                exc,
            )
            return None

        LOGGER.debug(
            "MQTTDataFlowAdapter.get_data: deserialized input=%s msg_type=%s",
            placeholder,
            mqtt_msg.msg_type,
        )
        return ros_msg

    @override
    def handle_message(self, input_name: str, msg: Any, topic_info: dict[str, Any]):
        """Default hook. Override in derived classes for catch-all behavior."""
        pass

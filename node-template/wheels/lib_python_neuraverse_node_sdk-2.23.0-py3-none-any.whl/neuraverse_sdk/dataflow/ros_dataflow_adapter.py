import re
import threading
from functools import partial
from typing import Any

import rclpy
from neuraverse.models.v1.gen.business.node_graph_pb2 import DataFlowNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from rclpy.executors import SingleThreadedExecutor
from typing_extensions import override

from neuraverse_sdk.dataflow.dataflow_helper import _import_msg_type
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.utils.exceptions import DataFlowException

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.dataflow.ros_dataflow_adapter")


_ROS_INVALID_CHAR = re.compile(r"[^A-Za-z0-9_]")

# Teardown timeouts. The engine enforces a 10 s deadline on the StopNode RPC
# (NODE_RPC_STOP_TIMEOUT_SEC), and the composite tears down the ROS adapter and
# THEN the MQTT adapter on that same RPC — so the ROS budget must leave room.
# shutdown(2.0) + join(2.0) caps ROS teardown at ~4 s, >5 s of headroom under
# the deadline. Do not inflate these: an unbounded shutdown() blocks until an
# in-flight subscription callback returns, which is exactly what used to push
# stop past the deadline.
_EXECUTOR_SHUTDOWN_TIMEOUT_S = 2.0
_SPIN_JOIN_TIMEOUT_S = 2.0


def _ros_safe_segment(segment: str) -> str:
    """Coerce one path segment of a topic into ROS2-compatible form.

    ROS rules per segment: ``[A-Za-z][A-Za-z0-9_]*``. Anything outside
    that class becomes ``_``; if the result is empty or begins with a
    digit, an ``n_`` prefix is added. Engine writes id-prefixed topics
    like ``node-0/out`` (valid for MQTT, illegal in ROS) — this is the
    one place that converts them so both publish and subscribe sides
    of the same adapter end up on the same sanitized topic name.
    """
    sanitized = _ROS_INVALID_CHAR.sub("_", segment)
    if not sanitized or not sanitized[0].isalpha():
        sanitized = "n_" + sanitized
    return sanitized


def _ros_safe_topic(topic: str) -> str:
    """Sanitize each non-empty segment of ``topic`` for ROS.

    Preserves ``/`` segment separators and any leading ``/`` (which
    denotes a fully-qualified topic in ROS); ``""`` segments stay
    empty so ``"/foo"`` round-trips to ``"/foo"``, not ``"n_/foo"``.
    """
    return "/".join(_ros_safe_segment(p) if p else p for p in topic.split("/"))


class ROSDataFlowAdapter(IDataFlow):
    """ROS2 data flow adapter."""

    def __init__(self):
        """Initialize the ROS data flow adapter with node and edge information.


        Args:
            node_info: Dictionary containing node information including id, name, inputs and outputs
        """
        super().__init__()
        self.node_info = None
        if not rclpy.ok():
            rclpy.init()
        self.publishers = {}
        self.subscribers = {}
        self.ros_node = None
        self.executor: SingleThreadedExecutor | None = SingleThreadedExecutor()
        self._break_loop = False
        self.connected_ports: dict[str, bool] = {}
        self.input_topics: dict[str, dict] = {}
        self.output_topics: dict[str, dict] = {}
        self.executor_thread: threading.Thread | None = None

    @override
    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        """Configure the data flow by connecting nodes and initializing the data flow."""
        self._construct_publishers_and_subscribers(node_data_flow_entry)
        self._init()

    @override
    def destroy(self):
        self.publishers = {}
        self.subscribers = {}
        self.blackboard = {}
        for key, event in self._data_events.items():
            event.clear()
        self._data_events = {}
        # ``_break_loop`` is functionally dead against the blocking
        # ``executor.spin()`` (spin() never reads it); kept only so callers /
        # tests can observe that destroy() was entered.
        self._break_loop = True

        # Bound the shutdown. ``Executor.shutdown()`` with no timeout blocks
        # until any in-flight subscription callback finishes — and callbacks run
        # user code inline (IDataFlow._save_data -> handler), so a slow/continuous
        # callback would block stop past the engine's StopNode deadline. Each rclpy
        # call is isolated so one failure can't strand the rest of teardown.
        if self.executor is not None:
            try:
                self.executor.shutdown(timeout_sec=_EXECUTOR_SHUTDOWN_TIMEOUT_S)
            except Exception as e:
                LOGGER.warning("ROS executor shutdown failed: %s", e)

        if self.executor_thread is not None:
            self.executor_thread.join(timeout=_SPIN_JOIN_TIMEOUT_S)

        thread_alive = (
            self.executor_thread.is_alive() if self.executor_thread is not None else False
        )

        if thread_alive:
            # The spin thread did not exit within the timeout — it is still
            # inside a callback. Destroying a node still owned by a live executor
            # deadlocks/segfaults rclpy, so skip node release and accept a
            # bounded, attributable leak instead of a hang. The refs are kept
            # (not nulled) so the leak stays observable; the daemon spin thread
            # cannot block process exit.
            LOGGER.warning(
                "ROS spin thread still alive after %.1fs join; skipping "
                "remove_node()/destroy_node() to avoid destroying a node owned "
                "by a live executor (node leaks until process exit)",
                _SPIN_JOIN_TIMEOUT_S,
            )
            return

        # Clean path: the spin thread exited, so the node is no longer being
        # dispatched against. Remove it from the executor before destroying it,
        # then null the refs so reconfigure cycles release the node, executor,
        # and DDS entities instead of accumulating them.
        if self.executor is not None and self.ros_node is not None:
            try:
                self.executor.remove_node(self.ros_node)
            except Exception as e:
                LOGGER.warning("ROS remove_node failed: %s", e)
        if self.ros_node is not None:
            try:
                self.ros_node.destroy_node()
            except Exception as e:
                LOGGER.warning("ROS destroy_node failed: %s", e)
        self.executor = None
        self.executor_thread = None
        self.ros_node = None

    @override
    def publish(self, target: str, message: Any, meta_data: Any = None) -> None:
        """Publish a message to the specified target output.

        Args:
            target: Name of the output to publish to
            message: Message to publish
            meta_data: Optional metadata
        """
        # LOGGER.info(f"ROSDataFlowAdapter: Publishing message to {target} | Metadata: {meta_data}")
        if target not in self.publishers:
            # LOGGER.info(f"ROSDataFlowAdapter: Unknown output target: {target}")
            raise DataFlowException(f"Unknown output target: {target}")

        publisher_info = self.publishers[target]

        try:
            publisher_info.publish(message)
            # LOGGER.info(
            #     f"ROSDataFlowAdapter: Published message to topic: {publisher_info.topic_name}"
            # )
        except Exception as e:
            LOGGER.warning(
                "Error publishing message to %s: %s",
                publisher_info.topic_name,
                e,
            )
            raise

    @override
    def wait_for_message(self, subscription: str, timeout: float = -1.0) -> tuple[bool, Any]:
        """Wait for a message on the specified input subscription.

        Args:
            subscription: Name of the input to wait for
            timeout: Timeout in seconds (-1 for infinite)

        Returns:
            Tuple of (success, message)
        """
        raise NotImplementedError("ROSDataFlowAdapter.wait_for_message is not implemented")

    @override
    def init(self, config):
        """Initialize the data flow adapter with configuration."""
        pass

    @override
    def get_connected_ports(self) -> dict[str, bool]:
        return self.connected_ports

    @override
    def get_input_topics(self) -> dict[str, dict]:
        return self.input_topics

    @override
    def get_output_topics(self) -> dict[str, dict]:
        return self.output_topics

    @override
    def handle_message(self, input_name: str, msg: Any, topic_info: dict[str, Any]):
        """Default hook. Override in derived classes for catch-all behavior."""
        pass

    def _construct_publishers_and_subscribers(
        self, node_data_flow_entry: DataFlowNodeEntry
    ) -> None:
        node_name = node_data_flow_entry.name + "_data_flow"
        self.ros_node = rclpy.create_node(node_name)
        # self.ros_nodes[node_info['id']] = ros_node
        # Initialize publishers for each output
        for output_name, output_conn in node_data_flow_entry.outputPorts.items():
            ros_type = output_conn.rosType
            # Use id, not name: name collides across graphs sharing
            # this engine process. Sanitize for ROS — production ids
            # like ``node-0`` contain hyphens which ROS rejects.
            topic_name = _ros_safe_topic(f"{node_data_flow_entry.id}/{output_name}")
            msg_type = _import_msg_type(ros_type)
            LOGGER.info(
                f"ROSDataFlowAdapter: Creating publisher for topic: {topic_name} {msg_type}"
            )
            self.output_topics[output_name] = {
                "topic_name": topic_name,
                "msg_type": msg_type,
                "ros_type": ros_type,
            }
            self.publishers[output_name] = self.ros_node.create_publisher(msg_type, topic_name, 10)

        # Initialize subscribers for each input
        for input_name, input_cfg in node_data_flow_entry.inputPorts.items():
            self.connected_ports[input_name] = False
            for topic_name in input_cfg.sourceConnection:
                ros_type = input_cfg.rosType
                if not topic_name or topic_name == "":
                    LOGGER.info(
                        f"ROSDataFlowAdapter: Input {input_name} is not connected, skipping creating a subscriber"
                    )
                    continue
                # Apply the same sanitization the publish path uses
                # so subscriber and publisher meet on the same name.
                topic_name = _ros_safe_topic(topic_name)
                msg_type = _import_msg_type(ros_type)
                LOGGER.info(
                    f"ROSDataFlowAdapter: Creating subscriber for topic: {topic_name} {msg_type}"
                )
                topic_info = {
                    "topic_name": topic_name,
                    "msg_type": msg_type,
                    "ros_type": ros_type,
                }
                self.input_topics[input_name] = topic_info
                self.subscribers[input_name] = self.ros_node.create_subscription(
                    msg_type,
                    topic_name,
                    partial(
                        self._save_data,
                        input_name=input_name,
                        topic_info=topic_info,
                    ),
                    10,
                )
                self.topic_map[topic_name] = input_name
                event = threading.Event()
                self._data_events[input_name] = event

                self.connected_ports[input_name] = True
        LOGGER.info(f"ROSDataFlowAdapter: Input topics: {self.input_topics}")
        LOGGER.info(f"ROSDataFlowAdapter: Output topics: {self.output_topics}")

    def _spin(self):
        # Block in the executor and dispatch callbacks as they arrive. The prior implementation
        # ran spin_once(timeout_sec=0.1) then time.sleep(0.1), throttling every ROS subscription
        # on this node to ~10 messages/second aggregate (one callback per ~100 ms) and dropping
        # the rest at the RMW queue. executor.spin() has no such cap; it blocks efficiently while
        # idle and returns when shutdown() is called from destroy().
        try:
            if self.executor is not None:
                self.executor.spin()
        except Exception as e:
            LOGGER.error("[ROSDataFlowAdapter._spin]: %s", e)

    def _init(self):
        if not rclpy.ok():
            _ = rclpy.init()
        # LOGGER.info(f"Adding node {self.node_info['id']} {self.ros_node}")
        if self.ros_node is None or self.executor is None:
            raise DataFlowException("ROS node is not initialized")

        _ = self.executor.add_node(self.ros_node)
        # Daemon so a spin thread wedged inside a long-blocking callback (which
        # destroy() deliberately refuses to join past its timeout) can never
        # block interpreter/process exit. Mirrors DataVisualizationStreamer.
        self.executor_thread = threading.Thread(
            target=self._spin, daemon=True, name="ros-dataflow-spin"
        )
        self.executor_thread.start()

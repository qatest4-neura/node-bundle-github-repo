from __future__ import annotations

import threading
from functools import partial
from typing import Any, TypedDict

from neuraverse.models.v1.gen.business.node_graph_pb2 import DataFlowNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory
from rclpy.serialization import deserialize_message, serialize_message
from typing_extensions import override

from neuraverse_sdk.dataflow.dataflow_helper import _import_msg_type
from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.utils.exceptions import DataFlowException
from neuraverse_sdk.utils.zenoh_singleton import ZenohHandler

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.dataflow.zenoh_dataflow_adapter"
)


class InputTopicInfo(TypedDict):
    topic_name: str
    msg_type: Any  # dynamically imported ROS2 message class
    ros_type: str


class OutputTopicInfo(TypedDict):
    topic_name: str
    ros_type: str


class ZenohDataFlowAdapter(IDataFlow):
    """Zenoh data flow adapter."""

    def __init__(self) -> None:
        super().__init__()
        self.publishers: dict[str, Any] = {}
        self.subscribers: dict[str, Any] = {}
        self.connected_ports: dict[str, bool] = {}
        self.input_topics: dict[str, InputTopicInfo] = {}
        self.output_topics: dict[str, OutputTopicInfo] = {}

    @override
    def init(self, config: Any) -> None:
        self._config = config

    @override
    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        """Configure data flow by connecting to Zenoh and setting up pub/sub."""
        self.zenoh_session = ZenohHandler()
        self.zenoh_session.configure(self._config)
        if self.zenoh_session.connect(blocking=True, timeout=2.0):
            LOGGER.info("Successfully connected to Zenoh router | %s", self._config)
        else:
            LOGGER.error("Failed to connect to Zenoh router | %s", self._config)
            raise ConnectionError(f"Failed to connect to Zenoh router | {self._config}")

        if not self.zenoh_session.is_connected():
            raise ValueError("Zenoh session is not connected.")

        self._construct_publishers_and_subscribers(node_data_flow_entry)

    @override
    def destroy(self) -> None:
        self.publishers = {}
        self.subscribers = {}
        self.blackboard = {}
        for event in self._data_events.values():
            event.clear()
        self._data_events = {}
        for topic in self.zenoh_session.get_topics():
            self.zenoh_session.unsubscribe(topic)
        self.zenoh_session.disconnect()

    @override
    def publish(self, target: str, message: Any, meta_data: Any = None) -> None:
        """Serialize and publish a ROS2 message to the given output port."""
        if target not in self.output_topics:
            raise DataFlowException(f"Unknown output target: {target}")
        try:
            topic = self.output_topics[target]["topic_name"]
            cdr_bytes = serialize_message(message)
            self.zenoh_session.publish(topic, cdr_bytes)
        except Exception as e:
            LOGGER.error("Error publishing message to %s: %s", target, e)

    @override
    def wait_for_message(self, subscription: str, timeout: float = -1.0) -> tuple[bool, Any]:
        raise NotImplementedError("This method is not implemented yet.")

    @override
    def get_connected_ports(self) -> dict[str, bool]:
        return self.connected_ports

    @override
    def get_input_topics(self) -> dict[str, InputTopicInfo]:
        return self.input_topics

    @override
    def get_output_topics(self) -> dict[str, OutputTopicInfo]:
        return self.output_topics

    @override
    def handle_message(self, input_name: str, msg: Any, topic_info: dict[str, Any]) -> None:
        """Default hook. Override in subclasses for catch-all message handling."""
        pass

    def get_data(self, placeholder: str, timeout: float | None = 1.0) -> Any:
        raw_payload = super().get_data(placeholder, timeout)
        if raw_payload is None:
            topic_info = self.input_topics.get(placeholder, {})
            LOGGER.debug(
                "No data within %.1fs for input=%s topic=%s",
                timeout or 0,
                placeholder,
                topic_info.get("topic_name", "?"),
            )
            return None

        topic_info = self.input_topics.get(placeholder, {})
        msg_type = topic_info.get("msg_type")

        try:
            ros_msg = deserialize_message(raw_payload, msg_type)
        except Exception as exc:
            LOGGER.error(
                "CDR deserialize failed for input=%s msg_type=%s payload_len=%d: %s",
                placeholder,
                msg_type,
                len(raw_payload) if raw_payload else 0,
                exc,
            )
            return None

        LOGGER.debug("Deserialized input=%s msg_type=%s", placeholder, msg_type)
        return ros_msg

    def _construct_publishers_and_subscribers(
        self, node_data_flow_entry: DataFlowNodeEntry
    ) -> None:
        if self.zenoh_session is None:
            raise ValueError("Zenoh session is not initialized")

        for output_name, output_conn in node_data_flow_entry.outputPorts.items():
            topic_name = f"{node_data_flow_entry.name}/{output_name}"
            self.output_topics[output_name] = {
                "topic_name": topic_name,
                "ros_type": output_conn.rosType,
            }

        for input_name, input_cfg in node_data_flow_entry.inputPorts.items():
            self.connected_ports[input_name] = False
            if not input_cfg.sourceConnection:
                LOGGER.info(
                    "input=%s has no sourceConnection — no Zenoh subscription created",
                    input_name,
                )
                continue

            for topic_name in input_cfg.sourceConnection:
                if not topic_name:
                    LOGGER.warning(
                        "input=%s has empty topic in sourceConnection — skipped",
                        input_name,
                    )
                    continue

                ros_type = input_cfg.rosType
                msg_type = _import_msg_type(ros_type)
                topic_info: InputTopicInfo = {
                    "topic_name": topic_name,
                    "msg_type": msg_type,
                    "ros_type": ros_type,
                }
                self.input_topics[input_name] = topic_info
                self.subscribers[input_name] = self.zenoh_session.add_topic(
                    topic_name,
                    partial(
                        self._save_data,
                        input_name=input_name,
                        topic_info=topic_info,
                    ),
                    1,
                )
                self.topic_map[topic_name] = input_name
                self._data_events[input_name] = threading.Event()
                self.connected_ports[input_name] = True

from importlib import import_module

from neuraverse_sdk.utils.exceptions import DataFlowException


def _import_msg_type(full_type):
    parts = full_type.strip("/").split("/")
    if len(parts) == 2:
        pkg, msg_name = parts
    elif len(parts) == 3 and parts[1] == "msg":
        pkg, msg_name = parts[0], parts[2]
    else:
        raise DataFlowException(f"Invalid message type format: {full_type}")

    module = import_module(f"{pkg}.msg")
    return getattr(module, msg_name)

from typing import Any, Optional

from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    DataFlowCommunicationType,
    DataFlowNodeEntry,
    InputConnection,
    OutputConnection,
)
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.dataflow.i_dataflow import IDataFlow
from neuraverse_sdk.dataflow.mqtt_dataflow_adapter import MQTTDataFlowAdapter
from neuraverse_sdk.dataflow.ros_dataflow_adapter import ROSDataFlowAdapter
from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.utils.exceptions import DataFlowException

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.dataflow.composite_dataflow"
)

_MQTT = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_MQTT
_ROS = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_ROS
_UNSPECIFIED = DataFlowCommunicationType.DATA_FLOW_COMMUNICATION_TYPE_UNSPECIFIED


class CompositeDataFlow(IDataFlow):
    """Routes each port to the correct adapter(s) (ROS and/or MQTT) based on communicationTypes."""

    def __init__(self, service_config: NodeServiceConfig):
        super().__init__()
        self._service_config = service_config
        self._ros_adapter: ROSDataFlowAdapter | None = None
        self._mqtt_adapter: MQTTDataFlowAdapter | None = None
        # Output ports may fan out to multiple adapters
        self._output_routing: dict[str, list[IDataFlow]] = {}
        # Input ports are always served by a single adapter
        self._input_routing: dict[str, IDataFlow] = {}

    def init(self, config):
        pass

    @property
    def ros_node(self):
        """Underlying rclpy node, so ``NodeBase.get_ros_node()`` works for the composite dataflow.

        ``get_ros_node()`` checks ``hasattr(self.data_flow, "ros_node")``; without this property
        it always returned ``None`` for composite-backed nodes, so any node attaching its own ROS
        subscriptions (e.g. a recorder capturing extra topics) silently got no node. Returns the
        ROS adapter's node when ROS ports exist, else ``None``.
        """
        return self._ros_adapter.ros_node if self._ros_adapter else None

    def configure(self, node_data_flow_entry: DataFlowNodeEntry) -> None:
        ros_entry, mqtt_entry = self._split_entry(node_data_flow_entry)

        # Destroy any prior adapters before replacing them. Without this
        # a second configure() leaks the previous adapter's MQTT
        # connect-ref (and any active subscriptions) — the new adapter
        # opens a fresh ref so the singleton refcount drifts past what
        # this composite legitimately holds, and future destroy() calls
        # don't actually release the broker connection. See
        # [[160-reconfigure-lifecycle.md]].
        if self._ros_adapter is not None:
            try:
                self._ros_adapter.destroy()
            except Exception as exc:
                LOGGER.warning("ROS adapter destroy on reconfigure failed: %s", exc)
            self._ros_adapter = None
        if self._mqtt_adapter is not None:
            try:
                self._mqtt_adapter.destroy()
            except Exception as exc:
                LOGGER.warning("MQTT adapter destroy on reconfigure failed: %s", exc)
            self._mqtt_adapter = None
        self._output_routing.clear()
        self._input_routing.clear()

        has_ros_ports = len(ros_entry.outputPorts) > 0 or len(ros_entry.inputPorts) > 0
        has_mqtt_ports = (
            len(mqtt_entry.outputPorts) > 0 or len(mqtt_entry.inputPorts) > 0
        )

        if has_ros_ports:
            self._ros_adapter = ROSDataFlowAdapter()
            self._ros_adapter.init({})
            self._ros_adapter.configure(ros_entry)

        if has_mqtt_ports:
            self._mqtt_adapter = MQTTDataFlowAdapter()
            self._mqtt_adapter.init(self._service_config.mqtt)
            self._mqtt_adapter.configure(mqtt_entry)

        # Build output routing — an output may need to publish on multiple adapters
        for port_name, output_conn in node_data_flow_entry.outputPorts.items():
            adapters = []
            comm_types = list(output_conn.communicationTypes)
            if not comm_types:
                comm_types = [_MQTT]  # Default to MQTT when unspecified
            for comm_type in comm_types:
                adapter = self._adapter_for(comm_type)
                if adapter and adapter not in adapters:
                    adapters.append(adapter)
            self._output_routing[port_name] = adapters

        # Build input routing — each input is served by exactly one adapter
        for port_name, input_conn in node_data_flow_entry.inputPorts.items():
            comm_type = input_conn.communicationType
            if comm_type == _UNSPECIFIED:
                comm_type = _MQTT  # Default to MQTT when unspecified
            self._input_routing[port_name] = self._adapter_for(comm_type)

    def destroy(self) -> None:
        if self._ros_adapter:
            self._ros_adapter.destroy()
        if self._mqtt_adapter:
            self._mqtt_adapter.destroy()

    def publish(self, target: Any, message: Any, meta_data: Any = None) -> None:
        adapters = self._output_routing.get(target)
        if not adapters:
            raise DataFlowException(f"Unknown output target: {target}")
        for adapter in adapters:
            adapter.publish(target, message, meta_data)

    def get_data(self, placeholder: str, timeout: Optional[float] = 1) -> Any:
        adapter = self._input_routing.get(placeholder)
        if adapter is None:
            LOGGER.debug(f"No adapter routed for input '{placeholder}'")
            return None
        return adapter.get_data(placeholder, timeout)

    def wait_for_message(
        self, subscription: Any, timeout: float = -1.0
    ) -> tuple[bool, Any]:
        adapter = self._input_routing.get(subscription)
        if adapter is None:
            raise DataFlowException(f"Unknown input subscription: {subscription}")
        return adapter.wait_for_message(subscription, timeout)

    def get_connected_ports(self) -> dict[str, bool]:
        result = {}
        if self._ros_adapter:
            result.update(self._ros_adapter.get_connected_ports())
        if self._mqtt_adapter:
            result.update(self._mqtt_adapter.get_connected_ports())
        return result

    def get_input_topics(self) -> dict[str, dict]:
        result = {}
        if self._ros_adapter:
            result.update(self._ros_adapter.get_input_topics())
        if self._mqtt_adapter:
            result.update(self._mqtt_adapter.get_input_topics())
        return result

    def get_output_topics(self) -> dict[str, dict]:
        result = {}
        if self._ros_adapter:
            result.update(self._ros_adapter.get_output_topics())
        if self._mqtt_adapter:
            result.update(self._mqtt_adapter.get_output_topics())
        return result

    def handle_message(self, input_name: str, msg: Any, topic_info: dict[str, Any]):
        pass

    def register_handler(self, callback, input_name: str = ""):
        if input_name:
            adapter = self._input_routing.get(input_name)
            if adapter:
                adapter.message_handlers[input_name] = callback
        else:
            if self._ros_adapter:
                self._ros_adapter.handle_message = callback
            if self._mqtt_adapter:
                self._mqtt_adapter.handle_message = callback

    # --- Private helpers ---

    def _adapter_for(self, comm_type: DataFlowCommunicationType) -> IDataFlow | None:
        if comm_type == _MQTT:
            return self._mqtt_adapter
        return self._ros_adapter

    @staticmethod
    def _split_entry(
        entry: DataFlowNodeEntry,
    ) -> tuple[DataFlowNodeEntry, DataFlowNodeEntry]:
        """Split a DataFlowNodeEntry into ROS and MQTT sub-entries.

        An output port with both ROS and MQTT in communicationTypes
        is included in both sub-entries.
        """
        ros_outputs: dict[str, OutputConnection] = {}
        mqtt_outputs: dict[str, OutputConnection] = {}
        for name, output_conn in entry.outputPorts.items():
            comm_types = list(output_conn.communicationTypes)
            if not comm_types:
                comm_types = [_MQTT]  # Default to MQTT when unspecified
            if _ROS in comm_types:
                ros_outputs[name] = output_conn
            if _MQTT in comm_types:
                mqtt_outputs[name] = output_conn

        ros_inputs: dict[str, InputConnection] = {}
        mqtt_inputs: dict[str, InputConnection] = {}
        for name, input_conn in entry.inputPorts.items():
            comm_type = input_conn.communicationType
            if comm_type == _UNSPECIFIED:
                comm_type = _MQTT  # Default to MQTT when unspecified
            if comm_type == _MQTT:
                mqtt_inputs[name] = input_conn
            else:
                ros_inputs[name] = input_conn

        ros_entry = DataFlowNodeEntry(
            id=entry.id,
            name=entry.name,
            outputPorts=ros_outputs,
            inputPorts=ros_inputs,
        )
        mqtt_entry = DataFlowNodeEntry(
            id=entry.id,
            name=entry.name,
            outputPorts=mqtt_outputs,
            inputPorts=mqtt_inputs,
        )
        return ros_entry, mqtt_entry

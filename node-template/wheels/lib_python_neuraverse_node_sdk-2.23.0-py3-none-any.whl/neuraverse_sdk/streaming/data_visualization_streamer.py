"""
Bridges ROS2 topic subscriptions to a LiveKit room for live data visualization.

Subscribes to requested ROS2 topics and publishes data to LiveKit:
- Scalar/complex types: JSON data channel messages (reliable, throttled)
- Image types: video tracks via LiveKit VideoSource
- Image-convertible types (e.g. OccupancyGrid): rendered as images, video tracks
- Audio types: sound-level meter rendered as image, video tracks
"""

import asyncio
import json
import math
import re
import threading
import time
from collections import OrderedDict
from typing import Any, Callable

from livekit import rtc as livekit_rtc
from neuraverse_common.observability.logging import Logger, LoggerFactory

# ROS2 type categories for throttle decisions
_SCALAR_TYPES = frozenset(
    {
        "std_msgs/msg/Bool",
        "std_msgs/msg/Float32",
        "std_msgs/msg/Float64",
        "std_msgs/msg/Int8",
        "std_msgs/msg/Int16",
        "std_msgs/msg/Int32",
        "std_msgs/msg/Int64",
        "std_msgs/msg/UInt8",
        "std_msgs/msg/UInt16",
        "std_msgs/msg/UInt32",
        "std_msgs/msg/UInt64",
        "std_msgs/msg/String",
    }
)

_IMAGE_TYPES = frozenset(
    {
        "sensor_msgs/msg/Image",
        "sensor_msgs/msg/CompressedImage",
    }
)

# Types whose data can be rendered as a 2D image (video track)
_IMAGE_CONVERTIBLE_TYPES = frozenset(
    {
        "nav_msgs/msg/OccupancyGrid",
        "instance_segmentation_ros_msgs/msg/SegmentationResult",
        "instance_segmentation_ros_msgs/msg/SegmentedInstanceArray",
    }
)

# Audio types — rendered as a live sound-level meter image (video track)
_AUDIO_TYPES = frozenset(
    {
        "audio_common_msgs/msg/AudioData",
        "audio_msgs/msg/AudioData",
    }
)

# Throttle intervals (seconds)
_SCALAR_MIN_INTERVAL = 1.0 / 10  # 10 Hz
_COMPLEX_MIN_INTERVAL = 1.0 / 5  # 5 Hz
# Fallback republish: when no fresh data has arrived on a topic for at least
# _CACHE_STALE_AFTER seconds, the republish loop re-emits the last cached value
# at _CACHE_REPUBLISH_INTERVAL on the same LiveKit channel, with a "CACHED"
# overlay (images) / marker field (data) so UIs can tell live from stale.
# This means a UI joining the room after the live stream stopped still sees the
# last value on each topic — no separate fetch API needed.
_CACHE_STALE_AFTER = 1.5
_CACHE_REPUBLISH_INTERVAL = 1.0

# Idle-watchdog cap.  The controller deliberately does NOT stop streamers when
# the underlying node is stopped, so cached frames keep being re-published for
# any UI still watching.  Without a back-stop the streamer would leak its
# LiveKit room + ROS2 node + asyncio loop until pod shutdown.  When no UI
# subscriber has been in the room for ``_IDLE_NO_SUBSCRIBER_SECONDS`` we
# self-stop; the next StartDataVisualization call recreates a fresh streamer
# (and re-seeds it from NodeBase's per-port last-output cache).
_IDLE_NO_SUBSCRIBER_SECONDS = 30 * 60   # 30 minutes
_IDLE_WATCHDOG_INTERVAL = 60.0          # check once a minute

# How long ``add_topics`` waits for a still-connecting streamer's LiveKit room
# to finish connecting before giving up on the extension. A second
# StartDataVisualization can arrive while the first streamer is still mid
# ``room.connect`` (its ``local_participant`` not yet available); rather than
# fail the extension outright we wait out the connect window. Matches the
# ``wait_for_sources_ready`` default the controller uses on the start path.
_ADD_TOPICS_READY_TIMEOUT_SEC = 10.0
_ADD_TOPICS_READY_POLL_SEC = 0.05


# A runtime token is the UUID the engine prepends to make each configure
# cycle's container state unique (``NodeEngineController._resolve_runtime_node_id``
# mints ``"{uuid}:{node_id}"`` and overwrites ``node.id`` on every per-node RPC).
# By the time it reaches us as a topic it appears in one of three shapes,
# depending on how far the topic has been through ROS sanitisation:
#   * its own ``/``-segment:        ``"{uuid}/{node_id}/{port}"``  (legacy / custom-node topics)
#   * colon-fused with the node id: ``"{uuid}:{node_id}/{port}"``  (raw wire id)
#   * underscore-fused (ROS-safe):  ``"{uuid}_{node_id}/{port}"``  (``_ros_safe_topic`` maps
#                                    ``:`` and the UUID's ``-`` to ``_``, so the whole wire id
#                                    collapses into a single segment)
# The UUID's internal separators are ``-`` when raw and ``_`` once ROS-sanitised,
# so ``[-_]`` covers both. ``(?:n_)?`` absorbs the ``n_`` prefix ``_ros_safe_segment``
# adds when the UUID starts with a digit.
_HEX = "[0-9a-fA-F]"
_VIZ_RUNTIME_TOKEN_RE = re.compile(
    rf"^(?:n_)?{_HEX}{{8}}[-_]{_HEX}{{4}}[-_]{_HEX}{{4}}[-_]{_HEX}{{4}}[-_]{_HEX}{{12}}"
)


def livekit_safe_viz_name(topic: str) -> str:
    """Map an internal ROS viz topic to the public LiveKit track/data name.

    Two LiveKit/UX constraints drive this:
      * LiveKit rejects a name whose ``/``-separated token starts with a digit
        ("topic name token must not start with a number"). Our topics are
        keyed on a ``runtime_token`` UUID, so roughly half the time its leading
        hex char is a digit and the publish fails intermittently.
      * The name MUST be keyed on the node id, not the random per-configure
        runtime-token GUID. The GUID rotates on every reconfigure (a fresh
        wire id is minted each cycle); if it leaks into the public name, every
        reconfigure publishes a *different* track name, so stale tracks from
        prior cycles pile up in the room (the UI shows each topic several
        times) and the UI binds to a no-longer-fed track (green noise / never
        starts) instead of the live one.

    So: drop the leading runtime-token UUID — whether it is its own segment
    (``{uuid}/node_id/port``) or fused into the first segment with the node id
    (``{uuid}:node_id/port`` raw, or ``{uuid}_node_id/port`` ROS-safe) — leaving
    a stable ``node_id/port``, and ``n_``-prefix any segment that would start
    with a digit. The transform is deterministic and must be applied identically
    wherever the public name is produced (the reported ``topicName`` and the
    LiveKit publish calls) so the UI — which subscribes by ``topicName``
    verbatim — matches what we publish.
    """
    segs = [s for s in (topic or "").split("/") if s != ""]
    if segs:
        m = _VIZ_RUNTIME_TOKEN_RE.match(segs[0])
        if m:
            remainder = segs[0][m.end():]
            if remainder:
                # Fused form: the token shares the segment with the node id —
                # strip the token (and the ``:``/``_`` separator left behind),
                # keeping the node id as the first segment.
                segs[0] = remainder.lstrip(":_")
            elif len(segs) >= 2:
                # The token was the whole first segment — drop it so the node
                # id (next segment) leads.
                segs = segs[1:]
    safe = [("n_" + s) if s[:1].isdigit() else s for s in segs]
    return "/".join(safe)


def _normalize_ros_type(ros_type: str) -> str:
    """Return the canonical three-part form ``pkg/msg/Type``."""
    clean = (ros_type or "").lstrip("/")
    parts = clean.split("/")
    if len(parts) == 2:
        return f"{parts[0]}/msg/{parts[1]}"
    return clean


def visualization_stream_type(ros_type: str) -> str:
    """Return the stream type the frontend will actually receive for a given ROS type.

    Types the streamer publishes as LiveKit video tracks are normalized to
    ``sensor_msgs/msg/Image`` so the frontend can render them as video elements
    without needing to know about custom ROS message packages.
    All other types pass through unchanged (they arrive as JSON on the data channel).
    """
    clean = _normalize_ros_type(ros_type)
    if clean in _IMAGE_TYPES or clean in _IMAGE_CONVERTIBLE_TYPES or clean in _AUDIO_TYPES:
        return "sensor_msgs/msg/Image"
    return ros_type

# Audio-waveform image dimensions (was the level-meter; users prefer a wiggly
# waveform showing the actual signal over the previous bar/peak indicators).
# Taller canvas + rainbow-tinted polyline so the strip reads as a "fancy" RGB
# visualiser even at small embed sizes.
_LEVEL_METER_W = 640
_LEVEL_METER_H = 200

# How many samples we keep in the rolling buffer behind the waveform.  ~100 ms
# at 48 kHz is a good compromise: long enough to look smooth on screen, short
# enough that the display still tracks live speech onsets.
_AUDIO_WAVEFORM_BUFFER_SAMPLES = 4800

# Output resolution for image-convertible tracks (segmentation, occupancy grid, etc.).
# All rendered frames are normalized to this size before being handed to the LiveKit
# codec.  Consistent dimensions prevent the I-frame / green-screen artifacts that arise
# when the codec sees a dimension change mid-stream (e.g. switching from the dark
# placeholder frame to a real rendered frame whose mask size differs from 640×480).
_STREAM_W: int = 640
_STREAM_H: int = 480


# Distinct RGBA colors for up to 8 segmentation instances (repeats beyond that)
_INSTANCE_COLORS = [
    (255, 80,  80,  180),
    (80,  220, 80,  180),
    (80,  120, 255, 180),
    (255, 210, 50,  180),
    (220, 80,  220, 180),
    (50,  220, 220, 180),
    (255, 140, 30,  180),
    (160, 255, 100, 180),
]


def _inst_score(inst: Any) -> "float | None":
    """Extract confidence score from a segmentation instance message.

    Tries ``detection_score`` (SegmentedInstance) then ``score`` / ``confidence``
    (MaskWithObjectName and other types) so one helper covers all variants.
    """
    for attr in ("detection_score", "score", "confidence"):
        v = getattr(inst, attr, None)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def _render_instance_masks(
    instances: list[tuple[Any, str, float | None, Any | None]],
    background: Any | None = None,
) -> Any | None:
    """Render a composite RGBA image overlaying all instance masks with distinct colours.

    Args:
        instances: list of (mask_ros_image, class_name, score, bbox) tuples.
                   mask_ros_image is a sensor_msgs/Image with encoding mono8/8UC1/png;
                   pixel values 0 = background, non-zero = instance.
                   score and bbox (BoundingBox2D) are optional (pass None to omit).
        background: optional RGBA numpy array to use as the canvas base instead of a
                    solid dark colour.  When provided:
                    - empty instances → return background unchanged
                    - non-empty instances → alpha-blend coloured masks over background

    Returns:
        RGBA numpy array (H, W, 4) or None if nothing could be rendered.
    """
    try:
        import cv2
        import numpy as np

        # No instances: show the source image unchanged (or nothing if not yet received)
        if not instances:
            return background

        # Determine canvas size from the first valid mask
        canvas_h, canvas_w = 0, 0
        for inst in instances:
            mask_msg = inst[0]
            if mask_msg.height > 0 and mask_msg.width > 0:
                canvas_h, canvas_w = mask_msg.height, mask_msg.width
                break
        if canvas_h == 0:
            return background

        if background is not None:
            bg = background
            bg_h, bg_w = bg.shape[:2]
            if bg_h != canvas_h or bg_w != canvas_w:
                bg = cv2.resize(bg, (canvas_w, canvas_h))
            canvas = bg.copy()
            if canvas.ndim == 2:
                canvas = cv2.cvtColor(canvas, cv2.COLOR_GRAY2RGBA)
            elif canvas.shape[2] == 3:
                canvas = cv2.cvtColor(canvas, cv2.COLOR_RGB2RGBA)
        else:
            # Opaque dark background — avoids green-chroma artifacts when transparent
            # (all-zero) RGBA pixels hit YUV chroma planes initialized to 0.
            canvas = np.full((canvas_h, canvas_w, 4), (12, 12, 18, 255), dtype=np.uint8)

        any_mask_written = False
        for idx, inst in enumerate(instances):
            mask_msg = inst[0]
            if mask_msg.height == 0 or mask_msg.width == 0:
                continue

            encoding = (getattr(mask_msg, "encoding", "") or "").lower()
            raw = np.frombuffer(bytes(mask_msg.data), dtype=np.uint8)

            if encoding == "png":
                decoded = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
                if decoded is None:
                    continue
                mask_img = decoded
            elif encoding in ("mono8", "8uc1"):
                mask_img = raw.reshape(mask_msg.height, mask_msg.width)
            elif encoding == "rgb8":
                mask_img = raw.reshape(mask_msg.height, mask_msg.width, 3).max(axis=2)
            else:
                if raw.size == mask_msg.height * mask_msg.width:
                    mask_img = raw.reshape(mask_msg.height, mask_msg.width)
                else:
                    continue

            color = _INSTANCE_COLORS[idx % len(_INSTANCE_COLORS)]
            mask_bool = mask_img > 0
            if not mask_bool.any():
                continue
            any_mask_written = True

            if background is not None:
                # Alpha-blend the instance colour over the real source image
                alpha = color[3] / 255.0
                for ch in range(3):
                    bg_ch = canvas[:, :, ch].astype(np.float32)
                    blended = (alpha * color[ch] + (1.0 - alpha) * bg_ch).clip(0, 255)
                    canvas[:, :, ch] = np.where(
                        mask_bool, blended.astype(np.uint8), canvas[:, :, ch]
                    )
                canvas[:, :, 3][mask_bool] = 255
            else:
                # No background — apply solid instance colour, always fully opaque.
                # Using color[3] (which is 180) as alpha produces semi-transparent pixels
                # that some codec paths misinterpret, so force alpha=255.
                for ch in range(3):
                    canvas[:, :, ch][mask_bool] = color[ch]
                canvas[:, :, 3][mask_bool] = 255

        if not any_mask_written:
            # Instances were all empty masks — return background (or None if unavailable)
            return background if background is not None else None

        # Second pass — bounding boxes and class-name labels.  Labels are drawn
        # with a filled background "pill" so they remain readable on top of the
        # alpha-blended mask overlays.  Confidence % was intentionally dropped
        # (clutter at small embed sizes); the class name alone is what callers
        # asked to keep visible.
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.6
        font_thickness = 1
        for idx, inst in enumerate(instances):
            if len(inst) < 4:
                continue
            _mask_msg, class_name, _score, bbox = inst[0], inst[1], inst[2], inst[3]
            if bbox is None:
                continue
            try:
                cx = float(bbox.center.position.x)
                cy = float(bbox.center.position.y)
                sx = float(bbox.size_x)
                sy = float(bbox.size_y)
                if sx <= 0 or sy <= 0:
                    continue
                x1 = max(0, int(cx - sx / 2))
                y1 = max(0, int(cy - sy / 2))
                x2 = min(canvas_w - 1, int(cx + sx / 2))
                y2 = min(canvas_h - 1, int(cy + sy / 2))
                color = _INSTANCE_COLORS[idx % len(_INSTANCE_COLORS)]
                # cv2 on RGBA: color tuple sets channels directly by index.
                cv2.rectangle(canvas, (x1, y1), (x2, y2), color, 2)

                # Always render a label so each colour pill stays identifiable
                # even when the upstream message ships an empty class_name
                # (e.g. model-inference responses that returned class_id only,
                # or converters that did not populate the name field).  The
                # numeric fallback matches the instance order, which is the
                # same order used to pick `_INSTANCE_COLORS[idx]`.
                label = (class_name or "").strip() or f"obj {idx + 1}"

                (text_w, text_h), baseline = cv2.getTextSize(
                    label, font, font_scale, font_thickness
                )
                pad_x, pad_y = 4, 3
                pill_w = text_w + 2 * pad_x
                pill_h = text_h + baseline + 2 * pad_y

                # Place pill above the bbox; flip below if it would clip the top.
                pill_x0 = x1
                pill_y0 = y1 - pill_h - 2
                if pill_y0 < 0:
                    pill_y0 = min(y2 + 2, canvas_h - pill_h - 1)
                pill_x1 = min(pill_x0 + pill_w, canvas_w - 1)
                pill_y1 = min(pill_y0 + pill_h, canvas_h - 1)

                # Filled pill matching the instance colour, fully opaque so the
                # text never blends into the mask underneath.
                cv2.rectangle(
                    canvas, (pill_x0, pill_y0), (pill_x1, pill_y1),
                    (color[0], color[1], color[2], 255), thickness=-1,
                )
                text_x = pill_x0 + pad_x
                text_y = pill_y0 + pad_y + text_h
                # Black outline + white fill for max contrast on any pill colour.
                cv2.putText(
                    canvas, label, (text_x, text_y),
                    font, font_scale, (0, 0, 0, 255),
                    font_thickness + 2, cv2.LINE_AA,
                )
                cv2.putText(
                    canvas, label, (text_x, text_y),
                    font, font_scale, (255, 255, 255, 255),
                    font_thickness, cv2.LINE_AA,
                )
            except Exception:
                pass

        return canvas

    except Exception:
        return background


def _ros_msg_to_dict(msg: Any) -> dict:
    """Convert a ROS2 message to an ordered dict for JSON serialization."""
    try:
        from rosidl_runtime_py.convert import message_to_ordereddict

        return message_to_ordereddict(msg)
    except ImportError:
        # Fallback: use __slots__ if rosidl_runtime_py is not available
        result = OrderedDict()
        for slot in msg.__slots__:
            attr_name = slot.lstrip("_")
            result[attr_name] = getattr(msg, slot)
        return result


class DataVisualizationStreamer:
    """Bridges ROS2 topic subscriptions to a LiveKit room."""

    def __init__(self, node_id: str, logger: Logger | None = None):
        self._node_id = node_id
        self._LOG = logger or LoggerFactory.get_logger(
            f"service.streaming.DataVisualizationStreamer.{node_id}"
        )
        self._room: livekit_rtc.Room | None = None
        self._ros_node = None
        self._owns_ros_node = False
        self._ros_executor = None
        self._ros_executor_thread: threading.Thread | None = None
        self._subscriptions: dict[str, Any] = {}
        self._video_sources: dict[str, livekit_rtc.VideoSource] = {}
        self._last_publish_times: dict[str, float] = {}
        self._running = False
        self._lock = threading.Lock()
        # Signalled once every video source for ``topic_configs`` is registered.
        self._sources_ready_event = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._loop_thread: threading.Thread | None = None
        # Background image buffering for image-convertible types (e.g. segmentation).
        # Maps segmentation topic name → latest RGBA numpy frame from the source image topic.
        self._background_frames: dict[str, Any] = {}
        # Cached `_render_instance_masks`-shaped tuples per segmentation topic, so when
        # a fresh background arrives we can re-render with the last-seen instances and
        # tick the video source — without this the codec starves between sporadic
        # SegmentationResult emissions (common with streaming inference) and the
        # browser shows a green frame.
        self._last_instances_by_topic: dict[str, list[tuple]] = {}
        self._background_frame_lock = threading.Lock()
        # Maps background image topic name → segmentation topic name it serves.
        self._background_topic_map: dict[str, str] = {}
        # Last-value cache used by the fallback republish loop.  When fresh data
        # has not arrived on a topic for `_CACHE_STALE_AFTER` seconds, the loop
        # re-emits the cached value on the same LiveKit channel (with a CACHED
        # overlay/marker so the UI can tell live from stale).  No separate fetch
        # endpoint exists; UIs receive cached values via normal LiveKit subscribe.
        self._last_image_frames: dict[str, Any] = {}  # topic → RGBA np.ndarray
        self._last_data_messages: dict[str, dict] = {}  # topic → unwrapped data dict
        # Rolling waveform buffer per audio topic — last
        # ``_AUDIO_WAVEFORM_BUFFER_SAMPLES`` int16 samples, used to render a
        # smooth waveform across multiple incoming chunks instead of
        # twitching once per RPC.
        self._audio_sample_buffers: dict[str, Any] = {}
        self._audio_buffer_lock = threading.Lock()
        self._last_capture_times: dict[str, float] = {}  # topic → monotonic ts
        self._cache_lock = threading.Lock()
        self._republish_task: asyncio.Task | None = None
        self._idle_watchdog_task: asyncio.Task | None = None
        # Set when the idle watchdog has decided to self-stop, so the
        # republish loop doesn't pointlessly re-fire after we've started
        # tearing down.
        self._idle_stop_requested: bool = False
        # Passive mode: live ROS subscriptions and direct push hooks are
        # gone, but the LiveKit room and republish loop are still alive.
        # Set by ``transition_to_passive`` (called when the underlying node
        # is stopped).  See that method's docstring for the trade-off.
        self._passive: bool = False
        # Optional callback the controller can wire up so the watchdog can
        # remove the streamer from its registry when it self-stops; without
        # this the streamer would stop itself but the controller would still
        # think it was active.
        self._on_idle_stop: "Callable[[], None] | None" = None
        # Replayed by _replay_initial_messages once the LiveKit connection is up.
        # Populated by start() from the controller's snapshot of the node's
        # last-output cache (see NodeBase.get_cached_output).  Initialized here
        # so direct callers of _connect_and_stream (e.g. unit tests) don't hit
        # an AttributeError when the replay step runs.
        self._initial_messages: dict[str, Any] = {}

    def start(
        self,
        room_name: str,
        publisher_token: str,
        livekit_url: str,
        topic_configs: list[dict],
        ros_node: Any = None,
        initial_messages: dict | None = None,
    ) -> None:
        """Start streaming ROS2 topics to LiveKit.

        Args:
            room_name: LiveKit room name
            publisher_token: LiveKit publisher JWT token
            livekit_url: LiveKit server WebSocket URL
            topic_configs: List of dicts with keys: topic_name, ros_type
            ros_node: Existing rclpy node to reuse for subscriptions; if None,
                      a dedicated rclpy node is created automatically.
            initial_messages: Optional ``{topic_name: ros_msg}`` map of cached
                last values to replay through the normal handlers immediately
                after the LiveKit connection is up.  Used so a UI that opens
                viz late still sees the most recent value (with the CACHED
                overlay/marker, since timestamps are stale).
        """
        with self._lock:
            if self._running:
                self._LOG.warning("Streamer already running, ignoring start request")
                return
            self._running = True

        self._sources_ready_event.clear()

        self._initial_messages: dict = dict(initial_messages or {})

        self._LOG.info(
            "Starting data visualization streamer: room=%s topics=%d initial_msgs=%d",
            room_name,
            len(topic_configs),
            len(self._initial_messages),
        )

        if ros_node is not None:
            self._ros_node = ros_node
            self._owns_ros_node = False
        else:
            self._ros_node = self._create_ros_node()
            self._owns_ros_node = self._ros_node is not None

        self._loop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(
            target=self._run_event_loop,
            args=(livekit_url, publisher_token, topic_configs),
            daemon=True,
            name=f"livekit-streamer-{self._node_id}",
        )
        self._loop_thread.start()

    def wait_for_sources_ready(self, timeout: float = 10.0) -> bool:
        """Block until every video source for this streamer is registered.

        Returns ``True`` if the readiness event fired within ``timeout``,
        ``False`` on timeout — the caller may proceed but the first
        publishes may drop until LiveKit setup completes.
        """
        return self._sources_ready_event.wait(timeout=timeout)

    def _create_ros_node(self) -> Any:
        """Create a dedicated rclpy node and start spinning it in a background thread."""
        try:
            import rclpy
            from rclpy.executors import SingleThreadedExecutor

            if not rclpy.ok():
                rclpy.init()

            safe_id = self._node_id.replace(":", "_").replace("-", "_")
            node = rclpy.create_node(f"viz_streamer_{safe_id}")
            executor = SingleThreadedExecutor()
            executor.add_node(node)

            spin_thread = threading.Thread(
                target=executor.spin,
                daemon=True,
                name=f"livekit-ros-spin-{self._node_id}",
            )
            spin_thread.start()

            self._ros_executor = executor
            self._ros_executor_thread = spin_thread
            self._LOG.info("Created dedicated ROS2 node for visualization subscriptions")
            return node
        except Exception as e:
            self._LOG.warning("Could not create dedicated ROS2 node: %s", e)
            return None

    def transition_to_passive(self) -> None:
        """Tear down active live-data ingestion; keep the cached republisher.

        Called by the controller when the underlying node stops.  After this
        runs the streamer no longer:
          * holds ROS2 subscriptions on the source node's output topics, or
          * spins its own ROS executor / dedicated rclpy node.

        It still:
          * keeps the LiveKit room connected (UIs stay subscribed), and
          * runs the republish loop, which re-emits the most recently
            captured frame/data on each topic at a low rate with the
            CACHED overlay/marker.

        Idempotent — safe to call repeatedly, even on an already-passive
        streamer (the second call is a no-op).
        """
        if getattr(self, "_passive", False):
            return
        self._passive = True
        self._LOG.info(
            "Transitioning streamer to passive cache-only mode for node %s "
            "(dropping live ROS subscriptions; keeping LiveKit + republish loop)",
            self._node_id,
        )
        self._teardown_live_subscriptions()

    def _teardown_live_subscriptions(self) -> None:
        """Drop ROS subscriptions and the owned ROS executor.

        Used by both ``transition_to_passive`` (which preserves the LiveKit
        side) and ``stop`` (which then also disconnects the room).
        """
        if self._ros_node:
            for topic_name, sub in self._subscriptions.items():
                try:
                    self._ros_node.destroy_subscription(sub)
                except Exception as e:
                    self._LOG.warning("Error destroying subscription for %s: %s", topic_name, e)
        self._subscriptions.clear()

        if self._owns_ros_node:
            if self._ros_executor:
                try:
                    self._ros_executor.shutdown()
                except Exception as e:
                    self._LOG.warning("Error shutting down ROS executor: %s", e)
            if self._ros_executor_thread:
                self._ros_executor_thread.join(timeout=3.0)
            if self._ros_node:
                try:
                    self._ros_node.destroy_node()
                except Exception as e:
                    self._LOG.warning("Error destroying ROS node: %s", e)
            self._ros_executor = None
            self._ros_executor_thread = None
            self._owns_ros_node = False

    def stop(self) -> None:
        """Stop streaming and clean up resources."""
        with self._lock:
            if not self._running:
                return
            self._running = False

        self._LOG.info("Stopping data visualization streamer for node %s", self._node_id)

        # Tear down ROS subscriptions and owned ROS executor (idempotent if
        # the streamer was already passive).
        self._teardown_live_subscriptions()

        # Disconnect from LiveKit
        if self._loop and self._room:
            future = asyncio.run_coroutine_threadsafe(self._disconnect_room(), self._loop)
            try:
                future.result(timeout=5.0)
            except Exception as e:
                self._LOG.warning("Error disconnecting from LiveKit room: %s", e)

        if self._loop_thread:
            self._loop_thread.join(timeout=5.0)

        self._video_sources.clear()
        self._last_publish_times.clear()
        with self._background_frame_lock:
            self._background_frames.clear()
            self._last_instances_by_topic.clear()
        self._background_topic_map.clear()
        self._room = None
        self._loop = None
        self._loop_thread = None
        self._LOG.info("Data visualization streamer stopped for node %s", self._node_id)

    @property
    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # Last-value cache + fallback republish loop
    # ------------------------------------------------------------------
    #
    # Records the most recent payload per topic and re-emits it on the
    # existing LiveKit channels at low frequency when the live stream goes
    # quiet.  Repurposes the same data path so any UI subscribed to the room
    # — at any point during the graph's life — sees the last value.
    #
    # Live captures call ``_remember_image_frame`` / ``_remember_data`` to
    # update the cache.  ``_republish_loop`` watches the per-topic timestamps
    # and stamps cached frames/messages with a CACHED indicator before
    # re-emitting.

    def _capture_to_livekit(
        self, source: Any, topic_name: str, livekit_frame: Any,
    ) -> None:
        """Push one frame to the LiveKit source; log first capture per topic.

        The one-shot first-capture log marks the point where the whole
        publish → render → encode → LiveKit path has succeeded at least once
        for the topic.
        """
        source.capture_frame(livekit_frame)
        captured = getattr(self, "_first_capture_logged", None)
        if captured is None:
            captured = set()
            self._first_capture_logged = captured
        if topic_name not in captured:
            captured.add(topic_name)
            self._LOG.info(
                "viz: first frame captured to LiveKit for topic %r",
                topic_name,
            )

    def _remember_image_frame(self, topic_name: str, rgba_frame: Any) -> None:
        """Record the latest RGBA frame published for an image topic."""
        if rgba_frame is None:
            return
        with self._cache_lock:
            self._last_image_frames[topic_name] = rgba_frame
            self._last_data_messages.pop(topic_name, None)
            self._last_capture_times[topic_name] = time.monotonic()

    def _remember_data(self, topic_name: str, data_dict: dict | None) -> None:
        """Record the latest unwrapped data payload for a non-image topic."""
        if data_dict is None:
            return
        with self._cache_lock:
            self._last_data_messages[topic_name] = data_dict
            self._last_image_frames.pop(topic_name, None)
            self._last_capture_times[topic_name] = time.monotonic()

    def clear_cache(self) -> None:
        """Drop all cached values.  Controller calls this on graph teardown."""
        with self._cache_lock:
            self._last_image_frames.clear()
            self._last_data_messages.clear()
            self._last_capture_times.clear()

    @staticmethod
    def _draw_cached_overlay(rgba_frame: Any, age_seconds: float) -> Any:
        """Return a copy of ``rgba_frame`` with a CACHED indicator drawn on it."""
        try:
            import cv2
            import numpy as np

            arr = np.ascontiguousarray(rgba_frame)
            h, w = arr.shape[:2]
            label = f"CACHED · {int(age_seconds)}s ago"
            # Translucent black bar across the bottom; amber text on top.
            bar_h = max(24, h // 16)
            y0 = max(0, h - bar_h)
            bar_color = (0, 0, 0, 200) if arr.shape[2] == 4 else (0, 0, 0)
            cv2.rectangle(arr, (0, y0), (w, h), bar_color, thickness=-1)
            text_color = (255, 200, 0, 255) if arr.shape[2] == 4 else (255, 200, 0)
            cv2.putText(
                arr, label, (8, h - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, text_color, 1, cv2.LINE_AA,
            )
            return arr
        except Exception:
            return rgba_frame

    @staticmethod
    def _wrap_cached_payload(data_dict: dict, age_seconds: float) -> dict:
        """Add a ``_meta.cached`` marker to a data payload."""
        wrapped = dict(data_dict) if isinstance(data_dict, dict) else {"data": data_dict}
        meta = dict(wrapped.get("_meta") or {})
        meta.update({"cached": True, "age_seconds": round(age_seconds, 2)})
        wrapped["_meta"] = meta
        return wrapped

    def _republish_image(self, topic_name: str, age: float) -> None:
        """Re-capture a cached image frame with overlay onto the LiveKit source."""
        source = self._video_sources.get(topic_name)
        if source is None:
            return
        with self._cache_lock:
            frame = self._last_image_frames.get(topic_name)
        if frame is None:
            return
        try:
            import cv2
            import numpy as np

            arr = np.array(frame, copy=True)  # don't mutate cached frame
            if arr.ndim != 3 or arr.shape[2] not in (3, 4):
                return
            if arr.shape[2] == 3:
                arr = cv2.cvtColor(arr, cv2.COLOR_RGB2RGBA)
            if arr.shape[0] != _STREAM_H or arr.shape[1] != _STREAM_W:
                arr = cv2.resize(arr, (_STREAM_W, _STREAM_H), interpolation=cv2.INTER_LINEAR)
            arr = self._draw_cached_overlay(arr, age)
            livekit_frame = livekit_rtc.VideoFrame(
                width=_STREAM_W, height=_STREAM_H,
                type=livekit_rtc.VideoBufferType.RGBA,
                data=arr.tobytes(),
            )
            source.capture_frame(livekit_frame)
        except Exception as exc:
            self._LOG.debug("Cached image republish failed for %s: %s", topic_name, exc)

    def _republish_data(self, topic_name: str, age: float) -> None:
        """Re-emit a cached data payload through the LiveKit data channel."""
        with self._cache_lock:
            data_dict = self._last_data_messages.get(topic_name)
        if data_dict is None or self._loop is None or self._room is None:
            return
        if not self._room.local_participant:
            return
        try:
            public_name = livekit_safe_viz_name(topic_name)
            payload = json.dumps(
                {
                    "nodeId": self._node_id,
                    "topicName": public_name,
                    "data": self._wrap_cached_payload(data_dict, age),
                    "timestamp": time.time(),
                },
                default=str,
            ).encode("utf-8")
            asyncio.run_coroutine_threadsafe(
                self._room.local_participant.publish_data(
                    payload=payload, reliable=True, topic=public_name,
                ),
                self._loop,
            )
        except Exception as exc:
            self._LOG.debug("Cached data republish failed for %s: %s", topic_name, exc)

    async def _republish_loop(self) -> None:
        """Tick at ``_CACHE_REPUBLISH_INTERVAL`` and re-emit any stale topic.

        A topic is "stale" if no fresh capture has occurred in the last
        ``_CACHE_STALE_AFTER`` seconds.  When fresh data is flowing the loop is
        a no-op; when it isn't, every topic with a cached value gets ticked at
        ~1 Hz with a CACHED indicator so subscribers see the last value.
        """
        try:
            while self._running:
                await asyncio.sleep(_CACHE_REPUBLISH_INTERVAL)
                now = time.monotonic()
                with self._cache_lock:
                    snapshot = list(self._last_capture_times.items())
                for topic, last_ts in snapshot:
                    age = now - last_ts
                    if age < _CACHE_STALE_AFTER:
                        continue
                    if topic in self._last_image_frames:
                        self._republish_image(topic, age)
                    elif topic in self._last_data_messages:
                        self._republish_data(topic, age)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # never let the loop die silently
            self._LOG.error("Republish loop error: %s", exc)

    async def _idle_watchdog(self) -> None:
        """Self-stop after a long period with no UI subscribers in the room.

        ``stop_node`` no longer tears down active streamers, so this is the
        only mechanism that releases the LiveKit room / ROS2 node / asyncio
        loop when the user closes their browser tab without explicitly
        ending the viz session.

        We measure idleness by ``room.remote_participants``: any non-empty
        set means a UI is currently subscribed to our publisher tracks.
        Once that set has been empty for ``_IDLE_NO_SUBSCRIBER_SECONDS``
        consecutive seconds, we tear down.  The next StartDataVisualization
        call will re-create a fresh streamer and re-seed it from
        NodeBase's per-port last-output cache, so the cached frames
        survive the recycle.
        """
        last_seen_subscriber_at = time.monotonic()
        try:
            while self._running and not self._idle_stop_requested:
                await asyncio.sleep(_IDLE_WATCHDOG_INTERVAL)
                room = self._room
                if room is None:
                    continue
                try:
                    has_subscriber = bool(getattr(room, "remote_participants", {}) or {})
                except Exception:
                    has_subscriber = True  # err on the side of staying alive
                now = time.monotonic()
                if has_subscriber:
                    last_seen_subscriber_at = now
                    continue
                idle_for = now - last_seen_subscriber_at
                if idle_for < _IDLE_NO_SUBSCRIBER_SECONDS:
                    continue
                self._LOG.info(
                    "Idle watchdog firing: no UI subscriber for %.0fs (>=%.0fs); "
                    "tearing down streamer for node %s",
                    idle_for, _IDLE_NO_SUBSCRIBER_SECONDS, self._node_id,
                )
                self._idle_stop_requested = True
                # Trigger our own stop() from a separate thread so we don't
                # deadlock waiting on this loop to drain itself.
                cb = self._on_idle_stop
                threading.Thread(
                    target=self._self_stop,
                    args=(cb,),
                    name=f"viz-streamer-idle-stop-{self._node_id}",
                    daemon=True,
                ).start()
                return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # never let the loop die silently
            self._LOG.error("Idle watchdog error: %s", exc)

    def _self_stop(self, on_stop: "Callable[[], None] | None") -> None:
        """Off-loop self-stop helper used by the idle watchdog."""
        try:
            self.stop()
        except Exception as exc:
            self._LOG.warning("Self-stop after idle timeout failed: %s", exc)
        if on_stop is not None:
            try:
                on_stop()
            except Exception as exc:
                self._LOG.warning("on_idle_stop callback failed: %s", exc)

    def push_background_frame(self, seg_topic: str, rgba_frame: "np.ndarray") -> None:
        """Push an RGBA background frame directly (bypasses ROS subscription).

        Used by nodes that receive image data via MQTT rather than ROS2, so a ROS
        subscription on the camera topic would receive nothing.  The node decodes the
        frame itself and calls this method to feed the compositor.

        Also ticks the LiveKit video source by re-rendering with the last-seen
        instances on this topic. The compositor here is the only place that calls
        ``source.capture_frame``; normally that only happens when a SegmentationResult
        arrives, but in streaming inference modes results may be emitted at <1 fps
        (or not at all during model warm-up). Re-capturing on every fresh background
        keeps the codec at the input image rate (~20 fps) so the browser doesn't see
        a green-frame stall.
        """
        with self._background_frame_lock:
            self._background_frames[seg_topic] = rgba_frame
            last_instances = list(self._last_instances_by_topic.get(seg_topic, []))
        # Render + capture outside the lock so we don't hold it across cv2 work.
        self._render_and_capture_segmentation(seg_topic, last_instances, rgba_frame)

    def push_segmentation_result(self, seg_topic: str, ros_msg: Any) -> None:
        """Push a segmentation result directly, bypassing the ROS2 subscription.

        MQTT-only nodes call NodeBase.publish() which sends only to MQTT — the
        DataVisualizationStreamer's ROS2 subscription for the segments topic
        never fires.  Those nodes must call this method explicitly after
        publishing so that segments are composited onto the background and
        sent to LiveKit.

        Accepts both upstream variants:
        - ``SegmentationResult`` — ``.instances`` of ``MaskWithObjectName``
          (fields: ``mask``, ``class_name``, ``score``, ``bounding_box``).
        - ``SegmentedInstanceArray`` — ``.segmented_instances`` of
          ``SegmentedInstance`` (fields: ``instance_mask``, ``class_name``,
          ``detection_score``, ``bounding_box``).
        """
        try:
            if hasattr(ros_msg, "instances"):
                items = ros_msg.instances
            elif hasattr(ros_msg, "segmented_instances"):
                items = ros_msg.segmented_instances
            else:
                items = []
            instance_tuples = [
                (
                    getattr(inst, "mask", None) or getattr(inst, "instance_mask", None),
                    getattr(inst, "class_name", "") or "",
                    _inst_score(inst),
                    getattr(inst, "bounding_box", None),
                )
                for inst in items
            ]
        except Exception as exc:
            self._LOG.warning(
                "push_segmentation_result: failed to read instances from %s: %s",
                type(ros_msg).__name__, exc,
            )
            return
        n = len(instance_tuples)
        source_ready = self._video_sources.get(seg_topic) is not None
        self._LOG.debug(
            "push_segmentation_result: topic=%s instances=%d source_ready=%s",
            seg_topic, n, source_ready,
        )
        # One-time diagnostic: log the first batch of class_names per topic so we
        # can tell whether labels are missing in the viz because upstream sent
        # them empty (vs. a render-side bug).  Logged once per (topic, msg type).
        diag_key = (seg_topic, type(ros_msg).__name__)
        logged = getattr(self, "_seg_class_names_logged", None)
        if logged is None:
            logged = set()
            self._seg_class_names_logged = logged
        if diag_key not in logged and n > 0:
            logged.add(diag_key)
            names = [t[1] for t in instance_tuples]
            empties = sum(1 for s in names if not s)
            self._LOG.info(
                "segmentation viz first batch: topic=%s type=%s instances=%d "
                "class_names=%r empty=%d",
                seg_topic, type(ros_msg).__name__, n, names, empties,
            )
        with self._background_frame_lock:
            background = self._background_frames.get(seg_topic)
            self._last_instances_by_topic[seg_topic] = list(instance_tuples)
        if not source_ready:
            self._LOG.warning(
                "push_segmentation_result: video source not ready for topic %s "
                "— %d instance(s) stored, will render when source is available",
                seg_topic, n,
            )
            return
        self._render_and_capture_segmentation(seg_topic, instance_tuples, background)

    def push_image_frame(self, topic_name: str, rgba_frame: Any) -> None:
        """Push an RGBA image frame directly for MQTT-only nodes.

        MQTT-only nodes (e.g. CameraStreamNode) call NodeBase.publish() which only
        sends to MQTT; the DataVisualizationStreamer's ROS2 subscription for the
        image topic never fires.  Those nodes must call this after publishing each
        frame so the LiveKit video track stays live.
        """
        source = self._video_sources.get(topic_name)
        if source is None:
            return
        try:
            import cv2

            if rgba_frame.shape[0] != _STREAM_H or rgba_frame.shape[1] != _STREAM_W:
                rgba_frame = cv2.resize(
                    rgba_frame, (_STREAM_W, _STREAM_H), interpolation=cv2.INTER_LINEAR
                )
            livekit_frame = livekit_rtc.VideoFrame(
                width=_STREAM_W,
                height=_STREAM_H,
                type=livekit_rtc.VideoBufferType.RGBA,
                data=rgba_frame.tobytes(),
            )
            self._capture_to_livekit(source, topic_name, livekit_frame)
            self._remember_image_frame(topic_name, rgba_frame)
        except Exception as exc:
            self._LOG.warning("push_image_frame failed for topic %s: %s", topic_name, exc)

    def _render_and_capture_segmentation(
        self,
        topic_name: str,
        instances: list[tuple],
        background: "np.ndarray | None",
    ) -> None:
        """Render the instance overlay and push one frame to the LiveKit video source.

        Shared by the SegmentationResult / SegmentedInstanceArray ROS-message path and
        the background-frame path (which ticks the source even when no new mask data
        has arrived). ``instances`` are the already-shaped tuples
        ``_render_instance_masks`` expects.
        """
        source = self._video_sources.get(topic_name)
        if source is None:
            return
        try:
            import cv2
            import numpy as np
        except ImportError:
            self._LOG.error("cv2/numpy not available for topic %s", topic_name)
            return
        try:
            frame = _render_instance_masks(instances, background=background)
            if frame is None:
                # No instances and no background yet — dark placeholder keeps
                # the video track alive until real data arrives.
                frame = np.full(
                    (_STREAM_H, _STREAM_W, 4), (12, 12, 18, 255), dtype=np.uint8
                )
            # Normalize to the declared stream resolution so the LiveKit codec always
            # receives frames of the same size. Dimension changes mid-stream cause
            # H.264/VP8 to lose its reference frame and produce green artefacts.
            if frame.shape[0] != _STREAM_H or frame.shape[1] != _STREAM_W:
                frame = cv2.resize(
                    frame, (_STREAM_W, _STREAM_H), interpolation=cv2.INTER_LINEAR
                )
            livekit_frame = livekit_rtc.VideoFrame(
                width=_STREAM_W,
                height=_STREAM_H,
                type=livekit_rtc.VideoBufferType.RGBA,
                data=frame.tobytes(),
            )
            self._capture_to_livekit(source, topic_name, livekit_frame)
            self._remember_image_frame(topic_name, frame)
        except Exception as e:
            self._LOG.warning(
                "render+capture for topic %s failed: %s", topic_name, e
            )

    def _run_event_loop(
        self,
        livekit_url: str,
        publisher_token: str,
        topic_configs: list[dict],
    ) -> None:
        """Run the asyncio event loop in a background thread."""
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(
                self._connect_and_stream(livekit_url, publisher_token, topic_configs)
            )
        except Exception as e:
            self._LOG.error("LiveKit event loop error: %s", e)
        finally:
            self._running = False
            try:
                self._loop.run_until_complete(self._loop.shutdown_asyncgens())
            except Exception:
                pass

    async def _connect_and_stream(
        self,
        livekit_url: str,
        publisher_token: str,
        topic_configs: list[dict],
    ) -> None:
        """Connect to LiveKit room and set up ROS2 subscriptions."""
        self._room = livekit_rtc.Room()
        await self._room.connect(livekit_url, publisher_token)
        self._LOG.info("Connected to LiveKit room as publisher (node=%s)", self._node_id)

        # Build background topic → segmentation topic mapping before subscribing
        for config in topic_configs:
            if config.get("role") == "background":
                bg_topic = config["topic_name"]
                seg_topic = config.get("background_for", "")
                if seg_topic:
                    self._background_topic_map[bg_topic] = seg_topic

        # Set up video sources for all types that stream via video tracks.
        # Background topics are never published as video tracks directly.
        for config in topic_configs:
            ros_type = _normalize_ros_type(config.get("ros_type", ""))
            topic_name = config["topic_name"]
            if config.get("role") == "background":
                continue
            if ros_type in _IMAGE_TYPES or ros_type in _IMAGE_CONVERTIBLE_TYPES or ros_type in _AUDIO_TYPES:
                await self._setup_video_track(topic_name)

        self._sources_ready_event.set()

        # Subscribe to ROS2 topics
        self._subscribe_ros_topics(topic_configs)

        # Replay any cached "last values" provided by the controller — pumps
        # the most recent message per output port through the normal handlers
        # so a UI that just connected sees data immediately even if the next
        # live publish is far away.  The republish loop will then re-emit
        # these with the CACHED overlay/marker until fresh data arrives.
        self._replay_initial_messages(topic_configs)

        # Start the cache fallback republisher.  Schedules itself on this loop
        # so when the live stream goes quiet, cached frames/data are re-emitted
        # on the same LiveKit channels at low rate with a CACHED indicator.
        self._republish_task = asyncio.ensure_future(self._republish_loop())
        # Start the idle watchdog — stops this streamer once the room has
        # been empty of UI subscribers for a while, so we don't leak the
        # LiveKit room when the user closes their tab without sending
        # StopDataVisualization.
        self._idle_watchdog_task = asyncio.ensure_future(self._idle_watchdog())

        # Keep the loop alive until stopped
        while self._running:
            await asyncio.sleep(0.5)

        # Drain the republisher and idle watchdog cleanly so we don't leak
        # tasks across loops.
        for task_attr in ("_republish_task", "_idle_watchdog_task"):
            task = getattr(self, task_attr, None)
            if task is not None:
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
                setattr(self, task_attr, None)

    async def _setup_video_track(self, topic_name: str) -> None:
        """Create a LiveKit video source and publish it as a track.

        The track is named with the LiveKit-safe public name (node-id keyed, no
        digit-leading token) so the publish doesn't get rejected and the UI —
        which subscribes by ``topicName`` — can bind. The source is keyed by the
        internal (real ROS) ``topic_name`` so frame dispatch is unchanged.
        """
        source = livekit_rtc.VideoSource(width=_STREAM_W, height=_STREAM_H)
        public_name = livekit_safe_viz_name(topic_name)
        track = livekit_rtc.LocalVideoTrack.create_video_track(public_name, source)
        options = livekit_rtc.TrackPublishOptions()
        options.source = livekit_rtc.TrackSource.SOURCE_CAMERA
        await self._room.local_participant.publish_track(track, options)
        self._video_sources[topic_name] = source
        self._LOG.info(
            "Published video track for topic: %s (livekit name: %s)",
            topic_name, public_name,
        )

    def add_topics(self, new_topic_configs: list[dict]) -> bool:
        """Extend a running streamer with additional topics.

        Publishes a new video track per applicable config on the *existing*
        LiveKit participant and adds ROS2 subscriptions, without touching
        the room connection.  Keeping the participant alive across topic
        expansions is what lets UI panels for previously-published topics
        keep rendering — a stop+reconnect cycle replaces the participant's
        SID, and UI clients that don't re-bind on identity-match silently
        lose the existing tracks.

        Returns True if the extension was scheduled; False if the streamer
        isn't in a state to accept new topics (not running or no event loop).

        Note: scheduling does not require the room to be connected yet — the
        coroutine waits out the connect window (see ``_add_topics_coroutine``),
        so a second Start arriving mid-connect no longer fails the extension.
        """
        if not self._running or self._loop is None:
            self._LOG.warning(
                "add_topics: streamer for %s not ready (running=%s loop=%s) "
                "— extension skipped",
                self._node_id, self._running, bool(self._loop),
            )
            return False
        asyncio.run_coroutine_threadsafe(
            self._add_topics_coroutine(new_topic_configs), self._loop,
        )
        return True

    async def _await_sources_ready(self, timeout: float) -> bool:
        """Wait until the LiveKit room has connected (``_sources_ready_event``
        is set after ``room.connect`` completes, so ``local_participant`` is
        then safe to access).

        Returns False if the streamer stops or the deadline elapses before the
        room is ready.
        """
        deadline = time.monotonic() + timeout
        while not self._sources_ready_event.is_set():
            if not self._running:
                return False
            if time.monotonic() >= deadline:
                return False
            await asyncio.sleep(_ADD_TOPICS_READY_POLL_SEC)
        return True

    async def _add_topics_coroutine(self, new_topic_configs: list[dict]) -> None:
        """Set up new video tracks + ROS subscriptions on the live streamer.

        Idempotent: topics already configured (present in
        ``_video_sources`` / ``_subscriptions``) are silently skipped, so
        callers may pass any superset of the currently-active configs.
        """
        try:
            # The room may still be mid-connect when a second Start triggers
            # this extension. Publishing a track touches ``local_participant``,
            # which raises "cannot access local participant before connecting"
            # until the connect completes — so wait for the room to be ready
            # first. If it never connects (e.g. signalling is blocked), bail
            # cleanly instead of raising.
            if not self._sources_ready_event.is_set():
                ready = await self._await_sources_ready(_ADD_TOPICS_READY_TIMEOUT_SEC)
                if not ready:
                    self._LOG.warning(
                        "add_topics: streamer for %s did not finish connecting within %.1fs "
                        "— extension skipped (new topics: %s)",
                        self._node_id,
                        _ADD_TOPICS_READY_TIMEOUT_SEC,
                        [c.get("topic_name") for c in new_topic_configs],
                    )
                    return

            # Background mappings first so segmentation callbacks find the
            # right segmentation target when their frames start arriving.
            for config in new_topic_configs:
                if config.get("role") == "background":
                    bg_topic = config["topic_name"]
                    seg_topic = config.get("background_for", "")
                    if seg_topic and bg_topic not in self._background_topic_map:
                        self._background_topic_map[bg_topic] = seg_topic

            for config in new_topic_configs:
                ros_type = _normalize_ros_type(config.get("ros_type", ""))
                topic_name = config["topic_name"]
                if config.get("role") == "background":
                    continue
                if topic_name in self._video_sources:
                    continue
                if (
                    ros_type in _IMAGE_TYPES
                    or ros_type in _IMAGE_CONVERTIBLE_TYPES
                    or ros_type in _AUDIO_TYPES
                ):
                    await self._setup_video_track(topic_name)

            # ROS subscriptions; ``_subscribe_ros_topics`` already dedupes
            # against ``_subscriptions``.
            self._subscribe_ros_topics(new_topic_configs)
        except Exception as exc:
            self._LOG.warning(
                "add_topics: failed to extend streamer for %s: %s",
                self._node_id, exc,
            )

    async def _disconnect_room(self) -> None:
        """Disconnect from the LiveKit room."""
        if self._room:
            await self._room.disconnect()

    def _subscribe_ros_topics(self, topic_configs: list[dict]) -> None:
        """Create ROS2 subscriptions for requested topics."""
        if not self._ros_node:
            self._LOG.warning("No ROS node available, cannot subscribe to topics")
            return

        from neuraverse_sdk.dataflow.dataflow_helper import _import_msg_type

        for config in topic_configs:
            topic_name = config["topic_name"]
            ros_type = _normalize_ros_type(config.get("ros_type", ""))
            role = config.get("role", "")

            # Skip duplicate subscriptions (same topic may appear as background for multiple targets)
            if topic_name in self._subscriptions:
                continue

            try:
                msg_class = _import_msg_type(ros_type)
            except Exception as e:
                self._LOG.error(
                    "Failed to import ROS message type %s for topic %s: %s",
                    ros_type,
                    topic_name,
                    e,
                )
                continue

            if role == "background":
                callback = self._make_background_callback(topic_name, ros_type)
            else:
                self._last_publish_times[topic_name] = 0.0
                callback = self._make_ros_callback(topic_name, ros_type)

            sub = self._ros_node.create_subscription(msg_class, topic_name, callback, 10)
            self._subscriptions[topic_name] = sub
            self._LOG.info(
                "Subscribed to ROS2 topic: %s (type=%s, role=%s)",
                topic_name,
                ros_type,
                role or "primary",
            )

    def _replay_initial_messages(self, topic_configs: list[dict]) -> None:
        """Replay cached last-value messages through the live handlers.

        ``self._initial_messages`` is a ``{topic_name: ros_msg}`` map populated
        by the caller from each node's ``NodeBase`` last-output cache.  We feed
        each one through the same handler the live ROS subscription would,
        which (a) immediately publishes onto LiveKit so a UI that connected
        late sees a frame, and (b) populates the streamer's own cache so the
        republish loop has something to re-emit at low rate with the CACHED
        overlay/marker.
        """
        if not self._initial_messages:
            return
        type_by_topic: dict[str, str] = {}
        role_by_topic: dict[str, str] = {}
        for cfg in topic_configs:
            t_name = cfg.get("topic_name", "")
            type_by_topic[t_name] = _normalize_ros_type(cfg.get("ros_type", ""))
            role_by_topic[t_name] = cfg.get("role", "")
        for topic_name, msg in self._initial_messages.items():
            if msg is None:
                continue
            ros_type = type_by_topic.get(topic_name)
            if not ros_type:
                continue
            try:
                if role_by_topic.get(topic_name) == "background":
                    # Background images feed the segmentation compositor —
                    # the make-background-callback path takes ROS Image and
                    # decodes to RGBA; replicate that conversion here.
                    rgba = self._decode_image_to_rgba(ros_type, msg, topic_name)
                    if rgba is not None:
                        seg_topic = self._background_topic_map.get(topic_name)
                        if seg_topic:
                            self.push_background_frame(seg_topic, rgba)
                elif ros_type in _IMAGE_TYPES:
                    self._handle_image_message(topic_name, ros_type, msg)
                elif ros_type in _IMAGE_CONVERTIBLE_TYPES:
                    self._handle_image_convertible_message(topic_name, ros_type, msg)
                elif ros_type in _AUDIO_TYPES:
                    self._handle_audio_message(topic_name, msg)
                else:
                    self._handle_data_message(topic_name, msg)
            except Exception as exc:
                self._LOG.debug(
                    "Initial-message replay failed for topic %s: %s", topic_name, exc
                )

    def _make_ros_callback(self, topic_name: str, ros_type: str):
        """Create a throttled ROS2 callback that bridges messages to LiveKit."""
        is_image = ros_type in _IMAGE_TYPES
        is_image_convertible = ros_type in _IMAGE_CONVERTIBLE_TYPES
        is_audio = ros_type in _AUDIO_TYPES
        is_scalar = ros_type in _SCALAR_TYPES

        # Image, image-convertible, and audio types publish video frames — no throttle needed
        min_interval = (
            0.0
            if (is_image or is_image_convertible or is_audio)
            else (_SCALAR_MIN_INTERVAL if is_scalar else _COMPLEX_MIN_INTERVAL)
        )

        def callback(msg):
            if not self._running:
                return

            now = time.monotonic()
            if min_interval > 0:
                elapsed = now - self._last_publish_times.get(topic_name, 0.0)
                if elapsed < min_interval:
                    return
            self._last_publish_times[topic_name] = now

            if is_image:
                self._handle_image_message(topic_name, ros_type, msg)
            elif is_image_convertible:
                self._handle_image_convertible_message(topic_name, ros_type, msg)
            elif is_audio:
                self._handle_audio_message(topic_name, msg)
            else:
                self._handle_data_message(topic_name, msg)

        return callback

    def _make_background_callback(self, topic_name: str, ros_type: str):
        """Create a ROS2 callback that buffers the latest image as a background frame."""
        def callback(msg):
            if not self._running:
                return
            frame = self._decode_image_to_rgba(ros_type, msg, topic_name)
            if frame is not None:
                seg_topic = self._background_topic_map.get(topic_name, "")
                if seg_topic:
                    with self._background_frame_lock:
                        self._background_frames[seg_topic] = frame
        return callback

    def _decode_image_to_rgba(self, ros_type: str, msg: Any, topic_name: str = "") -> Any | None:
        """Decode a ROS image message to an RGBA numpy array. Returns None on failure."""
        try:
            import cv2
            import numpy as np

            if ros_type == "sensor_msgs/msg/CompressedImage":
                raw = bytes(msg.data)
                fmt = getattr(msg, "format", "unknown")
                if len(raw) == 0:
                    self._LOG.warning(
                        "CompressedImage on %s has empty data (format=%s)", topic_name or ros_type, fmt
                    )
                    return None
                np_arr = np.frombuffer(raw, np.uint8)
                bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                if bgr is None:
                    self._LOG.warning(
                        "cv2.imdecode failed for CompressedImage on %s "
                        "(format=%r, data_len=%d, first_bytes=%s)",
                        topic_name or ros_type,
                        fmt,
                        len(raw),
                        raw[:4].hex(),
                    )
                    return None
                return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGBA)

            encoding = (getattr(msg, "encoding", "") or "").lower()
            raw = bytes(msg.data)
            h, w = msg.height, msg.width

            if encoding == "rgb8":
                rgb = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 3)
                return cv2.cvtColor(rgb, cv2.COLOR_RGB2RGBA)

            elif encoding in ("bgr8", "8uc3"):
                bgr = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 3)
                return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGBA)

            elif encoding == "mono8":
                mono = np.frombuffer(raw, dtype=np.uint8).reshape(h, w)
                return cv2.cvtColor(mono, cv2.COLOR_GRAY2RGBA)

            elif encoding in ("rgba8",):
                return np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 4).copy()

            elif encoding in ("bgra8",):
                bgra = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 4)
                return cv2.cvtColor(bgra, cv2.COLOR_BGRA2RGBA)

            elif encoding in ("16uc1", "mono16"):
                depth = np.frombuffer(raw, dtype=np.uint16).reshape(h, w)
                valid = depth > 0
                norm = np.zeros((h, w), dtype=np.uint8)
                if valid.any():
                    d_min = float(depth[valid].min())
                    d_max = float(np.percentile(depth[valid], 95))
                    if d_max > d_min:
                        # Invert: nearer (d_min) → 255, farther (d_max) → 0
                        norm[valid] = (
                            (1.0 - (depth[valid].astype(np.float32) - d_min) / (d_max - d_min)) * 255
                        ).clip(0, 255).astype(np.uint8)
                return cv2.cvtColor(norm, cv2.COLOR_GRAY2RGBA)

            elif encoding in ("32fc1",):
                depth = np.frombuffer(raw, dtype=np.float32).reshape(h, w)
                valid = np.isfinite(depth) & (depth > 0)
                norm = np.zeros((h, w), dtype=np.uint8)
                if valid.any():
                    d_min = float(depth[valid].min())
                    d_max = float(np.percentile(depth[valid], 95))
                    if d_max > d_min:
                        # Invert: nearer → 255, farther → 0
                        norm[valid] = (
                            (1.0 - (depth[valid] - d_min) / (d_max - d_min)) * 255
                        ).clip(0, 255).astype(np.uint8)
                return cv2.cvtColor(norm, cv2.COLOR_GRAY2RGBA)

            else:
                self._LOG.warning(
                    "Unsupported image encoding %r for topic %s — skipping frame",
                    encoding, topic_name or ros_type,
                )
                return None

        except Exception as exc:
            self._LOG.warning(
                "Error decoding image for topic %s (ros_type=%s): %s",
                topic_name or ros_type, ros_type, exc,
            )
            return None

    def _handle_data_message(self, topic_name: str, msg: Any) -> None:
        """Serialize ROS message to JSON and publish via LiveKit data channel."""
        try:
            data_dict = _ros_msg_to_dict(msg)
            self._remember_data(topic_name, dict(data_dict) if data_dict else None)
            public_name = livekit_safe_viz_name(topic_name)
            payload = json.dumps(
                {
                    "nodeId": self._node_id,
                    "topicName": public_name,
                    "data": data_dict,
                    "timestamp": time.time(),
                },
                default=str,
            ).encode("utf-8")

            if self._loop and self._room and self._room.local_participant:
                self._LOG.debug("Publishing data channel message: topic=%s len=%d", public_name, len(payload))

                def _on_done(fut):
                    try:
                        fut.result()
                    except Exception as e:
                        self._LOG.warning("Data channel publish failed for topic %s: %s", public_name, e)

                future = asyncio.run_coroutine_threadsafe(
                    self._room.local_participant.publish_data(
                        payload=payload,
                        reliable=True,
                        topic=public_name,
                    ),
                    self._loop,
                )
                future.add_done_callback(_on_done)
            else:
                self._LOG.warning(
                    "Cannot publish data for topic %s: loop=%s room=%s participant=%s",
                    topic_name,
                    bool(self._loop),
                    bool(self._room),
                    bool(self._room and self._room.local_participant),
                )
        except Exception as e:
            self._LOG.warning("Error publishing data for topic %s: %s", topic_name, e)

    def _handle_image_message(self, topic_name: str, ros_type: str, msg: Any) -> None:
        """Convert ROS image message to frame and publish via LiveKit video track."""
        source = self._video_sources.get(topic_name)
        if not source:
            return

        frame = self._decode_image_to_rgba(ros_type, msg, topic_name)
        if frame is None:
            self._LOG.warning(
                "Could not decode image for topic %s (encoding=%s)",
                topic_name,
                getattr(msg, "encoding", "n/a"),
            )
            return

        try:
            import cv2

            # Normalize to the declared stream resolution — dimension changes mid-stream
            # cause H.264/VP8 to lose their reference frame and produce green artefacts.
            if frame.shape[0] != _STREAM_H or frame.shape[1] != _STREAM_W:
                frame = cv2.resize(frame, (_STREAM_W, _STREAM_H), interpolation=cv2.INTER_LINEAR)
            livekit_frame = livekit_rtc.VideoFrame(
                width=_STREAM_W,
                height=_STREAM_H,
                type=livekit_rtc.VideoBufferType.RGBA,
                data=frame.tobytes(),
            )
            self._capture_to_livekit(source, topic_name, livekit_frame)
            self._remember_image_frame(topic_name, frame)
        except Exception as e:
            self._LOG.warning("Error publishing image frame for topic %s: %s", topic_name, e)

    def _handle_image_convertible_message(
        self, topic_name: str, ros_type: str, msg: Any
    ) -> None:
        """Convert a custom ROS type to an image and publish via LiveKit video track."""
        source = self._video_sources.get(topic_name)
        if not source:
            return

        try:
            import cv2
            import numpy as np

            if ros_type == "nav_msgs/msg/OccupancyGrid":
                width = msg.info.width
                height = msg.info.height
                if width == 0 or height == 0:
                    return
                data = np.array(msg.data, dtype=np.int8).reshape(height, width)
                # 0=free→white, 100=occupied→black, -1=unknown→mid-grey
                img = np.full((height, width), 127, dtype=np.uint8)
                img[data == 0] = 255
                img[data == 100] = 0
                img = cv2.resize(img, (512, 512), interpolation=cv2.INTER_NEAREST)
                frame = cv2.cvtColor(img, cv2.COLOR_GRAY2RGBA)

            elif ros_type == "instance_segmentation_ros_msgs/msg/SegmentationResult":
                instance_tuples = [
                    (inst.mask, inst.class_name, _inst_score(inst),
                     getattr(inst, "bounding_box", None))
                    for inst in msg.instances  # MaskWithObjectName[]
                ]
                with self._background_frame_lock:
                    background = self._background_frames.get(topic_name)
                    self._last_instances_by_topic[topic_name] = list(instance_tuples)
                self._render_and_capture_segmentation(topic_name, instance_tuples, background)
                return

            elif ros_type == "instance_segmentation_ros_msgs/msg/SegmentedInstanceArray":
                instance_tuples = [
                    (inst.instance_mask, getattr(inst, "class_name", ""),
                     # SegmentedInstance uses detection_score; fall back to score/confidence
                     _inst_score(inst), getattr(inst, "bounding_box", None))
                    for inst in msg.segmented_instances  # SegmentedInstance[]
                ]
                with self._background_frame_lock:
                    background = self._background_frames.get(topic_name)
                    self._last_instances_by_topic[topic_name] = list(instance_tuples)
                self._render_and_capture_segmentation(topic_name, instance_tuples, background)
                return

            else:
                self._LOG.warning("No image conversion defined for type %s", ros_type)
                return

            # Non-segmentation paths (OccupancyGrid, etc.) build `frame` above and
            # capture it directly here. Segmentation paths returned earlier via the
            # shared _render_and_capture_segmentation helper.
            if frame.shape[0] != _STREAM_H or frame.shape[1] != _STREAM_W:
                frame = cv2.resize(frame, (_STREAM_W, _STREAM_H), interpolation=cv2.INTER_LINEAR)

            livekit_frame = livekit_rtc.VideoFrame(
                width=_STREAM_W,
                height=_STREAM_H,
                type=livekit_rtc.VideoBufferType.RGBA,
                data=frame.tobytes(),
            )
            self._capture_to_livekit(source, topic_name, livekit_frame)
            self._remember_image_frame(topic_name, frame)

        except ImportError:
            self._LOG.error("cv2/numpy not available for topic %s", topic_name)
        except Exception as e:
            self._LOG.warning("Error converting %s to image for topic %s: %s", ros_type, topic_name, e)

    def _handle_audio_message(self, topic_name: str, msg: Any) -> None:
        """Render a waveform image from PCM audio data and stream as video.

        Each audio frame is appended to a per-topic rolling buffer so the
        rendered line covers a steady ~100 ms window; without the buffer
        every chunk would paint a fresh waveform from scratch and the
        display would jitter at the chunk rate.
        """
        source = self._video_sources.get(topic_name)
        if not source:
            # Surfaces port-name vs ROS-topic-name mismatches (the dispatch
            # path may pass either; only the latter is keyed in
            # ``_video_sources``).  Logged once per unseen topic.
            if not getattr(self, "_audio_no_source_logged", set()).__contains__(topic_name):
                self._LOG.warning(
                    "audio viz: no video source for topic %r — available sources: %s "
                    "(if the topic looks like a bare port name the viz publish "
                    "hook's port_to_ros_topic mapping is empty)",
                    topic_name,
                    sorted(self._video_sources.keys()),
                )
                logged = getattr(self, "_audio_no_source_logged", None)
                if logged is None:
                    logged = set()
                    self._audio_no_source_logged = logged
                logged.add(topic_name)
            return

        try:
            import numpy as np

            # Treat raw bytes as int16 PCM (most common ROS audio encoding)
            data_len = len(getattr(msg, "data", b"") or b"")
            samples = np.frombuffer(bytes(msg.data), dtype=np.int16)
            if len(samples) == 0:
                # Distinguishes "publish reached us with an empty PCM
                # payload" from "no publish at all".  Once per topic.
                if not getattr(self, "_audio_empty_logged", set()).__contains__(topic_name):
                    self._LOG.warning(
                        "audio viz: empty samples for topic %r (msg.data len=%d) — "
                        "publish hook reached the audio handler but PCM is empty",
                        topic_name, data_len,
                    )
                    logged = getattr(self, "_audio_empty_logged", None)
                    if logged is None:
                        logged = set()
                        self._audio_empty_logged = logged
                    logged.add(topic_name)
                return

            with self._audio_buffer_lock:
                buf = self._audio_sample_buffers.get(topic_name)
                if buf is None or len(buf) != _AUDIO_WAVEFORM_BUFFER_SAMPLES:
                    buf = np.zeros(_AUDIO_WAVEFORM_BUFFER_SAMPLES, dtype=np.int16)
                n = min(len(samples), _AUDIO_WAVEFORM_BUFFER_SAMPLES)
                # Roll the buffer left by `n` and overwrite the tail with
                # the freshest samples; older content drops off the front.
                buf = np.roll(buf, -n)
                buf[-n:] = samples[-n:]
                self._audio_sample_buffers[topic_name] = buf
                buf_snapshot = buf.copy()

            frame = self._render_waveform(buf_snapshot)
            livekit_frame = livekit_rtc.VideoFrame(
                width=frame.shape[1],
                height=frame.shape[0],
                type=livekit_rtc.VideoBufferType.RGBA,
                data=frame.tobytes(),
            )
            self._capture_to_livekit(source, topic_name, livekit_frame)
            self._remember_image_frame(topic_name, frame)

        except ImportError:
            self._LOG.error("numpy not available for audio topic %s", topic_name)
        except Exception as e:
            self._LOG.warning("Error processing audio for topic %s: %s", topic_name, e)

    @staticmethod
    def _render_waveform(samples: "np.ndarray") -> "np.ndarray":
        """Render an RGBA waveform image from int16 PCM samples.

        The polyline is coloured with a horizontal rainbow gradient (hue
        sweep across the X axis) so the strip looks like an RGB visualiser
        even at small embed sizes.  A wider, lower-alpha copy is drawn first
        to produce a soft glow/halo around the line.
        """
        import cv2
        import numpy as np

        w, h = _LEVEL_METER_W, _LEVEL_METER_H
        img = np.zeros((h, w, 4), dtype=np.uint8)

        # Vertical dark-purple → near-black gradient background for depth.
        bg_top = np.array((28, 14, 46), dtype=np.float32)
        bg_bot = np.array((6, 4, 14), dtype=np.float32)
        ramp = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None]
        bg_rgb = (bg_top * (1 - ramp) + bg_bot * ramp).astype(np.uint8)
        img[:, :, :3] = np.broadcast_to(bg_rgb[:, None, :], (h, w, 3))
        img[:, :, 3] = 255

        # Faint horizontal grid lines so the canvas reads as a "scope".
        for frac in (0.25, 0.5, 0.75):
            y = int(h * frac)
            img[y : y + 1, :, :3] = (40, 32, 60)

        if samples is None or len(samples) == 0:
            return img

        # Match the canvas width — down-sample for long buffers, interpolate
        # for short ones.  Use float32 normalised to [-1, 1] for amplitude.
        samples_f = samples.astype(np.float32) / 32767.0
        if len(samples_f) >= w:
            idx = np.linspace(0, len(samples_f) - 1, w).astype(np.int64)
            amps = samples_f[idx]
        else:
            amps = np.interp(
                np.linspace(0, len(samples_f) - 1, w),
                np.arange(len(samples_f)),
                samples_f,
            )

        y_center = h // 2
        y_range = (h // 2) - 6
        ys = (y_center - amps * y_range).clip(0, h - 1).astype(np.int32)
        xs = np.arange(w, dtype=np.int32)

        # Horizontal rainbow gradient — hue sweeps 0..180 across the strip
        # (OpenCV HSV hue is in [0, 180]).  We build one row of HSV, convert
        # to BGR via cvtColor, and reuse it per segment for fast colouring.
        # Phase oscillates with wall-clock time using a sine wave so the
        # rainbow drifts right, slows, reverses left, slows again — a
        # ping-pong motion that feels more "alive" than a one-way drift.
        # Period 4 s; amplitude ±90 hue units (half a full cycle).
        osc = math.sin(time.time() * (2.0 * math.pi / 4.0))  # −1..+1
        phase = int(osc * 90.0) % 180
        hues = (np.linspace(0, 180, w, endpoint=False).astype(np.int32) + phase) % 180
        hues = hues.astype(np.uint8)
        hsv_row = np.stack(
            [hues, np.full(w, 220, dtype=np.uint8), np.full(w, 255, dtype=np.uint8)],
            axis=-1,
        ).reshape(1, w, 3)
        bgr_row = cv2.cvtColor(hsv_row, cv2.COLOR_HSV2BGR).reshape(w, 3)
        # OpenCV produced BGR; our canvas is RGBA, so swap to RGB ordering.
        rgb_row = bgr_row[:, ::-1]

        # Glow + main line drawn as short coloured segments so each segment
        # picks up the local hue.  Two passes: first thick low-alpha halo,
        # then thin opaque core on top.
        for x0, x1 in zip(xs[:-1], xs[1:]):
            colour = rgb_row[x0]
            r, g, b = int(colour[0]), int(colour[1]), int(colour[2])
            # Halo: thicker, partially transparent (alpha 90).
            cv2.line(
                img, (int(x0), int(ys[x0])), (int(x1), int(ys[x1])),
                (r, g, b, 90), thickness=6, lineType=cv2.LINE_AA,
            )

        for x0, x1 in zip(xs[:-1], xs[1:]):
            colour = rgb_row[x0]
            r, g, b = int(colour[0]), int(colour[1]), int(colour[2])
            cv2.line(
                img, (int(x0), int(ys[x0])), (int(x1), int(ys[x1])),
                (r, g, b, 255), thickness=2, lineType=cv2.LINE_AA,
            )

        return img

    @staticmethod
    def _render_level_meter(rms: float, peak: float) -> "np.ndarray":
        """Render a 400×80 RGBA level-meter image for the given RMS and peak levels."""
        import numpy as np

        w, h = _LEVEL_METER_W, _LEVEL_METER_H
        img = np.zeros((h, w, 4), dtype=np.uint8)

        # Background
        img[:, :] = (15, 12, 26, 255)

        bar_margin = 8
        bar_h = 20
        rms_y = 10
        peak_y = rms_y + bar_h + 8
        bar_w = w - 2 * bar_margin

        def _bar_color(level: float) -> tuple:
            if level < 0.6:
                return (60, 179, 113, 255)   # green
            elif level < 0.8:
                return (255, 190, 50, 255)   # yellow
            else:
                return (220, 60, 60, 255)    # red

        # RMS bar
        rms_fill = int(rms * bar_w)
        img[rms_y : rms_y + bar_h, bar_margin : bar_margin + rms_fill] = _bar_color(rms)
        # RMS bar background track
        img[rms_y : rms_y + bar_h, bar_margin + rms_fill : bar_margin + bar_w] = (30, 28, 50, 255)

        # Peak bar
        peak_fill = int(peak * bar_w)
        img[peak_y : peak_y + bar_h, bar_margin : bar_margin + peak_fill] = _bar_color(peak)
        img[peak_y : peak_y + bar_h, bar_margin + peak_fill : bar_margin + bar_w] = (30, 28, 50, 255)

        # Peak needle (white vertical line on RMS bar)
        needle_x = bar_margin + int(peak * bar_w)
        needle_x = max(bar_margin, min(needle_x, bar_margin + bar_w - 1))
        img[rms_y : rms_y + bar_h, needle_x : needle_x + 2] = (255, 255, 255, 255)

        return img

import re
from typing import Dict

from neuraverse_common.observability.logging import Logger, LoggerFactory


from neuraverse_sdk.api.consul.clients.service_registry_api import ServiceRegistryClient
from neuraverse_sdk.utils.exceptions import InvalidEndpointError, NodeRegisteryError

LOGGER: Logger = LoggerFactory.get_logger(
    "service.controllers.service_registry_repository"
)


class ServiceRegistryRepository:
    def __init__(self, service_registry_endpoint: str, token=None):
        """Initialize the Python nodes instantiator."""
        super().__init__()
        self.service_registry_client: ServiceRegistryClient = ServiceRegistryClient(
            service_registry_endpoint, token
        )

    def register_node(
        self,
        node_endpoint: str,
        capability_name: str,
        node_configurations,
    ):
        """
        Register the nodes in service registry.
        #TODO: Error handling
        """
        try:
            if self._is_valid_target_request(node_endpoint):
                self.service_registry_client.register_node(
                    node_endpoint=node_endpoint,
                    capability_name=capability_name,
                    node_configurations=node_configurations
                )
            else:
                raise NodeRegisteryError(f"Invalid endpoint: {node_endpoint}")
        except Exception as e:
            LOGGER.error(f"Failed to register node: {node_endpoint}", exc_info=e)
            raise NodeRegisteryError(str(e))

    def stop_monitoring(self):
        """Stop the Consul health check monitoring."""
        if hasattr(self.service_registry_client, 'stop_monitoring'):
            self.service_registry_client.stop_monitoring()

    def _is_valid_target_request(self, s: str) -> bool:
        """Check if the target is a valid url."""
        pattern = re.compile(
            # r'^(https?://)'          # Must start with http:// or https://
            r"([a-zA-Z0-9.-]+)"  # Domain
            r"(:\d+)?"  # Optional port
            r"(/.*)?$"  # Optional path
        )
        return bool(pattern.match(s))

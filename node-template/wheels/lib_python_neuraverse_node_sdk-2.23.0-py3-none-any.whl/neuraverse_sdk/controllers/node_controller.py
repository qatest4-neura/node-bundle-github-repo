import queue
import re
import threading
import time
from typing import Any, Callable, Dict, List, Iterator

import inject
from google.protobuf.internal.containers import MessageMap
from neuraverse.models.v1.gen.business.node_graph_pb2 import (
    ExecutionState,
    Node,
    NodeConfigEntry,
    VisualizationsTopics,
)
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.models.config.node_service_config import NodeServiceConfig
from neuraverse_sdk.node_base import NodeBase
from neuraverse_sdk.streaming.data_visualization_streamer import (
    DataVisualizationStreamer,
)
from neuraverse_sdk.utils.exceptions import (
    NodeConfigurationError,
    NodeExecutionError,
    NodeNotFoundError,
    NodePauseError,
    NodeResumeError,
    NodeHealthCheckError,
    NodeSimulationModeError,
    NodeStopError,
)


def _normalize_ros_type(ros_type: str) -> str:
    """Return the canonical three-part form ``pkg/msg/Type``.

    Strips any leading slash and expands the two-part ``pkg/Type`` form that
    older node-graph JSON entries use into the standard ``pkg/msg/Type`` form
    required by the visualization type sets.
    """
    clean = (ros_type or "").lstrip("/")
    parts = clean.split("/")
    if len(parts) == 2:
        return f"{parts[0]}/msg/{parts[1]}"
    return clean


# The engine mints a fresh wire id ``"{uuid}:{node_id}"`` for every configure
# cycle (``NodeEngineController._resolve_runtime_node_id``) and sends it as the
# ``nodeId`` on every per-node RPC, so the ``node_id`` we receive carries a
# per-reconfigure UUID prefix. ``_logical_node_id`` strips it to recover the
# stable logical id, which lets us recognise that a streamer left over from a
# previous configure cycle belongs to the same logical node as a fresh Start.
_WIRE_RUNTIME_TOKEN_PREFIX_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}:"
)


def _logical_node_id(node_id: str) -> str:
    """Strip a leading runtime-token UUID prefix from a wire id.

    ``"{uuid}:{node_id}"`` -> ``"{node_id}"``. Returns the id unchanged when no
    runtime token is present (legacy/bare ids), so those keep their existing
    per-id behaviour.
    """
    return _WIRE_RUNTIME_TOKEN_PREFIX_RE.sub("", node_id or "", count=1)


LOGGER: Logger = LoggerFactory.get_logger("service.neuraverse-node-sdk.controllers")

# Stable, machine-readable marker prepended to ``resultMessage`` by the
# heartbeat re-emit path so consumers (UI, audit, dashboards) can
# distinguish a re-sent last-known snapshot from a fresh state
# transition. See [[170-status-resend]] for the rollout plan; the
# longer-term proto field ``is_resend`` will supersede the marker but
# this ships today without an entities-repo coordination.
_RESEND_MARKER = "[resend] "


def _heartbeat_worker(
    main_queue: queue.Queue,
    node_id: str,
    interval_s: float,
    stop_event: threading.Event,
    get_last_status: Callable[[], Dict[str, Any] | None],
    get_last_emit_time: Callable[[], float | None],
    log: Logger,
) -> None:
    """Re-publish the last-known status only when the stream has been quiet for ``interval_s``.

    Acts as a max-quiet-period guarantee instead of a fixed-rate ticker: during
    active transitions no extra duplicates are produced, but if nothing has
    flowed through ``main_queue`` for at least ``interval_s`` the last-known
    snapshot is re-published.  That keeps long-lived status streams alive on
    idle graphs and gives reconnecting subscribers fast visibility of the
    current state.

    ``get_last_emit_time`` returns the monotonic timestamp of the most recent
    item that passed through the fan-out (real or heartbeat), or ``None`` if
    nothing has been emitted yet.  Exits when ``stop_event`` is set.  A
    non-positive ``interval_s`` disables the heartbeat entirely.
    """
    if interval_s <= 0:
        return
    log_labels = {"node_id": node_id}
    # The fan-out's on_status_item callback updates the external emit
    # timestamp asynchronously, so right after our `put_nowait` it
    # still reflects the previous emit.  Track our own emit time and
    # use the later of the two so the worker never tight-loops while
    # the fan-out is catching up.
    own_last_emit: float | None = None
    try:
        while not stop_event.is_set():
            external_last = get_last_emit_time()
            if external_last is None and own_last_emit is None:
                # Nothing to re-send yet.  Re-check after one full interval.
                if stop_event.wait(interval_s):
                    return
                continue
            last_emit = max(
                t for t in (external_last, own_last_emit) if t is not None
            )
            elapsed = time.monotonic() - last_emit
            if elapsed < interval_s:
                # A real (or prior heartbeat) item is still recent.  Wait
                # only for the remainder of the interval; if another item
                # arrives during the wait the next iteration will see a
                # fresh timestamp and the interval restarts.
                if stop_event.wait(interval_s - elapsed):
                    return
                continue
            snapshot = get_last_status()
            if snapshot is None:
                if stop_event.wait(interval_s):
                    return
                continue
            # Mark the re-emit so consumers can distinguish heartbeat
            # snapshots from real transitions. See [[170-status-resend]].
            # Idempotent: a second heartbeat over the same snapshot must
            # not double-prefix.
            emitted = dict(snapshot)
            msg = emitted.get("resultMessage", "") or ""
            if not msg.startswith(_RESEND_MARKER):
                emitted["resultMessage"] = _RESEND_MARKER + msg
            try:
                main_queue.put_nowait(emitted)
            except queue.Full:
                log.warning(
                    "Main status queue full; dropping heartbeat",
                    **log_labels,
                )
            # Self-clock either way: a successful emit and a dropped emit
            # both count as "we tried this interval", and the worker waits
            # the full interval before considering another emit.
            own_last_emit = time.monotonic()
    except Exception as e:
        log.error(f"Heartbeat worker error: {e}", **log_labels)


def _fan_out_worker(
    main_queue: queue.Queue,
    subscribers: List[queue.Queue],
    subscribers_lock: threading.Lock,
    node_id: str,
    log: Logger,
    on_status_item: Callable[[Dict[str, Any]], None] | None = None,
) -> None:
    """Read from main_queue and put each item to every queue in subscribers. On None, put None to all and exit.

    on_status_item: invoked for each non-sentinel status dict so late subscribers can replay last-known state
    even when the subscriber list was empty at configure time (zero fan-out recipients).
    """
    log_labels = {"node_id": node_id}
    try:
        for item in iter(main_queue.get, None):
            if on_status_item is not None and isinstance(item, dict):
                try:
                    on_status_item(dict(item))
                except Exception as e:
                    log.warning(
                        "on_status_item callback failed for node_id=%s: %s",
                        node_id,
                        e,
                        **log_labels,
                    )
            with subscribers_lock:
                snapshot = list(subscribers)
            for q in snapshot:
                try:
                    q.put_nowait(item)
                except queue.Full:
                    # A subscriber-queue full drop means the UI (or
                    # whoever is consuming the status stream) is silently
                    # missing updates — a class of bug that is otherwise
                    # invisible. Emit at ERROR so dashboards / alerting
                    # surface it, and include the dropped item's state +
                    # node_id so triage doesn't need a second log line.
                    state = item.get("state") if isinstance(item, dict) else None
                    log.error(
                        "Subscriber queue full; dropping status update "
                        "(node_id=%s state=%s) — a consumer is too slow "
                        "or has stalled",
                        node_id,
                        state,
                        **log_labels,
                    )
            main_queue.task_done()
        # Sentinel received: end all subscriber streams
        with subscribers_lock:
            snapshot = list(subscribers)
        for q in snapshot:
            try:
                q.put_nowait(None)
            except queue.Full:
                pass
    except Exception as e:
        log.error(f"Fan-out worker error: {e}", **log_labels)
    finally:
        main_queue.task_done()


class NodesRegistry:
    def __init__(self, node_service_config: NodeServiceConfig):
        self.current_nodes_instances_registry = {}  # {NodeClassName: (NodeObject(),NodeId) }
        self.node_service_config = node_service_config

    def _get_class_instance(self, node_class_name: str):
        class_instance = None
        for node_class in self.current_nodes_instances_registry:
            if node_class.__name__ == node_class_name:
                class_instance = node_class
                break
        if class_instance == None:
            raise NodeNotFoundError(
                f"Node class {node_class_name} not found in the nodes registry:{self.current_nodes_instances_registry.items()}"
            )

        return class_instance

    def add_node_class(self, node_class, node_service_config: NodeServiceConfig):
        node_instance = node_class()
        self.current_nodes_instances_registry[node_class] = [[node_instance, None]]
        node_instance.register_node(node_service_config=node_service_config)

    def bind_node_instance_with_id(self, node_class_name: str, node_id: str):
        class_instance = self._get_class_instance(node_class_name)
        rows = self.current_nodes_instances_registry[class_instance]
        # Prefer slotting into the original ``[instance, None]`` row that
        # ``add_node_class`` seeded at controller bring-up so a fresh
        # controller's first init reuses that pre-registered instance.
        for row in rows:
            if row[1] is None:
                row[1] = node_id
                return
        # No reusable slot — mint a fresh instance, register it, append.
        # This branch covers two cases:
        #   (a) multiple inits on the same class within one session
        #       (e.g. a graph with several nodes of the same class), and
        #   (b) the post-stop re-init path: ``remove_node_by_id`` drops
        #       the previous row, leaving an empty list under this class.
        #       Without this fallthrough, ``bind`` used to silently no-op
        #       on an empty list and the next ``get_node_object`` would
        #       fail with "Node not found".
        new_instance = class_instance()
        new_instance.register_node(node_service_config=self.node_service_config)
        rows.append([new_instance, node_id])

    def get_node_object(self, node_id: str) -> NodeBase:
        for node_instance_list in self.current_nodes_instances_registry.values():
            for node_instance in node_instance_list:
                if node_instance[1] == node_id:
                    return node_instance[0]

        raise NodeNotFoundError(
            f"Node with id {node_id} not found in {self.current_nodes_instances_registry}"
        )

    def remove_node_by_id(self, node_id: str) -> bool:
        """Drop the ``[instance, wire_id]`` row whose wire id matches.

        Called from ``stop_node`` so the engine's "fresh UUID per session"
        contract is honoured symmetrically: after a successful stop the
        SDK no longer holds an instance under the old wire id, and the
        next configure on a new wire id is the engine's responsibility
        (must arrive paired with a fresh init). Returns True if a row
        was removed, False if no match — callers can use that to detect
        a double-stop without raising.
        """
        for _node_class, node_instance_list in self.current_nodes_instances_registry.items():
            for idx, node_instance in enumerate(node_instance_list):
                if node_instance[1] == node_id:
                    del node_instance_list[idx]
                    # Keep the class key even if the list becomes empty:
                    # ``_get_class_instance`` looks the class up by name
                    # and would otherwise raise NodeNotFoundError on the
                    # next bind/init.  ``bind_node_instance_with_id``
                    # handles the empty-list case by minting a fresh
                    # instance.
                    return True
        return False

    def get_all_node_instances(self) -> list[NodeBase]:
        all_node_instances = []
        for instance_list in self.current_nodes_instances_registry.values():
            for node_instance_tuple in instance_list:
                all_node_instances.append(node_instance_tuple[0])
        return all_node_instances

    # def get_all_node_instances_items(self) -> list[Tuple[str, NodeBase]]:
    #     return list(self.current_nodes_instances_registry.items())


class NodeController:
    @inject.params(node_classes=list[NodeBase], node_service_config=NodeServiceConfig)
    def __init__(self, node_classes: list[NodeBase], node_service_config: NodeServiceConfig):
        self._LOG: Logger = LoggerFactory.get_logger(
            f"service.controllers.{self.__class__.__name__}"
        )
        self.nodes_registry = NodesRegistry(node_service_config)
        self.status_queues = {}
        self.health_queues = {}
        # Per-node list of subscriber queues; fan-out puts each status update to all.
        self._status_subscribers: Dict[str, List[queue.Queue]] = {}
        self._status_subscribers_locks: Dict[str, threading.Lock] = {}
        self._health_subscribers: Dict[str, List[queue.Queue]] = {}
        self._health_subscribers_locks: Dict[str, threading.Lock] = {}
        self._node_locks: Dict[str, threading.Lock] = {}
        self._node_locks_lock = threading.Lock()
        self._last_status_lock = threading.Lock()
        self._last_status_by_node_id: Dict[str, Dict[str, Any]] = {}
        self._last_health_lock = threading.Lock()
        self._last_health_by_node_id: Dict[str, Dict[str, Any]] = {}
        # Monotonic timestamp (seconds) of the last item that flowed through
        # main_queue for each node, populated by the fan-out's on_status_item
        # callback so both real updates and prior heartbeats reset the clock.
        # The heartbeat worker reads it to enforce a max-quiet-period.
        self._last_status_timestamp_by_node_id: Dict[str, float] = {}
        # Per-node heartbeat: re-publishes the last-known status to the
        # main queue at status_stream_heartbeat_interval_s so long-lived
        # status streams stay alive and reconnecting subscribers see the
        # current state quickly. Stop event is set on stop/reconfigure.
        self._heartbeat_stop_events: Dict[str, threading.Event] = {}
        self._active_streamers: Dict[str, DataVisualizationStreamer] = {}
        # Track which topic set each streamer was started with so identical
        # re-requests are a no-op rather than stop+recreate.  Rapid viz toggles
        # used to thrash the streamer (new ROS2 node, new asyncio loop, new
        # LiveKit join) which sometimes never came back up cleanly.
        self._active_streamer_topics: Dict[str, frozenset] = {}
        # Pending Stop deferrals keyed by streamer_key.  Set when a Stop
        # arrives before the streamer's video sources are ready; cleared
        # when a follow-up Start (treated as a topic-set change) cancels it.
        self._pending_stops: Dict[str, threading.Event] = {}
        self._streamers_lock = threading.Lock()
        self.mqtt_config = node_service_config.mqtt
        self.node_classes = node_classes
        self.registry_config = node_service_config.registry_config
        self.node_service_config = node_service_config
        self._LOG.debug(
            "NodeController init: %s node class(es): %s",
            len(node_classes),
            [c.__name__ for c in node_classes],
        )

        for node_class in node_classes:
            self.nodes_registry.add_node_class(node_class, node_service_config)

        # Captured here so /admin/node/status can report uptime without
        # piping a separate boot-time signal through the service.  Mirrors
        # what proxy and engine controllers expose for the same purpose.
        self._start_time_monotonic: float = time.monotonic()

    def _record_last_status_snapshot(self, node_id: str, item: Dict[str, Any]) -> None:
        """Store last non-sentinel status per node for late gRPC subscribers (replay).

        Also records the monotonic timestamp so the heartbeat worker can tell
        how long the stream has been quiet.  Called for every item (real or
        heartbeat) that flows through the fan-out, so emits restart the
        heartbeat clock too.
        """
        snapshot = dict(item)
        if "nodeId" not in snapshot:
            snapshot["nodeId"] = node_id
        with self._last_status_lock:
            self._last_status_by_node_id[node_id] = snapshot
            self._last_status_timestamp_by_node_id[node_id] = time.monotonic()

    def _record_last_health_snapshot(self, node_id: str, item: Dict[str, Any]) -> None:
        snapshot = dict(item)
        if "nodeId" not in snapshot:
            snapshot["nodeId"] = node_id
        with self._last_health_lock:
            self._last_health_by_node_id[node_id] = snapshot

    def _lock_for_node(self, node_id: str) -> threading.Lock:
        """Return the lock for the given node_id, creating it if needed. Serializes configure/stop per node."""
        with self._node_locks_lock:
            if node_id not in self._node_locks:
                self._node_locks[node_id] = threading.Lock()
            return self._node_locks[node_id]

    def _with_node(
        self,
        node_id: str,
        cntx: ExecutionContext,
        log_prefix: str,
        fn,
        error_class=None,
        fail_message: str = None,
    ):
        """Run fn() after building log_labels and logging; fn() should get node and perform op. If error_class is set and fn() returns False, raise error_class(fail_message)."""
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        log_labels["node_id"] = node_id
        self._LOG.info(f"{log_prefix} {node_id}", **log_labels)
        result = fn()
        if error_class is not None and result is False:
            msg = (fail_message or f"Failed: {node_id}").format(node_id=node_id)
            raise error_class(msg)
        return result

    def initialize_node(
        self,
        project_id: str,
        node_id: str,
        class_name: str,
        cntx: ExecutionContext,
    ) -> MessageMap[str, NodeConfigEntry]:
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        log_labels["node_id"] = node_id
        self._LOG.info(f"Initializing node {node_id}", **log_labels)

        with self._lock_for_node(node_id):
            return self._initialize_node_locked(
                project_id, node_id, class_name
            )

    def _initialize_node_locked(
        self,
        project_id: str,
        node_id: str,
        class_name: str,
    ) -> MessageMap[str, NodeConfigEntry]:
        """Init body factored out so callers that already hold
        ``_lock_for_node(node_id)`` (notably ``configure_node``'s
        self-heal path for the re-configure-without-re-init flow) can
        reuse it without deadlocking on the non-reentrant per-node Lock."""
        self.nodes_registry.bind_node_instance_with_id(
            node_class_name=class_name, node_id=node_id
        )
        node_instance: NodeBase = self.nodes_registry.get_node_object(node_id)
        node_instance.stop()
        sub_lock, subscribers_ref = self.__get_node_locks(node_id)
        status_queue = self.__get_status_queue(sub_lock, subscribers_ref, node_id)
        health_sub_lock, health_subscribers_ref = self.__get_health_subscriber_locks(node_id)
        health_queue = self.__get_health_queue(
            health_sub_lock, health_subscribers_ref, node_id
        )
        node_instance.initialize(status_queue, node_id, health_queue=health_queue)
        node_instance.set_project_id(project_id)
        return node_instance.get_configuration()

    def __get_node_locks(self, node_id: str):
        # Ensure subscriber list and lock exist for this node
        with self._node_locks_lock:
            if node_id not in self._status_subscribers_locks:
                self._status_subscribers_locks[node_id] = threading.Lock()
            if node_id not in self._status_subscribers:
                self._status_subscribers[node_id] = []
        sub_lock = self._status_subscribers_locks[node_id]
        subscribers_ref = self._status_subscribers[node_id]
        return sub_lock, subscribers_ref

    def __get_health_subscriber_locks(self, node_id: str) -> tuple[threading.Lock, list[queue.Queue]]:
        with self._node_locks_lock:
            if node_id not in self._health_subscribers_locks:
                self._health_subscribers_locks[node_id] = threading.Lock()
            if node_id not in self._health_subscribers:
                self._health_subscribers[node_id] = []
        sub_lock = self._health_subscribers_locks[node_id]
        subscribers_ref = self._health_subscribers[node_id]
        return sub_lock, subscribers_ref

    def __get_health_queue(
        self, sub_lock: threading.Lock, subscribers_ref: list, node_id: str
    ) -> queue.Queue:
        self.health_queues.pop(node_id, None)
        with sub_lock:
            subscribers_ref.clear()
        health_queue = queue.Queue()
        self.health_queues[node_id] = health_queue
        fan_out = threading.Thread(
            target=_fan_out_worker,
            args=(
                health_queue,
                subscribers_ref,
                sub_lock,
                node_id,
                self._LOG,
            ),
            kwargs={
                "on_status_item": lambda item, _nid=node_id: self._record_last_health_snapshot(
                    _nid, item
                ),
            },
            daemon=True,
        )
        fan_out.start()
        return health_queue

    def __get_status_queue(
        self, sub_lock: threading.Lock, subscribers_ref: list, node_id: str
    ) -> queue.Queue:
        # After stop() the fan-out may have received None and exited; never reuse that queue.
        # Use a fresh queue and fan-out for every configure (first or re-configure).
        self._stop_heartbeat(node_id)
        self.status_queues.pop(node_id, None)
        with sub_lock:
            subscribers_ref.clear()
        status_queue = self.status_queues.get(node_id)
        if status_queue is None:
            status_queue = queue.Queue()
            self.status_queues[node_id] = status_queue
            # Start fan-out so every subscriber queue receives each update.
            # Fan-out calls _record_last_status_snapshot for each non-sentinel
            # item; the heartbeat thread reads that snapshot to re-emit it.
            fan_out = threading.Thread(
                target=_fan_out_worker,
                args=(
                    status_queue,
                    subscribers_ref,
                    sub_lock,
                    node_id,
                    self._LOG,
                ),
                kwargs={
                    "on_status_item": lambda item, _nid=node_id:
                        self._record_last_status_snapshot(_nid, item),
                },
                daemon=True,
            )
            fan_out.start()
            self._start_heartbeat(node_id, status_queue)
        return status_queue

    def _start_heartbeat(
        self, node_id: str, status_queue: queue.Queue
    ) -> None:
        interval = float(
            getattr(
                self.node_service_config,
                "status_stream_heartbeat_interval_s",
                1.0,
            )
        )
        if interval <= 0:
            return
        stop_event = threading.Event()
        self._heartbeat_stop_events[node_id] = stop_event

        def _get_last() -> Dict[str, Any] | None:
            with self._last_status_lock:
                snapshot = self._last_status_by_node_id.get(node_id)
                return dict(snapshot) if snapshot else None

        def _get_last_emit() -> float | None:
            with self._last_status_lock:
                return self._last_status_timestamp_by_node_id.get(node_id)

        threading.Thread(
            target=_heartbeat_worker,
            args=(
                status_queue,
                node_id,
                interval,
                stop_event,
                _get_last,
                _get_last_emit,
                self._LOG,
            ),
            daemon=True,
            name=f"status-heartbeat-{node_id}",
        ).start()

    def _stop_heartbeat(self, node_id: str) -> None:
        stop_event = self._heartbeat_stop_events.pop(node_id, None)
        if stop_event is not None:
            stop_event.set()

    def configure_node(self, node_info: Node, cntx: ExecutionContext) -> None:
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        log_labels["node_id"] = node_info.id
        self._LOG.info(f"Configuring node {node_info.id}", **log_labels)
        with self._lock_for_node(node_info.id):
            try:
                node_instance: NodeBase = self.nodes_registry.get_node_object(
                    node_info.id
                )
            except NodeNotFoundError:
                # Self-heal: studio sent Configure without a paired Init.
                # The typical trigger is engine-side re-configure, which
                # calls ``stop_graph`` on the previous execution engine
                # (cascading to ``stop_node`` on this SDK -> registry
                # row dropped) and then mints a fresh wire-id and calls
                # Configure directly. Without the fallback below the
                # caller would see "Node with id <fresh-uuid>:... not
                # found" even though the node was perfectly healthy
                # moments earlier.
                #
                # Auto-init recovers transparently: the Node proto
                # carries the className the engine resolved, so we can
                # bind a fresh instance under this wire-id and run the
                # normal initialize chain (state machine -> status
                # queue -> heartbeat) before falling through to
                # configure on the same instance.
                class_name = node_info.executionContext.className
                self._LOG.info(
                    "Configure for unknown wire_id %s — auto-initialising "
                    "with class %r (no prior Init RPC)",
                    node_info.id, class_name, **log_labels,
                )
                self._initialize_node_locked(
                    project_id="",
                    node_id=node_info.id,
                    class_name=class_name,
                )
                node_instance = self.nodes_registry.get_node_object(node_info.id)
            # After stop_node the status queue is removed. Recreate it so the
            # state machine can emit CONFIGURED and SubscribeNodeStatusStream can find the node.
            if node_info.id not in self.status_queues:
                sub_lock, subscribers_ref = self.__get_node_locks(node_info.id)
                status_queue = self.__get_status_queue(sub_lock, subscribers_ref, node_info.id)
                node_instance.status_queue = status_queue
                sm = getattr(node_instance, "state_machine", None)
                if sm is not None:
                    sm.state_queue = status_queue
            if node_info.id not in self.health_queues:
                health_sub_lock, health_subscribers_ref = self.__get_health_subscriber_locks(
                    node_info.id
                )
                health_queue = self.__get_health_queue(
                    health_sub_lock, health_subscribers_ref, node_info.id
                )
                node_instance.health_queue = health_queue
            try:
                is_configured: bool = node_instance.configure(node_info)
                if not is_configured:
                    self._stop_heartbeat(node_info.id)
                    self.status_queues.pop(node_info.id, None)
                    self.health_queues.pop(node_info.id, None)
                    raise NodeConfigurationError(f"Failed to configure node: {node_info.id}")
            except Exception:
                self._stop_heartbeat(node_info.id)
                self.status_queues.pop(node_info.id, None)
                self.health_queues.pop(node_info.id, None)
                with self._last_status_lock:
                    self._last_status_by_node_id.pop(node_info.id, None)
                    self._last_status_timestamp_by_node_id.pop(node_info.id, None)
                with self._last_health_lock:
                    self._last_health_by_node_id.pop(node_info.id, None)
                raise

    def execute_node(self, node_id: str, cntx: ExecutionContext) -> None:
        def _run():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.execute()

        self._with_node(
            node_id,
            cntx,
            "Executing node",
            _run,
            error_class=NodeExecutionError,
            fail_message="Failed to execute node: {node_id}",
        )

    def execute_node_background(self, node_id: str, cntx: ExecutionContext) -> None:
        def _run():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.execute_background()

        self._with_node(
            node_id,
            cntx,
            "Executing node asynchronously",
            _run,
            error_class=NodeExecutionError,
            fail_message="Failed to execute node asynchronously: {node_id}",
        )

    def stop_node(self, node_id: str, cntx: ExecutionContext) -> None:
        def _stop():
            with self._lock_for_node(node_id):
                # ``stop_node`` is the symmetric counterpart to
                # ``initialize_node``: once the underlying node has been
                # torn down we MUST drop its ``[instance, wire_id]`` row
                # from the registry, mirroring the engine's
                # ``_clear_runtime_node_ids_for_graph`` on its side. Without
                # this drop the registry grew unboundedly across init/stop
                # cycles AND a reconfigure-after-stop would arrive carrying
                # the engine's freshly-minted wire_id, miss every stale row
                # in the registry, and 500 with "Node with id ... not found"
                # (see node_controller.NodesRegistry.get_node_object).
                #
                # Two-step viz lifecycle on stop:
                #   1. Transition any active streamer to PASSIVE mode — drops
                #      its ROS subscriptions and its dedicated ROS executor,
                #      and unwires the node's direct push hooks
                #      (``_viz_*_push``) so any straggler publish() does NOT
                #      bridge into a now-stopping streamer.
                #   2. Stop the node normally.
                # The streamer's LiveKit room and republish loop stay alive
                # so a UI that's still watching keeps seeing the last cached
                # frame/data with the CACHED overlay/marker.  Without the
                # passive transition, the streamer would keep its ROS subs
                # and direct push hooks open, which (a) leaks the dedicated
                # ROS executor for the lifetime of the pod, and (b) lets a
                # streaming node's in-flight publish keep pushing live frames
                # through the LiveKit channel during teardown.
                #
                # Streamers are still ultimately released when:
                #   * the UI explicitly calls StopDataVisualization, or
                #   * the streamer's idle watchdog elapses (no UI subscriber
                #     in the LiveKit room for >30 min), or
                #   * the pod is torn down.
                self._transition_streamers_to_passive(node_id)
                try:
                    node_instance = self.nodes_registry.get_node_object(node_id)
                except NodeNotFoundError:
                    # Already released by a prior successful stop — the
                    # registry only holds an entry between init and the
                    # symmetric stop above.  A retry of the same StopNode
                    # RPC from a flaky engine→node link MUST still succeed
                    # without re-running the destroy chain (no double
                    # ``on_stop``, no double ``on_cleanup``).  Treat as
                    # idempotent success.
                    return True
                is_stopped = node_instance.stop()
                if is_stopped:
                    self._stop_heartbeat(node_id)
                    self.status_queues.pop(node_id, None)
                    self.health_queues.pop(node_id, None)
                    with self._last_status_lock:
                        self._last_status_by_node_id.pop(node_id, None)
                        self._last_status_timestamp_by_node_id.pop(node_id, None)
                    with self._last_health_lock:
                        self._last_health_by_node_id.pop(node_id, None)
                    self.nodes_registry.remove_node_by_id(node_id)
                return is_stopped

        self._with_node(
            node_id,
            cntx,
            "Stopping node",
            _stop,
            error_class=NodeStopError,
            fail_message="Failed to stop node: {node_id}",
        )

    def pause_node(self, node_id: str, cntx: ExecutionContext) -> None:
        def _pause():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.pause()

        self._with_node(
            node_id,
            cntx,
            "Pausing node",
            _pause,
            error_class=NodePauseError,
            fail_message="Failed to pause node: {node_id}",
        )

    def resume_node(self, node_id: str, cntx: ExecutionContext) -> None:
        def _resume():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.resume()

        self._with_node(
            node_id,
            cntx,
            "Resuming node",
            _resume,
            error_class=NodeResumeError,
            fail_message="Failed to resume node: {node_id}",
        )

    def toggle_simulation_mode(self, node_id: str, is_simulation: bool, cntx: ExecutionContext) -> None:
        def _toggle():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.toggle_simulation_mode(is_simulation)

        self._with_node(
            node_id,
            cntx,
            "Toggling simulation mode for node",
            _toggle,
            error_class=NodeSimulationModeError,
            fail_message="Failed to toggle simulation mode for node: {node_id}"
        )

    def get_health_check(self, node_id: str, cntx: ExecutionContext) -> tuple[bool, str]:
        def _check():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.get_health_check()

        return self._with_node(
            node_id,
            cntx,
            "Performing health check for node",
            _check,
            error_class=NodeHealthCheckError,
            fail_message="Health check failed for node: {node_id}"
        )

    def get_node_configuration(self, node_id: str, cntx: ExecutionContext) -> dict[str, str]:
        def _get():
            node_instance = self.nodes_registry.get_node_object(node_id)
            return node_instance.get_configuration()

        return self._with_node(
            node_id,
            cntx,
            "Getting node configuration for",
            _get,
            error_class=None,
        )

    def subscribe_node_status_stream(self, node_id: str, cntx: ExecutionContext):
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        log_labels["node_id"] = node_id
        if node_id not in self.status_queues:
            raise NodeNotFoundError(
                f"Status stream subscription failed. Node with id {node_id} does not exist"
            )
        sub_lock = self._status_subscribers_locks.get(node_id)
        # Legacy path: queue was set without configure (e.g. tests); read directly from main queue
        if sub_lock is None:
            status_queue = self.status_queues[node_id]
            self._LOG.debug(
                "subscribe_node_status_stream legacy single-queue path node_id=%s",
                node_id,
                **log_labels,
            )
            while True:
                try:
                    status_update = status_queue.get(block=True)
                    if status_update is None:
                        self._LOG.debug(
                            "Status stream ended (sentinel) node_id=%s",
                            node_id,
                            **log_labels,
                        )
                        return
                    yield status_update
                    status_queue.task_done()
                except Exception as e:
                    self._LOG.error(f"Error in status stream: {str(e)}", **log_labels)
                    raise e
            return

        # Per-caller queue so this stream gets every status update (fan-out fills it)
        subscriber_queue = queue.Queue()
        with sub_lock:
            self._status_subscribers[node_id].append(subscriber_queue)

        # Push current state so caller sees CONFIGURED even if they subscribed after configure
        # (configure-time fan-out may have had zero subscribers and dropped those updates).
        try:
            node_instance = self.nodes_registry.get_node_object(node_id)
            state = node_instance.state_machine.get_state()
            current = {
                "nodeId": node_id,
                "state": state,
                "resultCode": 0,
                "resultMessage": f"Current state: {ExecutionState.Name(state)}",
            }
            subscriber_queue.put_nowait(current)
        except Exception as e:
            self._LOG.debug(
                "Initial state_machine snapshot failed for node_id=%s (%s); trying replay buffer",
                node_id,
                e,
                **log_labels,
            )
            with self._last_status_lock:
                replay = self._last_status_by_node_id.get(node_id)
            if replay is not None:
                try:
                    subscriber_queue.put_nowait(dict(replay))
                    self._LOG.debug(
                        "Injected last-known status from replay buffer (node_id=%s)",
                        node_id,
                        **log_labels,
                    )
                except Exception as e2:
                    self._LOG.debug(
                        "Replay buffer inject failed for node_id=%s: %s",
                        node_id,
                        e2,
                        **log_labels,
                    )
            else:
                self._LOG.debug(
                    "No initial status and no replay buffer for node_id=%s; "
                    "stream may block until next transition",
                    node_id,
                    **log_labels,
                )

        self._LOG.debug(
            "subscribe_node_status_stream fan-out path started node_id=%s",
            node_id,
            **log_labels,
        )
        try:
            while True:
                try:
                    status_update = subscriber_queue.get(block=True)
                    if status_update is None:  # Sentinel for end-of-stream
                        self._LOG.debug(
                            "Status stream ended (sentinel) node_id=%s",
                            node_id,
                            **log_labels,
                        )
                        return
                    yield status_update
                    subscriber_queue.task_done()
                except Exception as e:
                    self._LOG.error(f"Error in status stream: {str(e)}", **log_labels)
                    raise e
        finally:
            with sub_lock:
                if node_id in self._status_subscribers:
                    try:
                        self._status_subscribers[node_id].remove(subscriber_queue)
                    except ValueError:
                        pass

    def subscribe_node_health_stream(self, node_id: str, cntx: ExecutionContext) -> Iterator[dict[str, Any]]:
        log_labels = (cntx.get_labels_for_log() if cntx else {}) or {}
        log_labels["node_id"] = node_id
        if node_id not in self.health_queues:
            raise NodeNotFoundError(
                f"Health stream subscription failed. Node with id {node_id} does not exist"
            )
        sub_lock = self._health_subscribers_locks.get(node_id)
        if sub_lock is None:
            health_queue = self.health_queues[node_id]
            while True:
                try:
                    health_update = health_queue.get(block=True)
                    if health_update is None:
                        return
                    yield health_update
                    health_queue.task_done()
                except Exception as e:
                    self._LOG.error(f"Error in health stream: {str(e)}", **log_labels)
                    raise e

        subscriber_queue = queue.Queue()
        with sub_lock:
            self._health_subscribers[node_id].append(subscriber_queue)

        try:
            node_instance = self.nodes_registry.get_node_object(node_id)
            node_instance._push_current_health()
        except Exception as e:
            self._LOG.debug(
                "Initial health snapshot failed for node_id=%s (%s); trying replay buffer",
                node_id,
                e,
                **log_labels,
            )
            with self._last_health_lock:
                replay = self._last_health_by_node_id.get(node_id)
            if replay is not None:
                try:
                    subscriber_queue.put_nowait(dict(replay))
                except Exception as e2:
                    self._LOG.debug(
                        "Health replay buffer inject failed for node_id=%s: %s",
                        node_id,
                        e2,
                        **log_labels,
                    )

        try:
            while True:
                try:
                    health_update = subscriber_queue.get(block=True)
                    if health_update is None:
                        return
                    yield health_update
                    subscriber_queue.task_done()
                except Exception as e:
                    self._LOG.error(f"Error in health stream: {str(e)}", **log_labels)
                    raise e
        finally:
            with sub_lock:
                if node_id in self._health_subscribers:
                    try:
                        self._health_subscribers[node_id].remove(subscriber_queue)
                    except ValueError:
                        pass

    def get_data_visualization_topics(
        self,
    ) -> Dict[
        str, VisualizationsTopics
    ]:  # {node_id : {output_port : {ros_topic_name: ros_topic_type}, ...}... }

        all_instantiated_nodes = self.nodes_registry.get_all_node_instances()
        # Only query nodes that have an active status queue — nodes stopped or from previous
        # configure cycles have had their queues removed and should not appear in the picker.
        active_node_ids = set(self.status_queues.keys())
        self._LOG.debug(
            "get_data_visualization_topics: %d total instance(s), %d active",
            len(all_instantiated_nodes),
            len(active_node_ids),
        )

        active_data_visualizations: Dict[str, VisualizationsTopics] = {}

        for node in all_instantiated_nodes:
            try:
                node_id = node.get_node_id()
                if node_id not in active_node_ids:
                    continue
                topics = node.get_data_visualizations_topics()
                if topics.topics:
                    active_data_visualizations[node_id] = topics
            except Exception as e:
                self._LOG.warning("Error while collecting visualization topics: %s", str(e))

        return active_data_visualizations

    def start_data_visualization(
        self,
        node_id: str,
        room_name: str,
        publisher_token: str,
        topic_names: list[str],
        livekit_url: str = "",
    ) -> None:
        """Start live data visualization streaming for a node."""
        streamer_key = f"{node_id}:{room_name}"
        log_labels = {"node_id": node_id, "room_name": room_name}
        requested_topic_set = frozenset(topic_names or [])

        # Reconfigure mints a fresh wire id for the same logical node, so a
        # Start after reconfigure lands on a NEW streamer_key while the previous
        # cycle's streamer is still registered under the old wire id: stop_node
        # only transitioned it to passive, so it stays connected to the room and
        # keeps republishing now-stale cached frames under the SAME (wire-id
        # independent) public track name. Left alone it shows up as a duplicate
        # topic and the UI can bind to that stale, no-longer-fed track (green
        # noise). Retire any such sibling — same room and logical node, but a
        # different wire id — before the new streamer joins.
        self._retire_stale_sibling_streamers(node_id, room_name)

        extend_existing: DataVisualizationStreamer | None = None
        with self._streamers_lock:
            existing = self._active_streamers.get(streamer_key)
            existing_topics = self._active_streamer_topics.get(streamer_key)
            # If a Stop is currently deferred for this streamer (Stop arrived
            # before the streamer's setup completed), cancel it — the Start
            # below supersedes it as a topic-set change.
            pending_stop = self._pending_stops.pop(streamer_key, None)
            if pending_stop is not None:
                pending_stop.set()
                self._LOG.info(
                    "Start arrived while a Stop was deferred for %s — "
                    "treating as topic change and cancelling the deferred Stop",
                    streamer_key, **log_labels,
                )
            if existing is not None and existing_topics == requested_topic_set:
                self._LOG.info(
                    "Streamer already active for %s with identical topics %s — "
                    "treating start as no-op",
                    streamer_key, sorted(requested_topic_set),
                    **log_labels,
                )
                # Re-run on_start_data_visualization so node-side caches (e.g.
                # input-image background re-push) refresh, but don't recreate
                # the LiveKit room or the ROS2 node.
                try:
                    node_instance = self.nodes_registry.get_node_object(node_id)
                    node_instance.on_start_data_visualization(topic_names)
                except NodeNotFoundError:
                    pass
                return
            if existing is not None:
                # The UI treats each viz panel as an independent Start, so a
                # second panel opening on the same node arrives as a Start
                # with a different topic set.  Take the union so both panels
                # stay live.  Crucially, we *extend* the existing streamer
                # rather than tearing it down and recreating: a recreate
                # makes the streamer's LiveKit participant disconnect and a
                # new one join with the same identity, rotating the SID; UI
                # clients that bind video elements to the SID (not the
                # identity) then lose the previously-live tracks.
                combined_topic_set = (existing_topics or frozenset()) | requested_topic_set
                if combined_topic_set == existing_topics:
                    self._LOG.info(
                        "Start for %s with topics %s — subset of existing %s, no-op",
                        streamer_key,
                        sorted(requested_topic_set),
                        sorted(existing_topics or []),
                        **log_labels,
                    )
                    try:
                        node_instance = self.nodes_registry.get_node_object(node_id)
                        node_instance.on_start_data_visualization(topic_names)
                    except NodeNotFoundError:
                        pass
                    return
                self._LOG.info(
                    "Streamer already active for %s with different topics — "
                    "extending in place to union (was=%s, requested=%s, combined=%s)",
                    streamer_key,
                    sorted(existing_topics or []),
                    sorted(requested_topic_set),
                    sorted(combined_topic_set),
                    **log_labels,
                )
                extend_existing = existing
                # Reflect the new topic set immediately so a concurrent Start
                # for the same key sees the broader set and short-circuits.
                self._active_streamer_topics[streamer_key] = frozenset(combined_topic_set)
                topic_names = sorted(combined_topic_set)
                requested_topic_set = frozenset(combined_topic_set)

        node_instance = self.nodes_registry.get_node_object(node_id)

        # Resolve topic configs from visualization topics.
        # topic_names contains visualization name keys (e.g. "rgb_compressed_raw"),
        # not ROS topic strings — match against viz_name, not viz_topic.topicName.
        viz_topics = node_instance.get_data_visualizations_topics()

        # Build a lookup from ROS topic path → actual (un-normalized) ros_type.
        # get_data_visualizations_topics() normalizes custom types to sensor_msgs/msg/Image
        # so the frontend can render them as video — but the ROS subscription needs
        # the real type (e.g. instance_segmentation_ros_msgs/msg/SegmentationResult,
        # sensor_msgs/msg/CompressedImage).
        #
        # Two sources (output topics take precedence over viz topics):
        # 1. on_get_data_visualization_topics() — stores the raw type before normalization;
        #    covers nodes that define their visualization topics manually without using the
        #    standard dataflow output ports (e.g. camera nodes with custom topic paths).
        # 2. get_output_topics() — covers nodes using the standard dataflow adapter.
        # viz_name -> REAL ROS topic + actual (un-normalized) ros_type. The
        # streamer must subscribe to the real ROS topic, while the UI-facing
        # ``viz_topic.topicName`` is now the LiveKit-safe public name (node-id
        # keyed). Both are keyed by viz_name (the port name), which is what the
        # UI requests and what survives the public-name transform.
        viz_name_to_real: dict[str, str] = {}
        viz_name_to_type: dict[str, str] = {}
        try:
            raw_viz = node_instance.on_get_data_visualization_topics()
            for _viz_name, _vt in raw_viz.topics.items():
                if _vt.topic_name:
                    viz_name_to_real[_viz_name] = _vt.topic_name
                _t = _normalize_ros_type(_vt.visualization_type or "")
                if _t:
                    viz_name_to_type[_viz_name] = _t
        except Exception:
            pass
        try:
            for _out_name, out_info in node_instance.get_output_topics().items():
                rn = out_info.get("topic_name")
                if rn:
                    viz_name_to_real[_out_name] = rn  # output ports win
                _t = _normalize_ros_type(out_info.get("ros_type", ""))
                if _t:
                    viz_name_to_type[_out_name] = _t
        except Exception:
            pass

        topic_configs = []
        for topic_name in topic_names:
            for viz_name, viz_topic in viz_topics.topics.items():
                if viz_name == topic_name:
                    real_topic = viz_name_to_real.get(viz_name) or viz_topic.topicName
                    actual_type = viz_name_to_type.get(
                        viz_name, viz_topic.visualizationType
                    )
                    self._LOG.info(
                        "Viz topic resolved: viz_name=%s ros_topic=%s public_name=%s "
                        "actual_type=%s (fallback_type=%s, lookup_hit=%s)",
                        viz_name,
                        real_topic,
                        viz_topic.topicName,
                        actual_type,
                        viz_topic.visualizationType,
                        viz_name in viz_name_to_type,
                        **log_labels,
                    )
                    topic_configs.append(
                        {
                            "topic_name": real_topic,
                            "ros_type": actual_type,
                        }
                    )
                    break
            else:
                self._LOG.warning(
                    "Requested topic %s not found in node %s visualizations",
                    topic_name,
                    node_id,
                    **log_labels,
                )

        if not topic_configs:
            self._LOG.warning("No valid topic configs resolved for node %s", node_id, **log_labels)
            return

        # For segmentation topics, also subscribe to image-type inputs as background frames.
        # This lets the streamer show the source image when no segments are detected, and
        # composite coloured mask overlays over it when segments are present.
        _SEGMENTATION_TYPES = frozenset({
            "instance_segmentation_ros_msgs/msg/SegmentationResult",
            "instance_segmentation_ros_msgs/msg/SegmentedInstanceArray",
        })
        _IMAGE_INPUT_TYPES = frozenset({
            "sensor_msgs/msg/Image",
            "sensor_msgs/msg/CompressedImage",
        })
        segmentation_topic_names = [
            c["topic_name"] for c in topic_configs if c["ros_type"] in _SEGMENTATION_TYPES
        ]
        if segmentation_topic_names:
            try:
                input_topics = node_instance.get_input_topics()
                seen = set()
                for in_info in input_topics.values():
                    t_type = (in_info.get("ros_type") or "").lstrip("/")
                    t_name = (in_info.get("topic_name") or "").strip()
                    if not t_name or t_type not in _IMAGE_INPUT_TYPES:
                        continue
                    for seg_name in segmentation_topic_names:
                        key = (t_name, seg_name)
                        if key in seen:
                            continue
                        seen.add(key)
                        topic_configs.append({
                            "topic_name": t_name,
                            "ros_type": t_type,
                            "role": "background",
                            "background_for": seg_name,
                        })
                        self._LOG.info(
                            "Adding background image topic %s → segmentation topic %s",
                            t_name,
                            seg_name,
                            **log_labels,
                        )
            except Exception as exc:
                self._LOG.warning(
                    "Could not resolve image input topics as backgrounds for node %s: %s",
                    node_id,
                    exc,
                    **log_labels,
                )

        # Get the ROS node via the hook (nodes override get_ros_node() if they manage
        # their own rclpy node rather than using the standard dataflow adapter)
        ros_node = node_instance.get_ros_node() if hasattr(node_instance, "get_ros_node") else None

        # NodeBase caches last messages keyed by port name; topic_configs is
        # keyed by ROS topic.  Build a topic→port lookup so the seed below
        # actually hits the cache.
        ros_topic_to_port: dict[str, str] = {}
        try:
            for port_name, out_info in node_instance.get_output_topics().items():
                t_name = (out_info.get("topic_name") or "").strip()
                if t_name:
                    ros_topic_to_port[t_name] = port_name
        except Exception:
            pass

        initial_messages: dict = {}
        try:
            getter = getattr(node_instance, "get_cached_output", None)
            if callable(getter):
                # Try every topic the streamer was configured with — including
                # background topics, since their last value can seed the
                # segmentation compositor.
                for cfg in topic_configs:
                    t_name = cfg.get("topic_name", "")
                    if not t_name:
                        continue
                    port_name = ros_topic_to_port.get(t_name)
                    cached = None
                    if port_name:
                        cached = getter(port_name)
                    if cached is None:
                        # Fall back to lookup by the ROS topic name itself —
                        # covers nodes that publish() with a custom key (rare).
                        cached = getter(t_name)
                    if cached is not None:
                        initial_messages[t_name] = cached
        except Exception as exc:
            self._LOG.debug(
                "Could not collect cached outputs for node %s: %s", node_id, exc,
                **log_labels,
            )

        if extend_existing is not None:
            streamer = extend_existing
            # Push the new topics' tracks + subscriptions onto the live
            # streamer.  ``add_topics`` is idempotent — already-configured
            # topics in ``topic_configs`` are silently skipped — so we can
            # safely pass the combined list.
            streamer.add_topics(topic_configs)
        else:
            streamer = DataVisualizationStreamer(node_id=node_id, logger=self._LOG)
            # Wire the streamer's idle watchdog to drop our registry entry
            # when it self-stops, so a follow-up StartDataVisualization
            # re-creates a fresh streamer instead of seeing a stale one.
            streamer._on_idle_stop = self._make_idle_stop_callback(streamer_key)
            streamer.start(
                room_name=room_name,
                publisher_token=publisher_token,
                livekit_url=livekit_url or self.node_service_config.livekit_url,
                topic_configs=topic_configs,
                ros_node=ros_node,
                initial_messages=initial_messages,
            )

        with self._streamers_lock:
            self._active_streamers[streamer_key] = streamer
            self._active_streamer_topics[streamer_key] = requested_topic_set

        # Wire up direct background-frame push for nodes that receive image data via MQTT
        # (ROS2 background subscriptions won't receive data for those nodes).
        bg_mqtt_to_seg = {
            c["topic_name"]: c["background_for"]
            for c in topic_configs
            if c.get("role") == "background" and c.get("background_for")
        }
        seg_topics = list({c["background_for"] for c in topic_configs if c.get("background_for")})
        if bg_mqtt_to_seg:
            node_instance._viz_bg_push = streamer.push_background_frame
            node_instance._viz_bg_mqtt_to_seg = bg_mqtt_to_seg
            # Wire up direct segmentation push: MQTT nodes' NodeBase.publish() goes to MQTT
            # only — the streamer's ROS2 subscription for the segments topic never fires.
            node_instance._viz_seg_push = streamer.push_segmentation_result
            node_instance._viz_seg_topics = seg_topics
        else:
            node_instance._viz_bg_push = None
            node_instance._viz_bg_mqtt_to_seg = {}
            node_instance._viz_seg_push = None
            node_instance._viz_seg_topics = []

        # Wire up direct image push for MQTT-only nodes with plain image outputs.
        # Covers cases like CameraStreamNode where the output IS the image (no segmentation
        # overlay) — the ROS2 subscription for the image topic also never fires.
        _IMAGE_OUTPUT_TYPES = frozenset({
            "sensor_msgs/msg/Image",
            "sensor_msgs/msg/CompressedImage",
        })
        image_push_map = {
            c["topic_name"]: c["topic_name"]
            for c in topic_configs
            if c.get("role") != "background"
            and _normalize_ros_type(c.get("ros_type", "")) in _IMAGE_OUTPUT_TYPES
        }
        node_instance._viz_image_push = streamer.push_image_frame if image_push_map else None
        node_instance._viz_image_push_map = image_push_map

        # Reset the placeholder→topic cache so it rebuilds fresh for this session
        node_instance._viz_bg_input_cache = None

        # Wire the publish hook only after LiveKit has registered the
        # video sources, so the first NodeBase.publish() doesn't land in
        # an empty ``_video_sources``.  Bounded so a flaky signaling
        # endpoint can't hang Start indefinitely.  Skipped for the
        # extension path — the streamer is already past its setup window.
        viz_ready_timeout = getattr(
            self.node_service_config, "viz_sources_ready_timeout_s", 10.0
        )
        if extend_existing is None and not streamer.wait_for_sources_ready(
            timeout=viz_ready_timeout
        ):
            self._LOG.warning(
                "Data visualization video sources not ready after %.1fs for "
                "node %s in room %s — wiring publish hook anyway; the first "
                "publishes may drop until LiveKit connects",
                viz_ready_timeout, node_id, room_name, **log_labels,
            )

        # Protocol-agnostic publish bridge — every NodeBase.publish() call
        # passes through this hook, regardless of whether the underlying
        # data flow is ROS, MQTT, or both.  This is what makes ROS-only
        # node graphs work without depending on the streamer's separate
        # rclpy subscription firing reliably (different rclpy nodes,
        # spin-after-subscribe timing, QoS pinning, etc.).  See
        # _make_viz_publish_hook for dispatch.
        node_instance._viz_publish_hook = self._make_viz_publish_hook(
            node_instance, streamer, topic_configs,
        )

        # Notify node via optional lifecycle hook
        node_instance.on_start_data_visualization(topic_names)

        self._LOG.info(
            "Data visualization started for node %s in room %s (%d topics)",
            node_id,
            room_name,
            len(topic_configs),
            **log_labels,
        )

    # Hard upper bound on how long ``stop_data_visualization`` will wait for
    # ``_sources_ready_event`` before going ahead and tearing the streamer
    # down anyway.  Tuned around the observed LiveKit publish-track latency
    # (~2 s) plus headroom for slow signaling.
    _STOP_SETUP_GRACE_SECONDS: float = 5.0

    def stop_data_visualization(self, node_id: str, room_name: str) -> None:
        """Stop live data visualization streaming for a node.

        If the streamer is still in its setup window (LiveKit room.connect +
        publish_track not finished), defer the actual teardown until either
        the setup completes or a follow-up Start cancels the deferral —
        otherwise a UI that fires ``Stop`` immediately after ``Start`` (to
        clean up a previously open panel) would tear down the just-created
        streamer before it ever published a frame.
        """
        streamer_key = f"{node_id}:{room_name}"
        log_labels = {"node_id": node_id, "room_name": room_name}

        with self._streamers_lock:
            streamer = self._active_streamers.get(streamer_key)
            if streamer is None:
                self._LOG.warning("No active streamer found for %s", streamer_key, **log_labels)
                return
            sources_ready = streamer._sources_ready_event.is_set()
            if sources_ready:
                self._active_streamers.pop(streamer_key, None)
                self._active_streamer_topics.pop(streamer_key, None)
                self._pending_stops.pop(streamer_key, None)
            else:
                if streamer_key in self._pending_stops:
                    self._LOG.info(
                        "Stop for %s already deferred — ignoring duplicate request",
                        streamer_key, **log_labels,
                    )
                    return
                cancel_event = threading.Event()
                self._pending_stops[streamer_key] = cancel_event

        if not sources_ready:
            self._LOG.info(
                "Stop for %s deferred — streamer setup not complete; will be honoured "
                "once video sources are ready unless a follow-up Start cancels it",
                streamer_key, **log_labels,
            )
            threading.Thread(
                target=self._deferred_stop_runner,
                args=(streamer_key, node_id, room_name, streamer, cancel_event),
                daemon=True,
                name=f"viz-stop-defer-{streamer_key}",
            ).start()
            return

        self._teardown_streamer(streamer, node_id, room_name, log_labels)

    def _deferred_stop_runner(
        self,
        streamer_key: str,
        node_id: str,
        room_name: str,
        streamer: DataVisualizationStreamer,
        cancel_event: threading.Event,
    ) -> None:
        """Wait out the streamer's setup window before running the actual stop.

        Returns early if a follow-up Start (which sets ``cancel_event``) has
        already superseded this deferral by the time setup completes.
        """
        # ``cancel_event.wait`` returns True the instant the event is set
        # (Start cancelled us) or False on timeout.  We additionally poll
        # ``_sources_ready_event`` every 100 ms so the deferred Stop can
        # fire as soon as setup completes — without polling we'd always
        # wait the full grace period.
        deadline = time.monotonic() + self._STOP_SETUP_GRACE_SECONDS
        while time.monotonic() < deadline:
            if cancel_event.is_set():
                self._LOG.info(
                    "Deferred Stop for %s cancelled by follow-up Start", streamer_key,
                )
                return
            if streamer._sources_ready_event.is_set():
                break
            cancel_event.wait(timeout=0.1)
        if cancel_event.is_set():
            self._LOG.info(
                "Deferred Stop for %s cancelled by follow-up Start", streamer_key,
            )
            return

        log_labels = {"node_id": node_id, "room_name": room_name}
        with self._streamers_lock:
            # A Start in the union path may have replaced this streamer
            # with a new one without cancelling our pending event (e.g.
            # crash between cancel + recreate).  Stop only the original.
            current = self._active_streamers.get(streamer_key)
            still_pending = self._pending_stops.get(streamer_key) is cancel_event
            if not still_pending:
                self._LOG.info(
                    "Deferred Stop for %s superseded — pending entry no longer matches",
                    streamer_key, **log_labels,
                )
                return
            self._pending_stops.pop(streamer_key, None)
            if current is not streamer:
                self._LOG.info(
                    "Deferred Stop for %s: streamer was replaced before deferral fired",
                    streamer_key, **log_labels,
                )
                return
            self._active_streamers.pop(streamer_key, None)
            self._active_streamer_topics.pop(streamer_key, None)

        self._LOG.info(
            "Executing deferred Stop for %s after setup grace window",
            streamer_key, **log_labels,
        )
        self._teardown_streamer(streamer, node_id, room_name, log_labels)

    def _teardown_streamer(
        self,
        streamer: DataVisualizationStreamer,
        node_id: str,
        room_name: str,
        log_labels: dict,
    ) -> None:
        streamer.stop()
        try:
            node_instance = self.nodes_registry.get_node_object(node_id)
            node_instance._viz_bg_push = None
            node_instance._viz_bg_mqtt_to_seg = {}
            node_instance._viz_bg_input_cache = None
            node_instance._viz_seg_push = None
            node_instance._viz_seg_topics = []
            node_instance._viz_image_push = None
            node_instance._viz_image_push_map = {}
            node_instance._viz_publish_hook = None
            node_instance.on_stop_data_visualization()
        except NodeNotFoundError:
            pass

        self._LOG.info(
            "Data visualization stopped for node %s in room %s",
            node_id,
            room_name,
            **log_labels,
        )

    def _make_viz_publish_hook(
        self,
        node_instance: NodeBase,
        streamer: DataVisualizationStreamer,
        topic_configs: List[Dict[str, Any]],
    ):
        """Build the protocol-agnostic publish hook for a viz session.

        ``NodeBase.publish(port_name, msg)`` invokes this hook on every
        publish.  We map the port to its ROS topic + ros_type (using the
        same metadata that ``topic_configs`` was built from) and dispatch
        to the streamer's existing handlers — so an ROS-only node graph
        produces frames in the live LiveKit feed without depending on
        the streamer's separate rclpy subscription reaching the
        publisher (which fails subtly when QoS, namespaces, or spin
        timing don't line up).

        Background-image bridging stays on ``_viz_bg_push`` because that
        crosses the *input* boundary of a different node and isn't
        reachable from this node's publish path.
        """
        from neuraverse_sdk.streaming.data_visualization_streamer import (
            _AUDIO_TYPES,
            _IMAGE_CONVERTIBLE_TYPES,
            _IMAGE_TYPES,
        )

        # port_name → (ros_topic, ros_type) for fast dispatch.  Built
        # from topic_configs (which lives at the ROS-topic layer) plus
        # the node's own get_output_topics() (port → ROS topic).
        cfg_by_topic: Dict[str, Dict[str, Any]] = {
            c.get("topic_name", ""): c
            for c in topic_configs
            if c.get("role") != "background"
        }
        port_to_ros_topic: Dict[str, str] = {}
        try:
            for port_name, info in node_instance.get_output_topics().items():
                t_name = (info.get("topic_name") or "").strip()
                if t_name:
                    port_to_ros_topic[port_name] = t_name
        except Exception:
            pass

        log = self._LOG

        # Snapshot the port→topic resolution so the operator can verify it
        # at session start without grepping subsequent per-frame logs.
        log.info(
            "viz publish hook constructed: port_to_ros_topic=%s cfg_topics=%s",
            port_to_ros_topic, sorted(cfg_by_topic.keys()),
        )

        # First dispatch + first skip per port are logged once each; per-port
        # heartbeats follow on a fixed dispatch count so a silent gap is
        # visible.  250 dispatches ≈ 5 s of audio (50 Hz) or ~17 s of video
        # at 15 fps.
        hook_dispatched: set[str] = set()
        hook_skipped: set[str] = set()
        hook_dispatch_counts: dict[str, int] = {}
        heartbeat_every = 250

        def hook(port_name: str, message: Any) -> None:
            # Look up the ROS topic + viz config for this port; bail if
            # the port isn't part of the active viz session.
            ros_topic = port_to_ros_topic.get(port_name, port_name)
            cfg = cfg_by_topic.get(ros_topic)
            if cfg is None:
                if port_name not in hook_skipped:
                    hook_skipped.add(port_name)
                    log.info(
                        "viz publish hook: skipping port=%r ros_topic=%r — not in cfg_topics=%s",
                        port_name, ros_topic, sorted(cfg_by_topic.keys()),
                    )
                return
            if port_name not in hook_dispatched:
                hook_dispatched.add(port_name)
                log.info(
                    "viz publish hook: dispatching port=%r ros_topic=%r ros_type=%r",
                    port_name, ros_topic, cfg.get("ros_type", ""),
                )
            count = hook_dispatch_counts.get(port_name, 0) + 1
            hook_dispatch_counts[port_name] = count
            if count % heartbeat_every == 0:
                log.info(
                    "viz publish hook heartbeat: port=%r ros_topic=%r dispatches=%d",
                    port_name, ros_topic, count,
                )
            ros_type = _normalize_ros_type(cfg.get("ros_type", ""))
            try:
                if ros_type in _IMAGE_TYPES:
                    streamer._handle_image_message(ros_topic, ros_type, message)
                elif ros_type in _IMAGE_CONVERTIBLE_TYPES:
                    streamer._handle_image_convertible_message(
                        ros_topic, ros_type, message,
                    )
                elif ros_type in _AUDIO_TYPES:
                    streamer._handle_audio_message(ros_topic, message)
                else:
                    streamer._handle_data_message(ros_topic, message)
            except Exception as exc:
                log.debug(
                    "viz publish hook failed for port=%s ros_topic=%s: %s",
                    port_name, ros_topic, exc,
                )

        return hook

    def _transition_streamers_to_passive(self, node_id: str) -> None:
        """Move all active streamers for ``node_id`` to passive cache-only mode.

        Drops the streamer's live ROS subscriptions / executor and unwires
        the node's direct push hooks (``_viz_*_push``), so the underlying
        node can stop cleanly without the streamer either holding open
        subscriptions or receiving in-flight frames.  The LiveKit room
        and republish loop stay alive so the UI sees the last cached
        value via the CACHED overlay/marker.
        """
        with self._streamers_lock:
            keys = [
                k for k in self._active_streamers if k.startswith(f"{node_id}:")
            ]
            streamers = [self._active_streamers[k] for k in keys]

        for streamer in streamers:
            try:
                streamer.transition_to_passive()
            except Exception as exc:
                self._LOG.warning(
                    "Error transitioning streamer to passive for node %s: %s",
                    node_id, exc,
                )

        # Sever the node-side hooks so any stragglers in the node's own
        # publish path don't try to call into a streamer that's tearing
        # down its ROS plumbing.  The cache (NodeBase._last_output_cache)
        # is independent and stays intact.
        try:
            node_instance = self.nodes_registry.get_node_object(node_id)
            for attr in (
                "_viz_bg_push",
                "_viz_seg_push",
                "_viz_image_push",
                "_viz_publish_hook",
            ):
                if hasattr(node_instance, attr):
                    setattr(node_instance, attr, None)
            for attr in (
                "_viz_bg_mqtt_to_seg",
                "_viz_seg_topics",
                "_viz_image_push_map",
            ):
                if hasattr(node_instance, attr):
                    cur = getattr(node_instance, attr)
                    if isinstance(cur, dict):
                        setattr(node_instance, attr, {})
                    elif isinstance(cur, list):
                        setattr(node_instance, attr, [])
        except NodeNotFoundError:
            pass

    def _make_idle_stop_callback(self, streamer_key: str):
        """Return a callback the streamer invokes after an idle self-stop.

        Drops the streamer from our registry so the next StartDataVisualization
        for the same node creates a fresh one (and re-seeds it from the
        node's per-port last-output cache).  The streamer has already
        torn down its LiveKit room and ROS node by the time this fires.
        """
        def _on_idle() -> None:
            with self._streamers_lock:
                self._active_streamers.pop(streamer_key, None)
                self._active_streamer_topics.pop(streamer_key, None)
            self._LOG.info(
                "Removed idle streamer from registry: %s", streamer_key,
            )
        return _on_idle

    def _retire_stale_sibling_streamers(self, node_id: str, room_name: str) -> None:
        """Fully stop streamers left over from a previous configure cycle.

        A sibling is a streamer in the same ``room_name`` for the same logical
        node (``_logical_node_id``) but a *different* wire id — i.e. the
        previous reconfigure's streamer, still passive-but-connected. We remove
        it from the registry under the lock, then stop it off-thread so the
        Start RPC isn't blocked on the streamer's room-disconnect / thread-join
        (which can take several seconds). The new streamer shares the publisher
        identity, so even before the off-thread stop completes LiveKit evicts
        the old participant on the new join — the explicit stop just guarantees
        the old streamer's loop, ROS node and republisher are released rather
        than lingering until the idle watchdog reaps them.

        Streamers for the *same* wire id (multiple viz panels opened within one
        configure cycle) are never siblings, so the in-place extend path that
        keeps the participant SID stable across panel opens is untouched.
        """
        suffix = f":{room_name}"
        logical = _logical_node_id(node_id)
        stale: list[tuple[str, DataVisualizationStreamer]] = []
        with self._streamers_lock:
            for key in list(self._active_streamers):
                if not key.endswith(suffix):
                    continue
                wire_id = key[: -len(suffix)]
                if wire_id == node_id or _logical_node_id(wire_id) != logical:
                    continue
                streamer = self._active_streamers.pop(key, None)
                self._active_streamer_topics.pop(key, None)
                # Cancel any deferred Stop racing on the dead key so its timer
                # thread exits instead of later operating on a stopped streamer.
                cancel_event = self._pending_stops.pop(key, None)
                if cancel_event is not None:
                    cancel_event.set()
                if streamer is not None:
                    stale.append((key, streamer))

        for key, streamer in stale:
            self._LOG.info(
                "Retiring stale viz streamer %s superseded by reconfigure "
                "(logical node %s, room %s)",
                key, logical, room_name,
            )
            threading.Thread(
                target=self._stop_streamer_safely,
                args=(key, streamer),
                name=f"viz-retire-{key}",
                daemon=True,
            ).start()

    def _stop_streamer_safely(self, key: str, streamer: DataVisualizationStreamer) -> None:
        """Best-effort ``streamer.stop()`` used by off-thread teardown paths."""
        try:
            streamer.stop()
        except Exception as exc:
            self._LOG.warning("Error stopping retired streamer %s: %s", key, exc)

    def _stop_all_streamers_for_node(self, node_id: str) -> None:
        """Stop all active visualization streamers for a given node."""
        keys_to_remove = []
        with self._streamers_lock:
            for key, streamer in self._active_streamers.items():
                if key.startswith(f"{node_id}:"):
                    keys_to_remove.append(key)

        for key in keys_to_remove:
            with self._streamers_lock:
                streamer = self._active_streamers.pop(key, None)
                self._active_streamer_topics.pop(key, None)
            if streamer:
                try:
                    streamer.stop()
                except Exception as e:
                    self._LOG.warning("Error stopping streamer %s: %s", key, e)

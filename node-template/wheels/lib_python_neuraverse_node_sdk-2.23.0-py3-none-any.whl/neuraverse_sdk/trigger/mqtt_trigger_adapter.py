from typing import Any, Callable, Dict

from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.trigger.i_trigger import ITrigger, TriggerType
from neuraverse_sdk.utils.exceptions import TriggerFlowException
from neuraverse_sdk.utils.mqtt_singleton import MQTTHandler, Subscription

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.adapter.MQTTTriggerAdapter"
)


class MQTTTriggerAdapter(ITrigger):
    """MQTT trigger adapter."""

    def __init__(self):
        super().__init__()
        # Subscription handles for our own trigger inputs, indexed by topic
        # so destroy() can release exactly what this adapter registered
        # without touching other adapters sharing the singleton.
        self._subscriptions: Dict[str, Subscription] = {}
        # Tracks whether this adapter owns one outstanding connect() ref on
        # the singleton, so repeated configure() calls don't keep bumping
        # the refcount and leaking it past destroy().
        self._holds_connect_ref = False

    def init(self, configuration: Any) -> None:
        """Initialize the MQTT trigger adapter."""
        # client_id is managed by the MQTTHandler singleton so a single
        # stable identity is used across all adapters in this process.
        self.mqtt_client: MQTTHandler = MQTTHandler()
        self.mqtt_client.configure(configuration)
        if self.mqtt_client.connect(blocking=True, timeout=10.0):
            self._holds_connect_ref = True
            LOGGER.info("Successfully connected to MQTT broker")
        else:
            LOGGER.error("Failed to connect to MQTT broker")
            raise ConnectionError("Failed to connect to MQTT broker")

    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """Configure the MQTT trigger adapter with the given configuration.

        Idempotent across repeated calls: any handles from a prior
        configure() are released first. Without this, each reconfigure
        would leak a callback into the MQTTHandler singleton's per-topic
        fan-out list, and every incoming trigger would fire execute()
        once per leaked handle.
        """
        if not self._holds_connect_ref:
            LOGGER.info("MQTT client not connected; reconnecting before configure")
            if not self.mqtt_client.connect(blocking=True, timeout=10.0):
                raise TriggerFlowException("Failed to reconnect to MQTT broker before configure")
            self._holds_connect_ref = True
        for handle in self._subscriptions.values():
            self.mqtt_client.unsubscribe(handle)
        self._subscriptions.clear()
        self._outgoing_triggers.clear()
        self._incoming_triggers.clear()
        self._construct_output_triggers(trigger_node_entry)
        self._construct_input_triggers(trigger_node_entry)

    def destroy(self):
        try:
            # Release only our own subscription handles. The MQTTHandler is
            # a process-wide singleton with topic fan-out; another adapter
            # may share a trigger topic and must keep receiving.
            for handle in self._subscriptions.values():
                self.mqtt_client.unsubscribe(handle)
            self._subscriptions.clear()
            self._incoming_triggers.clear()
            if self._holds_connect_ref:
                self.mqtt_client.disconnect()
                self._holds_connect_ref = False
        except Exception as e:
            raise TriggerFlowException(str(e))

    def trigger_next_node(self, type: TriggerType) -> None:
        """Trigger the next node by publishing to the outgoing topic.

        Surfaces publish failures via WARNING (e.g. the singleton was
        disconnected and the publish was dropped). Previously the
        return value was discarded with ``_ =`` and a successful log
        line was emitted regardless — which made silent reconfigure
        breakage indistinguishable from a working trigger in
        production logs.
        """
        outgoing_trigger = self.get_outgoing_trigger(type)
        ok = self.mqtt_client.publish(outgoing_trigger, "triggered", qos=1)
        if ok:
            LOGGER.info(f"Triggering next node type: {outgoing_trigger}...")
        else:
            LOGGER.warning(
                "Trigger publish dropped — downstream nodes will not "
                "wake. outgoing_trigger=%s (MQTT singleton not "
                "connected or publish failed).",
                outgoing_trigger,
            )

    def _import_trigger_type(self, trigger_typ_str: str):
        if trigger_typ_str not in [
            TriggerType.Start.name,
            TriggerType.Stop.name,
            TriggerType.Error.name,
            TriggerType.InLoop.name,
            TriggerType.BreakLoop.name,
            TriggerType.IfTrue.name,
            TriggerType.IfFalse.name,
        ]:
            raise TriggerFlowException(
                f"Invalid trigger type format: {trigger_typ_str}"
            )
        trigger_type = TriggerType(trigger_typ_str)
        return trigger_type

    def _construct_output_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for output_name, trigger_type in trigger_flow_entry.outputTriggers.items():
            # Use id, not name: name is not unique across graphs sharing
            # one engine process, and MQTTHandler is a process-wide
            # singleton with topic fan-out — same-named twins would
            # cross-trigger via the shared topic.
            topic_name = f"{trigger_flow_entry.id}/{output_name}"
            trigger_type = self._import_trigger_type(trigger_type)
            LOGGER.info(
                f"MQTTTriggerAdapter: Creating publisher for topic: {topic_name} of Type: {trigger_type}"
            )
            self._outgoing_triggers[trigger_type] = topic_name

    def _construct_input_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for input_name, input_cfg in trigger_flow_entry.inputTriggers.items():
            for topic_name in input_cfg.sourceConnection:
                trigger_type = input_cfg.rosType
                if not topic_name or topic_name == "":
                    LOGGER.info(
                        f"MQTTTriggerAdapter: Input {input_name} is not connected, skipping creating a subscriber"
                    )
                    continue
                trigger_type = self._import_trigger_type(trigger_type)
                LOGGER.info(
                    f"MQTTTriggerAdapter: Creating subscriber for topic: {topic_name} of Type: {trigger_type}"
                )
                callback = self._get_call_back_from_type(trigger_type)
                handle = self.mqtt_client.subscribe(topic_name, callback)
                if handle is None:
                    raise TriggerFlowException(
                        f"Failed to subscribe to topic: {topic_name}"
                    )
                self._incoming_triggers[topic_name] = callback
                self._subscriptions[topic_name] = handle

    def _wrap_callback(self, callback: Callable[[], bool]) -> Callable[[Any], bool]:
        """Wrap a no-arg callback to accept and ignore the MQTT message payload."""

        def wrapper(payload: Any = None) -> bool:
            return callback()

        return wrapper

    def _get_call_back_from_type(
        self, trigger_type: TriggerType
    ) -> Callable[[Any], bool]:
        if trigger_type in [
            TriggerType.Start,
            TriggerType.InLoop,
            TriggerType.BreakLoop,
            TriggerType.IfTrue,
            TriggerType.IfFalse,
        ]:
            if self._execute_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._execute_callback)

        elif trigger_type == TriggerType.Stop:
            if self._stop_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._stop_callback)

        elif trigger_type == TriggerType.Error:
            if self._error_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._error_callback)

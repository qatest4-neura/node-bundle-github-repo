from enum import Enum
from typing import Callable, Any

from neuraverse_sdk.trigger.mqtt_trigger_adapter import MQTTTriggerAdapter
from neuraverse_sdk.trigger.zenoh_trigger_adapter import ZenohTriggerAdapter
from neuraverse_sdk.trigger.i_trigger import ITrigger


class TriggerCommunicationType(Enum):
    TRIGGER_COMMUNICATION_TYPE_MQTT = "TRIGGER_COMMUNICATION_TYPE_MQTT"
    TRIGGER_COMMUNICATION_TYPE_ZENOH = "TRIGGER_COMMUNICATION_TYPE_ZENOH"


class TriggerFactory:
    """Factory for creating data flow adapters"""

    _adapters: dict[TriggerCommunicationType, Callable[..., ITrigger]] = {
        TriggerCommunicationType.TRIGGER_COMMUNICATION_TYPE_MQTT: MQTTTriggerAdapter,
        TriggerCommunicationType.TRIGGER_COMMUNICATION_TYPE_ZENOH: ZenohTriggerAdapter,
    }

    @classmethod
    def create_adapter(cls, adapter_type: TriggerCommunicationType, **kwargs: Any) -> ITrigger:
        try:
            factory = cls._adapters[adapter_type]
        except KeyError:
            available = ", ".join(t.name for t in cls._adapters.keys())
            raise ValueError(
                f"Unsupported adapter type '{adapter_type.name}'. Available: {available}"
            )
        return factory(**kwargs)

    @classmethod
    def get_available_adapters(cls) -> list[TriggerCommunicationType]:
        return list(cls._adapters.keys())


def create_trigger_adapter(
    trigger_communication_type: TriggerCommunicationType, **kwargs: Any
) -> ITrigger:
    return TriggerFactory.create_adapter(trigger_communication_type, **kwargs)

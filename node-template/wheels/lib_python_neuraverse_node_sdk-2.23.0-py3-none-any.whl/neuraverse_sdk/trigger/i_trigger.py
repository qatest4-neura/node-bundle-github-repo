from abc import ABC, abstractmethod
from typing import Callable, Any
from enum import Enum


from neuraverse_common.observability.logging import LoggerFactory, Logger
from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry

from neuraverse_sdk.utils.exceptions import TriggerFlowException

LOGGER: Logger = LoggerFactory.get_logger(
    "service.repositories.core.interfaces.ITrigger"
)


class TriggerType(Enum):
    Start = "Start"
    Stop = "Stop"
    Error = "Error"
    IfTrue = "IfTrue"
    IfFalse = "IfFalse"
    InLoop = "InLoop"
    BreakLoop = "BreakLoop"


class ITrigger(ABC):
    """Abstract base class for node trigger adapters."""

    def __init__(self):
        self._incoming_triggers: dict[str, Callable[[], bool]] = {}
        self._outgoing_triggers: dict[TriggerType, str] = {}
        self._execute_callback: Callable[[], bool]
        self._error_callback: Callable[[], bool]
        self._stop_callback: Callable[[], bool]

    @abstractmethod
    def init(self, configuration: Any) -> None:
        """trigger the node."""
        pass

    @abstractmethod
    def trigger_next_node(self, type: TriggerType) -> None:
        """trigger the node."""
        pass

    @abstractmethod
    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """trigger the error."""
        pass

    @abstractmethod
    def destroy(self):
        pass

    def set_execute_callback(self, callback: Callable[[], bool]):
        self._execute_callback = callback

    def set_error_callback(self, callback: Callable[[], bool]):
        self._error_callback = callback

    def set_stop_callback(self, callback: Callable[[], bool]):
        self._stop_callback = callback

    def has_outgoing_trigger(self, trigger_type: TriggerType) -> bool:
        return trigger_type in self._outgoing_triggers

    def get_outgoing_trigger(self, trigger_type: TriggerType) -> str:
        if trigger_type not in self._outgoing_triggers:
            raise TriggerFlowException(f"Trigger type {trigger_type} not found")
        return self._outgoing_triggers[trigger_type]

    def get_incoming_trigger(self, topic_name: str) -> Callable[[], bool]:
        if topic_name not in self._incoming_triggers:
            raise TriggerFlowException(f"Topic name {topic_name} not found")
        return self._incoming_triggers[topic_name]

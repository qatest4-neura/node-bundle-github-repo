from __future__ import annotations

from collections.abc import Callable
from typing import Any

from neuraverse.models.v1.gen.business.node_graph_pb2 import TriggerNodeEntry
from neuraverse_common.observability.logging import Logger, LoggerFactory

from neuraverse_sdk.trigger.i_trigger import ITrigger, TriggerType
from neuraverse_sdk.utils.exceptions import TriggerFlowException
from neuraverse_sdk.utils.zenoh_singleton import ZenohHandler

LOGGER: Logger = LoggerFactory.get_logger("service.repositories.core.adapter.ZenohTriggerAdapter")


class ZenohTriggerAdapter(ITrigger):
    """Zenoh trigger adapter."""

    def __init__(self):
        super().__init__()

    def init(self, configuration: Any) -> None:
        """Initialize the Zenoh trigger adapter."""
        self.zenoh_session: ZenohHandler = ZenohHandler()
        self.zenoh_session.configure(configuration)
        if self.zenoh_session.connect(blocking=True, timeout=10.0):
            LOGGER.info("Successfully connected to Zenoh router")
        else:
            LOGGER.error("Failed to connect to Zenoh router")
            raise ConnectionError("Failed to connect to Zenoh router")

    def configure(self, trigger_node_entry: TriggerNodeEntry) -> None:
        """Configure the Zenoh trigger adapter with the given configuration."""
        if not self.zenoh_session.is_connected():
            LOGGER.info("Zenoh session not connected; reconnecting before configure")
            if not self.zenoh_session.connect(blocking=True, timeout=10.0):
                raise TriggerFlowException("Failed to reconnect to Zenoh router before configure")
        self._outgoing_triggers.clear()
        self._incoming_triggers.clear()
        self._construct_output_triggers(trigger_node_entry)
        self._construct_input_triggers(trigger_node_entry)

    def destroy(self):
        try:
            self.zenoh_session.disconnect()
        except Exception as e:
            raise TriggerFlowException(str(e))

    def trigger_next_node(self, type: TriggerType) -> None:
        """Trigger the next node by publishing to the outgoing topic."""
        outgoing_trigger = self.get_outgoing_trigger(type)
        _ = self.zenoh_session.publish(outgoing_trigger, "triggered")
        LOGGER.info(f"Triggering next node type: {outgoing_trigger}...")

    def _import_trigger_type(self, trigger_typ_str: str):
        if trigger_typ_str not in [
            TriggerType.Start.name,
            TriggerType.Stop.name,
            TriggerType.Error.name,
            TriggerType.InLoop.name,
            TriggerType.BreakLoop.name,
            TriggerType.IfTrue.name,
            TriggerType.IfFalse.name,
        ]:
            raise TriggerFlowException(f"Invalid trigger type format: {trigger_typ_str}")
        trigger_type = TriggerType(trigger_typ_str)
        return trigger_type

    def _construct_output_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for output_name, trigger_type in trigger_flow_entry.outputTriggers.items():
            topic_name = f"{trigger_flow_entry.name}/{output_name}"
            trigger_type = self._import_trigger_type(trigger_type)
            LOGGER.info(
                f"ZenohTriggerAdapter: Creating publisher for topic:"
                f" {topic_name} of Type: {trigger_type}"
            )
            self._outgoing_triggers[trigger_type] = topic_name

    def _construct_input_triggers(self, trigger_flow_entry: TriggerNodeEntry) -> None:
        for input_name, input_cfg in trigger_flow_entry.inputTriggers.items():
            for topic_name in input_cfg.sourceConnection:
                trigger_type = input_cfg.rosType
                if not topic_name or topic_name == "":
                    LOGGER.info(
                        f"ZenohTriggerAdapter: Input {input_name} is not connected,"
                        " skipping creating a subscriber"
                    )
                    continue
                trigger_type = self._import_trigger_type(trigger_type)
                LOGGER.info(
                    f"ZenohTriggerAdapter: Creating subscriber for topic:"
                    f" {topic_name} of Type: {trigger_type}"
                )
                callback = self._get_call_back_from_type(trigger_type)
                if self.zenoh_session.subscribe(topic_name, callback):
                    self._incoming_triggers[topic_name] = callback
                else:
                    raise TriggerFlowException(f"Failed to subscribe to topic: {topic_name}")

    def _wrap_callback(self, callback: Callable[[], bool]) -> Callable[[Any], bool]:
        """Wrap a no-arg callback to accept and ignore the Zenoh message payload."""

        def wrapper(payload: Any = None) -> bool:
            return callback()

        return wrapper

    def _get_call_back_from_type(self, trigger_type: TriggerType) -> Callable[[Any], bool]:
        if trigger_type in [
            TriggerType.Start,
            TriggerType.InLoop,
            TriggerType.BreakLoop,
            TriggerType.IfTrue,
            TriggerType.IfFalse,
        ]:
            if self._execute_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._execute_callback)

        elif trigger_type == TriggerType.Stop:
            if self._stop_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._stop_callback)

        elif trigger_type == TriggerType.Error:
            if self._error_callback is None:
                raise TriggerFlowException(
                    f"Execute callback not initialized for trigger type: {trigger_type}"
                )
            return self._wrap_callback(self._error_callback)

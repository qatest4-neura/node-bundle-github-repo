from abc import ABC, abstractmethod


class INeuraverseService(ABC):
    """
    ToDo: move to common package
    Abstract class for Neuraverse services.

    This class defines the common interface and lifecycle methods
    that all Neuraverse services must implement.
    """

    @abstractmethod
    def configure(self) -> None:
        """
        Configure the service with the given configuration.

        Args:
            config (Any): The configuration object for the service.
        """

    @abstractmethod
    async def start(self) -> None:
        """
        Start the service.

        This method should contain the logic to initialize and start the service.
        """
        pass

    @abstractmethod
    def stop(self) -> None:
        """
        Stop the service by gracefully shutting down the gRPC server.
        """
        if self.server:
            self.server.stop(grace=5)  # Gracefully stop the server with a 5-second timeout

    @abstractmethod
    def wait_for_termination(self) -> None:
        """
        Wait for the gRPC server to terminate.

        This method blocks until the server is terminated, allowing for graceful shutdown.
        """
        if self.server:
            # TODO: close connections to mongodb
            self.server.wait_for_termination()

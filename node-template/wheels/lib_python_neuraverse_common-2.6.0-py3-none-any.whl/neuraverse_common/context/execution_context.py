from typing import Any, List, Optional

from neuraverse.models.v1.gen.error.errors_pb2 import Warning
from neuraverse_common.models.auth.AuthInfo import AuthInfo
from neuraverse_common.utilities import ids
from neuraverse_common.utilities.time import get_current_timestamp_in_milliseconds


class ExecutionContext(object):
    """
    This context can carry information through backend function call-chain - letting each participants know the invocation context.

    Normally this context is created at the first public endpoint within the system someone invokes - no matter if this is a HTTP / gRPC endpoint or Event consuming from a Message Broker.
    Carries:
     * Crucial information to uniquely identify a given business transaction.
     * Authenticated user info too (optional)

    To ensure good observability you should make sure you decorate your log event with at least the `transactionId` and the `traceId` as labels!
    The context help ypu doing that - see methods!
    """

    def __init__(
        self,
        request_timestamp: int = None,
        transaction_id: str = None,
        trace_id: str = None,
        service_name_and_version: str = None,
        api_version: str = None,
        auth_info: Optional[AuthInfo] = None,
        caller_name_and_version: Optional[str] = None,
        caller_context: Optional[str] = None,
        **kwargs,
    ):
        # Request Metadata
        """The transactionId associated with this context"""
        self.transaction_id = transaction_id if transaction_id else ids.generate_uuid()
        """The traceId associated with this context"""
        self.trace_id = trace_id if trace_id else ids.generate_uuid()
        """Linux UTC timestamp (since Epoch) in milliseconds set by the client."""
        self.request_origin_timestamp = request_timestamp
        """The name and version of the caller service that created this context"""
        self.caller_name_and_version = caller_name_and_version
        """The context of the caller service that created this context"""
        self.caller_context = caller_context
        # Response Metadata
        """When was this context created? Linux UTC timestamp (since Epoch)"""
        self.request_timestamp = get_current_timestamp_in_milliseconds()        
        """A list of warnings that occurred during the execution of this context"""
        self.warnings: List[Warning] = []
        """The service name and version that created this context"""
        self.service_name_and_version = service_name_and_version
        """The API version that created this context"""
        self.api_version = api_version
        # Further Request Data
        """The auth info associated with this context"""
        self.auth_info = auth_info
        """Any additional information you want to pass through the context"""
        self.keyvalues: dict[str, Any] = kwargs if kwargs else {}

    # --- Getters and Setters ---

    def get_request_timestamp(self) -> int:
        return self.request_timestamp

    def set_request_timestamp(self, timestamp: int):
        self.request_timestamp = timestamp

    def get_origin_request_timestamp(self) -> int:
        return self.request_origin_timestamp

    def set_origin_request_timestamp(self, timestamp: int):
        self.request_origin_timestamp = timestamp

    def get_transaction_id(self) -> str:
        return self.transaction_id

    def set_transaction_id(self, transaction_id: str):
        self.transaction_id = transaction_id

    def get_trace_id(self) -> str:
        return self.trace_id

    def set_trace_id(self, trace_id: str):
        self.trace_id = trace_id

    def get_caller_name_and_version(self) -> Optional[str]:
        return self.caller_name_and_version

    def set_caller_name_and_version(self, caller_name_and_version: str):
        self.caller_name_and_version = caller_name_and_version

    def get_caller_context(self) -> Optional[str]:
        return self.caller_context

    def set_caller_context(self, caller_context: str):
        self.caller_context = caller_context

    def get_service_name_and_version(self) -> Optional[str]:
        return self.service_name_and_version

    def set_service_name_and_version(self, service_name_and_version: str):
        self.service_name_and_version = service_name_and_version

    def get_api_version(self) -> Optional[str]:
        return self.api_version

    def set_api_version(self, api_version: str):
        self.api_version = api_version

    def get_auth_info(self) -> Optional[AuthInfo]:
        return self.auth_info

    def set_auth_info(self, auth_info: AuthInfo):
        self.auth_info = auth_info
    
    def add_warning(self, warning: Warning):
        """
        Adds a Neuraverse entities defined `Warning` (Protobuf object) to the context. The context can store these during the execution.

        Tip: You can use `utilities.neuraverse_entities.WarningBuilder` class to easily build a Warning object with appropriate details.
        """
        self.warnings.append(warning)
    
    def get_warnings(self) -> List[Warning]:
        """Get the list of all Neuraverse entities defined `Warning` objects which were collected during the execution."""
        return self.warnings.copy()

    # --- Dynamic (KeyValue pairs) Fields ---

    def set_keyvalue(self, key: str, value: Any):
        """
        You can use this context object as a key-value storage as well. With this method you can register a key-value into this context.
        """
        self.keyvalues[key] = value

    def get_keyvalue(self, key: str) -> Optional[Any]:
        """
        Retrieve a key-value pair which was added to this context using the `set_keyvalue()`
        """
        return self.keyvalues.get(key)

    def get_all_keyvalues(self) -> dict[str, Any]:
        return self.keyvalues.copy()

    def has_keyvalue(self, key: str) -> bool:
        return key in self.keyvalues

    # --- Utilities ---

    def get_labels_for_log(self) -> dict[str, any]:
        """
        Use this function to fetch minimalistic info you should decorate your log events with to correlate things nicely!
        """
        data = {
            "transactionId": self.transaction_id,
            "traceId": self.trace_id,
        }
        # if we have loggen in user let's add his ID - this way we can also search logs based on UserID later (not bad for audit...)
        if self.auth_info is not None:
            data["actorId"] = self.auth_info.get_displayed_id()

        return data

    def get_took_millis(self) -> int:
        """
        Returns the time elapsed in milliseconds since this context was created.
        Prefers the original client timestamp if available, otherwise uses the server's request timestamp.
        Handles timestamps in both seconds and milliseconds.
        Returns 0 if no valid timestamp is available or if the computed duration is negative.
        """
        # Prefer the origin timestamp if set, else fallback to server timestamp
        first_available_timestamp = self.request_origin_timestamp or self.request_timestamp
        if not first_available_timestamp:
            return 0  # No valid timestamp available

        now_ms = get_current_timestamp_in_milliseconds()

        # Handle timestamps in seconds (10 digits) or milliseconds (13 digits)
        if first_available_timestamp < 1e12:  # likely in seconds
            request_ts_ms = int(first_available_timestamp * 1000)
        else:
            request_ts_ms = int(first_available_timestamp)

        took = now_ms - request_ts_ms
        # If the computed duration is negative, return 0
        return took if took > 0 else 0

import os


def buildGlobalLabels() -> dict[str, any]:
    """
    Builds a dictionary whos key-value pairs will serve as labels in logging and monitoring.

    This is done by scanning environment variables (due to our never agreed standards but not bad practice... :-P)
    """

    serviceName = os.environ.get("SERVICE_NAME")
    if serviceName is None:
        serviceName = os.environ.get("CONTAINER_NAME")
    if serviceName is None:
        serviceName = "?"

    serviceVer = os.environ.get("SERVICE_VERSION")
    if serviceVer is None:
        serviceVer = os.environ.get("CONTAINER_VERSION")
    if serviceVer is None:
        serviceVer = "?"

    host = os.environ.get("HOSTNAME")
    if host is None:
        host = os.environ.get("HOST")
    if host is None:
        host = "?"

    instanceId = os.environ.get("INSTANCE_ID")
    if instanceId is None:
        instanceId = "?"

    return {
        "serviceName": serviceName,
        "serviceVer": serviceVer,
        "host": host,
        "instId": instanceId,
    }

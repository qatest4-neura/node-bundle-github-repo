import logging.config
import os
from typing import List
from threading import Lock

import structlog
import yaml

# """
# **Note:** The 'observability' package could be externalized into a library and become a shared code.
# If we would have already agreed standards...
# But as we do not have them clearly, for now it stays here
# """


def __extract_log_filenames__(config) -> List[str]:

    handlers = config.get("handlers", {})
    filenames = []
    for handler in handlers.values():
        filename = handler.get("filename")
        if filename:
            filenames.append(os.path.dirname(filename))

    distinct_items = list(set(filenames))

    return distinct_items


def create_log_dirs(config) -> None:
    directories = __extract_log_filenames__(config)
    for folder in directories:
        if folder and not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)


class Logger:
    """
    A Class which is wrapping the underlying logging framework - service code is using this.
    This way we can change underlying logging easily. Also brings the standard log level
    methods - see https://neurarobotics.atlassian.net/wiki/spaces/nv/pages/1479409710/Logging+standards#log-levels
    """

    def __init__(self, name: str):
        # let's get the wrapped underlying logger
        self._logger: structlog.BoundLogger = structlog.getLogger(name, LoggerFactory._globalLabels)

    def error(self, *args, **namedArgs):
        self._logger.error(*args, **namedArgs)

    def warning(self, *args, **namedArgs):
        self._logger.warning(*args, **namedArgs)

    def info(self, *args, **namedArgs):
        self._logger.info(*args, **namedArgs)

    def debug(self, *args, **namedArgs):
        self._logger.debug(*args, **namedArgs)

    def isDebugEnabled(self) -> bool:
        level = self._getLevel()
        # see structlog/_log_levels.py
        return level <= 10

    def isInfoEnabled(self) -> bool:
        level = self._getLevel()
        # see structlog/_log_levels.py
        return level <= 20

    def isWarningEnabled(self) -> bool:
        level = self._getLevel()
        # see structlog/_log_levels.py
        return level <= 30

    def isErrorEnabled(self) -> bool:
        level = self._getLevel()
        # see structlog/_log_levels.py
        return level <= 40

    # It's definitely magic and a bit hacky... but should work for now!
    def _getLevel(self) -> int:
        l = self._logger.bind()
        if l._logger.disabled:
            return 100
        return l._logger.getEffectiveLevel()


def enrich_with_globallabels(_, __, ed):
    # lets merge in all global labels
    ed.update(LoggerFactory._globalLabels)
    return ed


class LoggerFactory:
    """
    A Factory class to create Logger instances. This class has static methods to allow service code can easily interact with it from anywhere.
    """

    # static private dictionary of created logger instances
    _loggers: dict[str, Logger] = dict()
    _lock = Lock()


    # let's start empty
    _globalLabels: dict[str, any] = dict()

    @staticmethod
    def configure_logging(logCfgFilePath: str | None, globalLabels: dict[str, any]) -> None:
        LoggerFactory._globalLabels = globalLabels

        if logCfgFilePath is None:
            print(
                "LoggerFactory: configuring logging - since no config file provided using defaults"
            )
            logging.basicConfig()
        else:
            print(
                "LoggerFactory: configuring logging - log config file to be used: " + logCfgFilePath
            )
            # Load the config file
            with open(logCfgFilePath, "rt") as f:
                config = yaml.safe_load(f.read())

            # creates log folders in not present in the current directory
            # otherwise application will crash
            create_log_dirs(config)

            # Configure the logging module with the config file
            logging.config.dictConfig(config)

        structlog.configure(
            logger_factory=structlog.stdlib.LoggerFactory(),
            processors=[
                enrich_with_globallabels,
                structlog.stdlib.render_to_log_kwargs,
            ],
        )

    # class method to get a logger
    @staticmethod
    def get_logger(name: str) -> Logger:
        # name = name.lower()
        with LoggerFactory._lock:
            logger = LoggerFactory._loggers.get(name)
            if logger is None:
                logger = Logger(name)
                LoggerFactory._loggers.update({name: logger})
        return logger

    getLogger = get_logger  # noqa: N816
    """
    CamelCase alias for `get_logger`.
    """

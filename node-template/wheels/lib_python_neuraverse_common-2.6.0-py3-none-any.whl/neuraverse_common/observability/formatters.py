import logging
import re
from datetime import datetime

import json_log_formatter
import pytz

_DO_NOT_ADD_TO_EXTRA = json_log_formatter.BUILTIN_ATTRS.union({"extra"})


def _fixed_extra_from_record(record):
    """
    json_log_formatter.JSONFormatter has a bug in its method - it can add key 'extra' to the extras... recursively.
    this is a fixed version
    """
    return {
        attr_name: record.__dict__[attr_name]
        for attr_name in record.__dict__
        if attr_name not in _DO_NOT_ADD_TO_EXTRA
    }


class CustomisedPlainFormatter(logging.Formatter):
    """
    Extending the standard logging Formatter and fixing the problem it is actually loosing the 'extra' parameters one attached (dict) to log events.

    Fix is inspired by how json_log_formatter.JSONFormatter is doing this and kinda reusing that mechanism.
    """

    def __init__(
        self,
        fmt=None,
        datefmt=None,
        style="%",
        validate=True,
        *,
        defaults=None,
        timezone="Europe/Berlin",
    ):
        super().__init__(fmt, datefmt, style, validate, defaults=defaults)
        self.timezone = pytz.timezone(timezone)

    def formatTime(self, record, datefmt=None):
        """
        Format the time of the log record in a specific timezone (Germany).
        This method converts the timestamp of the log record to a datetime object in the specified timezone
        and formats it according to the provided date format or a default format.
        Args:
            record (logging.LogRecord): The log record containing the timestamp.
            datefmt (str, optional): The format string for the date and time. Defaults to None.
        Returns:
            str: The formatted date and time string, including timezone information.
        """
        dt = datetime.fromtimestamp(record.created, self.timezone)
        return dt.strftime(datefmt or "%Y-%m-%d %H:%M:%S %z")

    def format(self, record):
        """
        Format the specified log record, ensuring that the 'extra' attribute is set and sanitized.
        This method attaches a fixed 'extra' dictionary to the log record by calling
        '_fixed_extra_from_record'. If 'extra' is a dictionary, it removes the 'color_message'
        key if present to avoid unwanted log output. The formatted log message is then
        generated using the superclass's format method.
        Args:
            record (logging.LogRecord): The log record to be formatted.
        Returns:
            str: The formatted log message.
        """
        record.extra = _fixed_extra_from_record(record)
        # Remove color_message if present
        if isinstance(record.extra, dict):
            record.extra.pop("color_message", None)
        s = super().format(record)
        return s


class CustomisedJSONFormatter(json_log_formatter.JSONFormatter):
    """
    A standard Python logging formatter which adds some log event attribute manipulation possibilties to the base JSONFormatter class.

    Extra constructor named parameters (You can also add these to log config file under `formatters` entry and configure from there!):
     * `reorderAttributes`: Optional. If set this must be an array of attributes. When given then the formatter makes sure that attributes listed here will be the first entries
        in the attribute dictionary (which are not listed will just still pick up random order).
        This feature is useful in local development where 'human readability' might be important. For log collection it does not make much sense you just wasting resources... So do not set in PROD.
     * `attributesRemap`: this is a dict[str, any] map. The formatter will basically "re-map" the event attributes. During this you can drop stuff, add new/more.
       The Key is identifiying the attribute name in the event and the Value tells the formatter what to do with it. So it is basically an operation.
       Supported operations (Values) are the following:
        * `!drop`: the attribute will be removed from the event
        * `!record_get(<LogRecord attribute name>)`: the attribute will be added by reading the given LogRecord attribute. So this is enrichment basically.
          Supported LogRecord attributes:
           * 'filename'
           * 'funcName'
           * 'levelname' - the log level
           * 'lineno'
           * 'module'
           * 'name' - the name of the logger
           * 'pathname
           * 'process'
           * 'processName'
           * 'stack_info'
           * 'thread'
           * 'threadName'
    """

    RECORD_GET_OP_MATCHER = r"!record_get\((?P<attrName>[^\)]*)\)"

    def __init__(
        self,
        fmt=None,
        datefmt=None,
        style="%",
        validate=True,
        *,
        defaults=None,
        attributesRemap: dict[str, any] = None,
        reorderAttributes: list[str] = None,
        timezone="Europe/Berlin",
    ):
        super().__init__(fmt, datefmt, style, validate, defaults=defaults)
        self._attributesRemap = attributesRemap
        if len(reorderAttributes) > 0:
            self._reorderAttributes = reorderAttributes
        else:
            self._reorderAttributes = None
        self.timezone = pytz.timezone(timezone)

    def extra_from_record(self, record):
        return _fixed_extra_from_record(record)

    def json_record(self, message, extra, record):

        # let our super create the dictionary
        event = super().json_record(message, extra, record)

        # add the time in a specific timezone
        local_time = datetime.fromtimestamp(record.created, tz=self.timezone)
        event["time"] = local_time.isoformat()

        # and now let's manipulate its entries!
        for key, value in self._attributesRemap.items():

            assignedValue = None
            removeAttrib = False
            if value.startswith("!"):
                if value == "!drop":
                    # we remove the attribute from the dictionary
                    removeAttrib = True
                else:
                    match = re.search(CustomisedJSONFormatter.RECORD_GET_OP_MATCHER, value)
                    if match is not None:
                        # We need
                        attrName = match.group("attrName")
                        attrName = attrName.replace('"', "")
                        if hasattr(record, attrName):
                            assignedValue = getattr(record, attrName)

            if removeAttrib:
                event.pop(key)
            if assignedValue is not None:
                event[key] = assignedValue

        # finally, reorder the attributes if needed
        if self._reorderAttributes is not None:
            reordered = dict()
            # iterate through the listed keys first
            for key in self._reorderAttributes:
                reordered.update({key: event.pop(key)})
            # let's add the rest
            reordered.update(event)
            event = reordered

        return event

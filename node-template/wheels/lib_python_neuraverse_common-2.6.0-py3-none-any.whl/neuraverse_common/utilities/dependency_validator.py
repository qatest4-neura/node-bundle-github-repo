from neuraverse_common.observability.logging import Logger

class DependencyValidator:

    @staticmethod
    def ensure_given_and_type_matching(
        target_instance: object,
        paramvalue_to_check: any,
        param_name: str,
        accepted_types: type | tuple[type],
        logger_to_use: Logger = None,
    ) -> None:
        """
        Helper method to validate a given dependency - related to Dependency Injection. This method will raise an error if the checked dependency
        is `None` (not given) or even if given does not have one of the listed types in `acceptedTypes`.
        Using this method bring standardized errors / behavior and eliminate related boiler plate code from the point of validation.

        Params:
        * `target_instance`: here you pass the obj reference where you are doing the validation right now (typically `self` you will pass here)
        * `paramvalue_to_check`: just pass over the dependency you want to check
        * `param_name`: the name of the param in your method signature which carries the dependency - it used for error text generation
        * `accepted_types`: provide the type(s) you want to accept the dependency has
        * `logger_to_use`: makes sense to pass your Logger if you have there one around - if you do then an error will be logged immediately
        """
        if paramvalue_to_check is None:
            err = f"Failed to instantiate {target_instance.__class__} due to dependency injection issue! '{param_name}' can not be None! You must provide it."
            if logger_to_use is not None:
                logger_to_use.error(err)
            raise ValueError(err)
        if not isinstance(paramvalue_to_check, accepted_types):
            # create err message
            acceptedTypeNames = DependencyValidator._get_accepted_type_name_list(accepted_types=accepted_types)
            err = f"Failed to instantiate {target_instance.__class__} due to dependency injection issue! '{param_name}' must be one of types {acceptedTypeNames} but you provided type '{type(paramvalue_to_check)}'!"
            if logger_to_use is not None:
                logger_to_use.error(err)
            raise ValueError(err)

    @staticmethod
    def ensure_none_or_type_matching(
        target_instance: object,
        paramvalue_to_check: any,
        param_name: str,
        accepted_types: type | tuple[type],
        logger_to_use: Logger = None,
    ) -> None:
        """
        Helper method to validate a given dependency - related to Dependency Injection. This method will raise an error if the checked dependency
        is not `None` (given) and does not have one of the listed types in `acceptedTypes`.
        Using this method bring standardized errors / behavior and eliminate related boiler plate code from the point of validation.

        Params:
        * `target_instance`: here you pass the obj reference where you are doing the validation right now (typically `self` you will pass here)
        * `paramvalue_to_check`: just pass over the dependency you want to check
        * `param_name`: the name of the param in your method signature which carries the dependency - it used for error text generation
        * `accepted_types`: provide the type(s) you want to accept the dependency has
        * `logger_to_use`: makes sense to pass your Logger if you have there one around - if you do then an error will be logged immediately
        """
        if paramvalue_to_check is not None and not isinstance(paramvalue_to_check, accepted_types):
            # create err message
            accepted_type_names = DependencyValidator._get_accepted_type_name_list(accepted_types=accepted_types)
            err = f"Failed to instantiate {target_instance.__class__} due to dependency injection issue! '{param_name}' must be one of types {accepted_type_names} but you provided type '{type(paramvalue_to_check)}'!"
            if logger_to_use is not None:
                logger_to_use.error(err)
            raise ValueError(err)

    @staticmethod
    def _get_accepted_type_name_list(accepted_types: type | tuple[type]) -> list[str]:
        # let's assemble the readable list of accepted types
        accepted_type_names: list[str] = list()
        if isinstance(accepted_types, type):
            accepted_type_names.append(accepted_types.__qualname__)
        else:
            for t in accepted_types:
                accepted_type_names.append(t.__qualname__)
        return accepted_type_names

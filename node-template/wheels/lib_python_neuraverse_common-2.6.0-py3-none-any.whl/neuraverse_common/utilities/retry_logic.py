"""
Helper methods for retryable error handling.
"""

from tenacity import RetryCallState

def custom_wait(retry_state: RetryCallState) -> float:
    """
    Custom wait function for retrying gRPC calls.

    This function checks if the exception has a custom retry hint for wait time.
    If not, it defaults to 1 second.

    Args:
        retry_state (RetryCallState): The state of the retry call.

    Returns:
        float: The wait time in seconds before the next retry.

    """
    exc = retry_state.outcome.exception()
    if exc and hasattr(exc, "retry_hint_min_wait_ms"):
        return exc.retry_hint_min_wait_ms / 1000.0
    return 1.0
"""
HOW TO USE (masking / redaction helpers)

Examples:

1. mask_string
   from redact_utils import mask_string
   mask_string("john.doe@example.com")            # -> j******e@e******.c***
   mask_string("Alice Johnson")                   # -> A**** J******
   mask_string("PlainSecret!", field_name="password")  # -> *****

2. mask_value_for_field
   mask_value_for_field("email", "user@example.org")    # -> u**r@e******.o***
   mask_value_for_field("password", "MyP@ssw0rd!")       # -> *****
   mask_value_for_field("full_name", "Ada Lovelace")     # -> A** L********

3. mask_sensitive_fields (in-place)
   user = {"email": "a.smith@example.com", "password": "Secret123", "full_name": "Alice Smith"}
   mask_sensitive_fields(user, ["email", "password", "full_name"])
   # user =>
   # {
   #   "email": "a*****h@e******.c***",
   #   "password": "*****",
   #   "full_name": "A**** S****"
   # }

4. clean_sensitive_fields (blank out)
   record = {"token": "ABCD1234", "note": "ok"}
   clean_sensitive_fields(record, ["token"])
   # record => {"token": "", "note": "ok"}

5. redact_and_mask (compose clean + mask)
   data = {
       "email": "person@example.com",
       "password": "SuperSecret!",
       "full_name": "Person Example",
       "api_key": "ZZZ-111",
   }
   # Blank out password entirely, mask the rest.
   redact_and_mask(
       data,
       fields_to_clean=["password"],
       fields_to_mask=["email", "full_name", "api_key"]
   )
   # data =>
   # {
   #   "email": "p****n@e******.c***",
   #   "password": "",
   #   "full_name": "P***** E******",
   #   "api_key": "*****"
   # }

6. Custom extra maskers
   def mask_last4(value: str) -> str:
       return "*" * (len(value) - 4) + value[-4:]
   card = {"credit_card": "4111111111111111"}
   mask_sensitive_fields(card, ["credit_card"], extra_maskers={"credit_card": mask_last4})
   # credit_card -> ************1111
"""

import re
from typing import Any, Callable, Dict, List, Optional

__all__ = [
    "mask_string",
    "mask_value_for_field",
    "mask_sensitive_fields",
    "redact_and_mask",
    "clean_sensitive_fields",
]


def mask_string(
    value: Any,
    field_name: Optional[str] = None,
    extra_maskers: Optional[Dict[str, Callable[[str], str]]] = None,
) -> Any:
    """
    Mask a single standalone value.

    Args:
        value: The value to mask (only strings are transformed).
        field_name: Optional field name hint (uses field-based masking logic).
        extra_maskers: Optional custom field->masker mapping.

    Heuristics when field_name is not provided:
      - If the string contains exactly one '@' -> treat as email.
      - Otherwise use the generic mask.

    Returns:
        Masked string (or original value if non-string / None).
    """
    if value is None or not isinstance(value, str):
        return value
    if field_name:
        return mask_value_for_field(field_name, value, extra_maskers)
    if "@" in value and value.count("@") == 1:
        return _mask_email(value)
    return _generic_mask(value)


def mask_value_for_field(
    field_name: str, value: Any, extra_maskers: Optional[Dict[str, Callable[[str], str]]] = None
) -> Any:
    """
    Mask a single field value based on its semantic name.
    Non-string values are returned unchanged (except None).
    """
    if value is None:
        return None
    if not isinstance(value, str):
        return value
    fn: Optional[Callable[[str], str]] = None
    lname = field_name.lower()
    if lname in _DEFAULT_FIELD_MASKERS:
        fn = _DEFAULT_FIELD_MASKERS[lname]
    if extra_maskers:
        el = {k.lower(): v for k, v in extra_maskers.items()}
        if lname in el:
            fn = el[lname]
    if fn is None:
        if "email" in lname:
            fn = _mask_email
        elif any(k in lname for k in ("pass", "secret", "token", "key")):
            fn = _mask_password
        elif "name" in lname:
            fn = _mask_name
        else:
            fn = _generic_mask
    return fn(value)


def mask_sensitive_fields(
    obj: Any,
    fields_to_mask: List[str],
    extra_maskers: Optional[Dict[str, Callable[[str], str]]] = None,
) -> Any:
    """
    In-place masking of specified fields on an object or dict.
    """
    for field in fields_to_mask:
        if hasattr(obj, field):
            current = getattr(obj, field)
            setattr(obj, field, mask_value_for_field(field, current, extra_maskers))
        elif isinstance(obj, dict) and field in obj:
            obj[field] = mask_value_for_field(field, obj[field], extra_maskers)
    return obj


def redact_and_mask(
    obj: Any,
    fields_to_clean: Optional[List[str]] = None,
    fields_to_mask: Optional[List[str]] = None,
    clean_value: Optional[str] = "",
    extra_maskers: Optional[Dict[str, Callable[[str], str]]] = None,
) -> Any:
    """
    Convenience helper: first clean (blank out) some fields, then mask others.
    """
    if fields_to_clean:
        clean_sensitive_fields(obj, fields_to_clean, clean_value)
    if fields_to_mask:
        mask_sensitive_fields(obj, fields_to_mask, extra_maskers)
    return obj


def clean_sensitive_fields(obj, fields_to_clean: List[str], clean_value: Optional[str] = ""):
    """
    Blank out specified fields (attribute or dict key).
    """
    for field in fields_to_clean:
        if hasattr(obj, field):
            setattr(obj, field, clean_value)
        elif isinstance(obj, dict) and field in obj:
            obj[field] = clean_value
    return


def _mask_email(email: str) -> str:
    if not isinstance(email, str):
        return "***"
    try:
        local, domain = email.split("@", 1)
        if len(local) <= 2:
            masked_local = "*" * len(local)
        else:
            masked_local = local[0] + "*" * (len(local) - 2) + local[-1]
        domain_parts = domain.split(".")
        masked_domain = ".".join(
            (p[0] + "*" * (len(p) - 1)) if len(p) > 1 else "*" for p in domain_parts
        )
        return f"{masked_local}@{masked_domain}"
    except Exception:
        return "***"


def _mask_password(_: str) -> str:
    return "*****"


def _mask_name(name: str) -> str:
    if not isinstance(name, str):
        return "***"
    tokens = re.split(r"(\s+|-|\'|’)", name)
    out = []
    for t in tokens:
        if not t or re.fullmatch(r"(\s+|-|\'|’)", t):
            out.append(t)
        else:
            out.append("*" if len(t) == 1 else t[0] + "*" * (len(t) - 1))
    return "".join(out)


def _generic_mask(value: str) -> str:
    if not isinstance(value, str):
        return "***"
    if len(value) <= 1:
        return "*"
    if len(value) == 2:
        return value[0] + "*"
    return value[0] + "*" * (len(value) - 2) + value[-1]


_DEFAULT_FIELD_MASKERS: Dict[str, Callable[[str], str]] = {
    "email": _mask_email,
    "email_address": _mask_email,
    "user_email": _mask_email,
    "password": _mask_password,
    "passwd": _mask_password,
    "pwd": _mask_password,
    "secret": _mask_password,
    "api_key": _mask_password,
    "token": _mask_password,
    "name": _mask_name,
    "full_name": _mask_name,
    "first_name": _mask_name,
    "last_name": _mask_name,
    "given_name": _mask_name,
    "family_name": _mask_name,
}

import re

from neuraverse_common.utilities import preconditions


def is_blank(s: str) -> bool:
    """Returns TRUE if string is either None or only has white spaces"""
    preconditions.check_argument(
        s is None or isinstance(s, str),
        "input parameter must be string - you passed {}",
        type(s),
    )
    return not s or not s.strip()


def is_not_blank(s: str) -> bool:
    """Returns TRUE if string is not None and has at least one character other than whitespace"""
    return not is_blank(s)


def camel_to_kebab(name: str) -> str:
    """Convert a camelCase or PascalCase string to kebab-case."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1-\2", name)
    kebab = re.sub("([a-z0-9])([A-Z])", r"\1-\2", s1).lower()
    return kebab


def extract_vars(s: str) -> set[str]:
    """
    Takes a string which can have variables in it btw {} - e.g. "my string with {var} variables".
    The method returns all variable names extracted from the string.
    """
    return set(re.findall(r"\{([^}]+)\}", s))


from neuraverse.models.v1.gen.error.errors_pb2 import Error, Warning
from neuraverse_common.utilities.neuraverse_entities import value_building
from collections.abc import Iterable


class WarningBuilder:
    """
    Helps to build an `Warning` entity defined in https://gitlab.hrg.systems/neuraverse/neuraverse-entities/-/blob/main/protos/neuraverse/models/v1/gen/error/errors.proto?ref_type=heads.
    """

    def __init__(self, message_template: str):
        self.messagetemplate = message_template
        self.labels: dict[str, any] = None
        self.messagetemplate_by_audience: dict[str, str] = None
        self.codes: set[str] = None

    def with_messagetemplate(self, messageTemplate: str):
        self.messagetemplate = messageTemplate
        return self

    def with_audience_messagetemplate(self, audienceRole: str, messageTemplate: str):
        if self.messagetemplate_by_audience == None:
            self.messagetemplate_by_audience = dict()
        self.messagetemplate_by_audience[audienceRole] = messageTemplate
        return self

    def with_audience_messagetemplates(self, message_templates: dict[str, str]):
        if message_templates != None and len(message_templates) > 0:
            if self.messagetemplate_by_audience == None:
                self.messagetemplate_by_audience = dict()
            self.messagetemplate_by_audience.update(message_templates)
        return self

    def with_exact_audience_messagetemplates(self, message_templates: dict[str, str]):
        self.messagetemplate_by_audience = message_templates
        return self

    def without_audience_messagetemplate(self, audienceRole: str):
        if self.messagetemplate_by_audience != None:
            self.messagetemplate_by_audience.pop(audienceRole, None)
        return self

    def without_audience_messagetemplates(self):
        self.messagetemplate_by_audience = None
        return self

    def with_label(self, key: str, value: any):
        if self.labels == None:
            self.labels = dict()
        self.labels[key] = value
        return self

    def without_label(self, key: str):
        if self.labels != None:
            self.labels.pop(key, None)
        return self

    def with_labels(self, labels: dict[str, any]):
        if labels != None and len(labels) > 0:
            if self.labels == None:
                self.labels = dict()
            self.labels.update(labels)
        return self

    def with_exact_labels(self, labels: dict[str, any]):
        self.labels = labels
        return self

    def without_labels(self):
        self.labels = None
        return self

    def with_code(self, code: str):
        if self.codes == None:
            self.codes = set()
        self.codes.add(code)
        return self

    def without_code(self, code: str):
        if self.codes != None:
            self.codes.remove(code)
        return self

    def without_codes(self):
        self.codes = None
        return self

    def with_codes(self, codes: Iterable[str]):
        if codes != None and len(codes) > 0:
            if self.codes == None:
                self.codes = set()
            self.codes = self.codes.union(codes)
        return self

    def with_exact_codes(self, codes: Iterable[str]):
        self.codes = set()
        if codes != None:
            self.codes = self.codes.union(codes)
        return self


    def build(self) -> Warning:
        """
        Builds a new Warning object
        """
        warning = Warning(
            messageTemplate = self.messagetemplate,
        )
        if self.labels:
            for k,v in self.labels.items():
                _v = value_building.any_to_valueentity(v)
                warning.labels[k].CopyFrom(_v)
        if self.messagetemplate_by_audience:
            warning.messageTemplateByAudience.update(self.messagetemplate_by_audience)
        if self.codes:
            warning.codes.extend(self.codes)

        return warning
        
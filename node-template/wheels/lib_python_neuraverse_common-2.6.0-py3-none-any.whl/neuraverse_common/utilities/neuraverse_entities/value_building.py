
from neuraverse.models.v1.gen.business.common_pb2 import Value, NullValue, Struct, ListValue
from collections.abc import Iterable, Mapping
from neuraverse_common.utilities.logging_helpers import VarPrinter
from google.protobuf.message import Message
from neuraverse_common.utilities import proto_utils
from neuraverse_common.models.error import errors_v2
from neuraverse_common.utilities import preconditions

def any_to_valueentity(v: any) -> Value:
    """
    Takes a Python variable and converts it into a Value entity - defined in 
    https://gitlab.hrg.systems/neuraverse/neuraverse-entities/-/blob/main/protos/neuraverse/models/v1/gen/business/common.proto?ref_type=heads

    We use this Value structure multiple places, like in `labels` typically which is map<string, Value> pairs.
    """

    if v == None:
        return Value(null_value = NullValue.NULL_VALUE)
    
    if isinstance(v, Value):
        # nothing to do
        return v
    
    if isinstance(v, bool):
        return Value(bool_value = v)
    
    if isinstance(v, int) or isinstance(v, float):
        return Value(number_value = v)
    
    if isinstance(v, str):
        return Value(string_value = v)
    
    if isinstance(v, dict):
        # this thing might be tricky - simple until keys are primitive types
        # but are they...? we need to be careful
        valueMap: dict[any, Value] = dict()
        for k, v in v.items():
             # we go into recursion for the value
            _v = any_to_valueentity(v)
            # careful with keys
            if isinstance(k, str) or isinstance(k, int) or isinstance(k, float) or isinstance(k, bool):
                # OK simple - keep the simplicity
                valueMap[k] = any_to_valueentity(v)
            else:
                # TODO no idea what to do here so far - simply we do not nhave good use case
                # so let's just raise an error and if someone runs into this will scream :-)
                raise errors_v2.NeuraNotImplementedError(
                    "Oops you just ran into a situation which we postponed to handle due to lack of good use-case... We did not expect a dict of Value with non-primitive type keys. But it looks you have a key in the dict type '{unsupported_key_type}'... Reach out to library maintainer and discuss what you wanted to do! sorry..."
                ).with_label("unsupported_key_type", k.__class__.__name__)

        struct = Struct(fields = valueMap)
        return Value(struct_value = struct)

    if isinstance(v, Iterable):
        _list: list[any] = list()
        for item in v:
            # we go into recursion
            _list.append(any_to_valueentity(item))
        lvalue = ListValue(values = _list)
        return Value(list_value = lvalue)
    
    if isinstance(v, Message):
        # first we convert the message into a dict
        d = proto_utils.proto_to_dict(v, keep_all_fields=True)
        # and now go into recursion
        return any_to_valueentity(d)

    
    # OK if we are here that very likely means we received an object, a class instance
    # For now what makes sense is to convert it into its str value according to our best knowledge
    # We will get help from our `VarPrinter`!
    return Value(string_value = str(VarPrinter(v)))


def valueentity_to_python_value(value: Value) -> str|float|bool|dict|list|None:
    """
    This is the quasi-reverse operation of `any_to_valueentity()` method.

    It converts back primitive types nicely (string, number or bool) but gets tricky when Value is list or struct type...
    In this case list type is converted to `list()` object while struct type is converted into `dict()` - no better way.
    And this is the reason why it is just "quasi-reverse" operation... Since in original method multiple things converting
    into a list value type (sets, lists - any iterable). Similar for struct types.
    """

    if value == None:
        return None
    
    preconditions.check_argument(isinstance(value, Value), "type of 'value' is not Value type - its type is '{}'", type(value))
    
    kind = value.WhichOneof("kind")

    if kind == "null_value":
        return None
    if kind == "string_value":
        return value.string_value
    if kind == "number_value":
        return value.number_value
    if kind == "bool_value":
        return value.bool_value    

    if kind == "list_value":
        result: list[any] = list()
        for item in value.list_value.values:
            _item = valueentity_to_python_value(item)
            result.append(_item)
        return result
    
    if kind == "struct_value":
        result: dict[any, any] = dict()
        for key, val in value.struct_value.fields.items():
            result[key] = valueentity_to_python_value(val)
        return result

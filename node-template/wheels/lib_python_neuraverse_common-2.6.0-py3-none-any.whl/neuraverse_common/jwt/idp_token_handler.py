"""Auth Management API token handler."""

import http.client
import inspect
import json
import threading
import time

from cachetools import LRUCache
from deprecated import deprecated
from jose import jwt

from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.config.config_source.JwtConfig import AuthApplicationName, JwtConfig
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability.logging import Logger, LoggerFactory


class IdpTokenHandler:
    """Handles Identity Provider API token retrieval and caching."""

    _global_last_eviction_time = 0
    _global_eviction_lock = threading.Lock()
    logger_name: str = "lib.common.jwt.IdpTokenHandler"

    def __init__(self, jwt_config: JwtConfig):
        self.LOG: Logger = LoggerFactory.get_logger(self.logger_name)
        self.jwt_config = jwt_config
        self.token_cache = LRUCache(maxsize=jwt_config.token_cache_size)
        self._lazy_eviction_interval = jwt_config.token_cache_ttl_seconds

    # --- Token Retrieval ---
    def _fetch_idp_api_token(self, app_name: str, context: ExecutionContext = None) -> dict:
        """
        Fetches a new IdP API token using client credentials.

        Args:
            app_name (str): The application name for which to get the M2M token.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            dict: The Auth token response (includes `access_token`, `token_type`).
        """
        app_config = self.jwt_config.applications.get(app_name)
        if not app_config:
            raise errors_v2.NeuraIllegalStateError(
                f"Unknown IdP application name: {app_name}"
            ).with_is_retryable(False).with_errorcode(
                errors_v2.NeuraIllegalStateError.ERRCODE_CONFIG_ERROR
            )

        payload = {
            "client_id": app_config.client_id,
            "client_secret": app_config.client_secret,
            "audience": app_config.audience,
            "grant_type": "client_credentials",
        }

        headers = {"Content-Type": "application/json"}

        try:
            conn = http.client.HTTPSConnection(app_config.domain)
            conn.request("POST", "/oauth/token", json.dumps(payload), headers)
            response = conn.getresponse()
            if response.status != 200:
                # just a stupid brute force classification...
                is_retryable = response.status >= 500 and response.status < 600
                raise errors_v2.NeuraIllegalStateError(
                    f"Failed to fetch IdP API token: {response.status} {response.reason}"
                ).with_is_retryable(is_retryable).with_errorcode(
                    errors_v2.NeuraIllegalStateError.ERRCODE_EXCPECTATION_FAILED
                )
            data = response.read()
            return json.loads(data.decode("utf-8"))

        except Exception as e:
            raise errors_v2.NeuraIllegalStateError(
                f"Failed to fetch IdP API token: {str(e)}"
            ).with_is_retryable(False).with_errorcode(
                errors_v2.NeuraIllegalStateError.ERRCODE_EXCPECTATION_FAILED
            ) from e

    @deprecated(reason="Use get_m2m_token() instead, with new JWTConfig structure.")
    def get_management_token(self, audience: str, context: ExecutionContext = None) -> str:
        """
        Deprecated method. Please use get_m2m_token() instead.
        Returns a valid IdP API token, using cache if possible.

        Args:
            audience (str): The audience for which to request the token.
        Returns:
            str: The access token string.
        """
        # For now, we only used the auth0_mgmt app in the old structure.
        app_name = AuthApplicationName.AUTH0_MGMT
        return self.get_m2m_token(app_name=app_name, context=context)

    def get_m2m_token(self, app_name: str, context: ExecutionContext = None) -> str:
        """
        Returns a valid IdP API token, using cache if possible.

        Args:
            app_name (str): The application name for which to get the M2M token.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            str: The access token string.
        """
        log_labels = context.get_labels_for_log() if context else dict()
        method_name = inspect.currentframe().f_code.co_name
        self.LOG.debug("%s(): invoked - app_name: '%s'", method_name, app_name, **log_labels)

        # Check local development override (to avoid fetching from IdP every time)
        token_override = self.jwt_config.FOR_LOCAL_DEVELOPMENT_IDP_API_TOKEN_OVERRIDE
        if token_override and token_override != "":
            self.LOG.warning(
                "Using environment override token for IdP API access - for local development only"
            )
            return token_override

        self._evict_cache_if_needed(context=context)

        cached = self._get_cached_token(app_name=app_name, context=context)
        if cached:
            return cached["access_token"]

        token_data = self._fetch_idp_api_token(app_name=app_name, context=context)
        self._store_in_cache(token_data=token_data, app_name=app_name, context=context)
        return token_data["access_token"]

    # --- Cache Management ---
    def _store_in_cache(
        self, token_data: dict, app_name: str, context: ExecutionContext = None
    ) -> None:
        """
        Stores the fetched IdP API token with its expiry time in the local cache.

        Args:
            token_data (dict): The token response from Auth.
        """
        log_labels = context.get_labels_for_log() if context else dict()

        # Extract expiry from token claims
        now = time.time()
        unverified_claims = jwt.get_unverified_claims(token_data["access_token"])
        fallback_expiry_ts = now + self.jwt_config.token_cache_ttl_seconds
        expiry_ts = unverified_claims.get("exp", fallback_expiry_ts)

        # cache under a fixed key, since only one IdP API token exists
        self.token_cache[app_name] = (expiry_ts, token_data)
        self.LOG.info(
            "Stored new IdP API token in cache (expires in %ss).",
            self.jwt_config.token_cache_ttl_seconds,
            **log_labels,
        )

    def _get_cached_token(self, app_name: str, context: ExecutionContext = None) -> dict | None:
        """
        Retrieves the cached token if still valid.

        Args:
            app_name (str): The application name for which to get the M2M token.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            Optional[dict]: Cached token if valid, else None.
        """
        cached = self.token_cache.get(app_name)
        if cached:
            expiry_ts, token_data = cached
            if time.time() < expiry_ts:
                return token_data
            else:
                del self.token_cache[app_name]
        return None

    def _evict_expired_tokens(self, context: ExecutionContext = None) -> None:
        """Removes expired tokens from cache."""
        now = time.time()
        expired_keys = [key for key, (expiry_ts, _) in self.token_cache.items() if expiry_ts < now]
        for key in expired_keys:
            del self.token_cache[key]
        if expired_keys:
            log_labels = context.get_labels_for_log() if context else dict()
            self.LOG.info("Evicted %d expired tokens from cache.", len(expired_keys), **log_labels)

    def _evict_cache_if_needed(self, context: ExecutionContext = None):
        """
        Performs lazy eviction if enough time has passed since the last cleanup.
        """
        now = time.time()
        if now - IdpTokenHandler._global_last_eviction_time < self._lazy_eviction_interval:
            return

        if IdpTokenHandler._global_eviction_lock.acquire(blocking=False):
            try:
                self._evict_expired_tokens(context=context)
                IdpTokenHandler._global_last_eviction_time = now
            finally:
                IdpTokenHandler._global_eviction_lock.release()

    def clear_token_cache(self, context: ExecutionContext = None) -> None:
        """Clears the cached IdP API token."""
        log_labels = context.get_labels_for_log() if context else dict()
        method_name = inspect.currentframe().f_code.co_name
        self.LOG.debug("%s(): invoked", method_name, **log_labels)

        self.token_cache.clear()
        self.LOG.info("Cleared IdP API token cache manually.", **log_labels)

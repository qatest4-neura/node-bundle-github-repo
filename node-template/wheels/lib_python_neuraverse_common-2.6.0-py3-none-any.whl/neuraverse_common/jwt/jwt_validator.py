"""
This module implements the `JwtValidator` class for validating JWT tokens
using JSON Web Key Set (JWKS) endpoints.

The `JwtValidator` class fetches the JWKS from the configured authorization server,
retrieves the appropriate public key for a given token, and validates the token's
signature, audience, and issuer.
"""

import threading
import time
from functools import lru_cache
from typing import Optional

import requests
from cachetools import LRUCache
from jose import JWTError, jwt

from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.config.config_source.JwtConfig import AuthApplicationName, JwtConfig
from neuraverse_common.models.error import errors_v2
from neuraverse_common.observability.logging import Logger, LoggerFactory


@lru_cache(maxsize=1)
def load_jwks(jwks_url: str, ttl_hash=None, context: ExecutionContext = None) -> list:
    """
    Fetches JWKS from the given URL with caching.

    Args:
        jwks_url (str): JWKS endpoint.
        ttl_hash (int, optional): Dummy TTL-based hash to expire cache.

    Returns:
        list: List of JWK keys.
    """
    del ttl_hash
    response = requests.get(jwks_url)
    response.raise_for_status()
    return response.json()["keys"]


class JwtValidator:
    """
    Validates JWT tokens using a JSON Web Key Set (JWKS),
    with lazy cache eviction for expired tokens.
    """

    _global_last_eviction_time = 0
    _global_eviction_lock = threading.Lock()
    logger_name: str = "lib.common.jwt.JWTValidator"

    USER_ID_CLAIM = "https://neuraverse.com/user_id"
    USER_FALLBACK_CLAIM = "sub"
    SERVICE_ID_CLAIM = "https://neuraverse.com/service_id"
    SERVICE_FALLBACK_CLAIM = "gty"

    def __init__(self, jwt_config: JwtConfig):
        """
        Initializes the validator with the given JWT configuration.

        Args:
            jwt_config (JwtConfig): The JWT configuration for validation.
        """
        self.LOG: Logger = LoggerFactory.get_logger(self.logger_name)
        self.jwt_config = jwt_config
        self.token_cache = LRUCache(maxsize=jwt_config.token_cache_size)
        self._lazy_eviction_interval = jwt_config.token_cache_ttl_seconds

    # --- JWKS retrieval and caching ---
    def _get_ttl_hash(self, context: ExecutionContext = None) -> int:
        """
        Returns a value that changes every configured JWKS TTL interval (in days).
        Used to simulate TTL-based cache invalidation for lru_cache.
        """
        ttl_seconds = self.jwt_config.jwks_ttl_days * 24 * 60 * 60
        return round(time.time() / ttl_seconds)

    def _get_jwks(self, jwks_url: str, context: ExecutionContext = None) -> list:
        """
        Retrieves JWKS using TTL-based cached function.

        Args:
            jwks_url (str): The JWKS URL.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            list: List of JWKs.
        """
        ttl_hash = self._get_ttl_hash(context=context)
        return load_jwks(jwks_url=jwks_url, ttl_hash=ttl_hash, context=context)

    def force_refresh(self, context: ExecutionContext = None) -> None:
        """
        Forces JWKS cache to be cleared and refetched on next call.
        Clears the token cache as well.
        """
        # TODO context passing here?
        load_jwks.cache_clear()
        self.clear_token_cache(context=context)
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.info(
            "JWKS and token caches have been cleared. JWKS will be refetched on next call.",
            **log_labels,
        )

    def _get_public_key(self, token: str, jwks_url: str, context: ExecutionContext = None) -> dict:
        """
        Retrieves the public key matching the token's key ID (kid).

        Args:
            token (str): The JWT token.
            jwks_url (str): The JWKS URL to fetch keys from.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            dict: The public key.
        """
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
        jwks = self._get_jwks(jwks_url, context=context)
        key = next((k for k in jwks if k["kid"] == kid), None)
        if not key:
            raise errors_v2.NeuraIllegalStateError(
                message="Matching public key not found in JWKs"
            ).with_is_retryable(False).with_errorcode(
                errors_v2.NeuraIllegalStateError.ERRCODE_EXCPECTATION_FAILED
            )

        return key

    # --- Token validation and caching ---
    def _decode_token(self, token: str, context: ExecutionContext = None) -> dict:
        """
        Decodes and validates the JWT token using the public key.
        Args:
            token (str): The JWT token to decode.
            context (ExecutionContext, optional): The execution context for logging.

        Returns:
            dict: The decoded token payload.
        """
        try:
            # Get unverified claims to determine which application config to use
            unverified_claims = jwt.get_unverified_claims(token)
            if self.USER_ID_CLAIM in unverified_claims or unverified_claims.get(
                self.USER_FALLBACK_CLAIM, ""
            ).startswith("auth0|"):
                app_config = self.jwt_config.applications.get(AuthApplicationName.SPA)

            # TODO: [NRV-4541] Create config map for each M2M application by service_id
            elif self.SERVICE_ID_CLAIM in unverified_claims:
                app_config = self.jwt_config.applications.get(
                    [unverified_claims[self.SERVICE_ID_CLAIM]]
                )
            # Note: For now, we only have one M2M application, so we map all other cases to it
            elif (
                self.SERVICE_FALLBACK_CLAIM in unverified_claims
                and unverified_claims[self.SERVICE_FALLBACK_CLAIM] == "client-credentials"
            ):
                app_config = self.jwt_config.applications.get(AuthApplicationName.M2M_DEFAULT)

            else:
                # this is not a valid token format, let's raise an error
                raise Exception("Invalid token: missing required claims")

            # Validate using the appropriate application config
            audience = app_config.audience
            issuer = app_config.issuer
            jwks_url = app_config.jwks_url
            public_key = self._get_public_key(token, jwks_url)

            return jwt.decode(
                token,
                public_key,
                algorithms=[self.jwt_config.algorithm],
                audience=audience,
                issuer=issuer,
            )
        except JWTError as e:
            log_labels = context.get_labels_for_log() if context else {}
            self.LOG.error("JWT decoding failed: %s", str(e), **log_labels)
            if "Signature verification failed" in str(e):
                self.force_refresh(context=context)
                # we throw unsafe error at this point
                raise errors_v2.NeuraAuthenticationError(message="Invalid token signature") from e
            else:
                raise errors_v2.NeuraAuthenticationError(message=f"Invalid token: {str(e)}") from e

    def _get_cached_token(self, token: str, context: ExecutionContext = None) -> Optional[dict]:
        """
        Check cache and return decoded token if still valid.

        Args:
            token (str): The JWT token.

        Returns:
            Optional[dict]: The decoded token if found and not expired, else None.
        """
        cached = self.token_cache.get(token)
        if cached:
            expiry_ts, decoded_token = cached
            if time.time() < expiry_ts:
                return decoded_token
            else:
                del self.token_cache[token]
        return None

    def _store_in_cache(
        self, token: str, decoded_token: dict, context: ExecutionContext = None
    ) -> None:
        """
        Stores a token with its *exact* exp claim as cache expiry.
        If no exp is present, falls back to configured default TTL.
        Also, clears expired tokens from cache before storing.

        Args:
            token (str): The JWT token.
            decoded_token (dict): The decoded token payload.
        """
        now = time.time()
        exp = decoded_token.get("exp")

        expiry_ts = exp if exp is not None else now + self.jwt_config.token_cache_ttl_seconds

        self.token_cache[token] = (expiry_ts, decoded_token)

    def clear_token_cache(self, context: ExecutionContext = None) -> None:
        """Clear all cached validated tokens."""
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.debug("clearing cache", **log_labels)

        self.token_cache.clear()

    def _evict_expired_tokens(self, context: ExecutionContext = None) -> None:
        """
        Removes expired tokens from cache opportunistically.
        """
        now = time.time()
        expired_keys = [
            token for token, (expiry_ts, _) in self.token_cache.items() if expiry_ts < now
        ]
        for token in expired_keys:
            del self.token_cache[token]
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.info(f"Evicted {len(expired_keys)} expired tokens from cache.", **log_labels)

    def _evict_cache_if_needed(self, context: ExecutionContext = None):
        """
        Performs lazy eviction of expired tokens from the cache.
        Eviction is triggered only if the configured interval has elapsed since the last eviction.
        Uses a lock to ensure thread safety and prevent redundant evictions under concurrent access.
        """
        now = time.time()

        if now - JwtValidator._global_last_eviction_time < self._lazy_eviction_interval:
            return

        if JwtValidator._global_eviction_lock.acquire(blocking=False):
            try:
                self._evict_expired_tokens(context=context)
                JwtValidator._global_last_eviction_time = now
            finally:
                JwtValidator._global_eviction_lock.release()

    def validate_token(self, token: str, context: ExecutionContext = None) -> dict:
        """
        Validates JWT token, using cache if available & not expired.

        Args:
            token (str): The JWT token to validate.

        Returns:
            dict: The decoded token if valid.
        """
        log_labels = context.get_labels_for_log() if context else {}
        self.LOG.debug("validating token...", **log_labels)

        self._evict_cache_if_needed(context=context)

        cached = self._get_cached_token(token, context=context)
        if cached:
            self.LOG.debug("found in cache - returning as validated", **log_labels)
            return cached

        self.LOG.debug("decoding token...", **log_labels)
        decoded_token = self._decode_token(token, context=context)
        self._store_in_cache(token, decoded_token, context=context)

        self.LOG.debug("all done - token cached", **log_labels)
        return decoded_token

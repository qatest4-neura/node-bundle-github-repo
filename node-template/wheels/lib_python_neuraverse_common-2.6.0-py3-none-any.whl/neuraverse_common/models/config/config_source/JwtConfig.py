"""
This module defines the `JwtConfig` class for managing JWT configuration in the
NEURA robotics tenant service.

The `JwtConfig` class provides structured fields for defining JWT-related
settings, such as the JWKS URL, issuer, client ID, and roles. It
leverages Pydantic for validation and ensures that these fields are properly
set and documented.
"""

from enum import Enum
from typing import Dict, Union

from pydantic import ConfigDict, Field, model_validator
from pydantic_settings import BaseSettings


class AuthApplicationName(str, Enum):
    """
    This enum defines the standard names for authentication applications used in the Neuraverse ecosystem.

    New unknown application names can also be used as plain strings in the configuration.
    """

    # Single page application for end users
    SPA = "spa"
    # Auth0 Management API application
    AUTH0_MGMT = "auth0_mgmt"
    # Machine to Machine applications (for now only one, but will be extended in the future, 1 per service)
    M2M_DEFAULT = "m2m_default"


class AuthAppConfig(BaseSettings):
    audience: str = Field(default="Not set", description="Audience for the application")
    client_id: str = Field(default="Not set", description="Client ID for the application")

    client_secret: str = Field(default="Not set", description="Client Secret for the application")
    domain: str = Field(default="Not set", description="Auth0 domain for the application")
    issuer: str = Field(
        default="Not set",
        description="Token issuer (defaults to https://{domain}/)",
    )
    jwks_url: str = Field(
        default="Not set",
        description="JWKS URL for the authentication provider (defaults to https://{domain}/.well-known/jwks.json)",
    )


class JwtConfig(BaseSettings):
    """
    Configuration class for JWT settings.

    This class defines the necessary fields for configuring JWT authentication
    and role-based access control, now supporting multiple applications.

    Example configuration in YAML format:
    jwt:
        auth_type: "Bearer"
        algorithm: "RS256"
        domain: "xxx"  # default domain for applications
        jwks_ttl_days: 180
        token_cache_size: 1000
        token_cache_ttl_seconds: 32400
        applications:
            spa:
                audience: "xxx"
                # you can add/ omit domain, issuer, and jwks_url to use the defaults, or set them explicitly
                # domain: "xxx"
                # issuer: "xxx"
                # jwks_url: "xxx"
            auth0_mgmt:
                audience: "xxx"
            m2m_default:
                audience: "xxx"

    other fields like AUTH_CLIENT_ID, AUTH_IDP_API_CLIENT_ID, and AUTH_IDP_API_CLIENT_SECRET
    are expected to be set via environment variables or secret management.
    """

    model_config = ConfigDict(extra="allow")

    # Sensitive variables from environment variables or secret management
    AUTH_CLIENT_ID: str = Field(default="Not set", description="Default client ID")
    AUTH_IDP_API_CLIENT_ID: str = Field(
        default="Not set", description="Auth0 Client ID for Machine to Machine Application"
    )
    AUTH_IDP_API_CLIENT_SECRET: str = Field(
        default="Not set", description="Auth0 Client Secret for Machine to Machine Application"
    )
    # Only for local development
    FOR_LOCAL_DEVELOPMENT_IDP_API_TOKEN_OVERRIDE: str = Field(
        default="",
        description="Auth0 management API token - so we do not fetch a new one every time in local development",
    )
    # --- Deprecated fields for backward compatibility ---
    # TODO: Remove deprecated fields from secret manager. These variables can be derived from 'domain' in each app config.
    AUTH_JWKS_URL: str = Field(default="Not set", description="JWKS endpoint URL")
    AUTH_ISSUER: str = Field(default="Not set", description="JWT issuer")

    # Variables defined in the config file
    auth_type: str = Field(default="Bearer", description="Authentication type")
    algorithm: str = Field(default="RS256", description="JWT signing algorithm")
    domain: str = Field(default="Not set", description="Auth0 domain for default application")
    jwks_ttl_days: int = Field(
        default=180, description="Time-to-live for cached JWKS in days, defaults to 180 days"
    )
    token_cache_size: int = Field(default=1000, description="Maximum size of the token cache")
    token_cache_ttl_seconds: int = Field(
        default=32400, description="Time-to-live for cached tokens in seconds, defaults to 9 hours"
    )

    applications: Dict[Union[AuthApplicationName, str], AuthAppConfig] = Field(
        default_factory=dict,
        description="Configuration for different Auth0 applications",
    )

    @model_validator(mode="after")
    def map_client_credentials(self) -> "JwtConfig":
        for app_name, app_config in self.applications.items():
            # Populate domain if not set
            if app_config.domain == "Not set":
                app_config.domain = self.domain

            # Map client credentials to known applications
            if app_name == AuthApplicationName.SPA:
                app_config.client_id = self.AUTH_CLIENT_ID
            # TODO: [NRV-4541] Add support for multiple M2M applications with different configurations
            # Note: For now, we have only one M2M application used by multiple services, so we map the same credentials.
            # Note: auth0 mgmt api and m2m default share the same client id/secret but have different audiences/ domains
            elif app_name in (
                AuthApplicationName.AUTH0_MGMT,
                AuthApplicationName.M2M_DEFAULT,
            ):
                app_config.client_id = self.AUTH_IDP_API_CLIENT_ID
                app_config.client_secret = self.AUTH_IDP_API_CLIENT_SECRET

            # Derive OIDC fields if not explicitly set
            if app_config.issuer == "Not set":
                app_config.issuer = f"https://{app_config.domain}/"

            if app_config.jwks_url == "Not set":
                app_config.jwks_url = f"https://{app_config.domain}/.well-known/jwks.json"
        return self

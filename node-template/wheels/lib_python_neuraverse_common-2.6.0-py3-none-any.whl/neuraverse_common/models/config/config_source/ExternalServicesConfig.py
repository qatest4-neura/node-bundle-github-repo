"""
This module defines the `ExternalServicesConfig` class for managing external gRPC service
configuration in the NEURA robotics services.
"""

from pydantic import Field
from pydantic_settings import BaseSettings
from deprecated import deprecated

@deprecated("This does not belong here as a generic thing so if you use it, move away from here somehow as we will remove this class soon")
class ExternalServicesConfig(BaseSettings):
    """
    Configuration class for External services settings.

    This class defines the necessary fields for configuring external gRPC services,
    including service name, address, and port. It uses Pydantic's BaseSettings to
    provide validation and settings management.
    """

    name: str = Field(..., description="Name of the external gRPC service")
    address: str = Field(..., description="Hostname or IP address of the gRPC service")
    port: int = Field(..., description="Port number the gRPC service is running on")

    class Config:
        extra = "allow"

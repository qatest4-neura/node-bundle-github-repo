"""
This module defines the `HistoryTrack` class.
It is used define define the size of history entries list,
of entities maintained by service
"""

from pydantic import Field, FieldValidationInfo, field_validator
from pydantic_settings import BaseSettings

MIN_HISTORY_COUNT: int = 1


class HistoryTrackConfig(BaseSettings):
    """
    Configuration class for history tracking.
    """

    max_entity_num_of_history: int = Field(
        default=10,
        description="The maximum number of history entries to retain for each entity (at least 1)"
    )

    max_attachment_num_of_history: int = Field(
        default=3,
        description="The maximum number of attachment history entries to retain for each attachment (at least 1)."
    )

    @field_validator("max_entity_num_of_history", "max_attachment_num_of_history")
    def _validate_minimal_size(
        cls,
        config_param_value: int,
        info: FieldValidationInfo
    ) -> int:  # noqa: N805 - pydantic validator naming

        if config_param_value < MIN_HISTORY_COUNT:
            name = info.field.name if getattr(info, "field", None) is not None else "value"
            raise ValueError(f"{name} must be at least {MIN_HISTORY_COUNT}")
        return config_param_value

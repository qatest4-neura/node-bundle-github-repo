"""
This module defines the `LogConfig` class - comes handy some points to know things about it.
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class LogConfig(BaseSettings):
    """
    Configuration class for logging.
    """

    ENVVAR_LOG_CFG_PATH: str = Field(
        default="Not set",
        description="The path of the log-config file we used to configure logging",
    )

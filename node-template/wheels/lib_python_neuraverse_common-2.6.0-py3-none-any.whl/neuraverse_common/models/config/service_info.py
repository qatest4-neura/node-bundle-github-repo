import os
from typing import Optional


class ServiceInfo:
    """
    Data class representing basic metadata about a service.

    Attributes:
        service_name (str): The name of the service.
        service_version (str): The version string of the service (e.g., "1.0.0").
        api_version (str): The version number of the API exposed by the service.
    """

    def __init__(
        self,
        service_name: Optional[str] = None,
        service_version: Optional[str] = None,
        api_version: Optional[str] = None,
    ):
        self._service_name = service_name or os.getenv("SERVICE_NAME", "NAME_NOT_SET")
        self._service_version = service_version or os.getenv(
            "SERVICE_TAG", "SERVICE_VERSION_NOT_SET"
        )
        self._api_version = api_version or os.getenv("API_VERSION", "1")

    def get_service_name(self) -> str:
        return self._service_name

    def get_service_version(self) -> str:
        return self._service_version

    def get_api_version(self) -> str:
        return self._api_version

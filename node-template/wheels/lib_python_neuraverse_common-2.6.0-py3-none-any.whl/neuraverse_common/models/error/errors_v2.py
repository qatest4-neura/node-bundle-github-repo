"""
In this module we declare a few common error types we can use Service-wise for more sophisticated error handling.

The advantage of using these errors service-wide and in all layers (controllers, adapters, repositories - everywhere) is that
API adapters (towards gRPC, HTTP, etc) we can provide unified conversions of these errors into error details passed back to the user.

These errors are capable of to carry:
 * `error_codes` string set - to make errors more machine readable
 * `is_retryable` flag to make it easier for the caller to decide how to deal with them
 * `message` - for developers and logs
 * Audience specific error messages (not just one message)
 * Supporting `labels` - key-value pairs to decorate the error with. This can also make possible to turn `message`s into templates by
   simply adding placeholders like "{variable}" to the text
 * Builder style `with_xxx()` methods for the above for more convenient error constructing (if you want)
"""

from typing import Iterable
from neuraverse_common.observability.logging import Logger, LoggerFactory
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.utilities import strings


def _keep_labels_needed_for_messages_only(
    labels: dict[str, any], messages: dict[str, str]
) -> dict[str, any]:
    """
    Helper method. Takes set of labels and set of messages - and returns only those labels who we
    need to resolve the message strings. Other labels are removed.
    """
    result: dict[str, any] = dict()
    if messages is None or len(messages) == 0 or labels is None or len(labels) == 0:
        return result
    vars: set[str] = set()
    for key, msg in messages.items():
        vars.update(strings.extract_vars(msg))
    for name, value in labels.items():
        if name in vars:
            result[name] = value
    return result


MSGAUDIENCE_USER = "user"
"""
This is a special audience (for error messages) - if an exception carry this then when it is converted into a "public" version of the error then
this message is kept as "main" message of the error.

This just makes sense to add this alternate message if the error is not a `NeuraPublicXXX` type - otherwise makes no sense as the message itself
is treated as public message.
"""


class NeuraRuntimeError(RuntimeError):
    """
    This error (exception) can carry important named information: human and machine readable stuff both.

    This class supports builder fashion methods. So you don't need to focus on the constructor only, you can go with a more fluent dsl, e.g:
    `raise NeuraRuntimeError("default message with variable {l1}").with_errorcode("errCode").with_labels({"l1":"v1", "l2":v2"}).with_audience_message("user", "message for public user")`

    **Please note:** you can attach immediately a "public" version of the human readable error message with audience "user" (MSGAUDIENCE_USER constant).
    If you do so, when this exception is reaching public layer and is about to leave the boundary of the service, this message will be used
    as "public" facing message of this exception. You can even attach more audience messages - they will be all kept as well.

    Attributes:
        message (str): To be displayed for humans (developers). Can contain {variable} references which can be resolved from `labels`.
        messages_by_audience (dict[str,str]): Set of more specialized error messages for specific audiences - keyed with the audience name/role. E.g. "operator" => "a message for operators". Note: the `message` attribute is typically for developers internally.
        error_codes (set[str]): Very handy - for machine readable situations. Then caller who receives the error can start building some if statements.
        is_retryable (bool): Informs the caller if the error might go away in terms of retried (in the exact same form). Defult False.
        labels (dict[str, any]): You can decorate the error with key-value pairs. `message` can also contain variable references (see above) which could be resolved later from this.
        messages_by_audience (dict[str, str]): Sometimes we want to talk to different audiences differently so we can provide altername messages basically.
                                               **See class note** about "user" facing public message!
    """

    def __init__(
        self,
        # note: message can contain {var} variables, which can be resolved from `labels`
        message: str,
        is_retryable: bool = False,
        error_codes: str | Iterable[str] = set(),
        # key-value pairs - message can be resolved with these
        labels: dict[str, any] = dict(),
        messages_by_audience: dict[str, str] = dict(),
        retry_hint_min_wait_ms: int = 0,
    ):
        super().__init__(message)

        self.message = message
        """To be displayed for humans (developers). Can contain {variable} references which can be resolved from `labels`."""
        self.error_codes = error_codes
        """
        Set of machine readable error codes - related to the problem. See the convenience has_error_code() method!
        (yes, they are strings and not numerical! for maximum usability and human readability in logs)
        """
        # let's make sure the error codes are converted to set[str]! We can not throw another violation exception from an exception creation right? :-P
        if isinstance(self.error_codes, str):
            # lets convert single error code into one-element set
            self.error_codes = {self.error_codes}
        elif isinstance(self.error_codes, Iterable):
            # lets convert to set
            self.error_codes = set(self.error_codes)
        else:
            # TODO what if someone has sent in let's say {5, 6} ? so not strings but integers ...
            # for now we just simply leave it as one string - strange but at least we do not lose that much info entirely...
            self.error_codes = f"{error_codes}"

        self.is_retryable = is_retryable
        """Informs the caller if the error might go away in terms of retried (in the exact same form). Defult False."""
        self.retry_hint_min_wait_ms = retry_hint_min_wait_ms
        """Handy if error is_retryable=True - in this case you can give a hint to the caller (non-binding) how much time to wait at least before retry"""
        # lets take a copy
        self.labels = dict(labels)
        """You can decorate the error with key-value pairs. `messageTemplate`s can also contain variable references (see above) which could be resolved later from this."""
        # lets take a clone
        self.messages_by_audience = dict(messages_by_audience)
        """Sometimes we want to talk to different audiences differently so we can provide altername messages basically."""

    def with_errorcode(self, errcode: str):
        self.error_codes.add(errcode)
        return self

    def with_errorcodes(self, errcodes: Iterable[str]):
        if errcodes is None or not isinstance(errcodes, Iterable):
            return self
        for errcode in errcodes:
            self.error_codes.add(errcode)
        return self

    def with_label(self, key: str, value: any):
        self.labels[key] = value
        return self

    def with_labels(self, labels: dict[str, any]):
        """This is merging in these `labels` into the labels dict and NOT overwriting!"""
        self.labels.update(labels)
        return self

    def with_user_message(self, message: str):
        """
        You can set a "public" message into this exception with this right away.
        """
        self.messages_by_audience[MSGAUDIENCE_USER] = message
        return self

    def with_public_message(self, message: str):
        self.with_user_message(message)
        return self

    def with_audience_message(self, audience_role_name: str, message: str):
        self.messages_by_audience[audience_role_name] = message
        return self

    def with_audience_messages(self, audienceMessages: dict[str, str]):
        self.messages_by_audience.update(audienceMessages)
        return self

    def with_is_retryable(self, is_retryable: bool):
        self.is_retryable = is_retryable
        return self

    def with_retry_hint_min_wait_ms(self, retry_hint_min_wait_ms: int):
        self.retry_hint_min_wait_ms = retry_hint_min_wait_ms
        return self

    def has_error_code(self, error_code: str) -> bool:
        """Tells you if the given error code is associated with this error or not"""
        return error_code in self.error_codes

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return False

    def __repr__(self):
        return f"{self}"

    def __str__(self):
        return f"{self.__class__.__name__}['{self.message}', is_retryable: {self.is_retryable}, labels: {self.labels}, err_codes: {self.error_codes}, msg_alternates: {self.messages_by_audience}]"


class NeuraIllegalStateError(NeuraRuntimeError):
    """
    Informs the caller that the reason of this error is that we got into some "illegal state".

    This class also defines a few pretty common ERRCODE_xxx constants for this situation - use them for more standardization but of course you can also define
    your own codes, as you wish.
    """

    ERRCODE_CONFIG_ERROR = "config_error"
    """The config of the service is somehow wrong and this is causing a bad state"""
    ERRCODE_DEPENDENCY_MISSING = "missing_dependency"
    """A dependency is permanently missing"""
    ERRCODE_DEPENDENCY_UNAVAILABLE = "unavailable_dependency"
    """Can be a temporary problem when e.g. we rely on an external system but somehow we can not reach it right now"""
    ERRCODE_EXCPECTATION_FAILED = "expectation_failed"
    """What we expected did not happen / we got something else"""
    ERRCODE_TIMED_OUT = "timed_out"
    """Something timed out - job is not done, state is not good"""
    ERRCODE_EXHAUSTED = "exhausted"
    """Something has reached its limits - no more is possible"""


class _NonRetryableNeuraRuntimeError(NeuraRuntimeError):
    """
    A technical class to make sure this error reports `is_retryable=False`
    """

    def __init__(
        self,
        # note: message can contain {var} variables, which can be resolved from `labels`
        message: str,
        error_codes: str | set[str] | list[str] = set(),
        # key-value pairs - message can be resolved with these
        labels: dict[str, any] = dict(),
        messages_by_audience: dict[str, str] = dict(),
    ):
        super().__init__(
            message=message,
            error_codes=error_codes,
            labels=labels,
            messages_by_audience=messages_by_audience,
            is_retryable=False,
        )

    def with_is_retryable(self, is_retryable: bool):
        """
        We overwrite this to ensure it can not be set to true (this is obviously a warning situation)
        """
        self.is_retryable = False
        return self

    def with_retry_hint_min_wait_ms(self, retry_hint_min_wait_ms: int):
        """
        We overwrite this to ensure it can not be set (this is obviously a warning situation)
        """
        self.retry_hint_min_wait_ms = 0
        return self


class NeuraNotImplementedError(_NonRetryableNeuraRuntimeError):
    """
    Marks a certain functionality "not implemented (yet?)"

    But be very careful with this! As actually this error bubbles up, basically it can / should convert into some sort of "Bad request" or something
    problem
    """

    pass


class NeuraValidationError(_NonRetryableNeuraRuntimeError):
    """
    Layers can throw this error to describe they ran into a problem with the request they received - something is invalid.

    E.g. format/type of something is not good. It is basically an equivalent to "Bad request". And inheritedly not retryable.

    This class also defines a few pretty common ERRCODE_xxx constants for this situation - use them for more standardization but of course you can also define
    your own codes, as you wish.
    """

    ERRCODE_WRONG_DATATYPE = "wrong_datatype"
    """Use this error code if you expected something else as a type"""
    ERRCODE_WRONG_FORMAT = "wrong_format"
    """Use this error code if you expected a sepcific format for something but you received something else instead"""
    ERRCODE_MISSING_MANDATORY = "mandatoy_info_missing"
    """Use this error code if you expected a mandatory parameter but was not provided"""
    ERRCODE_SHOULD_NOT_BE_PROVIDED = "should_not_be_provided"
    """Use this error code if somewhere you expected to get nothing (e.g. a field should be None) but you got something"""
    ERRCODE_INVALID_VALUE = "invalid_value"
    """Use this error code if however data was provided it is not valid - content wise"""
    ERRCODE_READONLY_VALUE_CHANGED = "readonly_value_changed"
    """Use this error code if provided data is trying to change a value which actually is read-only"""
    ERRCODE_INVALID_STATE_TRANSITION = "invalid_state_transition"
    """Use this error code if the provided data is trying to cause a state transition which is not valid / allowed"""


class NeuraConstraintViolationError(_NonRetryableNeuraRuntimeError):
    """
    Layers can throw this error to describe they ran into a some precondition problems.
    E.g. someone tries to create a business object however the ID is already taken... So we have a "conflict".

    This error is equivalent of "conflict" or "precondition not met" type errors and thus inheritedly not retryable.

    This class also defines a few pretty common ERRCODE_xxx constants for this situation - use them for more standardization but of course you can also define
    your own codes, as you wish.
    """

    ERRCODE_ID_ALREADY_TAKEN = "id_already_taken"
    """Use this error code if you have a resource conflicting PrimaryKey or ID"""
    ERRCODE_ALREADY_EXIST = "already_exists"
    """A bit more generic representation of the fact: something already exists"""
    ERRCODE_DOES_NOT_EXIST = "not_exists"
    """The object / resource / whatever we were expected being there is actually not there"""
    ERRCODE_PRECONDITION_FAILED = "precondition_failed"
    """A generic description of the fact that the preconditions you were expected is not met"""
    ERRCODE_VERSION_CONFLICT = "resource_version_conflict"
    """Use this error code if you have a resource conflicting assumed vs real versions"""


class NeuraResourceNotFoundError(_NonRetryableNeuraRuntimeError):
    """
    Layers can throw this error to describe they could not find a record/resource/something which was requested / needed to complete the transaction.

    This is basically quivalent of a "Not found" situation and inheritedly not retryable.
    """


class NeuraAuthenticationError(_NonRetryableNeuraRuntimeError):
    """
    Layers can throw this error to describe they could not authenticate the transaction.

    E.g. someone tries to query a protected business object requires Auth.

    Inheritedly this error is not retryable.

    This class also defines a few pretty common ERRCODE_xxx constants for this situation - use them for more standardization but of course you can also define
    your own codes, as you wish.
    """

    ERROR_MISSING = "auth_missing"
    """Use this if you expected to have an authentication at certain point but it is not there"""
    ERROR_NOT_SUPPORTED = "auth_method_not_supported"
    """Use this if however auth info was there but it is using a method which you do not support"""
    ERROR_FAILED = "auth_failed"
    """Use this if however auth info was there auth process was not successful"""


class NeuraAuthorizationError(_NonRetryableNeuraRuntimeError):
    """
    Layers should throw this error to describe whoever is executing the business transaction (Authentication was there already!) is somehow not authorized for this.

    E.g. someone tries to query a business object / do some operations but he has no permission for this.

    **PLEASE NOTE!** This error is NOT for situations Auth is missing entirely! We do have `AuthenticationErrorV2` for that purpose! This is just for permission problems! It's different.

    Inheritedly this error is not retryable.
    """


class _NeuraPublicError:
    """
    Technical class to mark all public errors
    """

    def with_user_message(self, message: str):
        """
        We override this method - it will change the message itself
        """
        self.message = message
        return self

    def with_public_message(self, message: str):
        """
        We override this method - it will change the message itself
        """
        self.with_user_message(message)
        return self


class NeuraPublicRuntimeError(NeuraRuntimeError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraRuntimeError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!

    Please note: this class has a static factory method `from_error_or_exception()` which helps you to convert any
    error/exception into a public, safe one.
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True

    @staticmethod
    def from_error_or_exception(exc: Exception, logger_to_use: Logger, ecntx: ExecutionContext):
        """
        Static factory method to convert any error/exception into a `NeuraPublicRuntimeError` (or subclass) proper way.

        In case the provided exception is NOT a `NeuraPublicXXXError` then the error/exception is treated as unsafe to return details as is to caller.
        Message of the exception can easily contain implementation details (e.g. we use S3 buckets which failed - the exception message can reveal
        this fact we use S3 buckets - not good)

        The method will for sure log the original exception as it was. But afterwards it is getting converted into a `NeuraPublicRuntimeError`.
        (Yes, always NeuraPublicRuntimeError as this should be treated as "internal error occured" on public barriers!)

        If the orig error is a `NeuraRuntimeError` (or subclass) then we can keep some data from the original error for sure - but with care!
        The message of the exception is considered unsafe. But if it carries message for audience `MSGAUDIENCE_USER` then that one turns into
        the main message of the converted exception. All labels removed but the ones used in any `messages_by_audience`. Retry behavior
        is inherited. And error codes are also removed. They can potentially again leak out internal implementation details.

        All other type of errors/exceptions are only logged and basically a very minimal `NeuraPublicRuntimeError` is returned.

        Arguments:
            exc (Exception): The error/exception you want to turn into NeuraPublicRuntimeError.
            logger_to_use (Logger): This logger is used to log the original exception so we have it, because the converted error message will not give ANY specific details back. In case no logger provided
                                  then a default Logger will be used for this.
            ecntx (ExecutionContext): Labels from this context are used in the log - it is strongly recommend to provide that - you should have it in your code making this call...
        """

        if exc is None or not isinstance(exc, Exception):
            # ooops...
            exc = ValueError(
                f"CODE BUG! NeuraPublicRuntimeError.from_error_or_exception() was invoked with 'exc' param which is None or not an exception... It was: {exc}"
            )


        if isinstance(exc, _NeuraPublicError):
            # not much to do - already good
            return exc

        # we will convert it into something for sure
        serviceExc: NeuraPublicRuntimeError = None
        if ecntx:
            default_message = f"Error occured during processing, more details are in the logs with transactionId '{ecntx.transaction_id}'"
        else:
            default_message = "Error occured during processing, more details are in the logs (unfortunately transactionId is unknown...)"

        if isinstance(exc, NeuraRuntimeError):
            # does it have a user facing message? grab it
            user_msg = exc.messages_by_audience.get(MSGAUDIENCE_USER, default_message)
            serviceExc = NeuraPublicRuntimeError(message=user_msg)
            # time to inherit things
            serviceExc.is_retryable = exc.is_retryable
            serviceExc.retry_hint_min_wait_ms = exc.retry_hint_min_wait_ms
            # and some things we clean up...
            # labels - only we keep those who needed for messages
            serviceExc.labels = _keep_labels_needed_for_messages_only(
                exc.labels, exc.messages_by_audience
            )
            # and lets remove the "user" audience message
            audience_msgs = dict(exc.messages_by_audience)
            audience_msgs.pop(MSGAUDIENCE_USER, None)
            serviceExc.messages_by_audience = audience_msgs

        # make a log of the original exception so we keep all details
        log_labels = ecntx.get_labels_for_log() if ecntx else {}
        if logger_to_use is None or not isinstance(logger_to_use, Logger):
            logger_to_use = LoggerFactory.get_logger("lib.error.NeuraPublicRuntimeError")
        logger_to_use.warning(
            "Unsafe exception captured to turn into NeuraPublicRuntimeError error. We must hide details - unsafe to inherit. So we just log details and provide safe message. Orig exception was: %s",
            exc,
            **log_labels,
        )
        # let's create a default simple instance - if we do not have yet
        if serviceExc is None:
            serviceExc = NeuraPublicRuntimeError(is_retryable=False, message=default_message)
        return serviceExc


class NeuraPublicIllegalStateError(NeuraIllegalStateError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraNotImplementedError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicNotImplementedError(NeuraNotImplementedError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraNotImplementedError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicValidationError(NeuraValidationError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraValidationError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicConstraintViolationError(NeuraConstraintViolationError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraConstraintViolationError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicResourceNotFoundError(NeuraResourceNotFoundError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraResourceNotFoundError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicAuthenticationError(NeuraAuthenticationError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraAuthenticationError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True


class NeuraPublicAuthorizationError(NeuraAuthorizationError, _NeuraPublicError):
    """
    This error is the "public" pair of `NeuraAuthorizationError` so the exception message is suitable to be
    displayed publicly, as well as all content. Meaning: it DOES NOT LEAK out any internal implementation details for sure!
    """

    def is_public(self) -> bool:
        """Tells if the error is public or not. Public errors are OK to leave the service boundary."""
        return True

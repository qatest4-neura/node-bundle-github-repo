"""
Represents authentication information passed through the execution context.
"""


class AuthInfo:

    def __init__(self, auth_header_content: str, user_id: str = None, service_id: str = None, org_id: str = None):
        # Authorization header content is the full content of the authorization header
        self.auth_header_content = auth_header_content

        # User ID is the Neura UUID of the user (never IDP related!)
        self.user_id = user_id
        # Org ID is the Neura UUID of organisation the user has logged in with
        self.org_id = org_id
        # We can also have M2M tokens - in which case this identifies another service
        self.service_id = service_id

    # --- Getters and Setters ---

    def get_displayed_id(self) -> str:
        """
        Useful for logs - it returns either the UserID or the ServiceID stored in this AuthInfo object, making it clearly visible
        what do we have.
        """
        if self.user_id is not None:
            return f"user:{self.user_id}"
        if self.service_id is not None:
            return f"service:{self.service_id}"
        return "none"

    def get_user_id(self) -> str:
        """
        Returns the user ID (Neura UUID) of the authenticated user.
        """
        return self.user_id

    def set_user_id(self, user_id: str):
        """
        Sets the user ID (Neura UUID) of the authenticated user.
        """
        self.user_id = user_id

    def get_org_id(self) -> str:
        """
        Returns the organization ID (Neura UUID) of the authenticated user.
        """
        return self.org_id

    def set_org_id(self, org_id: str):
        """
        Sets the organization ID (Neura UUID) of the authenticated user.
        """
        self.org_id = org_id

    def get_service_id(self) -> str:
        """
        Returns the M2M ID of the authenticated service.
        """
        return self.service_id

    def set_service_id(self, service_id: str):
        """
        Sets the M2M ID of the authenticated service.
        """
        self.service_id = service_id

    def get_auth_header_content(self) -> str:
        """
        Returns the content of the authorization header.
        """
        return self.auth_header_content

    def set_auth_header_content(self, auth_header_content: str):
        """
        Sets the content of the authorization header.
        """
        self.auth_header_content = auth_header_content

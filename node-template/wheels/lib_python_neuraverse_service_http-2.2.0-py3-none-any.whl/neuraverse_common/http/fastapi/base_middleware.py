
from fastapi import FastAPI, Request
from starlette.routing import Match
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.models.error import errors_v2
from neuraverse_common.http.model.error.neura_http_error import NeuraHttpError

class BaseNeuraFastAPIMiddleware:
    """
    Useful class to be used as FastAPI middleware - you can add it with `app.add_middleware()` method.

    This middleware takes care of a few things to improve keep our error contract for example.
    """

    def __init__(self, app: FastAPI):
        self.app = app
        self.register()

    def register(self):
        @self.app.middleware("http")
        async def route_check_middleware(request, call_next):
            return await self.handle_nonexistent_path(request, call_next)
        
    async def handle_nonexistent_path(self, request: Request, call_next):
        """
        Middleware to handle requests to non-existent paths.
        If the requested path does not match any defined route, it returns a 400 Bad Request response.

        Args:
            app: The FastAPI application instance.
            request (Request): The incoming request object.
            call_next: The next middleware or route handler to call.
        """
        for route in self.app.router.routes:
            match, _ = route.matches(request.scope)
            if match == Match.FULL:
                return await call_next(request)

        # TODO how will we have ExecutionContext here??? We should find a way in a next version... now no time for this... :-(
        ecntx: ExecutionContext = None

        exc = errors_v2.NeuraPublicNotImplementedError(message="Endpoint on URI '{uri}' does not exist").with_label('uri', request.url.path).with_errorcode("request_uri_does_not_exist")
        neura_err = NeuraHttpError.from_error_or_exception(exc=exc, logger_to_use=None, ecntx=ecntx)
        # OK in this case let's override the error code - as this "not implemented" is actually a 400
        neura_err.status = 400
        return neura_err.to_JSON_response(ecntx=ecntx)        

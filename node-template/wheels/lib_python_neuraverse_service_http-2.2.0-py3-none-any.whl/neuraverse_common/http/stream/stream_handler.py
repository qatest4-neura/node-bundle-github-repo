import json
from typing import Dict, Generator, Tuple

from botocore.response import StreamingBody
from fastapi import Request
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.http.context.ecntx_handler import HttpEcntxHandler
from neuraverse_common.http.context.http_headers import HttpHeaders


class HttpStreamHandler:
    """
    A utility class for HTTP-related streaming operations.

    This class provides methods to process HTTP streaming requests and contexts, enabling
    seamless integration with the internal execution context standard.
    """

    @staticmethod
    def create_streaming_response(
        context: ExecutionContext,
        storage_object: Tuple[StreamingBody, Dict[str, str]],
        include_cache_control: bool = True,
    ) -> Tuple[Generator[bytes, None, None], Dict[str, str]]:
        """
        Creates a streaming HTTP response from the given context and data.

        Args:
            context (ExecutionContext): The execution context containing metadata.
            storage_object (Tuple[StreamingBody, dict]): A tuple containing the streaming body and its metadata from S3.
            include_cache_control (bool): Whether to include Cache-Control headers in the response.

        Returns:
            Tuple[Generator[bytes, None, None], Dict[str, str]]: A tuple containing the streaming content generator and its headers.
        """
        s3_stream_body, s3_metadata = storage_object

        content = HttpStreamHandler._get_streaming_body(s3_stream_body)

        ecntx_headers = HttpEcntxHandler.get_response_headers(context=context)
        s3_headers = HttpStreamHandler._get_s3_stream_headers(
            s3_stream_metadata=s3_metadata, include_cache_control=include_cache_control
        )
        headers = {**ecntx_headers, **s3_headers}
        return content, headers

    @staticmethod
    def _get_s3_stream_headers(
        s3_stream_metadata: Dict[str, str], include_cache_control: bool = True
    ) -> Dict[str, str]:
        """
        Returns the HTTP headers derived from S3 streaming metadata.

        Args:
            s3_stream_metadata (dict): The S3 streaming metadata.
            include_cache_control (bool): If True, adds default Cache-Control header with
                value "no-cache".

        Returns:
            dict: A dictionary of HTTP headers.
        """
        headers: Dict[str, str] = {}
        s3_http_headers = (s3_stream_metadata or {}).get("HTTPHeaders", {}) or {}

        headers[HttpHeaders.CONTENT_TYPE] = s3_http_headers.get(
            HttpHeaders.CONTENT_TYPE.lower(), "application/octet-stream"
        )
        headers[HttpHeaders.ETAG] = s3_http_headers.get(HttpHeaders.ETAG.lower(), "").strip('"')
        headers[HttpHeaders.LAST_MODIFIED] = s3_http_headers.get(
            HttpHeaders.LAST_MODIFIED.lower(), ""
        )
        if include_cache_control:
            headers[HttpHeaders.CACHE_CONTROL] = "no-cache"

        return headers

    @staticmethod
    def _get_streaming_body(s3_stream_body: StreamingBody) -> Generator[bytes, None, None]:
        """
        Generator yielding the S3 object in 5 MB chunks; always closes underlying stream.

        Args:
            s3_stream_body (StreamingBody): The S3 streaming body.

        Returns:
            Generator[bytes, None, None]: Generator yielding bytes chunks.
        """
        try:
            chunk_size = 5 * 1024 * 1024
            for chunk in s3_stream_body.iter_chunks(chunk_size=chunk_size):
                if not chunk:
                    continue
                yield chunk
        finally:
            try:
                s3_stream_body.close()
            except Exception:
                pass

    @staticmethod
    async def extract_content_and_metadata(
        request: Request,
    ) -> Tuple[bytes, Dict[str, str]]:
        """
        Extract content, and metadata from HTTP request based on its media type.

        Args:
            request: FastAPI Request object

        Returns:
            Tuple of (content_bytes, metadata_dict)
        """
        content_type = request.headers.get(HttpHeaders.CONTENT_TYPE, "application/octet-stream")
        # Future: Add here any additional metadata fields, e.g., content length etc.
        metadata = {
            HttpHeaders.CONTENT_TYPE: content_type,
        }

        # Extract content based on content type
        if content_type.startswith("application/json"):
            data = await request.json()
            content = json.dumps(data).encode("utf-8")
        else:
            content = await request.body()

        return content, metadata

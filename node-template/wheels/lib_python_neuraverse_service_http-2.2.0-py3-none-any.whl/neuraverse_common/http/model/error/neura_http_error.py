from fastapi import status as http_status

from neuraverse.models.v1.gen.error.errors_pb2 import Error
from neuraverse_common.observability.logging import Logger
from neuraverse_common.context.execution_context import ExecutionContext
from neuraverse_common.http.context.ecntx_handler import HttpEcntxHandler
from neuraverse_common.utilities.neuraverse_entities.error_builder import ErrorBuilder
from neuraverse_common.utilities import proto_utils
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from neuraverse_common.models.error import errors_v2


class NeuraHttpError(Exception):
    """
    This exception contains a HTTP statusCode and also carrying
    our standard `Error` - defined in https://gitlab.hrg.systems/neuraverse/neuraverse-entities/-/blob/main/protos/neuraverse/models/v1/gen/error/errors.proto?ref_type=heads
    - this is what we use to generate the response body

    **Please note:** this class has static factory method too `from_error_or_exception()` you can use to convert any error/exception
    easily into a NeuraHttpError safe way (meaning: we do not leak out unsafe internal info into a HTTP response). See method for more details!
    """
    status: int
    error: Error

    def __init__(self, status: int, error: Error):
        self.status = status
        self.error = error

    def to_JSON_response(self, ecntx: ExecutionContext) -> JSONResponse:
        """
        Takes this NeuraHttpError and converts it into a JSON response
        """
        headers = HttpEcntxHandler.get_response_headers(context=ecntx)

        if self.status == http_status.HTTP_304_NOT_MODIFIED:
            return Response(
                status_code=http_status.HTTP_304_NOT_MODIFIED,
                headers=headers,
            )
        
        return JSONResponse(
            status_code = self.status,
            content = proto_utils.proto_to_dict(proto_obj=self.error, keep_all_fields=True),
            headers=headers,
        )

    def to_plain_text_response(self, ecntx: ExecutionContext) -> PlainTextResponse:
        """
        Takes this NeuraHttpError and converts it into a JSON response
        """
        headers = HttpEcntxHandler.get_response_headers(context=ecntx)
        return PlainTextResponse(
            status_code = self.status,
            # mmm not sure this is the best way but will do for now...
            content = f"{proto_utils.proto_to_dict(proto_obj=self.error, keep_all_fields=True)}",
            headers=headers,
        )


    def __str__(self) -> str:
        return f"NeuraHttpError[status: {self.status}, error: {self.error}]"


    @staticmethod
    def from_error_or_exception(exc: Exception, logger_to_use: Logger, ecntx: ExecutionContext):
        """
        Static factory method to convert a - hopefully at least - `neuraverse_common.models.error.errors_v2.NeuraPublicRuntimeError` (or all subclasses)
        exception into a `NeuraHttpError`.

        In case the provided exception is not `NeuraPublicRuntimeError` (or subclass) it is treated as unsafe exception to return details to caller. In this case
        it is converted first into a `NeuraPublicRuntimeError` using its static factory method `.from_error_or_exception()` into one.
        See description of that method to know more!

        Arguments:
            exc (Exception): The error/exception you want to turn into NeuraGrpcError.
            logger_to_use (Logger): If a not safe exception/error is converted (means: not `neuraverse_common.models.error.errors_v2.NeuraPublicRuntimeError` or subclasses) then this logger
                                  is used to log the original exception so we have it, because the converted error message will not give ANY specific details back. In case no logger provided
                                  then a default Logger will be used for this.
            ecntx (ExecutionContext): if provided then labels from this context are used in the log exception conversions (recommended!)
        """

        # This method call ensures every non-safe exception is properly converted (logged too if happens) into a NeuraPublicRuntimeError
        # Exceptions already NeuraPublicRuntimeError class are not changed
        serviceExc: errors_v2.NeuraPublicRuntimeError = errors_v2.NeuraPublicRuntimeError.from_error_or_exception(exc=exc, logger_to_use=logger_to_use, ecntx=ecntx)

        error_builder = ErrorBuilder(
            message_template = serviceExc.message,
            is_retryable = serviceExc.is_retryable
        )
        error_builder = (
            error_builder.with_retryhint_minwaitmillis(serviceExc.retry_hint_min_wait_ms)
                        .with_codes(serviceExc.error_codes)
                        .with_labels(serviceExc.labels)
                        .with_audience_messagetemplates(serviceExc.messages_by_audience)
        )

        # the default status code is internal error
        status = http_status.HTTP_500_INTERNAL_SERVER_ERROR
        
        # Now lets be error type specific from this point
        # CAREFUL!!! Checking order matters as exception classes extend each other!
        # we need to do checks bottom-up!
        if isinstance(serviceExc, errors_v2.NeuraPublicAuthenticationError):
            status = http_status.HTTP_401_UNAUTHORIZED
        elif isinstance(serviceExc, errors_v2.NeuraPublicAuthorizationError):
            status = http_status.HTTP_403_FORBIDDEN
        elif isinstance(serviceExc, errors_v2.NeuraPublicResourceNotFoundError):
            status = http_status.HTTP_404_NOT_FOUND
        elif isinstance(serviceExc, errors_v2.NeuraPublicConstraintViolationError):
            status = http_status.HTTP_412_PRECONDITION_FAILED
            if serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_ID_ALREADY_TAKEN) or serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_ALREADY_EXIST):
                status = http_status.HTTP_409_CONFLICT
            elif serviceExc.has_error_code(errors_v2.NeuraPublicConstraintViolationError.ERRCODE_DOES_NOT_EXIST):
                status = http_status.HTTP_404_NOT_FOUND
        elif isinstance(serviceExc, errors_v2.NeuraPublicValidationError):
            status = http_status.HTTP_400_BAD_REQUEST
        elif isinstance(serviceExc, errors_v2.NeuraPublicNotImplementedError):
            status = http_status.HTTP_501_NOT_IMPLEMENTED
        elif isinstance(serviceExc, errors_v2.NeuraPublicIllegalStateError):
            status = http_status.HTTP_500_INTERNAL_SERVER_ERROR
            if serviceExc.has_error_code(errors_v2.NeuraPublicIllegalStateError.ERRCODE_DEPENDENCY_UNAVAILABLE):
                status = http_status.HTTP_503_SERVICE_UNAVAILABLE
            elif serviceExc.has_error_code(errors_v2.NeuraPublicIllegalStateError.ERRCODE_EXHAUSTED):
                status = http_status.HTTP_503_SERVICE_UNAVAILABLE
            elif serviceExc.has_error_code(errors_v2.NeuraPublicIllegalStateError.ERRCODE_TIMED_OUT):
                status = http_status.HTTP_503_SERVICE_UNAVAILABLE

        neura_exc = NeuraHttpError(
            status = status,
            error = error_builder.build()
        )

        return neura_exc

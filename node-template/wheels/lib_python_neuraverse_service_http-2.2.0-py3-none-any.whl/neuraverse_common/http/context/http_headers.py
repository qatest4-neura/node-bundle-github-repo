class HttpHeaders:
    """
    Constants for HTTP request and response headers used for tracing, auditing, and diagnostics.

    Request Headers:
        X_TRANSACTION_ID:
            The transactionId used internally to serve this request.
        X_TRACE_ID:
            The traceId used internally to serve this request.
        X_REQUEST_TIMESTAMP:
            The timestamp when this request was created on the caller side - UNIX (Epoch) timestamp with millis precision.
            This information might help us to detect strange latencies between the two parties on the callee side.
        X_CALLER_NAME_AND_VERSION:
            Who is the caller? This should be the name and version of the service sent the request. For logging purposes only.
        X_CALLER_CONTEXT:
            Anything like a submodule or process/flow name which fired this request - within the caller.
        AUTHORIZATION:
            Standard HTTP Authorization header.
        IF_NONE_MATCH:
            Standard HTTP If-None-Match header.
        CONTENT_TYPE:
            The content type of the response body, retrieved from S3 metadata.

    Response Headers:
        X_REQUEST_RECEIVED_AT_TIMESTAMP:
            The timestamp when we have received this request from the caller - UNIX (Epoch) timestamp with millis precision.
        X_ORIG_REQUEST_TIMESTAMP:
            Information from Request 'x-request-timestamp' header - to loop it back to the caller. This information might help us to detect strange latencies between the two parties on the caller side.
        X_TOOK_MILLIS:
            The number of milliseconds it took to process the request.
        X_WARNINGS:
            During the req-resp loop, even if the request did not fail, we might have collected some warnings - we want to send back to the caller to inform them. This is for debugging purposes only on the caller side.
        X_SERVICE_NAME_AND_VERSION:
            The name and version of the service (official name) that served the request - very useful to spot potential problems on the caller side because a new version of the (called) service was deployed.
        X_API_VERSION:
            We version APIs separately from the version of the service itself. This field can carry that information if we know it. Just like "serviceVersion", useful to spot potential problems on the caller side because a new API version of the (called) service was deployed.
        ETAG:
            The ETag of the response body, if applicable, retrieved from S3 metadata.
        LAST_MODIFIED:
            The last modified timestamp of the response body, if applicable, retrieved from S3 metadata.
    """

    # Request headers
    X_TRANSACTION_ID = "x-transaction-id"
    X_TRACE_ID = "x-trace-id"
    X_REQUEST_TIMESTAMP = "x-request-timestamp"
    X_CALLER_NAME_AND_VERSION = "x-caller-nameandversion"
    X_CALLER_CONTEXT = "x-caller-context"
    AUTHORIZATION = "authorization"
    IF_NONE_MATCH = "If-None-Match"
    CONTENT_TYPE = "Content-Type"

    # Response headers
    X_REQUEST_RECEIVED_AT_TIMESTAMP = "x-request-received-at-timestamp"
    X_ORIG_REQUEST_TIMESTAMP = "x-origin-request-timestamp"
    X_TOOK_MILLIS = "x-took-millis"
    X_WARNINGS = "x-warnings"
    X_SERVICE_NAME_AND_VERSION = "x-service-nameandversion"
    X_API_VERSION = "x-api-version"
    ETAG = "ETag"
    LAST_MODIFIED = "Last-Modified"
    CACHE_CONTROL = "Cache-Control"
